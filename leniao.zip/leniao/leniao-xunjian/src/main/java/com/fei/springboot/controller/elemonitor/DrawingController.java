package com.fei.springboot.controller.elemonitor;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.constant.Const;
import com.fei.springboot.constant.SysConst;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.device.Tblndeviceinfo;
import com.fei.springboot.domain.elemonitor.EleMonDrawing;
import com.fei.springboot.domain.elemonitor.EleMonGateinfo;
import com.fei.springboot.domain.unitavggrade.Tblnprojectinfo;
import com.fei.springboot.pojo.common.ElemonUnitOutput;
import com.fei.springboot.pojo.common.FindUnitParamDto;
import com.fei.springboot.pojo.elemonitor.*;
import com.fei.springboot.service.common.CommonService;
import com.fei.springboot.service.elemonitor.DrawingService;
import com.fei.springboot.service.elemonitor.GateService;
import com.fei.springboot.util.DateUtil;
import com.fei.springboot.util.HbaseUtil;
import com.fei.springboot.util.HttpClientPoolUtil;
import com.fei.springboot.util.URLUtil;
import com.fei.springboot.util.redis.RedisUtil;
import com.fei.springboot.util.thrift.realValueByNode1;
import com.github.pagehelper.PageInfo;
import com.sun.source.doctree.AttributeTree;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.ResettableListIterator;
import org.apache.hadoop.yarn.webapp.hamlet.Hamlet;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.ibatis.scripting.xmltags.ForEachSqlNode;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.mortbay.util.StringMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Decoder;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping(value = "/elemon")
public class DrawingController {

    @Autowired
    private DrawingService drawingService;
    @Autowired
    private GateService gateService;
    @Autowired
    private AmqpTemplate rabbitTemplate;
    @Autowired
    private CommonService commonService;

    /**
     * 新增图纸
     *
     * @param drawing
     * @return
     */
    @PostMapping("/drawing/insert")
    public AjaxResult insertDrawing(@RequestBody @Valid EleMonDrawing drawing) {
        AjaxResult result = new AjaxResult();
        EleMonDrawing oldDrawing = null;
        //查看单位是否存在未删除的同名称图纸
        oldDrawing = this.drawingService.findDrawingByName(drawing.getDrawName(), drawing.getUnitId(), 0);
        if (oldDrawing != null) {
            result.addFail("已存在相同名称的图纸");
            return result;
        }

        try {
            int flag = this.drawingService.insert(drawing);
            if (flag > 0) {
                result.addSuccess("添加图纸成功");
            } else {
                result.addFail("添加图纸失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;
    }


    /**
     * 查看图纸
     *
     * @param drawing
     * @return
     */
    @PostMapping("/drawing/view")
    public AjaxResult viewtDrawing(@RequestBody EleMonDrawing drawing) {
        AjaxResult result = new AjaxResult();

        if (drawing.getDrawId() == null) {
            result.addFail("图纸id不能为空");
            return result;
        }
        //先查询此图纸的信息
        drawing = this.drawingService.findDrawingById(drawing.getDrawId());
        if (drawing == null) {
            result.addFail("图纸信息不存在");
            return result;
        }
        //Integer unitId = drawing.getUnitId();
        Integer drawId = drawing.getDrawId();
        //查询此图纸上的所有空开信息
        List<EleMonGateinfo> gateinfos = this.gateService.findGatebyDrawId(drawId);
        if (CollectionUtils.isEmpty(gateinfos)) {
            result.addFail("此图纸上没有空开设备");
            return result;
        }
        //获取此图纸中的所有设备id
        List<Integer> devIdList = gateinfos.stream().map(EleMonGateinfo::getDevIdpk).filter(x -> x != null).collect(Collectors.toList());
        //获取故障的设备id
        List<Integer> faultDevIdList = this.drawingService.findFaultDeviceIds(devIdList);
        faultDevIdList = faultDevIdList == null ? new ArrayList<>() : faultDevIdList;
        //获取告警的设备id
        List<Integer> warnDevIdList = this.drawingService.findWarnDeviceIds(devIdList);
        warnDevIdList = warnDevIdList == null ? new ArrayList<>() : warnDevIdList;
        //获取所有空开设备中的一级空开
        List<EleMonGateinfo> firstGates = gateinfos.stream().filter(g -> g.getpGateId() == 0).collect(Collectors.toList());
        for (EleMonGateinfo gate : firstGates) {
            this.recursiveGetGates(gateinfos, gate, faultDevIdList, warnDevIdList);
        }
        result.addSuccess("查询成功");
        result.setData(firstGates);
        return result;
    }

    /**
     * @param gateinfos      图纸上所有的空开的集合
     * @param gate           当前空开
     * @param faultDevIdList 图纸上所有有故障的设备的id集合
     * @param warnDevIdList  图纸上所有有隐患的设备的id集合
     * @return
     */
    private EleMonGateinfo recursiveGetGates(List<EleMonGateinfo> gateinfos, EleMonGateinfo gate, List<Integer> faultDevIdList, List<Integer> warnDevIdList) {
        Integer gateId = gate.getGateId();//当前空开的id   第一次递归时是指图纸上的一级空开的id
        //得到当前空开的所有直接下级空开
        List<EleMonGateinfo> childList = gateinfos.stream().filter(g -> g.getpGateId().equals(gateId)).collect(Collectors.toList());
        Integer devIdpk = gate.getDevIdpk();
        gate.setChildList(childList);
        gate.setIsFault(faultDevIdList.contains(devIdpk) ? 1 : 0);
        gate.setIsWarn(warnDevIdList.contains(devIdpk) ? 1 : 0);

        //对当前空开和它的子级空开进行判断
        if (gate.getIsWarn() == 1 || gate.getIsFault() == 1) {
            Map<Integer, List<String>> map = this.diagnoseLine(gate, childList);
            if (map != null) {
                List<String> list = map.get(gate.getGateId());
                if (CollectionUtils.isNotEmpty(list)) {
                    gate.setLineState(1);
                    gate.setInfos(list);
                } else {
                    gate.setLineState(0);
                    gate.setInfos(null);
                }
            } else {
                gate.setLineState(0);
                gate.setInfos(null);
            }
        }
        //递归调用
        for (EleMonGateinfo g : childList) {
            recursiveGetGates(gateinfos, g, faultDevIdList, warnDevIdList);
        }
        return gate;
    }

    private Map<Integer, List<String>> diagnoseLine(EleMonGateinfo gate, List<EleMonGateinfo> childList) {
        Integer devIdpk = gate.getDevIdpk();// 绑定设备
        //所有需要监控的节点值
        //获取到绑定设备
        if (devIdpk != null) {//绑定了设备的话
            String nodeArray = this.getJiankongNodeStr(devIdpk);
            //获取此设备的被监控节点的实时值
            List<realValueByNode1> pDevRealTimeVals = this.gateService.getDeviceRealTimeVal(devIdpk, nodeArray, new Date());
            if (CollectionUtils.isEmpty(pDevRealTimeVals)) {
                List<String> list = new ArrayList<>();
                list.add("请先检查设备是否掉线");
                return new HashMap<Integer, List<String>>() {{
                    put(gate.getGateId(), list);
                }};

            }
            List<Map<Integer, List<realValueByNode1>>> lists = new ArrayList<>();
            //获取子设备 的实时数据
            for (EleMonGateinfo g : childList) {
                Map<Integer, List<realValueByNode1>> smap = new HashMap<>();
                Integer cDevId = g.getDevIdpk();
                if (cDevId != null) {
                    String nodeArr = this.getJiankongNodeStr(devIdpk);
                    List<realValueByNode1> cDevRealTimeVals = this.gateService.getDeviceRealTimeVal(devIdpk, nodeArr, new Date());
                    if (CollectionUtils.isNotEmpty(cDevRealTimeVals)) {
                        //将此空开的绑定的设备的实时值放入map
                        smap.put(g.getGateId(), cDevRealTimeVals);
                        lists.add(smap);//放入总的集合中
                    }
                }
            }

            List<Map<Integer, List<realValueByNode1>>> LMapList = new ArrayList<>();
            List<Map<Integer, List<realValueByNode1>>> IMapList = new ArrayList<>();
            List<Map<Integer, List<realValueByNode1>>> VMapList = new ArrayList<>();
            List<Map<Integer, List<realValueByNode1>>> TMapList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(lists)) {
                for (Map<Integer, List<realValueByNode1>> map : lists) {
                    Set<Integer> keySet = map.keySet();
                    for (Integer gateId : keySet) {
                        List<realValueByNode1> list = map.get(gateId);
                        //某一设备的漏电实时值
                        List<realValueByNode1> L1collect = list.stream().filter(n -> n.getNode().equalsIgnoreCase("L") || n.getNode().equalsIgnoreCase("L1")).collect(Collectors.toList());
                        Map<Integer, List<realValueByNode1>> lMap = new HashMap<>();
                        lMap.put(gateId, L1collect);
                        LMapList.add(lMap);
                        //电流实时值
                        List<realValueByNode1> Icollect = list.stream().filter(n -> n.getNode().equalsIgnoreCase("I") || n.getNode().equalsIgnoreCase("Ia")
                                || n.getNode().equalsIgnoreCase("Ib") || n.getNode().equalsIgnoreCase("Ic")
                        ).collect(Collectors.toList());
                        Map<Integer, List<realValueByNode1>> iMap = new HashMap<>();
                        iMap.put(gateId, Icollect);
                        IMapList.add(iMap);
                        //电压实时值
                        List<realValueByNode1> Vcollect = list.stream().filter(n -> n.getNode().equalsIgnoreCase("V") || n.getNode().equalsIgnoreCase("Va")
                                || n.getNode().equalsIgnoreCase("Vb") || n.getNode().equalsIgnoreCase("Vc")
                        ).collect(Collectors.toList());
                        Map<Integer, List<realValueByNode1>> vMap = new HashMap<>();
                        vMap.put(gateId, Vcollect);
                        VMapList.add(vMap);
                        //温度实时值
                        List<realValueByNode1> Tcollect = list.stream().filter(n -> n.getNode().equalsIgnoreCase("T1") || n.getNode().equalsIgnoreCase("T2")
                                || n.getNode().equalsIgnoreCase("T4") || n.getNode().equalsIgnoreCase("T3")
                        ).collect(Collectors.toList());
                        Map<Integer, List<realValueByNode1>> tMap = new HashMap<>();
                        tMap.put(gateId, Tcollect);
                        TMapList.add(tMap);

                    }
                }
            }
            //对漏电进行判断
            List<String> Llist = this.drawingService.chargeLoudian(gate.getGateId(), pDevRealTimeVals, LMapList);
            //对电流进行判断
            //对电压进行判断
            List<String> list = this.drawingService.chargeDianya(gate.getGateId(), pDevRealTimeVals, VMapList);
            //对温度进行判断

            //Llist不为null;
            if (list != null) {
                Llist.addAll(list);
            }
            Map<Integer, List<String>> map = new HashMap<>();
            map.put(gate.getGateId(), Llist);
            return map;

        }
        return null;
    }

    //获取设备的监控节点的拼接值  以 - 拼接
    private String getJiankongNodeStr(Integer devIdpk) {
        String[] strArr = {"L", "L1", "I", "Ia", "Ib", "Ic", "V", "Va", "Vb", "Vc", "T1", "T2", "T3", "T4"};
        List<String> allNodeList = Arrays.asList(strArr);
        List<String> nodeList = this.gateService.finddeviceNodes(devIdpk);
        if (CollectionUtils.isEmpty(nodeList)) {
            return "";
        }
        //查询设备监控节点的实时值
        List<String> devNodes = nodeList.stream().filter(
                v -> {
                    boolean flag = allNodeList.contains(v);
                    return flag;
                }
        ).collect(Collectors.toList());
        return String.join("-", devNodes);

    }


    /**
     * 更新图纸
     *
     * @param drawing
     * @return
     */
    @PostMapping("/drawing/edit")
    public AjaxResult editDrawing(@RequestBody @Valid EleMonDrawing drawing) {
        AjaxResult result = new AjaxResult();
        if (drawing.getDrawId() == null) {
            result.addFail("图纸id不能为空");
            return result;
        }
        //根据名称和单位查询是否存在重复名称
        EleMonDrawing oldDrawing = this.drawingService.findDrawingByName(drawing.getDrawName(), drawing.getUnitId(), 0);
        if (oldDrawing != null && !oldDrawing.getDrawId().equals(drawing.getDrawId())) {
            result.addFail("已存在相同名称的图纸");
            return result;
        }
        try {
            int flag = this.drawingService.update(drawing);
            if (flag > 0) {
                result.addSuccess("修改成功");
            } else {
                result.addFail("修改失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;


    }


    /**
     * 删除图纸
     *
     * @param drawing 只传id
     * @return
     */
    @PostMapping("/drawing/del")
    public AjaxResult deleteDrawing(@RequestBody EleMonDrawing drawing) {
        AjaxResult result = new AjaxResult();
        if (drawing.getDrawId() == null) {
            result.addFail("图纸id不能为空");
            return result;
        }
        try {
            int flag = this.drawingService.updateDelete(drawing.getDrawId());
            if (flag > 0) {
                result.addSuccess("删除成功");
            } else {
                result.addFail("删除失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;


    }

    /**
     * 查询图纸列表
     *
     * @param param
     * @return
     */
    @PostMapping("/drawing/list")
    public AjaxResult drawingList(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer unitId = param.getInteger("unitId");

        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        List<EleMonDrawing> drawingList = this.drawingService.findDrawingByUnitId(unitId, 0);
        if (CollectionUtils.isNotEmpty(drawingList)) {
            result.addSuccess("查询成功");
            result.setData(drawingList);
        } else {
            result.addFail("没有数据");
            result.setData(new ArrayList<>());
        }
        return result;
    }


    /**
     * 图纸信息统计
     *
     * @param param
     * @return
     */
    @PostMapping("/drawing/count")
    public AjaxResult drawingCount(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer drawId = param.getInteger("drawId");
        if (drawId == null) {
            result.addFail("图纸id不能为空");
            return result;
        }

        JSONObject json = this.drawingService.getEleMonitor(drawId);
        if (json != null) {
            result.addSuccess("查询成功");
            result.setData(json);
        } else
            result.addFail("没有数据");
        return result;
    }


    /**
     * 将picurl转换为base64
     *
     * @param param
     * @return
     */
    @PostMapping("/drawing/parsepicurl")
    public AjaxResult parsePicUrlToBase64(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        String picurl = param.getString("picurl");
        if (StringUtils.isEmpty(picurl)) {
            result.addFail("未获取图纸");
            return result;
        }

        String base64String = URLUtil.getBase64String(picurl);
        if (base64String.equals("图片转换异常")) {
            result.addFail("图纸转换异常");
        } else {
            result.addSuccess("图纸转换成功");
            result.setData(base64String);
        }
        return result;
    }


    /**
     * 根据条件查询单位列表
     *
     * @param param
     * @return
     */
    @PostMapping("/unit/page/find")
    public AjaxResult queryUnitByUnitName(@RequestBody @Valid FindUnitParamDto param, HttpServletRequest request) {
        AjaxResult result = new AjaxResult();
        String access_token = request.getHeader("access_token");
        if (StringUtils.isEmpty(access_token)) {
            result.addFail("暂无权限");
            return result;
        }
        String prefix = "LN.IOT.User:";
        access_token = prefix + access_token;
        //从Redis中获取token信息
        String hget = RedisUtil.getInstance().hash().hget(access_token, "LN.LoginUserList");
        if (StringUtils.isEmpty(hget)) {
            result.addFail("暂无权限");
            return result;
        }
        JSONObject jsonObject = JSON.parseObject(hget);
        int group_type = jsonObject.getIntValue("group_type");
        int platform_id = jsonObject.getIntValue("platform_id");
        PageInfo<ElemonUnitOutput> pageInfo = null;
        if (group_type <= 1) {
            pageInfo = this.gateService.pageingUnitListBy(param);
        } else if (group_type == 2) {
            pageInfo = this.gateService.pageingUnitListBy_areaUser(param, platform_id);
        } else {
            result.addFail("权限类型不匹配");
            return result;
        }


        if (pageInfo.getTotal() > 0) {
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        } else {
            result.addFail("暂无数据");
        }
        return result;
    }


    /**
     * 根据设备编码查询单位--如果统计出现错误,检查  如过没有绑定设备是否传的是空,传0 则不对
     *
     * @param param
     * @return
     */
    @PostMapping("/unit/firest/find")
    public AjaxResult queryUnitByDevSignature(@RequestParam("userId") Integer userId, @RequestBody FindUnitParamDto param) {
        AjaxResult result = new AjaxResult();
        if (userId == 0 || userId == null) {
            result.addFail("没有权限");
            return result;
        }
        if (param.getDevSignature() == null) {
            result.addFail("设备编号不能为空");
            return result;
        }
        ElemonUnitOutput dto = this.gateService.findUnitByDevSignature(param.getDevSignature(), userId);
        if (dto != null) {
            result.addSuccess("查询成功");
            result.setData(dto);
        } else {
            result.addFail("暂无查看权限");
        }
        return result;
    }


    /**
     * 查询当前设备的故障或报警信息---电力监控页面使用
     *
     * @return
     */
    @PostMapping(value = "/drawing/dev/errors")
    public AjaxResult findDeviceFaultOrWarn(@RequestBody @Valid DeviceErrorsParamDto param) {
        AjaxResult result = new AjaxResult();
        PageInfo<ErrorOutputDto> pageInfo = null;
        if (param.getType() == 1) {
            //查询故障
            pageInfo = this.drawingService.findDeviceFaults(param);
        } else if (param.getType() == 2) {
            pageInfo = this.drawingService.findDeviceWarns(param);//查询隐患
        } else {
            result.addFail("type不被支持");
            return result;
        }
        if (pageInfo.getTotal() > 0) {
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        } else {
            result.addFail("暂无数据");
        }
        return result;
    }

    /**
     * 查询此图纸其他设备的故障或报警信息---电力监控页面使用
     *
     * @return
     */
    @PostMapping(value = "/drawing/otherdev/errors")
    public AjaxResult findOtherDeviceFaultOrWarn(@RequestBody @Valid OtherDeviceErrorsParamDto param) {
        AjaxResult result = new AjaxResult();
        PageInfo<ErrorOutputDto> pageInfo = null;
        if (param.getType() == 1) {
            //查询故障
            pageInfo = this.drawingService.findOtherDeviceFaults(param);
        } else if (param.getType() == 2) {
            pageInfo = this.drawingService.findOtherDeviceWarns(param);
        } else {
            result.addFail("type不被支持");
            return result;
        }
        if (pageInfo.getTotal() > 0) {
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        } else {
            result.addFail("暂无数据");
        }
        return result;
    }

/*****************/


    /**
     * 根据日期统计单位所有设备的 用电量 -- 分页
     *
     * @param param
     * @return
     */
    @PostMapping("/unit/ele/uselist")
    public AjaxResult devElectricUsing(@RequestBody @Valid ElectricUsingParam param) {
        AjaxResult result = new AjaxResult();
        result = this.drawingService.findDeviceEleUsingBy(param);
        return result;
    }


    /**
     * 统计单位某月每日的用电量
     *
     * @param jsonParam
     * @return
     */
    @PostMapping("/unit/ele/daycount")
    public AjaxResult getEleDayCount(@RequestBody JSONObject jsonParam) {
        AjaxResult result = new AjaxResult();
        Integer unitId = jsonParam.getInteger("unitId");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        Date time = jsonParam.getDate("time");
        time = time == null ? new Date() : time;
        String keyWord = jsonParam.getString("keyWord");
        List<EleDayCountDto> list = this.drawingService.findEleDayCount(unitId, time, keyWord);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("没有数据");
        }
        return result;

    }

    /**
     * 统计单位某月每个设备的用电量
     *
     * @param jsonParam
     * @return
     */
    @PostMapping("/unit/ele/devcount")
    public AjaxResult getUnitDeviceEleUsing(@RequestBody JSONObject jsonParam) {
        AjaxResult result = new AjaxResult();
        Integer unitId = jsonParam.getInteger("unitId");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        Date time = jsonParam.getDate("time");
        time = time == null ? new Date() : time;
        String keyWord = jsonParam.getString("keyWord");
        List<JSONObject> list = this.drawingService.findEleDevCount(unitId, time, keyWord);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("没有数据");
        }
        return result;

    }

    /**
     * app 端查询月用电量列表
     *
     * @param jsonParam
     * @return
     */
    @PostMapping("/unit/month/ele_uselist")
    public AjaxResult getUnitMonthEleUseList(@RequestBody JSONObject jsonParam) {
        AjaxResult result = new AjaxResult();
        Integer unitId = jsonParam.getInteger("unitId");
        Integer elYear = jsonParam.getInteger("elYear");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        List<JSONObject> list = this.drawingService.findUnitMonthEleUseList(unitId, elYear);
        if (CollectionUtils.isNotEmpty(list)) {
            //Integer elYear = list.get(0).getInteger("elYear");
            JSONObject json = new JSONObject() {{
                put("elYear", elYear);
                put("elList", list);
            }};
            result.addSuccess("查询成功");
            result.setData(json);
        } else result.addFail("赞无数据");

        return result;

    }


    /**
     * POI 导出单位用电量统计信息
     *
     * @param param -- keyWord    unitId    time  type
     * @return
     */
    @PostMapping("/unit/export/electric_using")
    public void exportEleUsingInfo(@RequestBody @Valid ElectricUsingExportParam param, HttpServletRequest request, HttpServletResponse response) {
        String keyWord = param.getKeyWord();
        Integer unitId = param.getUnitId();
        Date time = param.getTime();
        time = time == null ? new Date() : time;
        param.setTime(time);
        String[] headInfo = {"用电量排名", "绑定设备位置", "设备编号", "设备型号", "配电柜号", "配电开关名称", "用电量", "日期"};
        //得到电量使用列表
        List<EleUsingOutput> usingList = this.drawingService.findDeviceEleUsingNotPageBy(param);
        //统计单位某月每日的用电量
        //List<EleDayCountDto> daylist = this.drawingService.findEleDayCount(unitId, time, keyWord);
        //统计单位某月每个设备的用电量
        //List<JSONObject> devCountList = this.drawingService.findEleDevCount(unitId, time, keyWord);

        try {
            HSSFWorkbook book = new HSSFWorkbook();//创建excel文件
            /*生成图表*/
            if (!StringUtils.isEmpty(param.getPicCode())) {
                HSSFSheet sheet1 = book.createSheet("图形统计");//创建一个工作簿  sheet页
                sheet1.setDefaultColumnWidth(20 * 256);
                String picCode = param.getPicCode();
                String[] imageArray = picCode.split("base64,");
                BASE64Decoder decoder = new BASE64Decoder();
                byte[] buffer = decoder.decodeBuffer(imageArray[1]);
                String picPath = request.getRealPath("") + "/" + UUID.randomUUID().toString() + ".png";
                File file = new File(picPath);//图片文件
                //生成图片
                OutputStream out = new FileOutputStream(file);//图片输出流
                out.write(buffer);
                out.flush();//清空流
                out.close();//关闭流
                ByteArrayOutputStream outStream = new ByteArrayOutputStream(); // 将图片写入流中
                BufferedImage bufferImg = ImageIO.read(new File(picPath));
                ImageIO.write(bufferImg, "PNG", outStream); // 利用HSSFPatriarch将图片写入EXCE
                HSSFPatriarch patri = sheet1.createDrawingPatriarch();
                HSSFClientAnchor anchor = new HSSFClientAnchor(0, 0, 255, 255, (short) 0, usingList.size() + 5, (short) 6, usingList.size() + 35);
                anchor.setAnchorType(3);
                patri.createPicture(anchor, book.addPicture(outStream.toByteArray(), HSSFWorkbook.PICTURE_TYPE_PNG));
                if (file.exists()) {
                    file.delete();//删除图片
                }
            }

            HSSFSheet sheet2 = book.createSheet("数据统计");//创建一个工作簿  sheet页

            //设置标题样式
            HSSFCellStyle titleStyle = book.createCellStyle();
            titleStyle.setAlignment(HorizontalAlignment.CENTER);
            titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            titleStyle.setWrapText(true);
            HSSFFont nameRowFont = book.createFont();
            nameRowFont.setFontName("微软雅黑");
            nameRowFont.setFontHeightInPoints((short) 10);
            nameRowFont.setBold(true);//加粗   原方法:setBoldweight(HSSFFont.BOLDWEIGHT_BOLD) 过时
            titleStyle.setFont(nameRowFont);

            /*创建问卷标题行*/
            CellStyle wrapTextStyle = book.createCellStyle(); //创建自动换行样式
            wrapTextStyle.setWrapText(true); //设置换行
            wrapTextStyle.setAlignment(HorizontalAlignment.CENTER);
            wrapTextStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            HSSFRow row0 = sheet2.createRow(0);//创建标题行
            row0.setHeight((short) 500);// 设置行高
            HSSFCell nameCell = null;
            // 创建标题行文本数据
            Tblnprojectinfo tblnprojectinfo = this.drawingService.findUnitInfo(param.getUnitId());
            String type = param.getType() == 1 ? "日" : "月";
            String titleInfo = new String(tblnprojectinfo.getProjName() + "-" + type + "用电量报表");
            for (int i = 0; i < headInfo.length; i++) {
                nameCell = row0.createCell(i);
                nameCell.setCellType(CellType.STRING);
                if (i == 0) {
                    nameCell.setCellStyle(wrapTextStyle);
                    nameCell.setCellValue(new HSSFRichTextString(titleInfo));
                }
            }
            CellRangeAddress nameCellRange = new CellRangeAddress(0, 0, 0, headInfo.length - 1);//标题合并单元格
            sheet2.addMergedRegion(nameCellRange);

            //创建表格表头数据行
            HSSFRow row1 = sheet2.createRow(1);
            HSSFCell cell = null;
            row1.setHeight((short) 400);//设置行高
            for (int i = 0; i < headInfo.length; i++) {
                /*设置列宽度*/
                if (i == 1) {
                    sheet2.setColumnWidth(i, 20 * 256);
                } else if (i > 1) {
                    sheet2.setColumnWidth(i, 30 * 256);
                } else {
                    sheet2.setColumnWidth(i, 12 * 256);
                }
                cell = row1.createCell(i);
                cell.setCellValue(headInfo[i]);
                cell.setCellStyle(titleStyle);
            }

            //正文数据
            EleUsingOutput data = null;
            HSSFRow dataRow = null;
            Cell dataCell = null;
            for (int i = 0; i < usingList.size(); i++) {
                data = usingList.get(i);
                dataRow = sheet2.createRow(i + 2);
                dataCell = dataRow.createCell(0);//用电量排名
                dataCell.setCellValue(data.getRank());
                dataCell = dataRow.createCell(1);//绑定设备位置
                dataCell.setCellValue(data.getInstallLocation());
                dataCell = dataRow.createCell(2);//设备编号
                dataCell.setCellValue(data.getDevSignature());
                dataCell = dataRow.createCell(3);//设备型号
                dataCell.setCellValue(data.getDevTy());
                dataCell = dataRow.createCell(4);//配电柜号
                dataCell.setCellValue(data.getCupName());
                dataCell = dataRow.createCell(5);//配电开关名称
                dataCell.setCellValue(data.getGateName());
                dataCell = dataRow.createCell(6);//用电量
                dataCell.setCellValue(data.getEleQ());
                dataCell = dataRow.createCell(7);//日期
                HSSFCellStyle cellStyle = book.createCellStyle();
                HSSFCreationHelper creationHelper = book.getCreationHelper();
                cellStyle.setDataFormat(
                        creationHelper.createDataFormat().getFormat("yyyy-MM-dd")
                );
                ((HSSFCell) dataCell).setCellStyle(cellStyle);
                dataCell.setCellValue(data.getTime());
            }

            // String fileName = tblnprojectinfo.getProjName()+type+"用电量统计表";
            String fileName = DateUtil.formartDateToString(param.getTime()) + "data";

            String agent = request.getHeader("USER-AGENT").toLowerCase();
            response.setContentType("application/vnd.ms-excel");
            String codedFileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            if (agent.contains("firefox")) {
                response.setCharacterEncoding("utf-8");
                response.setHeader("content-disposition", "attachment;filename=" + new String(fileName.getBytes(), "ISO8859-1") + ".xls");
            } else {
                response.setHeader("content-disposition", "attachment;filename=" + codedFileName + ".xls");
            }

            OutputStream os = response.getOutputStream();// 取得输出流
            //response.reset();// 清空输出流
            //response.setHeader("Connection", "close");
            //response.setContentType("application/octet-stream");// 指明response的返回对象是文件流
            //response.setHeader("Content-Disposition", "attachment;filename=" + fileName);// 设置在下载框默认显示的文件名
            book.write(os);
            os.flush();
            os.close();
        } catch (IOException e) {
            e.printStackTrace();

        }


    }


    /**
     * app端诊断功能接口
     *
     * @param param
     * @param request
     * @return
     */
    @PostMapping(value = "/app/err/diagnosis")
    public AjaxResult appCallDeviceErrDiagnosis(@RequestBody JSONObject param, HttpServletRequest request) {
        AjaxResult result = new AjaxResult();
        String nodeName = param.getString("nodeName");
        Integer devIdpk = param.getInteger("devIdpk");
        Integer type = param.getInteger("type");//1 故障  2 隐患
        if (StringUtils.isEmpty(nodeName) || devIdpk == null || type == null) {
            result.addFail("参数不能为空");
            return result;
        }
        //获取设备的类型,故障或隐患的类型,发生时间,还有
        DiagnosisParam toWebMethod = this.drawingService.findToWebMethod(devIdpk, nodeName, type);
        if (toWebMethod == null) {
            result.addFail("当前实时故障已消除,请刷新页面后查看");
            return result;
        }
        result = this.deviceErrDiagnosis(toWebMethod, request);
        return result;
    }

    @PostMapping(value = "/app/get/errTitle")
    public AjaxResult getErrTitle(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        String nodeName = param.getString("nodeName");
        Integer devIdpk = param.getInteger("devIdpk");
        Integer type = param.getInteger("type");//1 故障  2 隐患
        if (StringUtils.isEmpty(nodeName) || devIdpk == null || type == null) {
            result.addFail("参数不能为空");
            return result;
        }
        //获取当前设备的最近的故障或隐患的名称
        String title = this.drawingService.findErrDesc(devIdpk, nodeName, type);
        result.addSuccess("获取成功");
        result.setData(title);
        return result;
    }

    /**
     * web端诊断功能接口
     *
     * @return
     */
    @PostMapping(value = "/web/err/old_diagnosis")
    public AjaxResult old_deviceErrDiagnosis(@RequestBody @Valid DiagnosisParam param, HttpServletRequest request) {
        AjaxResult result = new AjaxResult();
        DiagnosisParamToQueue queueParam = new DiagnosisParamToQueue();
        BeanUtils.copyProperties(param, queueParam);
        String signalId = param.getDevIdpk() + "-" + param.getErrType() + "-" + param.getErrNode();
        queueParam.setSignalId(signalId);

        String access_token = request.getHeader("access_token");
        if (StringUtils.isEmpty(access_token)) {
            result.addFail("没有获取到token,请重新登录");
            return result;
        }
        if (param.getErrType().equals(0)) {
            //网络故障的诊断
            try {
                List<ResultItemList> resultItems = this.requestDotNetSelectDevicePhoneCardApi(param.getDevIdpk(), access_token, signalId);
                result.addSuccess("查询成功");
                result.setData(resultItems);
                return result;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {//先去Redis中获取是否有相关分析结果
            Map<String, String> map = RedisUtil.getInstance().hash().hgetAll("LN.Diagnosis:" + signalId);
            try {
                if (map == null || map.size() == 0) {
                    rabbitTemplate.convertAndSend("q_test_01", JSON.toJSONString(queueParam));//往q_test_01队列发送消息
                }
                for (int i = 0; i < 16; i++) {
                    if (map != null && map.size() >= 3) {//目前最多分析三步
                        //直接返回
                        result.addSuccess("查询成功");
                        List<ResultItemList> list = this.formartRedisResult(map);
                        result.setData(list);
                    }
                    Thread.sleep(1000);
                    map = RedisUtil.getInstance().hash().hgetAll("LN.Diagnosis:" + signalId);
                }
                List<ResultItemList> list = this.formartRedisResult(map);
                if (CollectionUtils.isNotEmpty(list)) {
                    result.addSuccess("查询成功");
                    result.setData(list);
                } else result.addFail("暂无结果,可刷新页面重试,或联系管理人员");

            } catch (InterruptedException e) {
                e.printStackTrace();
                result.addFail("网络连接超时,请稍后重试");
            }
        }
        return result;
    }


    /**
     * 新的web端诊断功能接口--如果大数据的Linux服务器到期,则去掉new_前缀再发布
     *
     * @return
     */
    @PostMapping(value = "/web/err/diagnosis")
    public AjaxResult deviceErrDiagnosis(@RequestBody @Valid DiagnosisParam param, HttpServletRequest request) {
        AjaxResult result = new AjaxResult();
        List<Integer> errTys = Arrays.asList(SysConst.errTyArray);
        if (!errTys.contains(param.getErrType())) {
            result.addFail("系统暂时不支持此类故障或隐患的诊断,请待后续服务的升级");
            return result;
        }
        String signalId = param.getDevIdpk() + "-" + param.getErrType() + "-" + param.getErrNode();

        if (StringUtils.isEmpty(request.getHeader("access_token"))) {
            result.addFail("没有获取到token,请重新登录");
            return result;
        }

        if (param.getErrType().equals(0)) {
            //网络故障的诊断
            try {
                List<ResultItemList> resultItems = this.requestDotNetSelectDevicePhoneCardApi(param.getDevIdpk(), request.getHeader("access_token"), signalId);
                result.addSuccess("查询成功");
                result.setData(resultItems);
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                result.addFail("网络异常,请稍后重试");
            }
        } else {
            //除了网络故障外的其他故障隐患的诊断
            Integer errType = param.getErrType();
            List<ResultItemList> resultItems = null;
            switch (errType) {
                case 4:
                    //传感器短路、断路
                    resultItems = this.commonService.SensorShortOrBreakCircuitError(param, signalId);
                    break;
                case 5:
                    //漏电过大
                    resultItems = this.commonService.louDianGuoDaError(param, signalId);
                    break;
                case 6:
                    //温度过高
                    resultItems = this.commonService.temperatureTooHeightError(param, signalId);
                    break;
                //过欠压的故障或隐患
                case 33:
                case 34:
                case 159:
                case 160:
                    resultItems = this.commonService.voltageTooHeightOrLowError(param, signalId);
                    break;

            }
            result.addSuccess("诊断成功");
            result.setData(resultItems);
            return result;
        }
        result.addFail("暂无诊断结果");
        return result;
    }


    //将从redis中取到的数据转换成对象
    private List<ResultItemList> formartRedisResult(Map<String, String> map) {
        if (map == null || map.size() == 0) {
            return null;
        }
        List<ResultItemList> list = new ArrayList<>();
        Set<String> keySet = map.keySet();
        for (String key : keySet) {
            String value = map.get(key);
            ResultItemList itemList = JSON.parseObject(value, ResultItemList.class);
            list.add(itemList);
        }
        List<ResultItemList> collect = list.stream().sorted(Comparator.comparing(ResultItemList::getStep)).collect(Collectors.toList());
        return collect;
    }

    /**
     * 远程调用.net的查询物联网卡的信息接口
     *
     * @param devIdpk
     * @param signalId
     */
    private List<ResultItemList> requestDotNetSelectDevicePhoneCardApi(Integer devIdpk, String access_token, String signalId) throws Exception {
        //先获取设备编号
        Tblndeviceinfo deviceInfo = this.drawingService.findDeviceInfo(devIdpk);
        if (deviceInfo == null) {
            return null;
        }
        String devSignature = deviceInfo.getDevSignature();
        //设备存在,调用.net接口
        String url = Const.DOTNET_GET_PHONECARD_INFO;
        List<NameValuePair> formparas = new ArrayList<>();
        formparas.add(new BasicNameValuePair("devSignature", devSignature));//设备编号
        JSONObject jsonResult = HttpClientPoolUtil.getInstance().doPost(url, formparas, access_token);

        ResultItem item1 = new ResultItem();
        //item1.setStep(1);
        if (jsonResult.getIntValue("status") == 1) {
            //查询成功
            JSONObject row = jsonResult.getJSONObject("row");
            item1.setMsg("物联网卡诊断");
            if (row != null) {
                JSONObject result = row.getJSONObject("Result");
                item1.setStatus(0);
                item1.setList(
                        new ArrayList<String>() {
                            {
                                add("电话号码:" + result.getString("CardNo"));
                                add("卡片状态:" + result.getString("CardState"));
                                add("使用状态:" + result.getString("UseState"));
                                add("流量状态:" + result.getString("GPRSState"));
                                add("流量总量:" + result.getString("GprsTotal"));
                                add("当月流量用量:" + result.getString("GprsUsed"));
                                add("服务结束日期:" + result.getString("EndDay"));
                            }
                        }
                );
            } else {
                item1.setStatus(1);
                item1.setList(
                        new ArrayList<String>() {
                            {
                                add("没有获取到物联网卡信息");
                            }
                        }
                );
            }

        } else {
            item1.setMsg("没有获取到物联网卡信息");
            item1.setStatus(1);
            item1.setList(null);
        }
        ResultItem item2 = new ResultItem();
        //item2.setStep(2);
        item2.setMsg("设备服务诊断");
        Date devProductTime = deviceInfo.getDevProductTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(devProductTime);
        calendar.add(Calendar.YEAR, 1);
        Date afterOneYear = calendar.getTime();
        Date now = new Date();
        if (afterOneYear.getTime() > now.getTime()) {//没有过期
            item2.setStatus(0);
            item2.setList(
                    new ArrayList<String>() {
                        {
                            add("设备生产日期为:" + DateUtil.formartDateToString(devProductTime));
                            add("设备免费到期日期为:" + DateUtil.formartDateToString(afterOneYear));
                            add("设备处于免费服务期,服务状态正常");

                        }
                    });

        } else {
            item2.setStatus(1);
            item2.setList(
                    new ArrayList<String>() {
                        {
                            add("设备生产日期为    " + DateUtil.formartDateToString(devProductTime));
                            add("设备免费到期日期为  " + DateUtil.formartDateToString(afterOneYear));
                            add("设备免费服务期已用完,服务状态欠费,请及时缴费");
                        }
                    });

        }

        ResultItem item3 = new ResultItem();
        //item3.setStep(3);
        item3.setMsg("设备服务诊断");
        item3.setStatus(0);
        List<String> list3 = new ArrayList<>();
        //调用Hbase数据,查询设备最近上传数据时的信号值
        String deviceRecentlyCSQValue = this.getDeviceRecentlyCSQValue(devIdpk);
        if ("0.00".equals(deviceRecentlyCSQValue)) {
            list3.add("系统无法获取到该设备中断时的信号值");
            item3.setStatus(1);
        } else {
            list3.add("设备信号中断时的信号量为 " + deviceRecentlyCSQValue + "%");
        }
        //查询数据库此单位其他设备,并获取到其他设备的最近的信号值,求平均,最高,最低
        List<Tblndeviceinfo> devList = this.drawingService.findDevicesOfTheSeamUnit(devIdpk);
        if (CollectionUtils.isEmpty(devList)) {
            list3.add("系统无法获取附近设备的信号值来作为参考");
        } else {
            List<Double> doubleValues = new ArrayList<>();
            for (Tblndeviceinfo dev : devList) {
                String csqValue = this.getDeviceRecentlyCSQValue(dev.getDevIdpk());
                doubleValues.add(Double.valueOf(csqValue));
            }
            Double aDouble = doubleValues.stream().reduce(Double::sum).orElse(0d);
            Double max = doubleValues.stream().reduce(Double::max).orElse(0d);
            Double min = doubleValues.stream().reduce(Double::min).orElse(0d);
            Double avgCSQ = aDouble / doubleValues.size();
            list3.add("其他设备的平均信号量为 " + new DecimalFormat("0.00").format(avgCSQ) + "%");
            list3.add("其他设备的最大信号量为 " + new DecimalFormat("0.00").format(max) + "%");
            list3.add("其他设备的最小信号量为 " + new DecimalFormat("0.00").format(min) + "%");

        }
        item3.setList(list3);

        ResultItemList itemList1 = new ResultItemList();
        itemList1.setSignalId(signalId);
        itemList1.setStep(1);
        itemList1.setResultMap(new ArrayList<ResultItem>() {
            {
                add(item1);
            }
        });
        ResultItemList itemList2 = new ResultItemList();
        itemList2.setSignalId(signalId);
        itemList2.setStep(2);
        itemList2.setResultMap(new ArrayList<ResultItem>() {
            {
                add(item2);
            }
        });
        ResultItemList itemList3 = new ResultItemList();
        itemList3.setSignalId(signalId);
        itemList3.setStep(3);
        itemList3.setResultMap(new ArrayList<ResultItem>() {
            {
                add(item3);
            }
        });

        List<ResultItemList> phoneCardInfos = new ArrayList<>();
        phoneCardInfos.add(itemList1);
        phoneCardInfos.add(itemList2);
        phoneCardInfos.add(itemList3);
        return phoneCardInfos;

    }

    private String getDeviceRecentlyCSQValue(Integer devIdpk) {
        String csqVal = "0";
        String[] timeArr = DateUtil.formartTimeToRowKey(new Date());
        List<realValueByNode1> realValueByNode1s = HbaseUtil.GetMaxSingleArrayByFilter(devIdpk.toString(), Const.HBASE_START_STORAGE_TIME, timeArr[1], "CSQ");
        if (CollectionUtils.isNotEmpty(realValueByNode1s)) {
            realValueByNode1 realValueByNode1 = realValueByNode1s.get(0);
            csqVal = realValueByNode1.getVal();
        }
        double v = Double.valueOf(csqVal) / Double.valueOf(31);
        csqVal = new DecimalFormat("0.00").format(v * 100);
        return csqVal;
    }


    private Logger logger = LoggerFactory.getLogger(DrawingController.class);

    //@RabbitListener(queues = "q_test_02")
    //@RabbitHandler
    public void receive(Message msg) {
        //String string = msg.toString();
        byte[] body = msg.getBody();
        String jsonStr = new String(body, Charset.forName("utf8"));
        logger.info("------MQ接受的信息为: " + jsonStr);
        //转化为json对象
        JSONObject jsonResult = JSON.parseObject(jsonStr);
        String signalId = jsonResult.getString("signalId");
        Integer step = jsonResult.getInteger("step");
        Object object = jsonResult.get("resultMap");
        ResultItemList itemList = new ResultItemList();
        itemList.setSignalId(signalId);
        itemList.setStep(step);
        if (object instanceof JSONObject) {
            ResultItem item = jsonResult.getObject("resultMap", ResultItem.class);
            itemList.setResultMap(
                    new ArrayList<ResultItem>() {{
                        add(item);
                    }});
            //存如Redis
        } else if (object instanceof JSONArray) {
            List<ResultItem> list = new ArrayList<>();
            JSONArray array = (JSONArray) object;
            for (int i = 0; i < array.size(); i++) {
                Object o = array.get(i);
                ResultItem item = JSON.parseObject(o.toString(), ResultItem.class);
                list.add(item);
            }
            itemList.setResultMap(list);
            //存入Redis

        }
        RedisUtil instance = RedisUtil.getInstance();
        instance.hash().hset("LN.Diagnosis:" + signalId, step.toString(), JSON.toJSONString(itemList));
        RedisUtil.Keys keys = instance.keys();
        keys.expire("LN.Diagnosis:" + signalId, 100);
    }


}
