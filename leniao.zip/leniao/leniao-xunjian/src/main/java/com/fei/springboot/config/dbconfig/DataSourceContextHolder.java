package com.fei.springboot.config.dbconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 本地线程，数据源上下文
 * @author Jfei
 *
 */
public class DataSourceContextHolder {

	private static Logger log = LoggerFactory.getLogger(DataSourceContextHolder.class);
	
	//线程本地环境
	private static final ThreadLocal<String> local = new ThreadLocal<String>();

    public static ThreadLocal<String> getLocal() {
        return local;
    }

    /**
     * 业务读库
     */
    public static void setReleaseRead() {
        local.set(DataSourceType.releaseRead.getType());
        log.info("数据库切换到业务读库...");
    }

    /**
     * 业务写库
     */
    public static void setReleaseWrite() {
        local.set(DataSourceType.releaseWrite.getType());
        log.info("数据库切换到业务写库...");
    }


    /**
     * 校验写库
     */
    public static void setProduceWrite() {
        local.set(DataSourceType.produceWrite.getType());
        log.info("数据库切换到校验写库...");
    }

    /**
     * 校验读库
     */
    public static void setProduceRead(){
        local.set(DataSourceType.produceRead.getType());
        log.info("数据库切换到校验读库...");
    }


    public static String getReadOrWrite() {
        return local.get();
    }
    
    public static void clear(){
    	local.remove();
    }
}
