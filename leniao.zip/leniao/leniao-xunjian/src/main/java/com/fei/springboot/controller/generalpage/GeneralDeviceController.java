package com.fei.springboot.controller.generalpage;

import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevty;
import com.fei.springboot.pojo.generalpage.detail.TblndevtyForSelect;
import com.fei.springboot.service.generalpage.GeneralDeviceDetailService;
import com.fei.springboot.service.generalpage.GeneralDeviceService;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.aspectj.weaver.loadtime.Aj;
import org.hibernate.validator.constraints.Length;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

/**
 * @Description: 通用模块的公共部分
 * @Author: haosw
 * @CreateDate: 2019/11/26 11:27
 * @UpdateUser: haosw
 * @UpdateDate: 2019/11/26 11:27
 * @UpdateRemark: 修改内容
 * @Version: 1.2
 */
@CrossOrigin
@Controller
@Validated
@RequestMapping(value = "/general")
public class GeneralDeviceController {

    private Logger logger = LoggerFactory.getLogger(GeneralDeviceController.class);

    @Autowired
    private GeneralDeviceService generalDeviceService;
    @Autowired
    private GeneralDeviceDetailService generalDeviceDetailService;


    /**
     * 查询需要增加还是更新
     *
     * @param
     * @return
     * @throws
     * @author Haosw
     * @date 2019/12/2 16:47
     */
    @RequestMapping(value = "/addOrUpdate")
    @ResponseBody
    public AjaxResult insertOrUpdate(@NotNull(message = "设备型号ID不能为NULL") @RequestParam("devTyId") Integer devTyId,
                                     @Max(value = 1, message = "查询目标最大值为 {value}")
                                     @Min(value = 0, message = "查询目标最小值为 {value}")
                                     @NotNull(message = "查询目标不能为NUll") Integer targ) {
        AjaxResult result = new AjaxResult();
        boolean flag = this.generalDeviceService.findIsExist(devTyId, targ);
        result.addSuccess("查询成功");
        result.setData(flag);
        return result;
    }


    /**
     * @Description: 根据平台, 系统, 模糊搜索设备类型
     * @Author: haosw
     * @CreateDate: 2019/11/25 13:13
     * @UpdateUser: haosw
     * @UpdateDate: 2019/11/25 13:13
     * @UpdateRemark: 修改内容
     * @Version: 1.2
     */
    @PostMapping(value = "/findDevTy")
    @ResponseBody
    public AjaxResult findDevTyByTycode(
            @RequestParam(required = true, name = "platformId") Integer platformId,
            @NotNull(message = "系统ID不能为NULL")
            @RequestParam Integer devSysId,
            @Length(max = 20, message = "类型编码长度不能大于 {max} 个字符")
            @RequestParam String devTy) {

        List<TblndevtyForSelect> devTyList = this.generalDeviceService.findDevtyByTyCode(platformId, devSysId, devTy);
        AjaxResult result = new AjaxResult();
        if (CollectionUtils.isNotEmpty(devTyList)) {
            result.addSuccess("查询成功");
            result.setData(devTyList);
        } else {
            result.addFailWithArray("暂无数据");
        }
        return result;
    }


    /**
    * 根据厂商ID, 系统ID, 型号名称模糊搜索型号
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/12/3 14:50
    */
    @PostMapping(value = "/findFirmDevTy")
    @ResponseBody
    public AjaxResult findFirmDevTyByTycode(
            @RequestParam(required = true, name = "firmId") Integer firmId,
            @NotNull(message = "firmId不能为NULL")
            @RequestParam Integer devSysId,
            @Length(max = 20, message = "类型编码长度不能大于 {max} 个字符")
            @RequestParam String devTy) {

        List<TblndevtyForSelect> devTyList = this.generalDeviceService.findFirmDevtyByTyCode(firmId, devSysId, devTy);
        AjaxResult result = new AjaxResult();
        if (CollectionUtils.isNotEmpty(devTyList)) {
            result.addSuccess("查询成功");
            result.setData(devTyList);
        } else {
            result.addFailWithArray("暂无数据");
        }
        return result;
    }


    /**
     * 查询某一设备型号的总体配置信息
     *
     * @param
     * @return
     * @throws
     * @author Haosw
     * @date 2019/11/28 9:56
     */
    @PostMapping(value = "/findTotalInfo")
    @ResponseBody
    public AjaxResult findDevTyTotalConfById(@NotNull(message = "平台ID不能为空")
                                             @RequestParam(required = true, name = "platformId") Integer platformId,
                                             @NotNull(message = "系统ID不能为NULL")
                                             @RequestParam Integer devSysId,
                                             @Min(value = 1, message = "型号ID必须为大于等于 {value} 的整数")
                                             @RequestParam("devTyId") Integer devTyId,
                                             @Length(min = 0, max = 50, message = "型号名称:devTy 长度在 {min} - {max} 个字符之间")
                                             @RequestParam("devTy") String devTy,
                                             @NotNull(message = "当前页码不能为空")
                                             @Min(value = 1, message = "当前页码最小值为 {value}")
                                             @RequestParam("index") Integer index,
                                             @NotNull(message = "每页条数不能为空")
                                             @Min(value = 1, message = "每页条数最小值为 {value}")
                                             @RequestParam("size") Integer size) {
        AjaxResult result = new AjaxResult();
        //判断设备型号是否存在
        if (devTyId != null) {
            Tblndevty tblndevTy = this.generalDeviceDetailService.findDevtyByPk(devTyId);
            if (tblndevTy == null) {
                result.addFail("该型号不存在");
                return result;
            }
            //绑定在哪个型号下
            Integer parentDevtyId = this.generalDeviceDetailService.findParentDevtyId(devTyId);
            if (parentDevtyId != null && !parentDevtyId.equals(0)) {
                devTyId = parentDevtyId;
            }
        }

        PageInfo<Map<String, Object>> pageInfo = this.generalDeviceService.findDevtyTotalConfById(index, size, platformId, devSysId, devTyId, devTy);
        if (pageInfo.getTotal() > 0) {
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        } else {
            result.addFail("没有数据");
        }
        return result;
    }


}
