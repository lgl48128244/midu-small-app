package com.fei.springboot;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.fei.springboot.constant.Const;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.web.HttpMessageConverters;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import javax.servlet.MultipartConfigElement;
import java.nio.charset.Charset;

@ServletComponentScan
@EnableTransactionManagement(order = 10) //开启事务，并设置order值，默认是Integer的最大值 //
//@MapperScan(basePackages = {"com.fei.springboot"})
//@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
@SpringBootApplication(scanBasePackages={"com.fei.springboot"},
        exclude = {DataSourceAutoConfiguration.class})
//@EnableSwagger2
public class Application extends SpringBootServletInitializer implements EmbeddedServletContainerCustomizer{

	 @Override  
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {  
        return application.sources(Application.class);  
    }  
  
	 
	 public static void main(String[] args) throws Exception {
	        SpringApplication.run(Application.class, args);
	 }


    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        //单个文件最大
        factory.setMaxFileSize(Const.CONFIG_FILE_SIZE+"MB");
        /// 设置总上传数据总大小
        factory.setMaxRequestSize("50MB");
        return factory.createMultipartConfig();
    }

    @Bean
    public RestTemplate restTemplate(){
	     return new RestTemplate();
    }

    /*@Bean
    public MethodValidationPostProcessor methodValidationPostProcessor(){
	     return new MethodValidationPostProcessor();
    }*/


    //配置fastjson
    @Bean
    public HttpMessageConverters httpMessageConverters ()  {
        FastJsonHttpMessageConverter converter = new FastJsonHttpMessageConverter();
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        //fastJsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");
        fastJsonConfig.setCharset(Charset.forName("utf8"));
        fastJsonConfig.setSerializerFeatures(
                //SerializerFeature.WriteClassName,//配置是否输出类名
                //SerializerFeature.WriteNullNumberAsZero,// 将Number类型的null转成0
                SerializerFeature.WriteMapNullValue,//配置是否输出value为null值的数据
                SerializerFeature.PrettyFormat,//生成的json格式化
                SerializerFeature.WriteNullListAsEmpty,//空集合输出[]而不是null
                SerializerFeature.WriteNullStringAsEmpty,//空字符串输出"" 而不是null
                SerializerFeature.DisableCircularReferenceDetect // 避免循环引用
        );
        converter.setFastJsonConfig(fastJsonConfig);
        return new HttpMessageConverters(converter);

    }



    public void customize(ConfigurableEmbeddedServletContainer configurableEmbeddedServletContainer) {
	//	configurableEmbeddedServletContainer.setPort(9090);
	}
}
