package com.fei.springboot.controller.common.dotnet;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.pojo.common.SelectDeviceByPIdApiParam;
import com.fei.springboot.service.common.CommonService;
import com.fei.springboot.util.redis.RedisUtil;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
@CrossOrigin
@RestController
public class DotNetInterfaceController {


    @Autowired
    private CommonService commonService;

    //查询设备列表的页面新曾返回单位的巡检点
    @PostMapping("/api/V2/LN_Device/SelectDeviceByPIdApi")
    public JSONObject selectDeviceByPIdApi(HttpServletRequest request, @RequestBody SelectDeviceByPIdApiParam param){

        String prefix = "LN.IOT.User:";//004D162821FBDCC0493238FC06BA699D
        String access_token = prefix + request.getHeader("access_token");
        String hget = RedisUtil.getInstance().hash().hget(access_token, "LN.LoginUserList");
        if (StringUtils.isEmpty(hget)) {
            JSONObject json = new JSONObject(){{
                put("Message","未授权");
            }};
            return json;
        }
        JSONObject jsonObject = JSON.parseObject(hget);
        int group_type = jsonObject.getIntValue("group_type");
        JSONObject result = commonService.findDeviceAndXJPoint(param,group_type);

        return result;
    }


}
