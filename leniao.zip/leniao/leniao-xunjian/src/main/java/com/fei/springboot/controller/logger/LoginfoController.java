package com.fei.springboot.controller.logger;

import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.pojo.logger.LogFormParam;
import com.fei.springboot.util.LogUtil;
import com.fei.springboot.util.redis.RedisUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
@RequestMapping(value = "/log")
public class LoginfoController {

    Logger logger = LoggerFactory.getLogger(LoginfoController.class);


//===========================================================================================
    //跳转到日志登录页面
    @RequestMapping("/index/{userPhone}")
    public String index(@PathVariable("userPhone")String userPhone){
        LogUtil.getInstance().setLogUser(userPhone);
        //本地测试代码
        //InsertFakeDataTask insertFakeDataTask = new InsertFakeDataTask(userPhone, 50);
        //insertFakeDataTask.start();//1
        //new Thread(insertFakeDataTask).start();//2
        return "index";
    }

    //设置查询参数
    @RequestMapping(value = "/set")
    public @ResponseBody
    AjaxResult add(@ModelAttribute LogFormParam param){
        AjaxResult result = new AjaxResult();
        if (StringUtils.isEmpty(param.getParam())) {
            result.addFail("查询参数不能为空");
            return result;
        }
        if (param.getTimeOut() == null || param.getTimeOut().equals(0)) {
            param.setTimeOut(30);
            result.addSuccess("日志过期时间默认设为30秒");
        }
        LogUtil logUtil = LogUtil.getInstance();
        //把匹配参数设置一下
        logUtil.setLogUser(param.getParam());
        logUtil.setTimeOut(param.getTimeOut());
        String message = "";
        if (!StringUtils.isEmpty(result.getMessage())) {
            message += "参数设置成功    "+result.getMessage();
        }else{
            message += "参数设置成功";
        }
        result.addSuccess(message);
        return result;
    }

    //获取实时日志信息
    @RequestMapping(value = "/get")
    @ResponseBody
    public AjaxResult getRealTimeInfo(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        String userPhone = param.getString("param");
        if (StringUtils.isEmpty(userPhone)) {
            result.addFail("没有获取到参数");
            return result;
        }
        String lpop = null;
        try {
            lpop = RedisUtil.getInstance().lists().lpop("AliveLog:" + userPhone);
            result.addSuccess("查询成功");
            result.setData(lpop);
        } catch (Exception e) {
            e.printStackTrace();
            result.addFail("程序异常");
        }
        return result;
    }
    //停止轮询并情况内存中的参数
    @RequestMapping(value = "/stopAndClear")
    @ResponseBody
    public AjaxResult stopAndClear(){
        AjaxResult result = new AjaxResult();
        LogUtil.getInstance().setLogUser("");
        result.addSuccess("查询参数已清空");
        return result;
    }
//=========================================================================================================
    //要手动转发数据的url
    private String url;

    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping(value = "/accept")
    @ResponseBody
    public void acceptData(@RequestBody JSONObject param){
        System.out.println(param.toJSONString());
        LogUtil.getInstance().writeSimpleLogger("simple",60,param.toJSONString());

        if (!StringUtils.isEmpty(this.url)) {
            ResponseEntity<String> responseEntity = this.restTemplate.postForEntity(url, param, String.class);
            System.out.println("转发路径"+ url +
                    "转发数据"+param.toJSONString()+
                    "转发状态"+ responseEntity.getStatusCodeValue()+
                    "转发结果"+ responseEntity.getBody());
        }else {
            System.out.println("转发路径为空,不做转发");
        }
    }

    //设置转发的路径
    @RequestMapping(value = "/setParam")
    public AjaxResult setParam(@RequestParam String url){
        AjaxResult result = new AjaxResult();
        if (StringUtils.isEmpty(url)) {
            result.addFail("转发路径不能为空");
            return result;
        }
        this.url = url;
        result.addSuccess("转发路径设置成功");
        return result;
    }



}