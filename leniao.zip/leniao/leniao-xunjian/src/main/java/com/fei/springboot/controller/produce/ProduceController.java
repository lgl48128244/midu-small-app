package com.fei.springboot.controller.produce;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.DeviceCheck.DeviceCheck;
import com.fei.springboot.domain.device.Tblndeviceinfo;
import com.fei.springboot.domain.group.Tblngroup;
import com.fei.springboot.domain.phonecardinfo.Tblnphonecardinfo;
import com.fei.springboot.domain.unitavggrade.Tblnprojectinfo;
import com.fei.springboot.domain.user.Tblnuserinfo;
import com.fei.springboot.pojo.produce.*;
import com.fei.springboot.service.produce.ProduceService;
import com.fei.springboot.util.DateUtil;
import com.fei.springboot.util.UUIDUtil;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/produce")
public class ProduceController {

    @Autowired
    private ProduceService produceService;

    //测试
    @RequestMapping("/get")
    public AjaxResult get() {
        AjaxResult result = new AjaxResult();
        List<JSONObject> list = this.produceService.findAll();
        if (list != null && list.size() > 0) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("没有数据");
        }
        return result;
    }

    /**
     * 查询单位和组
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/queryUnitAndGroup", method = RequestMethod.POST)
    public JSONObject queryUnitAndGroup(@RequestBody JSONObject param) {
        JSONObject jsonObject = new JSONObject();
        Integer platformId = param.getInteger("platformId");
        //Date now = param.getDate("now");
        Integer userId = param.getInteger("userId");
        if (userId == null || platformId == null) {
            jsonObject.put("message", "用户Id 或 平台id不能为空");
            jsonObject.put("status", 0);
            return jsonObject;
        }
        Date now = new Date();
        if (platformId == 0) {
            jsonObject.put("错误信息", "未获取到平台,请重新登陆");
            return jsonObject;
        }
        Calendar cal = Calendar.getInstance();
        if (now != null){
            cal.setTime(now);
        }
        int year = cal.get(Calendar.YEAR);//获取年
        int month = cal.get(Calendar.MONTH) + 1;//获取月
        String strMonth = month+"";
        if (month<10){
            strMonth = "0"+month;
        }
        int day = cal.get(Calendar.DATE);//获取当天
        String strDay = day+"";
        if (day<10){
            strDay = "0"+day;
        }
        // 去判断当月有没有项目 再去判断有没有组
        String unitName = "HappyBird-生产-" + year + "-" + strMonth+"-"+userId;
        String groupName = "HappyBird-生产-" + strDay;
        Tblnprojectinfo tblnprojectinfo = produceService.queryUnitByName(unitName, platformId);

        if (tblnprojectinfo != null) {
            Tblngroup tblngroup = produceService.queryGroupByName(groupName,tblnprojectinfo.getProjId());
            if (tblngroup != null) {
                //jsonObject.put("tblnprojectinfo",tblnprojectinfo);
                jsonObject.put("tblngroup", tblngroup);
                jsonObject.put("message", "查询项目和组成功");
                jsonObject.put("status", 1);
                return jsonObject;
            } else {  //没有组 则新建组
                Tblngroup tblngroup1 = new Tblngroup();
                Integer projId = tblnprojectinfo.getProjId();
                tblngroup1.setProjId(projId);
                tblngroup1.setGroupName(groupName);
                tblngroup1.setDevsysId(3);
                Tblngroup tblngroupNew = produceService.insertGroupByName(tblngroup1);
                //jsonObject.put("tblnprojectinfo",tblnprojectinfo);
                jsonObject.put("tblngroup", tblngroupNew);
                jsonObject.put("message", "新建组成功");
                jsonObject.put("status", 1);

                return jsonObject;
            }
        } else {  //没有这个项目 则新建项目并且新建组
            Tblnprojectinfo proj = new Tblnprojectinfo();
            proj.setIsDelete(0);
            proj.setPlatformId(platformId);
            proj.setProjName(unitName);
            proj.setProjRemark("java-cuijian");
            proj.setProCreateTime(new Date());
            Tblnprojectinfo tblnprojectinfoNew = produceService.insertUnit(proj,platformId);
            //新项目要跟用户关联
            this.joinUserAndProj(userId,tblnprojectinfoNew.getProjId());
            Tblngroup tblngroup = produceService.queryGroupByName(groupName,tblnprojectinfoNew.getProjId());
            if (tblngroup == null) {
                tblngroup = new Tblngroup();
                tblngroup.setProjId(tblnprojectinfoNew.getProjId());
                tblngroup.setGroupName(groupName);
                tblngroup.setDevsysId(3);
                produceService.insertGroupByName(tblngroup);
            }
            jsonObject.put("tblngroup", tblngroup);
            jsonObject.put("message", "新建项目和组成功");
            jsonObject.put("status", 1);
            return jsonObject;
        }
    }

    private void joinUserAndProj(Integer userId ,Integer projId){
        this.produceService.insertUserJnProj(userId,projId);
    }


    /**
     * 设备检查
     *
     * @param deviceCheck
     * @return
     */
    @RequestMapping(value = "/checkDevice", method = RequestMethod.POST)
    public AjaxResult checkDevice(@RequestBody @Valid DeviceCheck deviceCheck) {
        AjaxResult result = new AjaxResult();
        String devSignature = deviceCheck.getDevSignature();
        if (StringUtils.isEmpty(devSignature)) {
            result.addFail("设备编号不能为空");
            return result;
        }

        //Integer platform = deviceCheck.getPlatformId();
        Integer projId = deviceCheck.getProjId();
        Integer groupID = deviceCheck.getGroupId();

        Integer stepIndex = deviceCheck.getStepIndex();
        Integer recordType = deviceCheck.getRecordType();
        String stepId = deviceCheck.getStepId();
        Integer devSysId = deviceCheck.getDevSysId();

        Tblndeviceinfo device = produceService.queryDeviceBySign(devSignature);
        //校准之前先去判断该设备存不存在 存在的话直接校准 不存在的话新加一条设备信息
        if (device != null) {
            deviceCheck.setDeviceId(device.getDevIdpk());
            return judgeStepId(stepIndex, recordType, stepId, deviceCheck);
        } else {
            Integer devid = addDevice(projId, groupID, devSignature,deviceCheck.getDevTy(),
                    deviceCheck.getDevTyId(),deviceCheck.getFirmId(),devSysId,DateUtil.formartByPattern(new Date(),"yyyyMMddHHmmss"));
            deviceCheck.setDeviceId(devid);
            return judgeStepId(stepIndex, recordType, stepId, deviceCheck);
        }

    }

    /**
     * 查询是否合格
     *
     * @param param
     * @return
     */
    @PostMapping("/isOrNotQualified")
    public AjaxResult isOrNotQualified(@RequestBody @Valid ChecParamInDto param) {

        AjaxResult result = new AjaxResult();
        // 先通过平台id和设备型号去查询有没有此设备
        String devSignature = param.getDevSignature();
        Integer projId = param.getProjId();
        Integer groupId = param.getGroupId();
        String devTy = param.getDevTy();
        Integer devTyId = param.getDevTyId();
        Integer firmId = param.getFirmId();
        Integer devSysId = param.getDevSysId();
        String installLocation = param.getInstallLocation();
        Tblndeviceinfo tblndeviceinfo = produceService.queryDeviceBySign(devSignature);
        if (tblndeviceinfo != null) {
            //2019-09-30 新增需求,将原设备的删除状态改为:未删除--0   haosw
            if (tblndeviceinfo.getIsDelete().equals(1)) {
                this.produceService.updateDevice(tblndeviceinfo);
            }
            //如果不为空 则存在此设备 去新库里面查询是否合格 通过该设备id  不合格的设备
            Integer devIdpk = tblndeviceinfo.getDevIdpk();
            List<DeviceCheck> deviceChecks = produceService.queryDeviceIsOrNotQualified(devIdpk);
            if (deviceChecks != null && deviceChecks.size() > 0) {
                //说明该设备校准过 再去判断该设备的state是否都为1
                for (int i = 0; i < deviceChecks.size(); i++) {
                    String state = deviceChecks.get(i).getState();
                    if (state != null && state.equals(0))  {
                        result.addFail("该设备不合格,需要校准");
                        return result;
                    }
                }
                result.setMessage("该设备合格");
                return result;
            } else {
                result.addFail("该设备不合格,需要校准");
                return result;
            }

        } else {   //该设备为空 通过项目id 和组id 新加一台设备
            addDevice(projId, groupId, devSignature,devTy,devTyId,firmId,devSysId,installLocation);
            result.setMessage("添加新设备成功");
            return result;

        }

    }


    /**
     * 通过记录id查询该条记录详细信息
     *
     * @param param
     * @return
     */
    @PostMapping("/queryAllRecord")
    public AjaxResult queryAllRecord(@RequestBody JSONObject param) {
        Integer recordId = param.getInteger("recordId");
        return produceService.queryRecordById(recordId);
    }

    /**
     * 查询所有操作记录
     *
     * @param param
     * @return
     */
    @PostMapping("/queryAllOperating")
    public AjaxResult queryAllOperating(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer index = param.getInteger("index");
        Integer size = param.getInteger("size");
        Integer userId = param.getInteger("userId");
        String devSignature = param.getString("devSignature");
        int type = param.getIntValue("type");
        int recordType = param.getIntValue("recordType");
        Date startTime = param.getDate("startTime");
        Date endTime = param.getDate("endTime");
        int groupType = param.getIntValue("groupType");
        if (userId == null){
            result.addFail("用户id不能为空");
            return result;
        }
        List<Integer> userIdList = new ArrayList<>();
        if (type ==0){//查全部
            //获取用户下的管理人员
            List<Tblnuserinfo> list = this.produceService.findUnderUserList(groupType,userId,null);
            if (CollectionUtils.isNotEmpty(list)){
                userIdList = list.stream().map(a -> a.getUserId()).collect(Collectors.toList());
            }
        }
        userIdList.add(userId);
        List<OperateRecordDto> resultList = new ArrayList<>();
        PageInfo<OperateRecordDto> operateRecordDtos = produceService.queryAllOperateRecord(index, size, devSignature, userIdList,recordType,startTime,endTime);
        if (operateRecordDtos != null) {
            List<OperateRecordDto> list = operateRecordDtos.getList();
            for (int i = 0; i < list.size(); i++) {
                Integer deviceId = list.get(i).getDeviceId();
                Tblnprojectinfo proj = produceService.queryProByName(deviceId);
                if (proj != null){
                    list.get(i).setProName(proj.getProjName());
                    Integer userID = list.get(i).getUserId();
                    Tblnuserinfo userInfo = produceService.queryUserNameById(userID);
                    list.get(i).setUserName(userInfo.getUserName());
                    resultList.add(list.get(i));
                }else {
                    //证明这个设备被删除了 然后把记录也删掉
                    Integer recordId = list.get(i).getRecordId();
                    this.produceService.deleteRecord(recordId);
                }
            }
            operateRecordDtos.setList(resultList);
            result.setData(operateRecordDtos);
            result.setMessage("查询成功");
        } else {
            result.addFail("查询失败");
        }
        return result;
    }

    /**
     * 通过设备型号id查设备前置编码
     *
     * @param param
     * @return
     */
    @PostMapping("/queryDevCoding")
    public AjaxResult queryDevCoding(@RequestBody JSONObject param) {
        Integer devTyId = param.getInteger("devTyId");
        return produceService.queryDevCodingById(devTyId);
    }


    /**
     * 插入电话数据
     *
     * @param phoneCard
     * @return
     */
    @PostMapping("/addPhoneCard")
    public AjaxResult addPhoneCard(@RequestBody Tblnphonecardinfo phoneCard) {

        return produceService.addPhoneCardInfo(phoneCard);


    }

    /**
     * 通过prodbatch 去查询 最大数字
     *
     * @return
     */
    @PostMapping("/queryMaxSerialnumber")
    public JSONObject queryMaxSerialnumber(@RequestBody JSONObject param) {
        String prodbatch = param.getString("prodbatch");
        return produceService.queryMaxSerial(prodbatch);
    }


    /**
     * 添加新设备方法
     *
     * @param projId
     * @param groupId
     * @param devSignature
     * @return
     */
    public Integer addDevice(Integer projId, Integer groupId, String devSignature,String devTy,Integer devTyId,Integer firmId,Integer devSysId, String installLocation) {

        Tblndeviceinfo tblndevice = new Tblndeviceinfo();
        tblndevice.setDevSignature(devSignature);
        tblndevice.setInstallLocation(installLocation);
        tblndevice.setProjId(projId);
        tblndevice.setDevgroupId(groupId);
        tblndevice.setDevLoginTime(new Date());
        tblndevice.setDevProductTime(new Date());
        tblndevice.setIsDelete(0);//新增一个未删除的设备  --后来的需求 1删除   0未删除
        tblndevice.setDevSysId(devSysId);
        tblndevice.setDevId(1);
        tblndevice.setDevTy(devTy);
        tblndevice.setDevTyId(devTyId);
        tblndevice.setFirmId(firmId);
        tblndevice.setDevParentIdpk(0);
        produceService.addNewDevice(tblndevice);
        Integer idpk = tblndevice.getDevIdpk();
        return idpk;

    }


    /**
     * 判断stepid
     */
    public AjaxResult judgeStepId(Integer stepIndex, Integer recordType, String stepId, DeviceCheck deviceCheck) {

        if ((stepIndex <= 10) && (recordType <= 6)) {

            if (StringUtils.isEmpty(stepId)) {
                String uuid = UUIDUtil.getUUID();
                deviceCheck.setStepId(uuid);
                return this.produceService.insertProduce(deviceCheck);
            } else {
                return this.produceService.insertProduce(deviceCheck);
            }
        } else {
            AjaxResult result = new AjaxResult();
            result.addFail("数据异常");
            return result;
        }


    }

    /**
     * 获取用户的下级用户
     * @param param
     * @return
     */
    @PostMapping("/underUsers")
    public AjaxResult getUnderUserList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer groupType = param.getInteger("groupType");
        Integer userId = param.getInteger("userId");
        String userName = param.getString("userName");
        if (groupType == null){
            result.addFail("分组id不能为空");
            return result;
        }
        if (userId == null){
            result.addFail("用户id不能为空");
            return result;
        }

        List<Tblnuserinfo> userList = this.produceService.findUnderUserList(groupType,userId,userName);
        if (CollectionUtils.isNotEmpty(userList)){
            result.addSuccess("查询成功");
            result.setData(userList);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }


    /**
    * 获取用户的设备校准统计信息
    * @author      Haosw
    * @param       param
    * @return
    * @exception
    * @date        2019/5/23 10:08
    */
    @PostMapping("/userResult")
    public AjaxResult getResult(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer groupType = param.getInteger("groupType");
        Integer userId = param.getInteger("userId");
        String userName = param.getString("userName");
        Date startTime = param.getDate("startTime");
        Date endTime = param.getDate("endTime");
        Integer type = param.getInteger("type");//0 查全部   1查个人
        if (type == null){
            result.addFail("查询类别不能为空");
            return result;
        }
        if (startTime == null || endTime == null){
            result.addFail("时间不能为空");
            return result;
        }
        if (userId == null){
            result.addFail("用户id不能为空");
            return result;
        }
        if (type == 0){
            List<Tblnuserinfo> userList = this.produceService.findUnderUserList(groupType, userId, null);
            List<Integer> userIdList = userList.stream().map(u -> u.getUserId()).collect(Collectors.toList());
            DeviceProduceOutputDto userDeviceResult = this.produceService.getUserDeviceResult(userList, userIdList, startTime, endTime);
            result.addSuccess("查询成功");
            result.setData(userDeviceResult);
        }else{
            DeviceProduceOutputDto userDeviceRaio = this.produceService.findUserDeviceRaio( new ArrayList<Integer>(){{ add(userId);}}, startTime, endTime);
            result.addSuccess("查询成功");
            result.setData(userDeviceRaio);

        }

        return result;
    }


    /**
    * 查询所有最新一条记录
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/5/29 13:36
    */
    @PostMapping("/recentRecord")
    public AjaxResult getRecentRecord(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        //Integer recordType = param.getInteger("recordType");
        String devSignature = param.getString("devSignature");
        if ( StringUtils.isEmpty(devSignature)) {
            result.addFail("参数不能为空");
            return result;
        }
        //Integer projId = param.getInteger("projId");
        //获取校准表中的用户id
        List<Integer> userIdList = this.produceService.findUserIds();
        if (CollectionUtils.isEmpty(userIdList)) {
            result.addFail("没有数据");
            return result;
        }
        //根据设备编号查单位
        String proName = null;
        Tblnprojectinfo tblnprojectinfo = this.produceService.findProjectInfo(devSignature);
        proName = tblnprojectinfo == null ? "未获取单位名称" : tblnprojectinfo.getProjName();

        List<Tblnuserinfo> userList = this.produceService.queryUserInfoByUserIds(userIdList);
        List<LnDeviceCheckDto> list = this.produceService.findRecentRecordByType(userList,devSignature,null,null,null);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            for (LnDeviceCheckDto  dto : list) {
                dto.setProName(proName);
                dto.setProjId(tblnprojectinfo == null ? null : tblnprojectinfo.getProjId());
            }
            result.setData(list);
        }else{
            result.addFail("没有数据");
        }
        return result;
    }


    /**
     * 根据时间和用户查询用户所生产的设备是否合格
     * @param param
     * @return
     */
    @PostMapping(value = "/getRecordByTime")
    public AjaxResult getRecentRecordByTime(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer groupType = param.getInteger("groupType");
        Integer type = param.getInteger("type");//0 查全部   1查个人
        Integer userId = param.getInteger("userId");
        Date startTime = param.getDate("startTime");
        Date endTime = param.getDate("endTime");
        if (startTime != null && endTime != null) {
            if (startTime.getTime() == endTime.getTime()){
                //如果两个时间相等,则要查出startTime当天的数据  故 endTime加一天
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(startTime);
                calendar.add(Calendar.DAY_OF_MONTH,1);
                endTime = calendar.getTime();
            }
        }
        if (type == null){
            result.addFail("查询类别不能为空");
            return result;
        }
        if (userId == null){
            result.addFail("用户id不能为空");
            return result;
        }
        if (startTime == null || endTime == null) {
            result.addFail("时间参数不能为空");
            return result;
        }

        List<Integer> userIdList = new ArrayList<>();
        if (type ==0){//查询当前用户以及所管理的下级用户的所有记录
            List<Tblnuserinfo> userList = this.produceService.findUnderUserList(groupType,userId,null);
            userIdList = userList.stream().map(u -> u.getUserId()).collect(Collectors.toList());
        }else {
            userIdList.add(userId);
        }
        //获取这些用户的所有操作记录
        List<LnDeviceCheckDto> recordList = this.produceService.findRecentRecordByTime(userIdList, startTime, endTime);
        List<LnDeviceCheckDto> resultList = new ArrayList<>();
        //对这些操作记录进行分析
        if (CollectionUtils.isNotEmpty(recordList)) {
            List<Integer> deviceIds = recordList.stream().map(d -> d.getDeviceId()).collect(Collectors.toList());
            HashSet<Integer> set = new HashSet<>();
            set.addAll(deviceIds);
            deviceIds.clear();
            deviceIds.addAll(set);
            //查询所有项目名称
            HashMap<Integer,String> projNameMap = this.produceService.queryProjNameByDeviceIds(deviceIds);
            //根据userId批量查找用户信息
            List<Tblnuserinfo> userList = this.produceService.queryUserInfoByUserIds(userIdList);
            for (Integer deviceId : deviceIds) {
                //查询当前设备所有最新记录
                List<LnDeviceCheckDto> devRecentRecords = this.produceService.findRecentRecordByType(userList, null, deviceId,startTime,endTime);
                devRecentRecords.stream().forEach(d -> d.setProName(projNameMap.get(d.getDeviceId())));
                if (CollectionUtils.isNotEmpty(devRecentRecords)) {
                    LnDeviceCheckDto recored =  this.produceService.format(devRecentRecords);
                    resultList.add(recored);
                }

            }
            result.addSuccess("查询成功");
            result.setData(resultList);

        }else {
            result.addFail("没有数据");
        }
        return result;

    }


    @PostMapping("/getPhoneCardFirm")
    public AjaxResult getPhoneCardFirm(){
        AjaxResult result = this.produceService.selectPhoneCardFirm();
        return result;
    }




}



