package com.fei.springboot.controller.admin.devty;

import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.service.admin.devty.DevSendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by songtm on 2019/9/25.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/devSend")
public class DevSendController {
    @Autowired
    private DevSendService devSendService;

    @PostMapping("/dev")
    public AjaxResult addSend(){
        AjaxResult result=new AjaxResult();
        devSendService.devSend();
        return result;
    }

    /*@PostMapping("/update")
    public AjaxResult updateSend(){
        AjaxResult result=new AjaxResult();

        devSendService.updateSend();

        return result;
    }*/

    @PostMapping("/devs")
    public AjaxResult stringTest(@RequestBody JSONObject param){
        AjaxResult result=new AjaxResult();
        String aString=param.getString("aString");
        String sid=param.getString("sid");
        String ProtocolNo=param.getString("ProtocolNo");
        devSendService.sendDevs(aString,sid,ProtocolNo);
        return result;
    }


}
