package com.fei.springboot.config.paramchackconfig;

public interface Update {
}
