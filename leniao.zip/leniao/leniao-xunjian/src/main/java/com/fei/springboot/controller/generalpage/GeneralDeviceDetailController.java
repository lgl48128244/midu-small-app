package com.fei.springboot.controller.generalpage;

import com.alibaba.fastjson.JSON;
import com.fei.springboot.config.paramchackconfig.Add;
import com.fei.springboot.config.paramchackconfig.Update;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevty;
import com.fei.springboot.domain.generalpage.GeneralDevicedetail;
import com.fei.springboot.pojo.generalpage.detail.*;
import com.fei.springboot.service.generalpage.GeneralDeviceDetailService;
import com.fei.springboot.service.generalpage.GeneralDeviceService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.groups.Default;
import java.util.Arrays;
import java.util.List;

@CrossOrigin
@Slf4j
@Controller
@Validated
@RequestMapping(value = "/datil")
public class GeneralDeviceDetailController {

    //private Logger logger = LoggerFactory.getLogger(GeneralDeviceDetailController.class);

    @Autowired
    private GeneralDeviceDetailService generalDeviceDetailService;
    @Autowired
    private GeneralDeviceService generalDeviceService;



    /**
     * @Description: 新增设备详情页数据
     * @Author: haosw
     * @CreateDate: 2019/11/25 13:13
     * @UpdateUser: haosw
     * @UpdateDate: 2019/11/25 13:13
     * @UpdateRemark: 修改内容
     * @Version: 1.2
     * <p>
     * 异常抛给全局异常处理
     * 待校验:
     *      模态展示方式与模态图,测量范围的联合判断
     *      页面类型与数据展示区的联合判断
     */
    @PostMapping(value = "/insert")
    @ResponseBody
    public AjaxResult addDetailInfo(@RequestBody @Validated GeneralDevicedetailAllInputDto devicedetailAllDto) throws Exception {
        AjaxResult result = new AjaxResult();
        if (devicedetailAllDto.getModalType() != null && devicedetailAllDto.getModalType() > 1) {
            Integer minVal = devicedetailAllDto.getMinVal();
            Integer maxVal = devicedetailAllDto.getMaxVal();
            String unit = devicedetailAllDto.getUnit();
            if (minVal == null || maxVal == null || StringUtils.isEmpty(unit)) {
                result.addFail(" 测量范围不能为空");
                return result;
            }
        }

        //查看是否被绑定别的型号
        Tblndevty devty = this.generalDeviceService.findDevty(devicedetailAllDto.getDevTyId());
        if (devty == null) {
            result.addFail("此设备型号已不存在");
            return result;
        }
        Integer detailPageBind = devty.getDetailPageBind();
        //如果已绑定在了某个型号下
        if (detailPageBind != null && !detailPageBind.equals(0)) {
            result.addFail("该型号已绑定在了ID为:" + detailPageBind + " 的型号下,不可重复添加 ");
            return result;
        }
        //先判断是否存在同样的设备类型
        boolean exist = this.generalDeviceDetailService.findDevtyByTyId(devicedetailAllDto.getDevTyId());
        if (exist) {
            result.addFail("该型号的详情页配置信息已存在,不可重复添加");
            return result;
        }
        int flag = this.generalDeviceDetailService.insert(devicedetailAllDto);
        if (flag == -1) {
            result.addFail("初始化原有关联类型失败");
        } else if (flag == -2) {
            result.addFail("添加新的关联类型失败");
        } else if (flag > 0) {
            result.addSuccess("新增成功");
        } else {
            result.addFail("数据库异常,新增失败");
        }
        return result;
    }

    /**
    * 查询设备类型的详情页配置信息
    * @author      Haosw
    * @param       devTyId  --  设备类型ID主键
    * @return
    * @exception
    * @date        2019/11/26 10:05
    */
    @PostMapping(value = "/get")
    @ResponseBody
    public AjaxResult findDetailInfo(@NotNull(message = "设备型号ID不能为NUll")@RequestParam("devTyId") Integer devTyId) throws Exception {
        AjaxResult result = new AjaxResult();
        //先判断此型号绑定了在哪个主型号上
        Integer pId = this.generalDeviceDetailService.findParentDevtyId(devTyId);
        //如果有绑定
        if (pId != null && !pId.equals(0)) {
            devTyId = pId;
        }
        GeneralDevicedetailAllOutputDto outputDto = this.generalDeviceDetailService.findDevtyDetailInfo(devTyId);
        if (outputDto == null) {
            result.addFail("没有该型号的基本信息,请先添加此设备类型");
            return result;
        }else {
            result.addSuccess("查询成功");
            result.setData(outputDto);
        }
        return result;
    }

    /**
    * 详情页配置更新接口
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/11/29 09:48
    */
    @PostMapping(value = "/update")
    @ResponseBody
    public AjaxResult updateDetailInfo(@RequestBody @Validated({Update.class, Default.class}) GeneralDevicedetailAllInputDto allInputDto){
        AjaxResult result = new AjaxResult();
        //先判断此型号绑定了在哪个主型号上
        Integer pId = this.generalDeviceDetailService.findParentDevtyId(allInputDto.getDevTyId());
        //如果有绑定
        if (pId != null && !pId.equals(0)) {
            allInputDto.setDevTyId(pId);
        }
        int flag = this.generalDeviceDetailService.update(allInputDto);
        if (flag == -1) {
            result.addFail("初始化原有关联类型失败");
        } else if (flag == -2) {
            result.addFail("添加新的关联类型失败");
        } else if (flag > 0) {
            result.addSuccess("更新成功");
        } else {
            result.addFail("数据库异常,更新失败");
        }
        return result;
    }

    /**
    * 解析型号的母版数据
    * @author      Haosw
    * @return
    * @exception
    * @date        2019/11/29 11:21
    */
    @PostMapping(value = "/decodeTemplate")
    @ResponseBody
    public AjaxResult decodeMotherTemplate(@NotNull(message = "设备型号ID不能为NULL")
                                           @Min (value = 1, message = "型号ID值最小为 {value}")
                                           @RequestParam("devTyId")Integer devTyId){

        AjaxResult result = new AjaxResult();
        //先判断是被绑定
        //先判断此型号绑定了在哪个主型号上
        Integer pId = this.generalDeviceDetailService.findParentDevtyId(devTyId);
        //如果有绑定
        if (pId != null && !pId.equals(0)) {
            devTyId = pId;
        }
        String templateListStr = this.generalDeviceService.decodeMotherTemplate(devTyId);
        if (StringUtils.isBlank(templateListStr)){
            result.addFailWithArray("没有此类型的模板数据");
            return result;
        }
        List<JsonMatherTemplate> templateList;
        try {
            templateList = JSON.parseArray(templateListStr, JsonMatherTemplate.class);
            templateList.stream().forEach(t -> t.setSelected(0));
            //获取该型号已保存
            String savedJson = this.generalDeviceDetailService.findChartsDetailInfo(devTyId);
            if (StringUtils.isNotBlank(savedJson)) {
                List<AxisInputDto> charts = JSON.parseArray(savedJson, AxisInputDto.class);
                templateList.stream().forEach(t -> {
                    charts.stream().forEach(c -> {
                        String lNodes = c.getLNodes();
                        String rNodes = c.getRNodes();
                        if (StringUtils.isNotBlank(lNodes)) {
                            String[] lsplit = lNodes.split("-");
                            List<String> lList = Arrays.asList(lsplit);
                            if (lList.contains(t.getNodeName())) {
                                t.setSelected(1);
                            }
                        }
                        if (StringUtils.isNotBlank(rNodes)) {
                            String[] rsplit = rNodes.split("-");
                            List<String> rList = Arrays.asList(rsplit);
                            if (rList.contains(t.getNodeName())) {
                                t.setSelected(1);
                            }
                        }
                    });
                });
            }
        } catch (Exception e) {
            log.debug("解析json母版数据异常,设备型号 devTyId: "+ devTyId,e);
            result.addFailWithArray("该型号模板数据解析异常");
            return result;
        }

        if (CollectionUtils.isNotEmpty(templateList)) {
            result.addSuccess("查询成功");
            result.setData(templateList);
        }else {
            result.addFailWithArray("没有数据");
        }
        return result;
    }

    @PostMapping("/testValidator")
    @ResponseBody
    public AjaxResult testValidator(@RequestBody @Validated GeneralDevicedetail boday){
        AjaxResult result = new AjaxResult();


        return result;
    }



}
