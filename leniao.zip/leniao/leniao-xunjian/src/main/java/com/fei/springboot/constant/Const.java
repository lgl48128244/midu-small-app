package com.fei.springboot.constant;

public interface Const {

    //Hbase开始存储数据的时间
    String HBASE_START_STORAGE_TIME = "20190101000000";
    int UPLOAD_FILE_SIZE = 20;//图片上传的时候判断最大不得超过20MB
    int CONFIG_FILE_SIZE = 50;//SpringBoot配置单个最大文件为50MB
    int VIO_SIZE0 = 50;//SpringBoot配置单个最大文件为50MB

    /*
    权限相关
     */

    int USERTYPE_AREA = 2;
    int USERTYPE_SINGLE = 1;
    int USERTYPE_NON = 0;

    //潍坊-山东铭之泽单位的创建人id
    Integer MZZ_USERID = 12802;

    /**
     * 乐鸟配置
     */
    // 正式版上--获取萤石token的uri    测试版上的是8090
    String TEST_GET_TOKEN_URI = "http://39.106.219.106:8097/api/v2/DeviceOfVideo/GetToken";
    //产生巡检点编号的前缀---乐鸟---巡检点
    String XJ_POINT_CODE = "LN-Pt-";
    //产生巡检线路编号的前缀---乐鸟---巡检线路
    String XJ_LINE_CODE = "LN-L-";
    //产生巡检计划编号的前缀---乐鸟---巡检计划
    String XJ_PLAIN_CODE = "LN-Pl-";


    //获取设备实时值的路径
    String REAL_TIME_DEVICE_INFO_URL = "https://yjkpt.net/Terminal2/LN_RealVar.asmx/selectRealValListApi";
    //第三方对设备进行复位操作的url--不需要token
    String RESET_DEVICE_URL_WITHOUT_TOKEN = "39.106.219.106:8090/api/V2/ThirdPlatformRemote/ResetOfNonIot";
    //我们平台对设备进行复位,需要token
    String RESET_DEVICE_URL = "https://yjkpt.net/Terminal2/LN_Operation.asmx/ResetApi";

    //设备漏保自检地址
    String SELF_TEST_URL = "http://39.106.219.106:8080/leniaorestful/leniaonbiotcommand/sendLpsiCommand/%s/%s";
    //打开或关闭设备
    String OPREATE_DEVICE_URL = "http://39.106.219.106:8080/leniaorestful/leniaonbiotcommand/sendDropOutCommand/%s/%s";

    //导出单位用电设备电量间隔时间
    int ELE_WAIT_TIME = 3;

    //-------------------------------------------------------------------------------------------------------
    //阿里redis
    String ALI_REDIS_URL = "127.0.0.1";         //正式用
    //String ALI_REDIS_URL = "39.96.73.124";   //测试用


    /**
     * 此路径为测试服务器使用(124)
     */
   /* //新图片站点,用于前端画布,防止出现跨域问题
    String NEW_PIC_SITE_URL = "http://testapi.lny119.com/";                          //测试服务器站点ip
    //新图片站点,物理路径---程序中要记得加上\\yyyy-MM-dd\\uuid.png
    String NEW_PIC_SAVE_PATH = "C:\\Website\\newImageSite\\";                        //测试服务器上的物理路径
    //调用leniao-news的新增处理单的功能
    String FORM_INSERT_URL = "http://localhost:8080/leniao-news/rpc/forminsert";      //测试服务器用
    //巡检步骤二维码存放路径
    String XJ_ERWEIMA_SAVE_URL = "C:\\WebSite\\newImageSite\\xunjian\\";             //测试服务器(124)
    //巡检二维码访问路径
    String XJ_ERWEIMA_VIEW_URL = "http://testapi.lny119.com/xunjian/";               //测试服务器ip
    //电量使用信息excel保存物理路径
    String ELE_USE_INFO_SAVE_PATH = "C:\\WebSite\\newImageSite\\ExcelOfEleUseInfo\\"; //测试
    //电量使用excel所在的附件站点url
    String ELE_USE_INFO_FJ_URL = "http://testapi.lny119.com/ExcelOfEleUseInfo/";      //测试
*/
    /**
     * 此路径为正式服务器使用(106)
     */
    //巡检步骤二维码存放路径
    String XJ_ERWEIMA_SAVE_URL = "E:\\WebSite\\leniao_pic\\xunjian\\";
    //巡检二维码访问路径
    String XJ_ERWEIMA_VIEW_URL = "http://fj.yjkpt.net/xunjian/";
    //调用leniao-news的新增处理单的功能
    String FORM_INSERT_URL = "http://localhost:8111/rpc/forminsert";         //正式服务器用
    //新图片站点,用于前端画布,防止出现跨域问题
    String NEW_PIC_SITE_URL = "http://lnpic.yjkpt.net/";                     //正式服务器站点ip
    //新图片站点,物理路径---程序中要记得加上\\yyyy-MM-dd\\uuid.png
    String NEW_PIC_SAVE_PATH = "E:\\WebSite\\newImageSite\\";                //正式服务器上的物理路径
    //电量使用信息excel保存物理路径
    String ELE_USE_INFO_SAVE_PATH = "E:\\WebSite\\leniao_pic\\ExcelOfEleUseInfo\\";//正式上用E盘
    //电量使用excel所在的附件站点url
    String ELE_USE_INFO_FJ_URL = "http://fj.yjkpt.net/ExcelOfEleUseInfo/";//电量excel保存的站点路径

//--------------------------------------------------------------------------------------------------------

    //调用.net的接口获取电话卡的信息
    String DOTNET_GET_PHONECARD_INFO = "https://yjkpt.net/Terminal2/LN_Operation.asmx/SelectDevicePhoneCardApi";
    //远程操控断路器--一键操作提交任务
    String BREAKDEVICE_TASK_OF_SUBMIT_URL = "http://39.106.219.106:8080/leniaorestful/processizeCommand/batchOperation2";
    //String BREAKDEVICE_TASK_OF_SUBMIT_URL = "http://39.96.73.124:8182/leniaorestful/processizeCommand/batchOperation2";
    //提交漏保自检任务
    String BREAKDEVICE_SELF_TEST_SUBMIT_URL = "http://39.106.219.106:8080/leniaorestful/circuitBreaker/sendLpsiCommand";
    //远程操控断路器--轮询一键操作任务结果 || 轮询漏保自检任务结果
    String BREAKDEVICE_POLLING_OF_QUERY_URL = "http://39.106.219.106:8080/leniaorestful/processizeCommand/checkBatchOperation";
    //String BREAKDEVICE_POLLING_OF_QUERY_URL = "http://39.96.73.124:8182/leniaorestful/processizeCommand/checkBatchOperation";


    /*****************************************************************************************************


     /**
     * 爱德配置
     */
    /*// 正式版上--获取萤石token的uri    测试版上的是8090
     String TEST_GET_TOKEN_URI = "http://localhost:8097/api/v2/DeviceOfVideo/GetToken";
    //产生巡检点编号的前缀---乐鸟---巡检点
     String XJ_POINT_CODE = "EIT-Pt-";
    //产生巡检线路编号的前缀---乐鸟---巡检线路
     String XJ_LINE_CODE = "EIT-L-";
    //产生巡检计划编号的前缀---乐鸟---巡检计划
     String XJ_PLAIN_CODE = "EIT-Pl-";
    //巡检步骤二维码存放路径
     String XJ_ERWEIMA_SAVE_URL = "C:\\aide-Website\\API_FJ\\xunjian\\";
    //巡检二维码访问路径
     String XJ_ERWEIMA_VIEW_URL = "http://fj.eit119.net/xunjian/";
    //阿里redis
     //String ALI_REDIS_URL = "r-bp1e242fb75b2ea4.redis.rds.aliyuncs.com";
     String ALI_REDIS_URL = "127.0.0.1";

    //获取设备实时值的路径
    public static  final String REAL_TIME_DEVICE_INFO_URL = "47.98.47.61:8097/Terminal2/LN_RealVar.asmx/selectRealValListApi";
    //第三方对设备进行复位操作的url--不需要token
     String RESET_DEVICE_URL_WITHOUT_TOKEN =  "47.98.47.61:8097/api/V2/ThirdPlatformRemote/ResetOfNonIot";
    //爱德平台对设备进行复位,需要token
     String RESET_DEVICE_URL =  "47.98.47.61:8097/Terminal2/LN_Operation.asmx/ResetApi";
    //调用leniao-news的新增处理单的功能
     String FORM_INSERT_URL =  "http://localhost:8080/leniao-news/rpc/forminsert";  //正式服务器用
    //设备漏保自检地址
     String SELF_TEST_URL = "";

    //打开或关闭设备
     String OPREATE_DEVICE_URL = "localhost:8080/leniaorestful/leniaonbiotcommand/sendDropOutCommand/%s/%s";

    //TODO 如果发布爱德的版本,记得确认以下接口和站点是是否都已存在是否都配置正确
    //新图片站点的物理路径---程序中要记得加上\\yyyy-MM-dd\\uuid.png
    // String NEW_PIC_SAVE_PATH = "C:\\aide-Website\\newImageSite\\";//测试服务器上的物理路径
     String NEW_PIC_SAVE_PATH = "C:\\aide-Website\\newImageSite\\";//正式服务器上的物理路径

    //新图片站点,用于前端画布,防止出现跨域问题
    // String NEW_PIC_SITE_URL = "http://pics.eit119.net/";//测试服务器站点ip
     String NEW_PIC_SITE_URL = "http://pics.eit119.net/";//正式服务器站点ip

    //调用.net的接口获取电话卡的信息
     String DOTNET_GET_PHONECARD_INFO = "47.98.47.61:8097/Terminal2/LN_Operation.asmx/SelectDevicePhoneCardApi";

    //远程操控断路器--提交任务
      String BREAKDEVICE_TASK_OF_SUBMIT_URL = "http://47.98.47.61:8080/leniaorestful/processizeCommand/batchOperation2";
    //提交漏保自检任务
     String BREAKDEVICE_SELF_TEST_SUBMIT_URL = "http://47.98.47.61:8080/leniaorestful/circuitBreaker/sendLpsiCommand";
    //远程操控断路器--轮询一键操作任务结果 || 轮询漏保自检任务结果
     String BREAKDEVICE_POLLING_OF_QUERY_URL = "http://47.98.47.61:8080/leniaorestful/processizeCommand/checkBatchOperation";

      //电量excel保存路径  --- 2020-04-21 待测试
     String XJ_ERWEIMA_SAVE_URL = "C:\\aide-Website\\API_FJ\\ExcelOfEleUseInfo\\";
    //电量excel站点访问路径
     String XJ_ERWEIMA_VIEW_URL = "http://fj.eit119.net/ExcelOfEleUseInfo/";
*/
}
