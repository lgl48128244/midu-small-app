package com.fei.springboot.controller.common;

import cn.afterturn.easypoi.excel.annotation.Excel;

import java.util.Objects;

/**
 * 用于子设备导入的包装Excel中数据的类
 */
public class ChildDevicePoiInputDto {

    @Excel(name = "主机编码", orderNum = "1")
    private String devSignaure;//设备编码

    @Excel(name = "回路号", orderNum = "2")
    private Integer roadNo;//设备回路号1,2,3,4,5,6  对应设备表的road

    @Excel(name = "地址号", orderNum = "3")
    private Integer addressNo;//设备的地址号  1,2,3,4,5,6 对应设备表的devId

    @Excel(name = "设备类型", orderNum = "4")
    private String devTy;//设备类型

    @Excel(name = "安装位置", orderNum = "5")
    private String installLocation;//安装位置

    public ChildDevicePoiInputDto() {
    }

    public ChildDevicePoiInputDto(String devSignaure, Integer roadNo, Integer addressNo, String devTy, String installLocation) {
        this.devSignaure = devSignaure;
        this.roadNo = roadNo;
        this.addressNo = addressNo;
        this.devTy = devTy;
        this.installLocation = installLocation;
    }

    public String getDevSignaure() {
        return devSignaure;
    }

    public void setDevSignaure(String devSignaure) {
        this.devSignaure = devSignaure;
    }

    public Integer getRoadNo() {
        return roadNo;
    }

    public void setRoadNo(Integer roadNo) {
        this.roadNo = roadNo;
    }

    public Integer getAddressNo() {
        return addressNo;
    }

    public void setAddressNo(Integer addressNo) {
        this.addressNo = addressNo;
    }

    public String getDevTy() {
        return devTy;
    }

    public void setDevTy(String devTy) {
        this.devTy = devTy;
    }

    public String getInstallLocation() {
        return installLocation;
    }

    public void setInstallLocation(String installLocation) {
        this.installLocation = installLocation;
    }

    @Override
    public String toString() {
        return "ChildDevicePoiInputDto{" +
                "devSignaure='" + devSignaure + '\'' +
                ", roadNo=" + roadNo +
                ", addressNo=" + addressNo +
                ", devTy='" + devTy + '\'' +
                ", installLocation='" + installLocation + '\'' +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChildDevicePoiInputDto dto = (ChildDevicePoiInputDto) o;
        return Objects.equals(devSignaure, dto.devSignaure) &&
                Objects.equals(roadNo, dto.roadNo) &&
                Objects.equals(addressNo, dto.addressNo) &&
                Objects.equals(devTy, dto.devTy) &&
                Objects.equals(installLocation, dto.installLocation);
    }

    @Override
    public int hashCode() {

        return Objects.hash(devSignaure, roadNo, addressNo, devTy, installLocation);
    }
}
