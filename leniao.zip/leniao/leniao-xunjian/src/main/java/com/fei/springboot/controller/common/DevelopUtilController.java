package com.fei.springboot.controller.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.util.redis.RedisUtil;
import org.jboss.netty.handler.ipfilter.OneIpFilterHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/develop")
public class DevelopUtilController {

    @RequestMapping(value = "/api/access/list")
    public List<JSONObject> getApiAccessTime(@RequestParam(value = "reset",required = false) boolean reset,
                                             @RequestParam(value = "type") Integer type){

        RedisUtil instance = RedisUtil.getInstance();
        if (reset) {
            RedisUtil.Keys keys = instance.keys();
            keys.del("ApiAccessTime:news");
            keys.del("ApiAccessTime:xunjian");

            return new ArrayList<JSONObject>(){{
                add(new JSONObject(){{
                    put("result", "记录已清空");
                }});
            }};
        }

        if (type == 1) {
            Map<String, String> map = instance.hash().hgetAll("ApiAccessTime:news");
            return  new ArrayList<JSONObject>(){{
                add(new JSONObject(){{
                    put("result",map);
                }});
            }};
        }
        if (type == 2) {
            Map<String, String> map = instance.hash().hgetAll("ApiAccessTime:xunjian");
            return  new ArrayList<JSONObject>(){{
                add(new JSONObject(){{
                    put("result",map);
                }});
            }};
        }
        if (type == 3) {
            Map<String, String> map1 = instance.hash().hgetAll("ApiAccessTime:news");
            Map<String, String> map2 = instance.hash().hgetAll("ApiAccessTime:xunjian");
            map1.putAll(map2);
            return  new ArrayList<JSONObject>(){{
                add(new JSONObject(){{
                    put("result",map1);
                }});
            }};
        }


        return new ArrayList<JSONObject>(){{
            add(new JSONObject(){{
                put("result","参数类型不匹配,请携带参数type=1或2或3,1:news项目接口耗时,2:xunjian,3:两者都有");
            }});
        }};
    }


}
