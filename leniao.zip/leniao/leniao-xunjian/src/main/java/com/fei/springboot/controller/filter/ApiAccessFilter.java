package com.fei.springboot.controller.filter;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.util.DateUtil;
import com.fei.springboot.util.redis.RedisUtil;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

@WebFilter(filterName = "ApiAccessFilter", urlPatterns = "/*")
public class ApiAccessFilter implements Filter {


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;

        long start = System.currentTimeMillis(); // 请求进入时间
        String requestURI = request.getRequestURI();
        String ip = getIP(request);
        filterChain.doFilter(servletRequest, servletResponse);
        long l = System.currentTimeMillis() - start;
        String hget = RedisUtil.getInstance().hash().hget("ApiAccessTime:" + "xunjian", requestURI);
        if (StringUtils.isNotBlank(hget)) {
            JSONObject jsonObject = JSON.parseObject(hget);
            long aLong = jsonObject.getLongValue("long");
            jsonObject.put("count",jsonObject.getIntValue("count") + 1);
            if (l > aLong) {
                jsonObject.put("long", l);
            }
            RedisUtil.getInstance().hash().hset("ApiAccessTime:" + "xunjian", requestURI, jsonObject.toJSONString());
        } else {
            RedisUtil.getInstance().hash().hset("ApiAccessTime:" + "xunjian",  requestURI, JSON.toJSONString(new HashMap<String, Object>() {{
                put("uri", requestURI);
                put("ip", ip);
                put("long", l);
                put("count",1);
                put("addTime", DateUtil.formartDateTimeToString(new Date()));
            }}));
        }


    }

    @Override
    public void destroy() {

    }

    /**
     * 获取IP地址
     *
     * @param request 请求
     * @return request发起客户端的IP地址
     */
    private String getIP(HttpServletRequest request) {
        if (request == null) {
            return "0.0.0.0";
        }

        String Xip = request.getHeader("X-Real-IP");
        String XFor = request.getHeader("X-Forwarded-For");

        String UNKNOWN_IP = "unknown";
        if (StringUtils.isNotEmpty(XFor) && !UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            //多次反向代理后会有多个ip值，第一个ip才是真实ip
            int index = XFor.indexOf(",");
            if (index != -1) {
                return XFor.substring(0, index);
            } else {
                return XFor;
            }
        }

        XFor = Xip;
        if (StringUtils.isNotEmpty(XFor) && !UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            return XFor;
        }

        if (StringUtils.isBlank(XFor) || UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isBlank(XFor) || UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isBlank(XFor) || UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_CLIENT_IP");
        }
        if (StringUtils.isBlank(XFor) || UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (StringUtils.isBlank(XFor) || UNKNOWN_IP.equalsIgnoreCase(XFor)) {
            XFor = request.getRemoteAddr();
        }
        return XFor;
    }

}
