package com.fei.springboot.controller.elemonitor;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.elemonitor.EleMonDevmodel;
import com.fei.springboot.domain.elemonitor.EleMonDevnodeinfo;
import com.fei.springboot.domain.elemonitor.EleMonGateinfo;
import com.fei.springboot.domain.fault.Tblnrealtimefaultinfo;
import com.fei.springboot.domain.fault.Tblnrealtimewarninfo;
import com.fei.springboot.pojo.elemonitor.*;
import com.fei.springboot.service.elemonitor.GateService;
import com.fei.springboot.service.ushare.DeviceService;
import com.fei.springboot.util.DateUtil;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/elemon")
public class GateController {

    @Autowired
    private GateService gateService;
    @Autowired
    private DeviceService deviceService;


    /**
     * 获取空开设备的详细信息--编辑前的查询
     *
     * @param param
     * @return
     */
    @PostMapping("/gate/view")
    public AjaxResult beforEdit(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer gateId = param.getInteger("gateId");
        Integer unitId = param.getInteger("unitId");
        if (gateId == null || unitId == null) {
            result.addFail("空开Id或单位Id不能为空");
            return result;
        }
        //获取空气开关的信息
        GateInfoOutputDto gateOutDto = this.gateService.findGateOutDtoById(gateId);
        if (gateOutDto != null) {
            Integer devIdpk = gateOutDto.getDevIdpk();
            DeviceSysInfoDto sysInfoDto = null;
            List<EleMonDevmodel> models = new ArrayList<>();
            if (devIdpk != null) {
                //获取设备的信息
                sysInfoDto = this.deviceService.findDeviceSysInfo(devIdpk);
                //获取设备显示模型的信息
                models = this.gateService.getDeviceNodeModel(devIdpk);

               // models.addAll(model);
            }
            JSONObject json = new JSONObject();
            json.put("gateInfo", gateOutDto);
            json.put("sysInfo", sysInfoDto);
            json.put("models", models);
            result.addSuccess("查询成功");
            result.setData(json);
        } else {
            result.addFail("没有数据");
        }
        return result;
    }


    /**
     * 编辑空开信息
     *
     * @param gateinfo
     * @return
     */
    @PostMapping(value = "/gate/edit")
    public AjaxResult updateGate(@RequestBody @Valid EleMonGateinfo gateinfo, HttpServletRequest request) {
        String contentType = request.getContentType();
        AjaxResult result = new AjaxResult();
        if (gateinfo.getDrawId()== 0){
            result.addFail("所属图示id不能为0");
            result.setData("contentType:" + contentType);
            return result;
        }
        //查询绑定设备是否合法
        Integer devIdpk = gateinfo.getDevIdpk();
        if (null != devIdpk) {
            EleMonGateinfo seamDevGate = this.gateService.findGateByDevIdpk(devIdpk);
            if (seamDevGate != null && !seamDevGate.getGateId().equals(gateinfo.getGateId())) {
                result.addFail("保存失败,此设备已被绑定");
                return result;
            }
        }
        //根据上传的名称查询
        try {
            if (gateinfo.getGateId() == null) {
                //走新增功能,返回自增主键
                //查询是否存在同名的空开
                if (StringUtils.isEmpty(gateinfo.getGateName())) {
                    result.addFail("空气开关的名称不能为空");
                    return result;
                }
               /* EleMonGateinfo oldGate = this.gateService.findGateByName(gateinfo.getGateName(), gateinfo.getUnitId());
                if (oldGate != null) {
                    result.addFail("开关的名称已存在,请更名");
                    return result;
                }*/

                int flag = this.gateService.insert(gateinfo);
                if (flag > 0) {
                    result.addSuccess("添加成功");
                    result.setData(gateinfo.getGateId());
                } else {
                    result.addFail("添加失败");
                }
                return result;
            } else {
                //走更新功能
               /* EleMonGateinfo oldGate = this.gateService.findGateByName(gateinfo.getGateName(), gateinfo.getUnitId());
                if (oldGate != null && !oldGate.getGateId().equals(gateinfo.getGateId())) {
                    result.addFail("开关的名称已存在,请更名");
                    return result;
                }*/

                int flag = this.gateService.updateSelective(gateinfo);
                if (flag > 0) {
                    result.addSuccess("操作成功");
                    result.setData(gateinfo.getGateId());
                } else {
                    result.addFail("操作失败");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;
    }

    /**
     * 根据设备id查询节点信息
     *
     * @param param
     * @return
     */
    @PostMapping(value = "/gate/devnodes")
    public AjaxResult getDeviceNodes(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        //Integer bType = param.getInteger("bType");
        Integer devIdpk = param.getInteger("devIdpk");
        if (devIdpk == null) {
            result.addFailWithArray("设备id不能为空");
            return result;
        }
        //先根据设备id查询设备的btype
        Integer bType = this.gateService.findDevBType(devIdpk);
        //获取所有支持的bType
        List<Integer> bTypes = this.gateService.findAllEnableBtype();
        if (bType == null || !bTypes.contains(bType)) {
            result.addFailWithArray("此设备不在监控范围内,不能绑定");
            return result;
        }
        //先去模型表中查询曾经的模型编辑记录
        List<EleMonDevmodel> modelList = this.gateService.getDeviceNodeModel(devIdpk);
        //获取去btype下的所有节点信息
        List<EleMonDevnodeinfo> nodes = this.gateService.getDeviceNodes(bType);
        if (CollectionUtils.isEmpty(nodes)) {
            result.addFailWithArray("没有获取到节点信息,不能绑定");
            return result;
        }

        //如果有编辑模型,且数量与节点信息一样则证明编辑模型中的节点信息是全面的,返回前端
        if (CollectionUtils.isNotEmpty(modelList) && modelList.size() == nodes.size()) {
            List<ModelListInfo> modelListInfos = this.sortedModeList(modelList);
            result.addSuccess("查询成功");
            result.setData(modelListInfos);
            return result;
        } else if (CollectionUtils.isNotEmpty(modelList) && modelList.size() != nodes.size()) {
            //此处默认为有可能会往节点信息表中添加数据,即  nodes > nodelList  如果出现节点信息表中的数据小于模型表数据,请手动解除绑定
            //模型中的节点信息不全,要补充
            List<String> nodeNameList = modelList.stream().map(a -> a.getNodeName()).collect(Collectors.toList());
            Iterator<EleMonDevnodeinfo> iterator = nodes.iterator();
            while (iterator.hasNext()) {
                EleMonDevnodeinfo next = iterator.next();
                if (nodeNameList.contains(next.getDevNode())) {
                    iterator.remove();
                }
            }
            //保存到数据库
            try {
                List<EleMonDevmodel> newModels = this.gateService.insertDeviceModels(devIdpk, nodes);
                modelList.addAll(newModels);
                List<ModelListInfo> modelListInfos = this.sortedModeList(modelList);
                result.addSuccess("查询成功");
                result.setData(modelListInfos);
            } catch (Exception e) {
                e.printStackTrace();
                result.addFailWithArray("程序异常");
            }
            return result;
        }
        try {
            if (CollectionUtils.isNotEmpty(nodes)) {//给模型显示表插入数据
                modelList = this.gateService.insertDeviceModels(devIdpk, nodes);
                List<ModelListInfo> modelListInfos = this.sortedModeList(modelList);
                result.addSuccess("查询成功");
                result.setData(modelListInfos);
            } else {
                result.addFail("设备类型不匹配，查询失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;
    }

    //对设备的节点信息进行排序并格式化
    private  List<ModelListInfo> sortedModeList(List<EleMonDevmodel> list){
        //漏电
        List<EleMonDevmodel> l = list.stream().filter(dto -> dto.getNodeName().contains("L")).collect(Collectors.toList());
        l = l.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName)).collect(Collectors.toList());
        //温度
        List<EleMonDevmodel> t = list.stream().filter(dto -> dto.getNodeName().contains("T")).collect(Collectors.toList());
        t = t.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName).reversed()).collect(Collectors.toList());
        //电压
        List<EleMonDevmodel> v = list.stream().filter(dto -> dto.getNodeName().contains("V")).collect(Collectors.toList());
        v = v.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName)).collect(Collectors.toList());
        //电流
        List<EleMonDevmodel> i = list.stream().filter(dto -> dto.getNodeName().contains("I")).collect(Collectors.toList());
        i = i.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName)).collect(Collectors.toList());
        //电量
        List<EleMonDevmodel> q = list.stream().filter(dto -> dto.getNodeName().contains("Q")).collect(Collectors.toList());
        q = q.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName)).collect(Collectors.toList());
        //功率
        List<EleMonDevmodel> p = list.stream().filter(dto -> dto.getNodeName().contains("P")).collect(Collectors.toList());
        p = p.stream().sorted(Comparator.comparing(EleMonDevmodel::getNodeName)).collect(Collectors.toList());

        //Map<String,List<EleMonDevmodel>> map = new HashMap();
        ModelListInfo listL = new ModelListInfo("漏电",l);
        ModelListInfo listT = new ModelListInfo("温度",t);
        ModelListInfo listV = new ModelListInfo("电压",v);
        ModelListInfo listI = new ModelListInfo("电流",i);
        ModelListInfo listQ = new ModelListInfo("电量",q);
        ModelListInfo listP = new ModelListInfo("功率",p);

        List<ModelListInfo> reList = new ArrayList<ModelListInfo>(){{
            add(listL);
            add(listT);
            add(listV);
            add(listI);
            add(listQ);
            add(listP);

        }};

        return reList;


    }




    /**
     * 编辑数据模型
     *
     * @return
     */
    @PostMapping("/model/edit")
    public AjaxResult editModelInfo(@RequestBody @Valid DeviceModelInfoInputDto modelsDto) {
        AjaxResult result = new AjaxResult();
        //修改
        try {
            int flag = this.gateService.updateDeviceModelInfo(modelsDto.getDevmodels());
            if (flag > 0) {
                result.addSuccess("更新显示模型成功");
            } else result.addFail("更新显示模型失败");
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("程序异常");
        }
        return result;
    }


    /**
     * 查询可作为上级的空开
     * @param param
     * @return
     */
    @PostMapping("/gate/relation")
    public AjaxResult findOtherDevice(@RequestBody JSONObject param) {
        AjaxResult ajaxResult = new AjaxResult();
        Integer gateId = param.getInteger("gateId");
        Integer drawId = param.getInteger("drawId");

        if (drawId == null) {
            ajaxResult.addFail("当前图纸的主键id不能为空");
            return ajaxResult;
        }
        List<EleMonGateinfo> list;
        if (gateId != null) {
            EleMonGateinfo gate = this.gateService.findGateByPrimaryKey(gateId);
            Integer unitId = gate.getUnitId();
            list = this.gateService.findOtherGatesExcPC(unitId,gateId,drawId);
        }else{
            list = this.gateService.findGateListByDrawID(drawId);
        }
        if (CollectionUtils.isNotEmpty(list)){
            ajaxResult.addSuccess("查询成功");
            ajaxResult.setData(list);
        }
        else ajaxResult.addFail("没有数据");

        return ajaxResult;
    }


    /**
     * 解除设备的绑定
     * @param param
     * @return
     */
    @PostMapping("/gate/unbind")
    public AjaxResult unbind(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer devIdpk = param.getInteger("devIdpk");
        Integer gateId = param.getInteger("gateId");
        if (devIdpk == null || gateId == null) {
            result.addFail("devIdpk 或 gateId 不能为空");
            return result;
        }
        EleMonGateinfo gate = this.gateService.findGateByPrimaryKey(gateId);
        if (null == gate.getDevIdpk()) {
            result.addSuccess("当前空开没有绑定设备无需解绑");
            return result;
        }
        if (!gate.getDevIdpk().equals(devIdpk)) {
            result.addFail("当前空开绑定的不是此设备");
            return result;
        }
        gate.setDevIdpk(null);
        gate.setDevSignature(null);
        int update = this.gateService.updateUnSelective(gate);
        if (update > 0)
            result.addSuccess("解除绑定成功");
        else
            result.addFail("解除绑定失败");
        return result;
    }


    /**
     * 获取空开设备相关信息
     * @param param
     * @return
     */
    @PostMapping("/gate/deviceinfo")
    public AjaxResult deviceInfo(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        //Integer devIdpk = param.getInteger("devIdpk");
        Integer gateId = param.getInteger("gateId");
        if (gateId == null) {
            result.addFail("空开id不能为空");
            return result;
        }
        EleMonGateinfo gate = this.gateService.findGateByPrimaryKey(gateId);
        if (gate == null) {
            result.addFail("空开不存在,请刷新重试");
            return result;
        }
        RightItemDevInfo outPut = new RightItemDevInfo();
        BeanUtils.copyProperties(gate,outPut);
        //查找当前设备的管理人
        if (gate.getDevIdpk() != null) {
            List<ManageUser> users = this.gateService.findDeviceManagers(gate.getDevIdpk());
            outPut.setUsers(users);
        }
        DeviceItem device = new DeviceItem();
        if (gate.getDevIdpk() != null) {
            device  = this.gateService.findDeviceItemInfo(gate.getDevIdpk());
            outPut.setDevice(device);
        }
        result.addSuccess("查询成功");
        result.setData(outPut);
        return result;
    }


    /**
     * 查询设备模型的数据
     * @param param
     * @return
     */
    @PostMapping("/gate/devmodel")
    public AjaxResult getDeviceModel(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        //
        Integer devIdpk = param.getInteger("devIdpk");
        if (devIdpk == null) {
            result.addFail("设备id不能为空");
            return result;
        }
        List<DeviceModelInfoOutDto> list = this.gateService.findDeviceModelValue(devIdpk);
        //查找此设备的所有所有故障和所有异常
        List<Tblnrealtimefaultinfo> faultList = this.gateService.findRealTimeFaultByDevIdpk(devIdpk);
        List<String> fualtNodes = faultList.stream().map(f -> f.getFaultNode1()).collect(Collectors.toList());
        List<Tblnrealtimewarninfo> warnList = this.gateService.findRealTimeWarnByDevIdpk(devIdpk);
        List<String> warnNodes = warnList.stream().map(w -> w.getWarnNode1()).collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(list)) {
            for (DeviceModelInfoOutDto dto : list) {
                if (fualtNodes.contains(dto.getNodeName())) {
                    dto.setIsFault(1);
                    /*Tblnrealtimefaultinfo faultinfo = faultList.stream().filter(f -> f.getFaultNode1().equals(dto.getNodeName())).findFirst().get();
                    dto.setErrNode(faultinfo.getFaultNode1());
                    dto.setErrType(faultinfo.getFaultTy());
                    dto.setDate(DateUtil.formartDateToString(faultinfo.getFaultTime()));*/
                    //dto.setDevTyId();
                }
                if (warnNodes.contains(dto.getNodeName())) {

                    dto.setIsWarn(1);
                }
            }
            //漏电
            List<DeviceModelInfoOutDto> l = list.stream().filter(dto -> dto.getNodeName().contains("L")).collect(Collectors.toList());
            l = l.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());
            //温度
            List<DeviceModelInfoOutDto> t = list.stream().filter(dto -> dto.getNodeName().contains("T")).collect(Collectors.toList());
            t = t.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());
            //电压
            List<DeviceModelInfoOutDto> v = list.stream().filter(dto -> dto.getNodeName().contains("V")).collect(Collectors.toList());
            v = v.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());
            //电流
            List<DeviceModelInfoOutDto> i = list.stream().filter(dto -> dto.getNodeName().contains("I")).collect(Collectors.toList());
            i = i.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());
            //电量
            List<DeviceModelInfoOutDto> q = list.stream().filter(dto -> dto.getNodeName().contains("Q")).collect(Collectors.toList());
            q = q.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());
            //功率
            List<DeviceModelInfoOutDto> p = list.stream().filter(dto -> dto.getNodeName().contains("P")).collect(Collectors.toList());
            p = p.stream().sorted(Comparator.comparing(DeviceModelInfoOutDto::getNodeName)).collect(Collectors.toList());

            //Map<String,List<DeviceModelInfoOutDto>> map = new HashMap();
            ModelValueListInfo infoL = new ModelValueListInfo("L",l);
            ModelValueListInfo infoT = new ModelValueListInfo("T",t);
            ModelValueListInfo infoV = new ModelValueListInfo("V",v);
            ModelValueListInfo infoI = new ModelValueListInfo("I",i);
            ModelValueListInfo infoQ = new ModelValueListInfo("Q",q);
            ModelValueListInfo infoP = new ModelValueListInfo("P",p);
            List<ModelValueListInfo> relist = new ArrayList<ModelValueListInfo>(){{
                add(infoL);
                add(infoT);
                add(infoV);
                add(infoI);
                add(infoQ);
                add(infoP);
            }};

            result.addSuccess("查询成功");
            result.setData(relist);
        }else {
            result.addFailWithArray("没有数据");
        }
        return result;
    }


    /**
     * 查询设备的三日电量
     * @param param
     * @return
     */
    @PostMapping("/gate/elecount")
    public AjaxResult getDeviceElectricQ(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer devIdpk = param.getInteger("devIdpk");
        if (devIdpk == null) {
            result.addFail("设备id不能为空");
            return result;
        }
        //根据设备的id查询设备的节点信息
        //List<String> nodeList = this.gateService.finddeviceType(devIdpk);
        //if (CollectionUtils.isNotEmpty(nodeList)) {
            //String nodeArray = String.join("-", nodeList);
            //查询电量的使用情况
            Map<String,String> map = this.gateService.findDeviceElectircQ(devIdpk,null,new Date());
            result.addSuccess("查询成功");
            result.setData(map);
        //}else {
            //result.addFail("没有该设备的节点信息");
        //}

        return result;
    }

     /**
     * 删除空开
     * @param param
     * @return
     */
    @PostMapping("/gate/delete")
    public AjaxResult deleteGateInfo(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer gateId = param.getInteger("gateId");
        if (gateId == null) {
            result.addFail("空开id不能为空");
            return result;
        }
        try {
            int flag = this.gateService.delete(gateId);
            if (flag > 0)
                result.addSuccess("删除空开成功");
            else result.addFail("删除空开失败");
        } catch (Exception e) {
            e.printStackTrace();
            result.addFail("网络异常,请稍后重试");
        }

        return result;
    }


    /**
     * app查询空开列表
     * @param param
     * @return
     */
    @PostMapping(value = "/gate/list")
    public AjaxResult getGateList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int index = param.getIntValue("index");
        int size = param.getIntValue("size");
        Integer drawId = param.getInteger("drawId");
        if (drawId == null) {
            result.addFail("图纸id不能为空 ");
            return result;
        }
        PageInfo<EleMonGateinfo> pageInfo = this.gateService.pageingGateList(drawId,index,size);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        } else result.addFail("没有数据");

        return result;

    }

     /**
     * 批量更新空开信息
     * @param gateDto  有  list 属性
     * @return
     */
    @PostMapping(value = "/gate/batch/update")
    public AjaxResult updateGateBatch(@RequestBody @Valid GateSaveBatchDto gateDto){
        AjaxResult result = new AjaxResult();
        List<EleMonGateinfo> gates = gateDto.getGates();
        try {
            int flag = this.gateService.updateGateBatch(gates);
            if (flag >0){
                result.addSuccess("修改成功");
            }else {
                result.addFail("修改失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.addError("网络异常,请稍后重试");
        }
        return result;

    }

    /**
     * 根据单位id 空开名称或设备安装位置查询空开
     * @param param
     * @return
     */
    @PostMapping(value = "/gate/list/keyword")
    public AjaxResult updateGateBatch(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer unitId = param.getInteger("unitId");
        String keyWord = param.getString("keyWord");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        List<SimpleGateDto> list = this.gateService.findGateByKeyWord(unitId,keyWord);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        }else {
            result.addFailWithArray("没有数据");
        }
        return result;

    }







}
