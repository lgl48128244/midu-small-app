package com.fei.springboot.controller.unitavggrade;

import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.service.unitavggrade.UnitAvgGradeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@CrossOrigin
@RestController
@RequestMapping("/rank")
public class UnitAvgGradeController {

    @Autowired
    private UnitAvgGradeService unitAvgGradeService;

    private Logger logger = LoggerFactory.getLogger(UnitAvgGradeController.class);


    @PostMapping("/paging")
    public AjaxResult paging(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        Integer groupType = param.getInteger("groupType");
        if (groupType == null){
            result.addFail("用户权限组类型不能为空");
            return result;
        }
        int platformId = param.getIntValue("platformId");
        if (platformId ==0){
            result.addFail("平台Id不能为空");
            return result;
        }
        if (groupType>=0 && groupType<=1){//个人
            result = this.unitAvgGradeService.findPersonalUnitRank(param);
        }else if (groupType ==2){//区域
            result = this.unitAvgGradeService.findAreaUnitRank(param);
        }else{
            result.addFail("无法确认您的权限");
            return result;
        }



        return result;
    }


}
