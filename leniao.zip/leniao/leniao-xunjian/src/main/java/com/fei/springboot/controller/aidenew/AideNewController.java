package com.fei.springboot.controller.aidenew;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.pojo.aidenew.*;
import com.fei.springboot.service.aidenew.AideNewService;
import com.fei.springboot.util.MyDateUtil;
import com.fei.springboot.util.page.*;
import com.google.common.base.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.PublicKey;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.fei.springboot.util.page.RSAUtil.*;

/**
 * Created by stm on 2019/7/1.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class AideNewController {

    private Logger logger = LoggerFactory.getLogger(AideNewController.class);

    /*//测试地址 ， 正式地址待申请
    private static final String GET_PUBLIC_KEY_URL = "http://36.26.79.155:8120/api/getPublicKey";
    private static final String LOGIN_URL = "http://36.26.79.155:8120/api/getMqInfo";*/

    //正式环境地址
    private static final String GET_PUBLIC_KEY_URL = "http://122.228.219.106:8120/api/getPublicKey";
    private static final String LOGIN_URL = "http://122.228.219.106:8120/api/getMqInfo";

    @Autowired private AideNewService aideNewService;

    @Autowired
    private RedisUtil redisUtil;

    /*@GetMapping("/getPublicKey")
    public StatusResult<Object> getPublicKey(){
        Map<String, String> map = new HashMap<String, String>();
        try{
            String publicKey = redisUtil.get("publicKey");
            if(StringUtils.isEmpty(publicKey)){//判断公钥是否已在缓存，不存在则重新生成
                Map<String, String> keyMap = RSAUtil.generateKeyBytes();
                redisUtil.set(RSAUtil.PRIVATE_KEY, keyMap.get(RSAUtil.PRIVATE_KEY), 600L);
                redisUtil.set(PUBLIC_KEY, keyMap.get(PUBLIC_KEY), 600L);
                publicKey = keyMap.get(PUBLIC_KEY);
            }
            map.put(PUBLIC_KEY, publicKey);
        }catch(Exception e){
            e.printStackTrace();
            return ResultUtil.error("获取公钥失败：" + e.getMessage());
        }
        return ResultUtil.success(map);
    }*/


    /**
     * 获取公钥
     * @return
     */

    @GetMapping("/getPublicKey")
    public StatusResult<Object> getPublicKey(){
        Map<String, String> map = new HashMap<String, String>();

        Map<String, String> keyMap = RSAUtil.generateKeyBytes();

        String publicKey = keyMap.get(PUBLIC_KEY);

        map.put(PUBLIC_KEY, publicKey);

        return ResultUtil.success(map);
    }

    /*@PostMapping("/login")
    public StatusResult<Object> login(String username, String password, HttpServletRequest request) throws Exception {
        if(StringUtils.isEmpty(username)){
            return ResultUtil.other("用户名不能为空");
        }
        if(StringUtils.isEmpty(password)){
            return ResultUtil.other("密码不能为空");
        }
        String priKey = redisUtil.get(RSAUtil.PRIVATE_KEY);
        if(StringUtils.isEmpty(priKey)){
            return ResultUtil.other("公钥已过期");
        }
        Map<String, String> keyMap = RSAUtil.generateKeyBytes();
        PublicKey publicKey = restorePublicKey(keyMap.get(PUBLIC_KEY));
        //String password="123456";
        byte[] encodedText = RSAEncode(publicKey, password.getBytes());
        PrivateKey privateKey = restorePrivateKey(keyMap.get(PRIVATE_KEY));
        String  passwordStr=RSADecode(privateKey, org.apache.commons.codec.binary.Base64.encodeBase64String(encodedText));
        logger.info("解密后的密码为：" + passwordStr);
        if(StringUtils.isEmpty(passwordStr)){
            return ResultUtil.other("密码解密失败");
        }

        Tblnuserinfo user = aideNewService.findByName(username);
        if(null == user){
            return ResultUtil.other("用户不存在");
        }

        //demo 中密码只通过md5加密匹配，实际运用根据各自系统情况匹配
        if(!DesUtils.encrypt(passwordStr,"12345678").equals(user.getUserPwd())){
            return ResultUtil.other("密码错误");
        }

        String tokenKey = RequestUtil.getIpAddr(request);
        String tokenId = redisUtil.get(tokenKey);//demo中tokenId只生成uuid保存缓存中1小时，实际运用根据各自系统情况调整
        if(StringUtils.isEmpty(tokenId)){
            tokenId = IdGen.uuid();
            redisUtil.set(tokenKey, tokenId, 60*60l);
        }
        Map<String, Object> data = new HashMap<>();
        data.put("tokenId", tokenId);
        return ResultUtil.success(data);
    }*/

    /**
     * 登录
     * @param username
     * @param password
     * @param request
     * @return
     * @throws Exception
     */
    @PostMapping("/login")
    public StatusResult<Object> login(String username, String password, HttpServletRequest request) throws Exception {
        /*if(StringUtils.isEmpty(username)){
            return ResultUtil.other("用户名不能为空");
        }
        if(StringUtils.isEmpty(password)){
            return ResultUtil.other("密码不能为空");
        }

        String priKey = PRIVATE_KEY;
        if(StringUtils.isEmpty(priKey)){
            return ResultUtil.other("公钥已过期");
        }
        Map<String, String> keyMap = RSAUtil.generateKeyBytes();
        PublicKey publicKey = restorePublicKey(keyMap.get(PUBLIC_KEY));
        //String password="123456";
        byte[] encodedText = RSAEncode(publicKey, password.getBytes());
        PrivateKey privateKey = restorePrivateKey(keyMap.get(PRIVATE_KEY));
        String  passwordStr=RSADecode(privateKey, org.apache.commons.codec.binary.Base64.encodeBase64String(encodedText));
        logger.info("解密后的密码为：" + passwordStr);
        if(StringUtils.isEmpty(passwordStr)){
            return ResultUtil.other("密码解密失败");
        }

        Tblnuserinfo user = aideNewService.findByName(username);
        if(null == user){
            return ResultUtil.other("用户不存在");
        }*/

        //demo 中密码只通过md5加密匹配，实际运用根据各自系统情况匹配
/*        if(!DesUtils.encrypt(passwordStr,"12345678").equals(user.getUserPwd())){
            return ResultUtil.other("密码错误");
        }*/

        String  tokenId = IdGen.uuid();
        Map<String, Object> data = new HashMap<>();
        data.put("tokenId", tokenId);
        System.out.println(data.get("tokenId"));
        return ResultUtil.success(data);
    }

   /* @PostMapping("login")
    public StatusResult<Object> login(String username, String password, HttpServletRequest request) throws Exception {
        if(StringUtils.isEmpty(username)){
            return ResultUtil.other("用户名不能为空");
        }
        if(StringUtils.isEmpty(password)){
            return ResultUtil.other("密码不能为空");
        }

        String priKey = redisUtil.get(RSAUtil.PRIVATE_KEY);
        if(StringUtils.isEmpty(priKey)){
            return ResultUtil.other("公钥已过期");
        }
        PrivateKey privateKey = RSAUtil.restorePrivateKey(priKey);
        String passwordStr = RSAUtil.RSADecode(privateKey, password);
        logger.info("解密后的密码为：" + passwordStr);
        if(StringUtils.isEmpty(passwordStr)){
            return ResultUtil.other("密码解密失败");
        }

        Tblnuserinfo user = aideNewService.findByName(username);
        if(null == user){
            return ResultUtil.other("用户不存在");
        }

        //demo 中密码只通过md5加密匹配，实际运用根据各自系统情况匹配
        if(!DesUtils.encrypt(passwordStr,"12345678").equals(user.getUserPwd())){
            return ResultUtil.other("密码错误");
        }

        String tokenKey = RequestUtil.getIpAddr(request);
        String tokenId = redisUtil.get(tokenKey);//demo中tokenId只生成uuid保存缓存中1小时，实际运用根据各自系统情况调整
        if(StringUtils.isEmpty(tokenId)){
            tokenId = IdGen.uuid();
            redisUtil.set(tokenKey, tokenId, 60*60l);
        }
        Map<String, Object> data = new HashMap<>();
        data.put("tokenId", tokenId);
        return ResultUtil.success(data);
    }*/

    /**
     * 单位（或者站点、或者建筑）信息
     * @param demo
     * @return
     * @throws ParseException
     */
    @PostMapping("/getBuilding")
    public com.fei.springboot.util.page.StatusResult<Page<Building>> getBuilding(Demo demo) throws ParseException {

        /*int pageNo = demo.getPageNo();
        int pageSize = demo.getPageSize();*/

        Page page = new Page();
        if(StringUtils.isEmpty(String.valueOf(demo.getPageNo()))&&demo.getPageNo()==0){
            page.setPageNo(1);
            page.setPageSize(50);
        }else {
            page.setPageNo(demo.getPageNo());
            page.setPageSize(demo.getPageSize());
        }

        Long createDateB =demo.getCreateDateB();
        Long createDateE = demo.getCreateDateE();
        Long updateDateB =demo.getUpdateDateB();
        Long updateDateE = demo.getUpdateDateE();

        //int Id=param.getIntValue("Id");
        String Id=demo.getId();

        if((createDateB==null&&createDateE==null)&&(updateDateB==null&&updateDateE==null)&& (StringUtils.isEmpty(Id))){
            return ResultUtil.other("创建时间、更新时间、主键id三个参数至少传一个参数");
        }

        Map map = new HashMap<>();

        if (createDateB != null) {

            //将传入的Long类型时间转换成date类型
            Date   CreateDateB = MyDateUtil.stampToDate(createDateB);
            map.put("CreateDateB", CreateDateB);
        }

        if (createDateE != null) {
            Date CreateDateE = MyDateUtil.stampToDate(createDateE);
            map.put("CreateDateE",CreateDateE);
        }

        if(updateDateB!=null){
            Date UpdateDateB = MyDateUtil.stampToDate(updateDateB);
            map.put("UpdateDateB",UpdateDateB);
        }

        if(updateDateE!=null){
            Date UpdateDateE = MyDateUtil.stampToDate(updateDateE);
            map.put("UpdateDateE",UpdateDateE);
        }

        Page<Building>  page1 =  aideNewService.getBuilding11(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"), Id);
        if(page1.getCount()==0){
            return ResultUtil.other("查询失败，数据为空");
        }

        return  ResultUtil.success("查询成功",page1);
    }

    /**
     * 获取运营服务公司（单位）信息接口
     * @param demo
     * @return
     * @throws ParseException
     */
    @PostMapping("/getCompany")
    public com.fei.springboot.util.page.StatusResult<Page<Company>> getCompany(Demo demo) throws ParseException {

        int pageNo = demo.getPageNo();
        int pageSize = demo.getPageSize();
        Page page = new Page();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        Long createDateB =demo.getCreateDateB();
        Long createDateE = demo.getCreateDateE();
        Long updateDateB =demo.getUpdateDateB();
        Long updateDateE = demo.getUpdateDateE();

        //int Id=param.getIntValue("Id");
        String Id=demo.getId();

        if((createDateB==null&&createDateE==null)&&(updateDateB==null&&updateDateE==null)&& (StringUtils.isEmpty(Id))){
            return ResultUtil.other("创建时间、更新时间、主键id三个参数至少传一个参数");
        }

        Map map = new HashMap<>();

        if (createDateB != null) {
            Date   CreateDateB = MyDateUtil.stampToDate(createDateB);
            map.put("CreateDateB", CreateDateB);
        }

        if (createDateE != null) {
            Date CreateDateE = MyDateUtil.stampToDate(createDateE);
            map.put("CreateDateE",CreateDateE);
        }

        if(updateDateB!=null){
            Date UpdateDateB = MyDateUtil.stampToDate(updateDateB);
            map.put("UpdateDateB",UpdateDateB);
        }

        if(updateDateE!=null){
            Date UpdateDateE = MyDateUtil.stampToDate(updateDateE);
            map.put("UpdateDateE",UpdateDateE);
        }

        Page<Company> pages=aideNewService.getCompany(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"), Id);
        if(pages.getCount()==0){
            return  ResultUtil.other("查询失败，数据为空");
        }

        return ResultUtil.success("查询成功",pages);
    }

    /**
     * 获取设备信息
     * @param demo
     * @return
     * @throws ParseException
     */
    @PostMapping("/getEquipment")
    public com.fei.springboot.util.page.StatusResult<Page<Equipment>> getEquipment(Demo demo) throws ParseException {

        int pageNo = demo.getPageNo();
        int pageSize = demo.getPageSize();
        Page page = new Page();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        Long createDateB =demo.getCreateDateB();
        Long createDateE = demo.getCreateDateE();
        Long updateDateB =demo.getUpdateDateB();
        Long updateDateE = demo.getUpdateDateE();

        //int Id=param.getIntValue("Id");
        String Id=demo.getId();


        if((createDateB==null&&createDateE==null)&&(updateDateB==null&&updateDateE==null)&& (StringUtils.isEmpty(Id))){
            return ResultUtil.other("创建时间、更新时间、主键id三个参数至少传一个参数");
        }

        Map map = new HashMap<>();

        if (createDateB != null) {
            Date   CreateDateB = MyDateUtil.stampToDate(createDateB);
            map.put("CreateDateB", CreateDateB);
        }

        if (createDateE != null) {
            Date CreateDateE = MyDateUtil.stampToDate(createDateE);
            map.put("CreateDateE",CreateDateE);
        }

        if(updateDateB!=null){
            Date UpdateDateB = MyDateUtil.stampToDate(updateDateB);
            map.put("UpdateDateB",UpdateDateB);
        }

        if(updateDateE!=null){
            Date UpdateDateE = MyDateUtil.stampToDate(updateDateE);
            map.put("UpdateDateE",UpdateDateE);
        }

        Page<Equipment>  pages=aideNewService.getEquipment(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"),Id);

        if(pages.getCount()==0){
            return  ResultUtil.other("查询失败，数据为空");
        }

        return ResultUtil.success("查询成功",pages);

    }



    //@PostMapping("/getParts")
    public com.fei.springboot.util.page.StatusResult<Page<Part>> getPartss(Demo demo) throws ParseException {

        int pageNo = demo.getPageNo();
        int pageSize = demo.getPageSize();
        Page page = new Page();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        Long createDateB =demo.getCreateDateB();
        Long createDateE = demo.getCreateDateE();
        Long updateDateB =demo.getUpdateDateB();
        Long updateDateE = demo.getUpdateDateE();

        //int Id=param.getIntValue("Id");
        String Id=demo.getId();

        if((createDateB==null&&createDateE==null)&&(updateDateB==null&&updateDateE==null)&& (StringUtils.isEmpty(Id))){
            return ResultUtil.other("创建时间、更新时间、主键id三个参数至少传一个参数");
        }

        Map map = new HashMap<>();

        if (createDateB != null) {
            Date   CreateDateB = MyDateUtil.stampToDate(createDateB);
            map.put("CreateDateB", CreateDateB);
        }

        if (createDateE != null) {
            Date CreateDateE = MyDateUtil.stampToDate(createDateE);
            map.put("CreateDateE",CreateDateE);
        }

        if(updateDateB!=null){
            Date UpdateDateB = MyDateUtil.stampToDate(updateDateB);
            map.put("UpdateDateB",UpdateDateB);
        }

        if(updateDateE!=null){
            Date UpdateDateE = MyDateUtil.stampToDate(updateDateE);
            map.put("UpdateDateE",UpdateDateE);
        }

        try{
            Page<Part>  pages=aideNewService.getParts(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"),Id);
            if(pages.getCount()==0){
                return ResultUtil.other("查询失败，数据为空");
            }

            return ResultUtil.success("查询成功",pages);
        }   catch (Exception e ){
            return ResultUtil.other("查询异常，请检查查询输入数据");
        }


    }


    /**
     * 获取mq相关信息
     * @param username
     * @param password
     * @return
     * @throws Exception
     */
    @PostMapping("/getMqInfo")
    public String getMqInfo(String username, String password) throws Exception {
        String result = "";
        String publicKey = this.getThePublicKey();
        if (org.apache.commons.lang3.StringUtils.isNoneEmpty(publicKey)) {
            // 加密密码
            PublicKey pubKey = restorePublicKey(publicKey);
            byte[] encodedText = RSAEncode(pubKey, password.getBytes());
            String encodedPwd = org.apache.commons.codec.binary.Base64.encodeBase64String(encodedText);
            logger.info("RSA encoded: " + encodedPwd);

            Map<String, String> parameters = new HashMap<>();
            parameters.put("username", username);
            parameters.put("password", encodedPwd);
            result = HttpRequestUtil.post(LOGIN_URL, parameters);
        }
        logger.info("获取mq信息如下：" + result);
        return result;
    }

    /**
     * 获取mq信息   现在位测试服务器信息
     * @param username
     * @param password
     * @return
     * @throws Exception
     */
    @PostMapping("/getMqInfos")
    public JSONObject getMqInfos(String username, String password) throws Exception {
        JSONObject result = new JSONObject();
        String publicKey = this.getThePublicKey();
        if (org.apache.commons.lang3.StringUtils.isNoneEmpty(publicKey)) {
            // 加密密码
            PublicKey pubKey = restorePublicKey(publicKey);
            byte[] encodedText = RSAEncode(pubKey, password.getBytes());
            String encodedPwd = org.apache.commons.codec.binary.Base64.encodeBase64String(encodedText);
            logger.info("RSA encoded: " + encodedPwd);

            Map<String, String> parameters = new HashMap<>();
            parameters.put("username", username);
            parameters.put("password", encodedPwd);
            String a = HttpRequestUtil.post(LOGIN_URL, parameters);
            result.put("data",a);
        }
        logger.info("获取mq信息如下：" + result);
        return result;
    }

    /**
     * 获取公钥
     *
     * @return
     * @throws Exception
     */
    //@GetMapping("/getThePublicKey")
    public String getThePublicKey() throws Exception {
        String result = HttpRequestUtil.get(GET_PUBLIC_KEY_URL, new HashMap<>());
        JSONObject json = JSONObject.parseObject(result);
        logger.info(result);
        String publicKey = "";
        if (Objects.equal(ResultUtil.SUCCESS_CODE, json.getInteger("code"))) {
            publicKey = json.getJSONObject("data").getString("publicKey");
        }
        return publicKey;
    }



   // @PostMapping("/getPartss")
    public com.fei.springboot.util.page.StatusResult<Page<Part>> getParts(Demo demo) throws ParseException {

        int pageNo = demo.getPageNo();
        int pageSize = demo.getPageSize();
        Page page = new Page();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        Long createDateB =demo.getCreateDateB();
        Long createDateE = demo.getCreateDateE();
        Long updateDateB =demo.getUpdateDateB();
        Long updateDateE = demo.getUpdateDateE();

        //int Id=param.getIntValue("Id");
        String Id=demo.getId();

        if((createDateB==null&&createDateE==null)&&(updateDateB==null&&updateDateE==null)&& (StringUtils.isEmpty(Id))){
            return ResultUtil.other("创建时间、更新时间、主键id三个参数至少传一个参数");
        }

        Map map = new HashMap<>();

        if (createDateB != null) {
            Date   CreateDateB = MyDateUtil.stampToDate(createDateB);
            map.put("CreateDateB", CreateDateB);
        }

        if (createDateE != null) {
            Date CreateDateE = MyDateUtil.stampToDate(createDateE);
            map.put("CreateDateE",CreateDateE);
        }

        if(updateDateB!=null){
            Date UpdateDateB = MyDateUtil.stampToDate(updateDateB);
            map.put("UpdateDateB",UpdateDateB);
        }

        if(updateDateE!=null){
            Date UpdateDateE = MyDateUtil.stampToDate(updateDateE);
            map.put("UpdateDateE",UpdateDateE);
        }


          //  Page<Part>  pages=aideNewService.getPartsDevNull(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"),Id);

        Page<Part>  pages=aideNewService.getPartsDevNull(page,map.get("CreateDateB"), map.get("CreateDateE"),map.get("UpdateDateB"),map.get("UpdateDateE"),Id);

            if(pages.getCount()==0){
                return ResultUtil.other("查询失败，数据为空");
            }else {
                return ResultUtil.success("查询成功",pages);
            }

    }

    /**
     * 获取部件信息
     * @param demo
     * @return
     * @throws ParseException
     */
    @PostMapping("/getParts")
    public com.fei.springboot.util.page.StatusResult<Page<Part>> getPartsss(Demo demo) throws ParseException {

        StatusResult result=new StatusResult();

        if(demo.getId()==null||StringUtils.isEmpty(demo.getId())){

            result=getParts(demo);

        }else {
            result= getPartss(demo);

        }

        return result;

    }





}
