package com.fei.springboot.controller.admin.devty;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by songtm on 2019/9/23.
 */
@Controller
@RequestMapping(value = "/Http")
public class PostTest {

    @PostMapping(value = "/test")
    public void getRequest(@RequestBody JSONObject param){
        System.out.println(param.toJSONString());

    }
}
