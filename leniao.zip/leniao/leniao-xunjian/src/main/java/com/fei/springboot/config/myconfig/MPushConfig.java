package com.fei.springboot.config.myconfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = {"classpath:mpush.yml"},encoding = "utf-8")
@ConfigurationProperties(prefix = "aliyun.push")
public class MPushConfig {

    @Value("${regionId}")
    private String regionId;

    @Value("${accessKeyId}")
    private String accessKeyId;

    @Value("${accessKeySecret}")
    private String accessKeySecret;

    @Value("${appKeyAndroid}")
    private Long appKeyAndroid;

    @Value("${appKeyIos}")
    private Long appKeyIos;

    @Value("${signName}")
    private String signName;

    @Value("${templateCode}")
    private String templateCode;



    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public void setAccessKeyId(String accessKeyId) {
        this.accessKeyId = accessKeyId;
    }

    public String getAccessKeySecret() {
        return accessKeySecret;
    }

    public void setAccessKeySecret(String accessKeySecret) {
        this.accessKeySecret = accessKeySecret;
    }

    public Long getAppKeyAndroid() {
        return appKeyAndroid;
    }

    public void setAppKeyAndroid(Long appKeyAndroid) {
        this.appKeyAndroid = appKeyAndroid;
    }

    public Long getAppKeyIos() {
        return appKeyIos;
    }

    public void setAppKeyIos(Long appKeyIos) {
        this.appKeyIos = appKeyIos;
    }

    public String getSignName() {
        return signName;
    }

    public void setSignName(String signName) {
        this.signName = signName;
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode;
    }
}
