package com.fei.springboot.controller.admin.devty;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevicenodeinfo;
import com.fei.springboot.domain.admin.devTy.Tblndevsys;
import com.fei.springboot.domain.admin.devTy.Tblndevty;
import com.fei.springboot.domain.admin.devTy.Tblnfirminfo;
import com.fei.springboot.pojo.admin.devty.DevTyDto;
import com.fei.springboot.service.admin.devty.DevTyService;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by songtm on 2019/8/5.
 */

@CrossOrigin
@RestController
@RequestMapping(value = "/devTy")
public class DevTyController {
    private Logger logger = LoggerFactory.getLogger(DevTyController.class);

    @Autowired
    private DevTyService devTyService;

    //新建设备型号数据
    @PostMapping("/addDevTy")
    public AjaxResult addDevTy(@RequestBody  DevTyDto devTyDto){
        AjaxResult result = new AjaxResult();

        if(devTyDto.getDevFirmId()==null){
            result.addFail("生产厂商不能为空");
            return result;
        }
        if(devTyDto.getDevSysId()==null){
            result.addFail("设备系统不能为空");
            return result;
        }
        if(StringUtils.isEmpty(devTyDto.getDevTy())){
            result.addFail("产品型号不能为空");
            return result;
        }
        if(devTyDto.getOrder()==null){
            result.addFail("显示顺序不能为空");
            return result;
        }
        if(StringUtils.isEmpty(devTyDto.getDevCoding())){
            result.addFail("请添加扫描编码");
            return result;
        }
        if(devTyDto.getDevParentIdpk()==null){
            result.addFail("devParentIdpk不能为空");
            return result;
        }
        if(devTyDto.getIsNetErr()==null){
            result.addFail("IsNetErr不能为空");
            return result;
        }
        if(devTyDto.getIsIoT()==null){
            result.addFail("IsIoT不能为空");
            return result;
        }
        if(devTyDto.getBType()==null){
            result.addFail("BType不能为空");
            return result;
        }
        if(devTyDto.getIsRoot()==null){
            result.addFail("IsRoot不能为空");
            return result;
        }
        if(devTyDto.getIsRoot()==null){
            result.addFail("IsRoot不能为空");
            return result;
        }
        if(devTyDto.getCodeLength()==null){
            result.addFail("CodeLength不能为空");
            return result;
        }
        if(devTyDto.getOrder()==null){
            result.addFail("显示顺序不能为空");
            return result;
        }

        try{
            result = devTyService.addDevTy(devTyDto);
            result.setMessage("新建成功");
        }catch (Exception e){
            result.addFail("新建失败");
        }

       /* result = devTyService.addDevTy(devTyDto);
        result.setMessage("新建成功");*/

        return result;
    }

    //查询生产厂商列表
    @PostMapping("/selectFirm")
    public AjaxResult selectFirm(){
        AjaxResult result = new AjaxResult();
        result = devTyService.selectFirm();
        return result;
    }

    //查询设备系统列表
    @PostMapping("/selectDevSys")
    public AjaxResult selectDevSys(){
        AjaxResult result = new AjaxResult();
        result = devTyService.selectDevSys();
        return result;
    }

    //新建厂商
    @PostMapping("/newFirm")
    public AjaxResult newFirm(@RequestBody Tblnfirminfo tblnfirminfo){
        AjaxResult result = new AjaxResult();
        if(tblnfirminfo.getFirmName()==null|| StringUtils.isEmpty(tblnfirminfo.getFirmName())){
            result.addFail("厂商名称不能为空");
            return result;
        }

        if(tblnfirminfo.getFirmPhone()==null|| StringUtils.isEmpty(tblnfirminfo.getFirmPhone())){
            result.addFail("厂商电话不能为空");
            return result;
        }

        if(tblnfirminfo.getFirmPerpon()==null|| StringUtils.isEmpty(tblnfirminfo.getFirmPerpon())){
            result.addFail("厂商联系人不能为空");
            return result;
        }
        result = devTyService.newFirm(tblnfirminfo);
        return result;
    }


    //新建系统
    @PostMapping("/addDevSys")
    public AjaxResult addDevSys(@RequestBody Tblndevsys tblndevsys){
        AjaxResult result = new AjaxResult();
        if(StringUtils.isEmpty(tblndevsys.getDevSysName())){
            result.addFail("系统名称不能为空");
            return result;
        }
        if(StringUtils.isEmpty(tblndevsys.getRemark())){
            result.addFail("remark不能为空");
            return result;
        }
        result = devTyService.addDevSys(tblndevsys);
        return result;
    }

    //新建型号
    @PostMapping("/newDevTy")
    public AjaxResult newDevTy(@RequestBody Tblndevty tblndevty){
        AjaxResult result = new AjaxResult();

        if(StringUtils.isEmpty(tblndevty.getDevTy())){
            result.addFail("产品型号不能为空");
            return result;
        }
        if(tblndevty.getOrder()==null){
            result.addFail("显示顺序不能为空");
            return result;
        }
        if(StringUtils.isEmpty(tblndevty.getDevCoding())){
            result.addFail("请添加扫描编码");
            return result;
        }
        if(tblndevty.getDevParentIdpk()==null){
            result.addFail("devParentIdpk不能为空");
            return result;
        }
        if(tblndevty.getIsNetErr()==null){
            result.addFail("IsNetErr不能为空");
            return result;
        }
        if(tblndevty.getIsIoT()==null){
            result.addFail("IsIoT不能为空");
            return result;
        }
        if(tblndevty.getBType()==null){
            result.addFail("BType不能为空");
            return result;
        }
        if(tblndevty.getIsRoot()==null){
            result.addFail("IsRoot不能为空");
            return result;
        }
        if(tblndevty.getIsRoot()==null){
            result.addFail("IsRoot不能为空");
            return result;
        }
        if(tblndevty.getCodeLength()==null){
            result.addFail("CodeLength不能为空");
            return result;
        }
        result =devTyService.newDevTy(tblndevty);
        return result;
    }

    //添加设备型号节点信息
    @PostMapping("/addNodeInfo")
    public  AjaxResult addNodeInfo(@RequestBody Tblndevicenodeinfo tblndevicenodeinfo){
        AjaxResult result = new AjaxResult();
        if(tblndevicenodeinfo.getDevTy()==null){
            result.addFail("设备类型不能为空");
            return result;
        }
        if(StringUtils.isEmpty(tblndevicenodeinfo.getDevNode1())){
            result.addFail("设备节点不能为空");
            return result;
        }
        if(StringUtils.isEmpty(tblndevicenodeinfo.getDevNode1Desc())){
            result.addFail("设备节点描述不能为空");
            return result;
        }
        if(StringUtils.isEmpty(tblndevicenodeinfo.getDevUint())){
            result.addFail("单位不能为空");
            return result;
        }
        result = devTyService.addNodeInfo(tblndevicenodeinfo);
        return result;
    }

    //删除设备型号节点信息
    @PostMapping("/deleteNodeInfo")
    public AjaxResult deleteNodeInfo(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int pkId=param.getIntValue("pkId");
        result = devTyService.deleteNodeInfo(pkId);
        return result;
    }

    //查询设备型号数据
    @PostMapping("/selectDevTyInfo")
    public AjaxResult selectDevTyInfo(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int devTyId=param.getIntValue("devTyId");
        try{
            result = devTyService.selectDevTyInfo(devTyId);
            result.setMessage("查询成功");
        }catch (Exception e){
            result.addFail("查询失败");
        }

        return result;
    }

    //更新设备型号数据
    @PostMapping("/updateDevTyInfo")
    public AjaxResult updateDevTyInfo(@RequestBody DevTyDto devTyDto){
        AjaxResult result = new AjaxResult();
        try {
            result = devTyService.updateDevTyInfo(devTyDto);
            result.setMessage("修改成功");
        }catch (Exception e){
            result.addFail("修改失败");
        }

       /* result = devTyService.updateDevTyInfo(devTyDto);
        result.setMessage("修改成功");*/

        return result;
    }

    //分页查询设备型号列表
    @PostMapping("/selectDevTyList")
    public AjaxResult selcetDevTyList(@RequestBody  JSONObject param){
        AjaxResult result = new AjaxResult();

        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        String devTy = param.getString("devTy");
        PageInfo<DevTyDto> pageInfo = devTyService.selectDevTyList(index,size,devTy);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }

    //分页查询厂商列表
    @PostMapping("/selectFirmList")
    public AjaxResult selectFirmList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        PageInfo<Tblnfirminfo> pageInfo = devTyService.selectFirmList(index,size);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }

    //生成编码
    @PostMapping("/proDevCode")
    public AjaxResult proDevCode(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        int devSysId = param.getIntValue("devSysId");
        String code = devTyService.pruDevCoding(devSysId);
        result.setData(code);
        result.setMessage("成功生成编码");
        return  result;
    }

    //删除设备型号数据
    @PostMapping("/deleteDevTyInfo")
    public AjaxResult deleteDevTyInfo(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int devTyId = param.getIntValue("devTyId");
        result = devTyService.deleteDevTyInfo(devTyId);
        return result;
    }

    //编辑厂商
    @PostMapping("/updateFirmInfo")
    public AjaxResult updateFirmInfo(@RequestBody Tblnfirminfo tblnfirminfo){
        AjaxResult result = new AjaxResult();
        result = devTyService.updateFirmInfo(tblnfirminfo);
        return result;
    }


   /* //批量添加  设备系统ID
    @PostMapping("/MyStirng")
    public  AjaxResult myString(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        String myParam = param.getString("string");
        String[] splited = myParam.split("\\s+");
        result.setData(splited);
        return result;
    }*/


}
