package com.fei.springboot.controller.common.dotnet;

import org.springframework.web.bind.annotation.RestController;

@RestController("")
public class ProjectEleUseController {
}
