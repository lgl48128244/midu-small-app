package com.fei.springboot.controller.common.dotnet;

import com.fei.springboot.constant.Const;
import com.fei.springboot.pojo.common.DayeleUse;
import com.fei.springboot.pojo.common.DeviceEleUseResultDTO;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.joda.time.DateTime;

import java.io.*;
import java.util.List;

public class AsyncCreateElecel implements Runnable {
    @Override
    public void run() {

    }
/* private Integer year;
    private Integer month;
    private String projName;
    private List<DeviceEleUseResultDTO> resultDTOList;

    public AsyncCreateElecel(Integer year, Integer month, String projName){
        this.year =  year;
        this.month =  month;
        this.projName =  projName;
    }


    @Override
    public void run() {
        ReceiveController.isCalculating = true;
        ReceiveController.lastCalculate = DateTime.now().toDate();

        //创建excel文件
        HSSFWorkbook book = new HSSFWorkbook();

        *//*第一个sheet页开始*//*
        HSSFSheet sheet1 = book.createSheet("每月用电量");
        //设置标题样式
        HSSFCellStyle titleStyle = book.createCellStyle();
        titleStyle.setAlignment(HorizontalAlignment.CENTER);
        titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        titleStyle.setWrapText(true);
        HSSFFont nameRowFont = book.createFont();
        nameRowFont.setFontName("微软雅黑");
        nameRowFont.setFontHeightInPoints((short) 30);
        nameRowFont.setBold(true);//加粗
        titleStyle.setFont(nameRowFont);

        //创建自动换行样式
        CellStyle wrapTextStyle = book.createCellStyle();
        wrapTextStyle.setWrapText(true); //设置换行
        wrapTextStyle.setAlignment(HorizontalAlignment.CENTER);
        wrapTextStyle.setVerticalAlignment(VerticalAlignment.CENTER);


        //爱克林2020年2月份用电量统计表
        String title = projName + year + "年" + month + "月份用电量统计报表";
        String[] headInfo = {"序号", "监测线路", "月份", "用电量(单位：KWh)"};

        //设置头部格式和信息
        this.initSheetHeadInfo(sheet1, titleStyle, wrapTextStyle, title, headInfo);


        //sheet1正文数据
        DeviceEleUseResultDTO data;
        //HSSFRow zwRow = null;
        HSSFCell zwCell;
        for (int i = 0; i < resultDTOList.size(); i++) {
            data = resultDTOList.get(i);

            HSSFRow dataRow = sheet1.createRow(i + 2);
            //序号
            zwCell = dataRow.createCell(0);
            zwCell.setCellValue(i + 1);
            //监测路线(安装位置)
            zwCell = dataRow.createCell(1);
            zwCell.setCellValue(data.getInstallLocation());
            //月份
            zwCell = dataRow.createCell(2);
            zwCell.setCellValue(month);
            //用电量
            zwCell = dataRow.createCell(3);
            zwCell.setCellValue(data.getTotal());
        }
        *//*第一个sheet页完毕*//*

        *//*第二个sheet页开始*//*
        HSSFSheet sheet2 = book.createSheet("每日用电量");

        DateTime firstDayOfMonth = new DateTime(year, month, 1, 0, 0);
        int endDay = firstDayOfMonth.dayOfMonth().withMaximumValue().getDayOfMonth();
        //加上序号和名称或日期的列数 2
        headInfo = new String[endDay + 2];
        for (int i = 0; i < headInfo.length; i++) {
            if (i == 0) {
                headInfo[0] = "序号";
            } else if (i == 1) {
                headInfo[1] = "名称/日期";
            } else {
                headInfo[i] = firstDayOfMonth.toString("yyyy-MM-dd");
                firstDayOfMonth = firstDayOfMonth.plusDays(1);
            }
        }

        this.initSheetHeadInfo(sheet2, titleStyle, wrapTextStyle, title, headInfo);


        HSSFRow dataRow;
        for (int i = 0; i < resultDTOList.size(); i++) {
            //int index = 0;
            data = resultDTOList.get(i);
            dataRow = sheet2.createRow(i + 2);//从第三行开始是数据
            //序号
            zwCell = dataRow.createCell(0);
            zwCell.setCellValue(i + 1);
            //名称(安装位置)
            zwCell = dataRow.createCell(1);
            zwCell.setCellValue(data.getInstallLocation());
            //每天数据
            List<DayeleUse> dayEleUseList = data.getDayEleUseList();
            for (int j = 0; j < dayEleUseList.size(); j++) {
                HSSFCell hssfCell = dataRow.createCell(j + 2);
                hssfCell.setCellValue(dayEleUseList.get(j).getValue());
                //index++;
            }
        }

        //保存文件到本地
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            book.write(os);
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] b = os.toByteArray();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(b);

        this.saveFileToLocal(inputStream, firstDayOfMonth.toString("yyyy-MM"), title +".xlsx");

        //没有人在生成excel
        ReceiveController.isCalculating = false;
    }

    *//**
     * 设置sheet页的头部样式
     *
     * @param sheet
     * @param titleStyle
     * @param wrapTextStyle
     * @param title
     * @param headInfo
     *//*
    private void initSheetHeadInfo(HSSFSheet sheet, HSSFCellStyle titleStyle, CellStyle wrapTextStyle, String title, String[] headInfo) {
        //创建标题行
        HSSFRow row0 = sheet.createRow(0);
        //row0.setHeight((short) 500);// 设置行高
        //设置表格的大标题的值
        HSSFCell nameCell = null;
        for (int i = 0; i < headInfo.length; i++) {
            nameCell = row0.createCell(i);
            nameCell.setCellStyle(wrapTextStyle);
            if (i == 0) {
                nameCell.setCellStyle(wrapTextStyle);
                nameCell.setCellValue(new HSSFRichTextString(title));
            }
        }
        //标题合并单元格
        CellRangeAddress nameCellRange = new CellRangeAddress(0, 0, 0, headInfo.length - 1);
        sheet.addMergedRegion(nameCellRange);

        //创建表格表头数据行 //设置行高
        HSSFRow row1 = sheet.createRow(1);
        //row1.setHeight((short) 20);

        *//*设置列宽度*//*
        HSSFCell cell = null;
        for (int i = 0; i < headInfo.length; i++) {
            if (i == 1) {
                sheet.setColumnWidth(i, 10 * 256);
            } else if (i > 1) {
                sheet.setColumnWidth(i, 20 * 256);
            } else {
                sheet.setColumnWidth(i, 15 * 256);
            }
            cell = row1.createCell(i);
            cell.setCellValue(headInfo[i]);
            //cell.setCellStyle(titleStyle);
        }
    }

    *//**
     * @param inputStream
     * @param fileName
     *//*
    private String saveFileToLocal(InputStream inputStream, String date, String fileName) {
        OutputStream os = null;
        String url = "";
        try {
            String path = Const.ELE_USE_INFO_SAVE_PATH + date + "\\";
            // 2、保存到临时文件
            // 1K的数据缓冲
            byte[] bs = new byte[1024];
            // 读取到的数据长度
            int len;
            // 输出的文件流保存到本地文件
            File tempFile = new File(path);
            if (!tempFile.exists()) {
                tempFile.mkdirs();
            }
            os = new FileOutputStream(tempFile.getPath() + File.separator + fileName);
            // 开始读取
            while ((len = inputStream.read(bs)) != -1) {
                os.write(bs, 0, len);
            }
            //TODO
            url = "";
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 完毕，关闭所有链接
            try {
                os.close();
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return "";

    }*/

}
