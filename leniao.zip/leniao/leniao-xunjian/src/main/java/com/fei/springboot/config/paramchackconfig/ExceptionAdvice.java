package com.fei.springboot.config.paramchackconfig;

import com.fei.springboot.domain.AjaxResult;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Iterator;
import java.util.Set;

@ControllerAdvice
public class ExceptionAdvice {

    private Logger logger = LoggerFactory.getLogger(ExceptionAdvice.class);


    /*@ResponseBody
    @ExceptionHandler(value = Exception.class)
    public AjaxResult defaultExceptionHandler(Exception exception) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        try {
            throw exception;
        } catch (MethodArgumentNotValidException argEx) {
            FieldError fieldError = argEx.getBindingResult().getFieldError();
            String errorMsg = String.format("%s: %s", fieldError.getField(),
                    fieldError.getDefaultMessage());
            //logger.error("【全局异常捕获】>> 参数校验异常  >>  {}", errorMsg);
            result.setMessage(errorMsg);
        } catch (ConstraintViolationException argEx) {
            Set<ConstraintViolation<?>> constraintViolations = argEx.getConstraintViolations();
            Iterator<ConstraintViolation<?>> iterator = constraintViolations.iterator();
            if (iterator.hasNext()) {
                result.setMessage(iterator.next().getMessage());
            } else {
                result.setMessage("请检查参数是否合法");
            }
        } catch (MissingServletRequestParameterException argEx) {
            result.setMessage("参数: " + argEx.getParameterName() + " 是必须项");
        } catch (HttpRequestMethodNotSupportedException e) {
            String errorMsg = String.format("请求方式 %s 错误 ! 请使用 %s 方式", e.getMethod(), e.getSupportedHttpMethods());
            logger.error("【全局异常捕获】>> {}", errorMsg);
            result.setMessage(errorMsg);
        } catch (HttpMediaTypeNotSupportedException e) {
            String errorMsg = String.format("请求类型 %s 错误 ! 请使用 %s 方式", e.getContentType(), e.getSupportedMediaTypes());
            logger.error("【全局异常捕获】>> {}", errorMsg);
            result.setMessage(errorMsg);
        } catch (Exception e) {
            logger.error("【全局异常捕获】>>  未知异常 stack = {}", ExceptionUtils.getStackTrace(e));
            result.setMessage("未知异常");
        }
        return result;
    }*/

    @ResponseBody
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public AjaxResult defaultExceptionHandler(MethodArgumentNotValidException argEx) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        FieldError fieldError = argEx.getBindingResult().getFieldError();
        String errorMsg = String.format("%s: %s", fieldError.getField(),
                fieldError.getDefaultMessage());
        //logger.error("【全局异常捕获】>> 参数校验异常  >>  {}", errorMsg);
        result.setMessage(errorMsg);

        return result;
    }

    @ResponseBody
    @ExceptionHandler(value = ConstraintViolationException.class)
    public AjaxResult defaultExceptionHandler(ConstraintViolationException argEx) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        Set<ConstraintViolation<?>> constraintViolations = argEx.getConstraintViolations();
        Iterator<ConstraintViolation<?>> iterator = constraintViolations.iterator();
        if (iterator.hasNext()) {
            result.setMessage(iterator.next().getMessage());
        } else {
            result.setMessage("请检查参数是否合法");
        }

        return result;
    }
    @ResponseBody
    @ExceptionHandler(value = MissingServletRequestParameterException.class)
    public AjaxResult defaultExceptionHandler(MissingServletRequestParameterException argEx) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        result.setMessage("参数: " + argEx.getParameterName() + " 是必须项");
        return result;
    }

    @ResponseBody
    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    public AjaxResult defaultExceptionHandler(HttpRequestMethodNotSupportedException e) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        String errorMsg = String.format("请求方式 %s 错误 ! 请使用 %s 方式", e.getMethod(), e.getSupportedHttpMethods());
        logger.error("【全局异常捕获】>> {}", errorMsg);
        result.setMessage(errorMsg);
        return result;
    }

    @ResponseBody
    @ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
    public AjaxResult defaultExceptionHandler(HttpMediaTypeNotSupportedException e) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        String errorMsg = String.format("请求类型 %s 错误 ! 请使用 %s 方式", e.getContentType(), e.getSupportedMediaTypes());
        logger.error("【全局异常捕获】>> {}", errorMsg);
        result.setMessage(errorMsg);
        return result;
    }

    @ResponseBody
    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    public AjaxResult defaultExceptionHandler(HttpMessageNotReadableException e) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        logger.error("【全局异常捕获】>>  请求体为空 stack = {}", ExceptionUtils.getStackTrace(e));
        if (e.getMessage().startsWith("Required request body is missing")){
            result.setMessage("请求体参数不能为空");
        }else {
            result.setMessage(e.getMessage());
        }
        return result;
    }

    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public AjaxResult defaultExceptionHandler(Exception e) {
        AjaxResult result = new AjaxResult();
        result.setStatus(0);
        result.setData(new Object());
        logger.error("【全局异常捕获】>>  未知异常 stack = {}", ExceptionUtils.getStackTrace(e));
        result.setMessage("未知异常");
        return result;
    }

}
