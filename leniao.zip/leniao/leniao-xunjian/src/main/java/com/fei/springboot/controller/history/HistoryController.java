package com.fei.springboot.controller.history;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.pojo.history.HistoryCountParam;
import com.fei.springboot.pojo.history.HistoryInfoParam;
import com.fei.springboot.service.history.HistoryService;
import com.fei.springboot.util.redis.RedisUtil;
import com.mysql.jdbc.exceptions.jdbc4.MySQLTimeoutException;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @Description: 历史模块controller
 * @Author: haosw
 * @CreateDate: 2019/4/15 9:42
 * @UpdateUser: haosw
 * @UpdateDate: 2019/4/15 9:42
 * @UpdateRemark: 修改内容
 * @Version: 1.2
 */
@CrossOrigin
@Controller
@RequestMapping(value = "/history")
public class HistoryController {

    private Logger logger = LoggerFactory.getLogger(HistoryController.class);

    @Autowired
    private HistoryService historyService;

    @RequestMapping(value = "/count",method = RequestMethod.POST)
    public @ResponseBody  AjaxResult count(@RequestBody HistoryCountParam param) {
        AjaxResult result = new AjaxResult();
        switch (param.getGroupType()) {
            case 1:
                if (param.getgUserId()==null){
                    result.addFail("上下级用户不能为空");
                    return result;
                }
                return this.historyService.findPersonHistoryCount(param);
            case 2:
                return this.historyService.findAreaHistoryCount(param);

        }

        result.addFail("暂无数据");
        return result;
    }


    @RequestMapping(value = "/paging",method = RequestMethod.POST)
    public @ResponseBody AjaxResult pagingHistoryInfo(@RequestBody HistoryInfoParam infoParam){
        AjaxResult result = new AjaxResult();

        try {
            switch (infoParam.getGroupType()) {
                case 1:
                    if (infoParam.getgUserId()==null){
                        result.addFail("上下级用户不能为空");
                        return result;
                    }
                    return this.historyService.findPersonHistoryInfo(infoParam);
                case 2:
                    return this.historyService.findAreaHistoryInfo(infoParam);

            }
        } catch (MySQLTimeoutException e) {
            logger.error("历史模块分页查询异常",e);
            result.addError("网络连接超时");
            return result;
        }

        result.addFail("暂无数据");
        return result;
    }



    @RequestMapping(value = "/findunit",method = RequestMethod.POST)
    public @ResponseBody AjaxResult getProjByAreaOrGrid(HttpServletRequest request, @RequestBody JSONObject jsonParam){
        AjaxResult result = new AjaxResult();
        String tokenVal = request.getHeader("access_token");
        if (StringUtils.isEmpty(tokenVal)){
            result.addFail("TOKEN不能为空");
            return result;
        }
        String prefix = "LN.IOT.User:";//004D162821FBDCC0493238FC06BA699D
        String access_token = prefix +tokenVal;
        String hget = RedisUtil.getInstance().hash().hget(access_token, "LN.LoginUserList");
        if (StringUtils.isEmpty(hget)){
            result.addFail("TOKEN已过期,请重新登录");
            return result;
        }
        JSONObject jsonObject = JSONObject.parseObject(hget);
        //Integer platform_id = jsonObject.getInteger("platform_id");
        Integer userId = jsonObject.getInteger("user_id");
        //判断用户权限
        Integer group_type = jsonObject.getInteger("group_type");
        if(group_type >2){
            result.addFail("权限不匹配");
            return result;
        }

        if (jsonParam.getInteger("platformId") == null || 0==jsonParam.getInteger("platformId")){
            result.addFail("平台id不能为空");
            return result;
        }
        List<JSONObject> unitList = this.historyService.findUnit(jsonParam,userId,group_type);
        if (CollectionUtils.isNotEmpty(unitList)){
            result.addSuccess("查询成功");
            result.setData(unitList);
        }else {
            result.addFail("没有数据");
        }

        return result;
    }




}
