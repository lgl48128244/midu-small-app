package com.fei.springboot.controller.common.dotnet;

import com.alibaba.fastjson.JSON;
import com.fei.springboot.constant.Const;
import com.fei.springboot.constant.SysConst;
import com.fei.springboot.controller.websocket.WebSocketServer;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevicenodeinfo;
import com.fei.springboot.domain.device.Tblndeviceinfo;
import com.fei.springboot.domain.unitavggrade.Tblnprojectinfo;
import com.fei.springboot.pojo.ErrPushDto;
import com.fei.springboot.pojo.common.*;
import com.fei.springboot.service.common.HbaseService;
import com.fei.springboot.service.common.ReceiveService;
import com.fei.springboot.service.device.TblndeviceinfoService;
import com.fei.springboot.service.project.TblnprojectinfoService;
import com.fei.springboot.util.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping(value = "/receive")
@Slf4j
public class ReceiveController {

    @Autowired
    private ReceiveService receiveService;
    @Autowired
    private TblndeviceinfoService tblndeviceinfoService;
    @Autowired
    private TblnprojectinfoService tblnprojectinfoService;

    public static boolean isCalculating = false;
    public static DateTime lastCalculate = DateTime.now();
    public static int times = 1;

    @PostMapping("webErrPush")
    public Object receiveMsgToWebPush(@RequestBody ErrPushDto.PushMsgV2 pushMsgV2) {

        //if (WebSocketServer.getOnlineCount() > 0) {
        if (DateTime.now().getMillis() / 1000 - WebSocketServer.getTimep() <= 60) {
            if (pushMsgV2 != null) {
                //存入Redis
                RedisUtil.SortSet sortSet = RedisUtil.getInstance().sortSet();
                long score = DateTime.now().getMillis() / 1000;
                long zadd = sortSet.zadd("JAVA-PushMsgV2", score, JSON.toJSONString(pushMsgV2));
                if (zadd == 1) {
                    log.info("Success---接受Web推送数据后保存成功");
                } else if (zadd == 0) {
                    log.info("Info---接受Web推送数据保存时发现数据已存在");
                } else {
                    log.info("Fail---接受Web推送数据后保存失败");
                }
                return zadd;
            }
            return "fail";
        } else {
            return 0;
        }
    }


    @RequestMapping("getAllDevEleUse")
    public Object excelFindAndDownload(@RequestBody @Valid DeviceEleUseOfProjectParamVO paramVO) {
        //如果没有正在导出的单位,或者上次导出的时间距离现在超过3分钟,则可以导出
        if (!ReceiveController.isCalculating || ReceiveController.lastCalculate.plusMinutes(Const.ELE_WAIT_TIME).isBeforeNow()) {
            List<Tblndeviceinfo> deviceList = this.tblndeviceinfoService.findDeviceListHasEleUseByProjId(paramVO.getProjId(), 0);
            if (CollectionUtils.isEmpty(deviceList)) {
                return AjaxResult.renderDataWithMsg( new DeviceEleUseResultExcelDTO(Collections.emptyList(), ""), "暂无用电设备");
            }
            ReceiveController.isCalculating = true;
            ReceiveController.lastCalculate = DateTime.now();

            Integer year = paramVO.getYear();
            Integer month = paramVO.getMonth();
            List<DeviceEleUseResultDTO> resultDTOList = new ArrayList<>();
            DeviceEleUseResultDTO deviceEleUseResultDTO = null;
            for (Tblndeviceinfo dev : deviceList) {
                deviceEleUseResultDTO = new DeviceEleUseResultDTO();
                BeanUtils.copyProperties(dev, deviceEleUseResultDTO);
                this.receiveService.findDeviceEleUseResultAllMonth_new(deviceEleUseResultDTO, year, month);
                resultDTOList.add(deviceEleUseResultDTO);
            }
            AjaxResult ajaxResult = new AjaxResult();
            String excelUrl = "";
            try {
                excelUrl = this.getExcelUrl(paramVO.getProjId(), paramVO.getYear(), paramVO.getMonth(), resultDTOList);
                ajaxResult.setMessage("导出资源充足,操作成功");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                ReceiveController.isCalculating = false;
            }
            //重置标志位
            ReceiveController.isCalculating = false;
            DeviceEleUseResultExcelDTO dto = new DeviceEleUseResultExcelDTO(resultDTOList, excelUrl);
            ajaxResult.setData(dto);
            return ajaxResult;
        } else {
            DeviceEleUseResultExcelDTO dto = new DeviceEleUseResultExcelDTO(Collections.emptyList(), "");
            return AjaxResult.renderDataWithMsg(dto,"导出资源占用中,请"+Const.ELE_WAIT_TIME+"分钟后再试");
        }
    }


    /**
     * 根据单位ID查询单位下设备的
     * 指定年月的每日的电量
     *
     * @param paramVO
     * @return
     */
    @RequestMapping("getAllDevEleUse_back")
    public Object findDeviceEleUseOfProject(@RequestBody @Valid DeviceEleUseOfProjectParamVO paramVO) {
        ReceiveController.isCalculating = true;
        ReceiveController.lastCalculate = DateTime.now();
        AjaxResult ajaxResult = new AjaxResult();
        //查询单位下的所有设备
        //List<Tblndeviceinfo> deviceList = this.tblndeviceinfoService.findDeviceListByProjId(paramVO.getProjId(), 0);
        List<Tblndeviceinfo> deviceList = this.tblndeviceinfoService.findDeviceListHasEleUseByProjId(paramVO.getProjId(), 0);
        List<DeviceEleUseResultDTO> resultDTOList = new ArrayList<>();
        for (Tblndeviceinfo dev : deviceList) {
            DeviceEleUseResultDTO deviceEleUseResultDTO = this.findDeviceEleUseResult(dev.getDevIdpk(), paramVO.getYear(), paramVO.getMonth());
            resultDTOList.add(deviceEleUseResultDTO);
        }
        //生成excel
        String excelUrl = "";
        try {
            excelUrl = this.getExcelUrl(paramVO.getProjId(), paramVO.getYear(), paramVO.getMonth(), resultDTOList);
            ajaxResult.setMessage("导出资源充足,操作成功");
        } catch (Exception e) {
            e.printStackTrace();
            ReceiveController.isCalculating = false;
        }
        ReceiveController.isCalculating = false;
        DeviceEleUseResultExcelDTO dto = new DeviceEleUseResultExcelDTO(resultDTOList, excelUrl);
        ajaxResult.setData(dto);
        return ajaxResult;
    }

    /**
     * 查询设备的指定年月的每日的电量
     *
     * @param paramVO
     * @return
     */
    @RequestMapping("deviceEleUseInfo")
    public Object findDeviceEleUseToDonet(@RequestBody @Valid DeviceEleUseParamVO paramVO) {
        log.error(paramVO.toString());
        return AjaxResult.renderSuccessData(this.findDeviceEleUseResult(paramVO.getDevIdpk(), paramVO.getYear(), paramVO.getMonth()));
    }


    /**
     * @param projId
     * @param year
     * @param month
     * @param resultDTOList
     * @return
     */
    public String getExcelUrl(Integer projId, Integer year, Integer month, List<DeviceEleUseResultDTO> resultDTOList) {

        //获取单位名称
        String projName = this.tblnprojectinfoService.findProjectName(projId);
        //TODO 流程走完改
        if (projName == null || "".equals(projName)) {
            return null;
        }

        //TODO 流程走完改
        if (resultDTOList.size() == 0) {
            return null;
        }

        //创建excel文件
        HSSFWorkbook book = new HSSFWorkbook();

        /*第一个sheet页开始*/
        HSSFSheet sheet1 = book.createSheet("每月用电量");
        //设置标题样式
        HSSFCellStyle titleStyle = book.createCellStyle();
        titleStyle.setAlignment(HorizontalAlignment.CENTER);
        titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        titleStyle.setWrapText(true);
        HSSFFont nameRowFont = book.createFont();
        nameRowFont.setFontName("宋体");
        nameRowFont.setFontHeightInPoints((short) 30);
        nameRowFont.setBold(true);//加粗
        titleStyle.setFont(nameRowFont);

        //创建自动换行样式
        CellStyle wrapTextStyle = book.createCellStyle();
        wrapTextStyle.setWrapText(true); //设置换行
        wrapTextStyle.setAlignment(HorizontalAlignment.CENTER);
        wrapTextStyle.setVerticalAlignment(VerticalAlignment.CENTER);


        //爱克林2020年2月份用电量统计表
        String title = projName + year + "年" + month + "月份用电量统计报表";
        String[] headInfo = {"序号", "监测线路", "月份", "用电量(单位：KWh)"};

        //设置头部格式和信息
        this.initSheetHeadInfo(sheet1, titleStyle, wrapTextStyle, title, headInfo);


        //sheet1正文数据
        DeviceEleUseResultDTO data;
        //HSSFRow zwRow = null;
        HSSFCell zwCell;
        for (int i = 0; i < resultDTOList.size(); i++) {
            data = resultDTOList.get(i);

            HSSFRow dataRow = sheet1.createRow(i + 2);
            //序号
            zwCell = dataRow.createCell(0);
            zwCell.setCellValue(i + 1);
            //监测路线(安装位置)
            zwCell = dataRow.createCell(1);
            zwCell.setCellValue(data.getInstallLocation());
            //月份
            zwCell = dataRow.createCell(2);
            zwCell.setCellValue(month);
            //用电量
            zwCell = dataRow.createCell(3);
            zwCell.setCellValue(data.getTotal());
        }
        /*第一个sheet页完毕*/

        /*第二个sheet页开始*/
        HSSFSheet sheet2 = book.createSheet("每日用电量");

        DateTime firstDayOfMonth = new DateTime(year, month, 1, 0, 0);
        int endDay = firstDayOfMonth.dayOfMonth().withMaximumValue().getDayOfMonth();
        //加上序号和名称或日期的列数 2
        headInfo = new String[endDay + 2];
        for (int i = 0; i < headInfo.length; i++) {
            if (i == 0) {
                headInfo[0] = "序号";
            } else if (i == 1) {
                headInfo[1] = "名称/日期";
            } else {
                headInfo[i] = firstDayOfMonth.toString("yyyy-MM-dd");
                firstDayOfMonth = firstDayOfMonth.plusDays(1);
            }
        }

        this.initSheetHeadInfo(sheet2, titleStyle, wrapTextStyle, title, headInfo);


        HSSFRow dataRow;
        for (int i = 0; i < resultDTOList.size(); i++) {
            data = resultDTOList.get(i);
            dataRow = sheet2.createRow(i + 2);//从第三行开始是数据
            //序号
            zwCell = dataRow.createCell(0);
            zwCell.setCellValue(i + 1);
            //名称(安装位置)
            zwCell = dataRow.createCell(1);
            zwCell.setCellValue(data.getInstallLocation());
            //每天数据
            List<DayeleUse> dayEleUseList = data.getDayEleUseList();
            for (int j = 0; j < dayEleUseList.size(); j++) {
                HSSFCell hssfCell = dataRow.createCell(j + 2);
                hssfCell.setCellValue(dayEleUseList.get(j).getValue());
            }
        }

        //保存文件到本地
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            book.write(os);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        byte[] b = os.toByteArray();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(b);

        String url = this.saveFileToLocal(inputStream, firstDayOfMonth.minusDays(1).toString("yyyy-MM"), title + ".xls");
        ReceiveController.isCalculating = false;
        return url;
    }

    /**
     * 设置sheet页的头部样式
     *
     * @param sheet
     * @param titleStyle
     * @param wrapTextStyle
     * @param title
     * @param headInfo
     */
    private void initSheetHeadInfo(HSSFSheet sheet, HSSFCellStyle titleStyle, CellStyle wrapTextStyle, String title, String[] headInfo) {
        //创建标题行
        HSSFRow row0 = sheet.createRow(0);
        //row0.setHeight((short) 500);// 设置行高
        //设置表格的大标题的值
        HSSFCell nameCell = null;
        for (int i = 0; i < headInfo.length; i++) {
            nameCell = row0.createCell(i);
            nameCell.setCellStyle(wrapTextStyle);
            if (i == 0) {
                nameCell.setCellStyle(wrapTextStyle);
                nameCell.setCellValue(new HSSFRichTextString(title));
            }
        }
        //标题合并单元格
        CellRangeAddress nameCellRange = new CellRangeAddress(0, 0, 0, headInfo.length - 1);
        sheet.addMergedRegion(nameCellRange);


        //创建表格表头数据行 //设置行高
        HSSFRow row1 = sheet.createRow(1);
        //row1.setHeight((short) 20);

        /*设置列宽度*/
        HSSFCell cell = null;
        for (int i = 0; i < headInfo.length; i++) {
            if (i == 1) {
                sheet.setColumnWidth(i, 10 * 256);
            } else if (i > 1) {
                sheet.setColumnWidth(i, 20 * 256);
            } else {
                sheet.setColumnWidth(i, 15 * 256);
            }
            //sheet.autoSizeColumn(1, true);
            cell = row1.createCell(i);
            cell.setCellValue(headInfo[i]);
            //cell.setCellStyle(titleStyle);
        }
    }

    /**
     * @param inputStream
     * @param fileName
     */
    private synchronized String saveFileToLocal(InputStream inputStream, String date, String fileName) {
        OutputStream os = null;
        String url = "";
        try {
            String path = Const.ELE_USE_INFO_SAVE_PATH + date + "\\";
            // 2、保存到临时文件
            // 1K的数据缓冲
            byte[] bs = new byte[1024];
            // 读取到的数据长度
            int len;
            // 输出的文件流保存到本地文件
            File tempFile = new File(path);
            if (!tempFile.exists()) {
                tempFile.mkdirs();
            }
            os = new FileOutputStream(tempFile.getPath() + File.separator + fileName);
            // 开始读取
            while ((len = inputStream.read(bs)) != -1) {
                os.write(bs, 0, len);
            }
            //TODO
            url = Const.ELE_USE_INFO_FJ_URL + date + "/" + fileName;
            return url;
        } catch (Exception e) {
            e.printStackTrace();
            ReceiveController.isCalculating = false;
        } finally {
            // 完毕，关闭所有链接
            try {
                if (os != null) {
                    os.close();
                }
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return url;

    }


    /**
     * 通用的获取设备指定年月份的用电量
     *
     * @param devIdpk
     * @param year
     * @param month
     * @return
     */
    private DeviceEleUseResultDTO findDeviceEleUseResult(Integer devIdpk, Integer year, Integer month) {
        //获取设备的基本信息
        DeviceEleUseResultDTO deviceEleUseResultDTO = this.tblndeviceinfoService.findDevInstallInfo(devIdpk);
        //没有此设备
        if (deviceEleUseResultDTO == null) {
            return this.returnZeroVal(deviceEleUseResultDTO, year, month, devIdpk);
        }
        //获取设备信息
        List<Tblndevicenodeinfo> nodeList = this.receiveService.findDeviceNodeList(devIdpk);
        if (nodeList == null || nodeList.size() == 0) {
            //属于没有节点的设备 都反0
            return this.returnZeroVal(deviceEleUseResultDTO, year, month, devIdpk);
        }
        List<String> eleNodeList = Arrays.asList(SysConst.eleNodeArray);
        StringBuffer sb = new StringBuffer();
        for (Tblndevicenodeinfo node : nodeList) {
            if (eleNodeList.contains(node.getDevNode1())) {
                sb.append(node.getDevNode1()).append("-");
            }
        }
        //没有电量的节点 都反0
        if (sb.toString().length() == 0) {
            return this.returnZeroVal(deviceEleUseResultDTO, year, month, devIdpk);
        }
        String nodeArray = sb.toString();
        nodeArray = nodeArray.substring(0, nodeArray.length() - 1);
        //获取时间
        DateTime firstDayOfMonth = new DateTime(year, month, 1, 0, 0, 0);
        DateTime beforOfFirstDay = firstDayOfMonth.minusDays(7);
        DateTime endDayOfMonth = firstDayOfMonth.dayOfMonth().withMaximumValue().hourOfDay().withMaximumValue().millisOfDay().withMaximumValue();
        int endDay = endDayOfMonth.getDayOfMonth();
        List<DayeleUse> dayeleUseList = new ArrayList<>();
        //总用电量
        double sumEleUse = 0;
        //上一天的最大值
        double beforMaxVal = 0;
        for (int i = 1; i <= endDay; i++) {
            if (i == 1) {
                //1号 第一条数据
                double firstVal = HbaseService.getDeviceEleNodeNewstSum(devIdpk, nodeArray, beforOfFirstDay.toString("yyyyMMddHHmmss"), firstDayOfMonth.toString("yyyyMMddHHmmss"));
                double endVal = HbaseService.getDeviceEleNodeNewstSum(devIdpk, nodeArray, firstDayOfMonth.toString("yyyyMMddHHmmss"), firstDayOfMonth.millisOfDay().withMaximumValue().toString("yyyyMMddHHmmss"));
                double use = endVal - firstVal < 0 ? 0 : endVal - firstVal;
                DayeleUse firstDayeleUse = new DayeleUse();
                firstDayeleUse.setTime(firstDayOfMonth.toString("yyyy-MM-dd"));
                firstDayeleUse.setValue(BigDecimal.valueOf(use).setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                dayeleUseList.add(firstDayeleUse);
                sumEleUse = BigDecimal.valueOf(use).add(BigDecimal.valueOf(sumEleUse)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
                if (endVal >= 0) {
                    beforMaxVal = endVal;
                }
                continue;
            }
            //不是第一天的直接取当前的最大的值
            DateTime start = new DateTime(year, month, i, 0, 0, 0);
            DateTime end = start.millisOfDay().withMaximumValue();
            double currMaxVal = HbaseService.getDeviceEleNodeNewstSum(devIdpk, nodeArray, start.toString("yyyyMMddHHmmss"), end.toString("yyyyMMddHHmmss"));
            double use = currMaxVal - beforMaxVal < 0 ? 0 : currMaxVal - beforMaxVal;
            DayeleUse currDayeleUse = new DayeleUse();
            currDayeleUse.setTime(start.toString("yyyy-MM-dd"));
            currDayeleUse.setValue(BigDecimal.valueOf(use).setScale(2, BigDecimal.ROUND_HALF_UP).toString());
            dayeleUseList.add(currDayeleUse);
            sumEleUse = BigDecimal.valueOf(use).add(BigDecimal.valueOf(sumEleUse)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            if (currMaxVal >= 0) {
                beforMaxVal = currMaxVal;
            }
        }
        deviceEleUseResultDTO.setDayEleUseList(dayeleUseList);
        deviceEleUseResultDTO.setTotal(BigDecimal.valueOf(sumEleUse).setScale(2, BigDecimal.ROUND_HALF_UP).toString());
        return deviceEleUseResultDTO;
    }


    /**
     * 没有电量节点,没有节点,没有当前设备的统一反0用电
     *
     * @param year
     * @param month
     * @param devIdpk
     * @return
     */
    private DeviceEleUseResultDTO returnZeroVal(DeviceEleUseResultDTO deviceEleUseResultDTO, Integer year, Integer month, Integer devIdpk) {
        if (deviceEleUseResultDTO == null) {
            deviceEleUseResultDTO = new DeviceEleUseResultDTO();
        }
        deviceEleUseResultDTO.setDevIdpk(devIdpk);
        deviceEleUseResultDTO.setTotal("0.00");
        List<DayeleUse> dayeleUseList = new ArrayList<>();
        //当月1号
        DateTime time = new DateTime(year, month, 1, 0, 0, 0);
        //当月的天数
        int endDayOfMonth = time.dayOfMonth().withMaximumValue().getDayOfMonth();
        for (int i = 1; i <= endDayOfMonth; i++) {
            //每天的时间
            DateTime day = new DateTime(year, month, i, 0, 0, 0);
            DayeleUse dayeleUse = new DayeleUse();
            dayeleUse.setTime(day.toString("yyyy-MM-dd"));
            dayeleUse.setValue("0.00");
            dayeleUseList.add(dayeleUse);
        }
        deviceEleUseResultDTO.setDayEleUseList(dayeleUseList);
        return deviceEleUseResultDTO;
    }

}
