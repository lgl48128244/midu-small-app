package com.fei.springboot.controller.generalpage;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevty;
import com.fei.springboot.domain.generalpage.GeneralDeviceparameter;
import com.fei.springboot.pojo.generalpage.parameter.GeneralParamPageInputDto;
import com.fei.springboot.pojo.generalpage.parameter.GeneralParamPageOutputDto;
import com.fei.springboot.service.generalpage.GeneralDeviceDetailService;
import com.fei.springboot.service.generalpage.GeneralDeviceParameterService;
import com.fei.springboot.service.generalpage.GeneralDeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin
@Controller
@Validated
@RequestMapping(value = "/param")
public class GeneralDeviceParameterController {


    @Autowired
    private GeneralDeviceService generalDeviceService;
    @Autowired
    private GeneralDeviceParameterService generalDeviceParameterService;


    /**
    * 新增参数页的配置接口
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/12/2 11:48
    */
    @PostMapping(value = "/insert")
    @ResponseBody
    public AjaxResult insert(@RequestBody @Valid GeneralParamPageInputDto inputDto) throws Exception{
        AjaxResult result = new AjaxResult();
        //查看是否被绑定别的型号
        Tblndevty devty = this.generalDeviceService.findDevty(inputDto.getDevTyId());
        if (devty == null) {
            result.addFail("此设备型号已不存在");
            return result;
        }
        Integer paramPageBind = devty.getParamPageBind();
        //如果已绑定在了某个型号下
        if (paramPageBind != null && !paramPageBind.equals(0)) {
            result.addFail("该型号已绑定在了ID为:" + paramPageBind + " 的型号下,不可重复添加 ");
            return result;
        }
        //判断是否已添加过
        GeneralDeviceparameter parmInfo = this.generalDeviceParameterService.findParamInfoByPk(inputDto.getDevTyId());
        if (parmInfo != null) {
            result.addFail("已存在相同的型号配置信息");
            return result;
        }
        int flag = this.generalDeviceParameterService.insert(inputDto);
        if (flag == -1) {
            result.addFail("初始化原有关联类型失败");
        } else if (flag == -2) {
            result.addFail("添加新的关联类型失败");
        } else if (flag > 0) {
            result.addSuccess("新增成功");
        } else {
            result.addFail("数据库异常,更新失败");
        }

        return result;

    }



    /**
    * 更新参数页的配置
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/12/2 10:51
    */
    @PostMapping(value = "/update")
    @ResponseBody
    public AjaxResult update(@RequestBody @Valid GeneralParamPageInputDto inputDto) throws Exception{
        AjaxResult result = new AjaxResult();
        //查看此型号是否还存在
        Tblndevty devty = this.generalDeviceService.findDevty(inputDto.getDevTyId());
        if (devty == null) {
            result.addFail("此设备型号已不存在");
            return result;
        }
        int flag = this.generalDeviceParameterService.update(inputDto);
        if (flag == -1) {
            result.addFail("初始化原有关联类型失败");
        } else if (flag == -2) {
            result.addFail("添加新的关联类型失败");
        } else if (flag > 0) {
            result.addSuccess("更新成功");
        } else {
            result.addFail("数据库异常,更新失败");
        }

        return result;

    }


    /**
    * 查询参数配置信息接口
    * @author      Haosw
    * @param
    * @return
    * @exception
    * @date        2019/12/2 11:53
    */
    @RequestMapping(value = "/get")
    @ResponseBody
    public AjaxResult get(@RequestParam("devTyId") Integer devTyId){
        AjaxResult result = new AjaxResult();
        //先判断此型号绑定了在哪个主型号上
        Tblndevty devty = this.generalDeviceService.findDevty(devTyId);
        if (devty == null) {
            result.addFail("没有该型号的基本信息,请先添加此设备类型");
            return result;
        }
        Integer paramPageBind = devty.getParamPageBind();
        if (paramPageBind != null && paramPageBind != 0) {
            devTyId = paramPageBind;
        }
        /*GeneralDeviceparameter paramInfoByPk = this.generalDeviceParameterService.findParamInfoByPk(devTyId);
        if (paramInfoByPk == null) {
            result.addFail("暂无数据");
            return result;
        }*/

        GeneralParamPageOutputDto totalInfo = this.generalDeviceParameterService.findTotalInfo(devTyId);
        if (totalInfo == null) {
            result.addFail("JSON模板数据解析异常");
            return result;
        }
        result.addSuccess("查询成功");
        result.setData(totalInfo);
        return result;
    }




}
