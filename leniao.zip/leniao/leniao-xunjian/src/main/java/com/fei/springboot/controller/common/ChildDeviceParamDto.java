package com.fei.springboot.controller.common;


import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

/**
 * 用于批量导入是Controller层接收参数的包装类
 */
public class ChildDeviceParamDto {

    @NotNull(message = "文件不能为空")
    private MultipartFile file;

    @NotNull(message = "单位Id不能为空")
    private Integer projId;

    @NotNull(message = "厂商Id不能为空")
    private Integer firmId;

    @NotNull(message = "设备系统Id不能为空")
    private Integer devSysId;

    @NotNull(message = "设备分钟Id不能为空")
    private Integer groupId;

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public Integer getProjId() {
        return projId;
    }

    public void setProjId(Integer projId) {
        this.projId = projId;
    }

    public Integer getFirmId() {
        return firmId;
    }

    public void setFirmId(Integer firmId) {
        this.firmId = firmId;
    }

    public Integer getDevSysId() {
        return devSysId;
    }

    public void setDevSysId(Integer devSysId) {
        this.devSysId = devSysId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
}
