package com.fei.springboot.controller.filter;


import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.util.ParameterRequestWrapper;
import com.fei.springboot.util.redis.RedisUtil;
import org.springframework.stereotype.Component;
import redis.clients.jedis.exceptions.JedisDataException;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;



@Component
@WebFilter(urlPatterns={"/elemon/unit/firest/find","/combo/*","/charge/*","/dev/*","/scene/*","/circuitBreakerV3/*"}, filterName="tokenAuthorFilter")
public class TokenAuthorFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        servletResponse.setCharacterEncoding("utf-8");
        servletResponse.setContentType("application/json;charset=utf-8");
        //PrintWriter out = response.getWriter();
        String prefix = "LN.IOT.User:";//004D162821FBDCC0493238FC06BA699D
        String access_token = prefix + request.getHeader("access_token");//LN.LoginUserList
        //RedisUtil redisUtil = RedisUtil.getInstance();
        Integer platform_id = 0;
        Integer userId = 0;
        Integer group_type = 0;
        Integer group_onlyread = 0;
        try {
            //System.out.println("access_token为: ===  "+access_token);
            String hget = RedisUtil.getInstance().hash().hget(access_token, "LN.LoginUserList");
            //System.out.println("从Redis中获取的数据hget:  ====  " +hget);
            if (!StringUtils.isEmpty(hget)){
                JSONObject jsonObject = JSONObject.parseObject(hget);
                platform_id = jsonObject.getInteger("platform_id");
                userId = jsonObject.getInteger("user_id");
                group_type = jsonObject.getInteger("group_type");
                group_onlyread = jsonObject.getInteger("group_onlyread");
            }else{
                System.out.println("====没有从redis中获取到token=====");
                platform_id =0;
            }

            Map<String,String[]> map = new HashMap<>(request.getParameterMap());
            map.put("platformId",new String[]{platform_id+""});
            map.put("userId",new String[]{userId+""});
            map.put("groupType",new String[]{group_type+""});
            map.put("groupOnlyread",new String[]{group_onlyread+""});
            request = new ParameterRequestWrapper(request,map);
        } catch (JedisDataException e) {
            e.printStackTrace();

        }
        filterChain.doFilter(request, response);

    }

    @Override
    public void destroy() {

    }
}
