package com.fei.springboot.config.dbconfig;

public enum DataSourceType {

    produceWrite("produce-write", "校验主库"),
    produceRead("produce-read", "校验从库"),
	releaseRead("release-read", "业务从库"),
    releaseWrite("release-write", "业务主库");


    private String type;
    
    private String name;

    DataSourceType(String type, String name) {
        this.type = type;
        this.name = name;
    }

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    
}
