package com.fei.springboot.controller.admin.devty;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.domain.admin.devTy.Tblndevicesend;
import com.fei.springboot.domain.admin.devTy.Tblndevicesendsystem;
import com.fei.springboot.pojo.admin.devty.*;
import com.fei.springboot.service.admin.devty.SystemService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by songtm on 2019/8/14.
 */
@CrossOrigin
@RestController
@RequestMapping("/system")
public class SystemController {
    @Autowired
    private SystemService systemService;

    //系统管理页面  查询系统列表
    @PostMapping("/list")
    public AjaxResult systemList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        String  sysname =param.getString("sysname");
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        PageInfo<Tblndevicesendsystem> pageInfo=systemService.systemList(index,size,sysname);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }

    //添加系统
    @PostMapping("/addSystem")
    public AjaxResult addSystem(@RequestBody Tblndevicesendsystem tblndevicesendsystem){
        AjaxResult result = new AjaxResult();
        try{
            result = systemService.addSystem(tblndevicesendsystem);
            result.setMessage("添加成功");
        }catch (Exception e){
            result.addFail("添加失败");
        }

        return result;
    }

    //编辑系统
    @PostMapping("/updateSystem")
    public AjaxResult updateSystem(@RequestBody Tblndevicesendsystem tblndevicesendsystem){
        AjaxResult result = new AjaxResult();

        if(StringUtils.isEmpty(tblndevicesendsystem.getSid())){
            result.addFail("sid为必传字段");
            return result;
        }

        try {
            result = systemService.updateSystem(tblndevicesendsystem);
            result.setMessage("更新成功");
        }catch (Exception e){
            result.addFail("更新失败");
        }
        return result;
    }
/*
    //设备管理页面  设备列表 已配置转发的设备列表
    @PostMapping("/devList")
    public AjaxResult devList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        String sid = param.getString("sid");
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        String projName = param.getString("projName");
        PageInfo<SystemDevDto> pageInfo = systemService.devList(index,size,sid,projName);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }*/

    //编辑设备
    @PostMapping("/updateDevData")
    public AjaxResult updateDevData(@RequestBody Tblndevicesend tblndevicesend){
        AjaxResult result = new AjaxResult();
        try{
            result = systemService.updateDevData(tblndevicesend);
            result.setMessage("编辑成功");
        }catch (Exception e){
            result.addFail("编辑失败");
        }

        return result;
    }

    /*//添加设备  设备列表  未配置转发的设备列表
    @PostMapping("/disDevList")
    public AjaxResult disDevList(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        String devSignature = param.getString("devSignature");
        String projName = param.getString("projName");
        String systemId = param.getString("SystemId");
        PageInfo<DistributionDevDto> pageInfo = systemService.disDevList(index,size,devSignature,projName,systemId);
        if(pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }
*/
  /*  //添加设备
    @PostMapping("/addDev")
    public  AjaxResult addDev(@RequestBody AddDevDto addDevDto){
        AjaxResult result = new AjaxResult();
        try{
            result = systemService.addDev(addDevDto);
            result.setMessage("添加成功");
        }catch (Exception e){
            result.addFail("添加失败");
        }
        return result;
    }*/

    //批量添加设备转发
    @PostMapping("/addDevs")
    public  AjaxResult addDevs(@RequestBody AddDevs addDevs){
        AjaxResult result = new AjaxResult();
        try{
             systemService.addDevs(addDevs);
             result.setMessage("设置转发成功");
        }catch (Exception e){
            result.addFail("设置转发失败");
        }
        return  result;
    }


  /*  //取消转发
    @PostMapping("/clearSend")
    public AjaxResult clearSend(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int devid = param.getIntValue("devid");
        try {
            systemService.deleteSend(devid);
            result.setMessage("删除成功");
        }catch (Exception e){
            result.addFail("删除失败");
        }
        return result;
    }*/

    //批量取消转发
    @PostMapping("/clearSends")
    public AjaxResult clearSends(@RequestBody CleaSendInfo cleaSendInfo){
        AjaxResult result = new AjaxResult();
        try{
            systemService.deleteSends(cleaSendInfo);
            result.setMessage("取消成功");
        }catch (Exception e){
            result.addFail("取消失败");
        }
        return result;
    }

    //保存测试转发的数据
    @PostMapping("/seveSend")
    public AjaxResult saveSendData(@RequestBody Sendata sendata ){
        AjaxResult result = new AjaxResult();
        try{
            systemService.updateSendData(sendata);
            result.setMessage("保存成功");
        }catch (Exception e){
            result.addFail("保存失败");
        }

        return result;
    }

    //添加设备  设备列表  未配置设备转发管理
    @PostMapping("/disDevLists")
    public AjaxResult disDevLists(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        String devSignature = param.getString("devSignature");
        String projName = param.getString("projName");
        PageInfo<DistributionDevDto> pageInfo = systemService.disDevLists(index,size,devSignature,projName);
        if(pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }

    //设备管理页面  设备列表 已配置转发的设备列表
    @PostMapping("/devLists")
    public AjaxResult devLists(@RequestBody JSONObject param){
        AjaxResult result = new AjaxResult();
        String sid = param.getString("sid");
        int index=param.getIntValue("index");
        int size=param.getIntValue("size");
        String projName = param.getString("projName");
        String devSignature = param.getString("devSignature");
        PageInfo<SystemDevDto> pageInfo = systemService.devLists(index,size,sid,projName,devSignature);
        if (pageInfo.getTotal()>0){
            result.addSuccess("查询成功");
            result.setData(pageInfo);
        }else {
            result.addFail("没有数据");
        }
        return result;
    }

    //查询所有的系统
    @PostMapping("/selectSys")
    public AjaxResult slectSys(){
        AjaxResult result=new AjaxResult();
        result=systemService.selectSys();
        return result;
    }

    @PostMapping(value = "/hello")
    public void getRequest(@RequestBody JSONObject param){
        System.out.println(param.toJSONString());

    }




}
