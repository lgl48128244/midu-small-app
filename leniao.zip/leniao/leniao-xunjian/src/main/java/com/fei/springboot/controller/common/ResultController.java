package com.fei.springboot.controller.common;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.constant.Const;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.service.common.CommonService;
import com.fei.springboot.util.UUIDUtil;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.validation.constraints.NotNull;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@CrossOrigin
@RestController
@Validated
@RequestMapping(value = "/getneedresult")
public class ResultController {

    @Autowired
    private CommonService commonService;

    // @ApiOperation(value="获取唯一主键", notes="获取唯一主键")
    @RequestMapping(value = "/getuuid", method = RequestMethod.POST)
    public AjaxResult getUUID() {
        AjaxResult result = new AjaxResult();
        String uuid = UUIDUtil.getUUID();
        while (StringUtils.isEmpty(uuid)) {
            uuid = UUIDUtil.getUUID();
        }
        result.addSuccess("请求成功");
        result.setData(uuid);
        return result;
    }

    @PostMapping(value = "/picupload")
    public AjaxResult picUpload(@RequestParam("file") MultipartFile file) {
        AjaxResult result = new AjaxResult();
        if (file.isEmpty()) {
            result.addFail("未收到图片");
            return result;
        }
        try {
            //检查是否是图片
            BufferedImage bi = ImageIO.read(file.getInputStream());
            if (bi == null) {
                result.addFail("上传的不是图片");
                return result;
            }

            //判断图片大小
            long size = file.getSize();
            if (size > Const.UPLOAD_FILE_SIZE * 1024 * 1024) {
                result.addFail("所传图片不能大于"+Const.UPLOAD_FILE_SIZE+"MB");
                return result;
            }
            //获取图片名称带后缀名
            String originalFilename = file.getOriginalFilename();//"微信截图90283778.png"
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currDate = new Date();
            //指定保存的路径
            String savePath = Const.NEW_PIC_SAVE_PATH + sdf.format(currDate);
            //获取后缀
            String extendName = originalFilename.substring(originalFilename.lastIndexOf("."), originalFilename.length());
            UUID uuid = UUID.randomUUID();
            //重新生成随机的图片名称防止重复后覆盖丢失或名称自动加1
            String fileName = uuid.toString().replaceAll("-", "") + extendName;
            //创建一个文件
            File dir = new File(savePath, fileName);
            //创建文件的保存路径
            File filepath = new File(savePath);
            //如果保存路径不存在  则 创建这个目录文件加
            if (!filepath.exists()) {
                filepath.mkdirs();
            }
            //将文件保存
            file.transferTo(dir);
            String picName = Const.NEW_PIC_SITE_URL + sdf.format(currDate) + "/" + fileName;
            result.addSuccess("图片上传成功");
            result.setData(picName);
        } catch (IOException e) {
            e.printStackTrace();
            result.addFail("图片上传失败");
        }

        return result;
    }


    //查询单位的系统
    @PostMapping(value = "/systemOfUnit")
    public AjaxResult findSystemOfUnit(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer unitId = param.getInteger("projId");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        String sysName = param.getString("devSysName");
        List<JSONObject> list = this.commonService.findSystemOfUnit(unitId, sysName);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("暂无数据");
        }

        return result;
    }

    /**
    * 查询单位下设备所属的分组
    * @author      Haosw
    * @param       param: projId:单位id  devSysId:系统id
    * @return
    * @exception
    * @date        2019/10/9 14:18
    */
    @PostMapping(value = "/groupOfUnit")
    public AjaxResult findGroupOfUnit(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer unitId = param.getInteger("projId");
        Integer devSysId = param.getInteger("devSysId");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        if (devSysId == null) {
            result.addFail("系统id不能为空");
            return result;
        }

        String groupName = param.getString("groupName");
        List<JSONObject> list = this.commonService.findGroupOfUnit(unitId, devSysId, groupName);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("暂无数据");
        }

        return result;
    }

    /**
     * 查询分组下的设备
     * @author      Haosw
     * @param       param projId:单位id  devSysId:设备系统id
     * @return
     * @exception
     * @date        2019/10/9 14:05
     */
    @PostMapping(value = "/deviceOfUnit")
    public AjaxResult findDeviceOfUnit(@RequestBody JSONObject param) {
        AjaxResult result = new AjaxResult();
        Integer unitId = param.getInteger("projId");
        Integer devgroupId = param.getInteger("devgroupId");
        Integer devSysId = param.getInteger("devSysId");
        if (unitId == null) {
            result.addFail("单位id不能为空");
            return result;
        }
        if (devgroupId == null) {
            result.addFail("分组id不能为空");
            return result;
        }
        if (devSysId == null) {
            result.addFail("系统id不能为空");
            return result;
        }
        String installLocation = param.getString("installLocation");
        List<JSONObject> list = this.commonService.findDeviceOfUnit(unitId, devgroupId, installLocation,devSysId);
        if (CollectionUtils.isNotEmpty(list)) {
            result.addSuccess("查询成功");
            result.setData(list);
        } else {
            result.addFail("暂无数据");
        }

        return result;
    }


    /**
    * 查询平台列表
    * @author      Haosw
    * @param       platformName  平台名称  可以为空 不能为null
    * @exception
    * @date        2019/11/21 17:48
    */

    @RequestMapping(value = "/platList")
    public AjaxResult platformList(@NotNull(message = "平台名称字段不能为NULL")
                                   @Length(max = 20, message = "平台名称长度必须小于20字符")
                                   @RequestParam("platformName") String platformName){
        //查询平台数据
        List<HashMap<String, Object>> plats = this.commonService.findPlatfomrsByName(platformName);
        AjaxResult result = new AjaxResult();
        if (CollectionUtils.isNotEmpty(plats)) {
            result.addSuccess("查询成功");
            result.setData(plats);
        }else {
            result.addFailWithArray("没有平台数据");
        }
        return result;
    }


    //查询厂商列表
    @RequestMapping(value = "/firmList")
    public AjaxResult firmList(@NotNull(message = "厂商名称字段不能为NULL")
                                   @Length(max = 20, message = "平台名称长度必须小于20字符")
                                   @RequestParam("firmName") String firmName){
        //查询厂商数据
        List<HashMap<String, Object>> firms = this.commonService.findFirmsByName(firmName);
        AjaxResult result = new AjaxResult();
        if (CollectionUtils.isNotEmpty(firms)) {
            result.addSuccess("查询成功");
            result.setData(firms);
        }else {
            result.addFailWithArray("没有厂商数据");
        }
        return result;
    }



    /**
     * 查询系统列表
     * @author      Haosw
     * @param
     * @exception
     * @date        2019/11/21 17:54
     */
    @RequestMapping(value = "/devsysList")
    public AjaxResult devSysList(@NotNull(message = "系统名称字段不能为NULL")
                                   @Length(max = 20, message = "系统名称长度必须小于20字符")
                                   @RequestParam("devSysName") String devSysName){
        //查询平台数据
        List<HashMap<String, Object>> sysList = this.commonService.finddevSysByName(devSysName);
        AjaxResult result = new AjaxResult();
        if (CollectionUtils.isNotEmpty(sysList)) {
            result.addSuccess("查询成功");
            result.setData(sysList);
        }else {
            result.addFailWithArray("暂无数据");
        }
        return result;
    }



}
