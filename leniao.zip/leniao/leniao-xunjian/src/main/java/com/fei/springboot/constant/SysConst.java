package com.fei.springboot.constant;

import java.util.HashMap;

public class SysConst {

    //各个平台的的智慧消防AI大脑的token 爱德和乐鸟一致



    public static final HashMap<String, String> AI_PLATORM_TOKEN = new HashMap<>();

    static
    {
        AI_PLATORM_TOKEN.put("1", "6047FBD2EFF77CF395BDE618E6E90EA4");//redis中的前缀为:LN.IOT.User:
        AI_PLATORM_TOKEN.put("2", "6048DAA0691816BA2F8286CC1DE59C9E");
        AI_PLATORM_TOKEN.put("3", "6049FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("4", "6050FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("5", "6051FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("6", "6052FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("7", "6053FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("8", "6054FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("9", "6055FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("10", "6056FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("11", "6057FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("12", "6084FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("13", "6685FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("14", "6686FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("15", "6687FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("16", "6688FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("17", "6689FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("18", "6690FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("19", "6691FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("20", "6692FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("21", "6693FBD2EFF77CF395BDE618E6E90EA4");
        AI_PLATORM_TOKEN.put("22", "6694FBD2EFF77CF395BDE618E6E90EA4");
    }


    //支持诊断的错误类型
    public static final Integer[] errTyArray = {0,6, 5, 159, 160, 33, 34, 4};
    //电力监控的设备类型 14,45,46,71,83,191为智慧用电,55,159,171,174为灭弧保护器 175,192为智能断路器
    public static final Integer[] wedevTyArray = {14,45,46,71,83,191};
    public static final Integer[] aedevTyArray = {55,159,171,174};
    public static final Integer[] cb2sdevTyArray = {175,192};

    /**
     * 设备电量节点,截止到2020-04-15 所有设备的电量节点都无外乎这四种
     * QA:A相电量
     * QB:C相电量
     * QC:C相电量
     * Q:灭弧设备的电量
     */
    public static final String[] eleNodeArray = {"QA", "QB", "QC","Q"};

}
