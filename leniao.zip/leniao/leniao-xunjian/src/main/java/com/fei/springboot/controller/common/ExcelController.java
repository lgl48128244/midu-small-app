package com.fei.springboot.controller.common;

import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import com.alibaba.fastjson.JSONObject;
import com.fei.springboot.domain.AjaxResult;
import com.fei.springboot.service.common.CommonService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/excel")
public class ExcelController {

    private Logger logger = LoggerFactory.getLogger(ExcelController.class);

    @Autowired
    private CommonService commonService;

    @PostMapping("/import/devchild")
    public AjaxResult importExcel(@Valid ChildDeviceParamDto paramDto) {
        AjaxResult ajaxResult = new AjaxResult();

        MultipartFile file = paramDto.getFile();
        Integer firmId = paramDto.getFirmId();
        Integer devSysId = paramDto.getDevSysId();
        Integer projId = paramDto.getProjId();
        Integer groupId = paramDto.getGroupId();
        ImportParams importParams = new ImportParams();
        // 数据处理
        importParams.setHeadRows(1);//表头1行
        //importParams.setTitleRows(1);//表格标题行数
        // 需要验证
        importParams.setNeedVerfiy(false);

        try {
            ExcelImportResult<ChildDevicePoiInputDto> result = ExcelImportUtil.importExcelMore(file.getInputStream(), ChildDevicePoiInputDto.class, importParams);
            List<ChildDevicePoiInputDto> devList = result.getList();
            if (CollectionUtils.isEmpty(devList)) {
                ajaxResult.addFail("所传文件不能为空");
                return ajaxResult;
            }
            for (ChildDevicePoiInputDto dto : devList) {
                // System.out.println(User);
                logger.info("从Excel导入数据到数据库的详细为 ：" + JSONObject.toJSONString(dto));

            }
            ajaxResult = this.commonService.insertChildDevices(devList, firmId, devSysId, projId, groupId);
            logger.info("从Excel导入数据一共 {} 行 ", devList.size());
            return ajaxResult;
        } catch (IOException e) {
            logger.error("导入失败：{}", e.getMessage());
            ajaxResult.addFail("导入失败");
        } catch (Exception e1) {
            logger.error("导入失败：{}", e1.getMessage());
            ajaxResult.addFail("导入失败");
        }


        return ajaxResult;
    }
}
