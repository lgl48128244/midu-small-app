package com.fei.springboot.config.dbconfig;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;

/**
 * 数据库源配置
 * @author Jfei
 *
 */
@Configuration
public class DataSourceConfiguration {

	private static Logger log = LoggerFactory.getLogger(DataSourceConfiguration.class);
	
	@Value("${mysql.datasource.type}")
	private Class<? extends DataSource> dataSourceType;
    
	/**
	 * 业务写库 数据源配置
	 * @return
	 */
	@Bean(name = "releaseWriteDataSource")
    @Primary
    @ConfigurationProperties(prefix = "mysql.datasource.release-write")
    public DataSource writeDataSource() {
        log.info("-------------------- release-write DataSource init ---------------------");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

	/**
     * 有多少个从库就要配置多少个
     * @return
     */
    @Bean(name = "releaseReadDataSource01")
    @ConfigurationProperties(prefix = "mysql.datasource.release-read01")
    public DataSource readDataSourceOne() {
        log.info("-------------------- release-read01 DataSourceOne init ---------------------");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    @Bean(name = "releaseReadDataSource02")
    @ConfigurationProperties(prefix = "mysql.datasource.release-read02")
    public DataSource readDataSourceTwo() {
        log.info("-------------------- release-read02 DataSourceTwo init ---------------------");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    @Bean(name = "releaseReadDataSource03")
    @ConfigurationProperties(prefix = "mysql.datasource.release-read03")
    public DataSource readDataSourceThree() {
        log.info("-------------------- release-read03 DataSourceThree init ---------------------");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }


    /**
     * 校验数据库 数据源配置
     * @return
     */
    @Bean(name = "produceWriteDataSource")
    @ConfigurationProperties(prefix = "mysql.datasource.produce-write")
    public DataSource produceDataSource() {
        log.info("=================== produce-write DataSource init ===================");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    //从库
    @Bean(name = "produceReadDataSource01")
    @ConfigurationProperties(prefix = "mysql.datasource.produce-read01")
    public DataSource produceDataSourceOne() {
        log.info("=================== produce-read01 DataSourceThree init ===================");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }
    @Bean(name = "produceReadDataSource02")
    @ConfigurationProperties(prefix = "mysql.datasource.produce-read02")
    public DataSource produceDataSourceTwo() {
        log.info("=================== produce-read02 DataSourceThree init ===================");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }
    @Bean(name = "produceReadDataSource03")
    @ConfigurationProperties(prefix = "mysql.datasource.produce-read03")
    public DataSource produceDataSourceThree() {
        log.info("=================== produce-read03 DataSourceThree init ===================");
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

}
