# leniao-cloud 乐鸟云

乐鸟云平台是基于SpringBoot2.2.2搭建的一套分布式架构，架构包含的技术有：

SpringBoot、Spring、SpringMvc、Mybatis、druid、Mysql……

### 所包含的模块有

#### 公共模块

##### cloud-commons

```txt
aop、filter、servlet、listener、cache、util、exception、config、constant……
```



##### cloud-model

```txt
dto、vo
```



##### cloud-service

```txt
service
```



##### cloud-dao

```txt
entity、mapper
```



#### 应用模块

##### cloud-admin

```txt
后台管理模块
```



##### cloud-huanbao

```txt
环保云模块
```
