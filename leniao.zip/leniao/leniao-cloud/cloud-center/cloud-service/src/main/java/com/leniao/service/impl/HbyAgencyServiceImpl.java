package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyAgencyExample;
import com.leniao.mapper.AgencyMapper;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.model.constant.SpringCacheConstants;
import com.leniao.model.dto.BaseAgencyDTO;
import com.leniao.service.HbyAgencyService;
import org.springframework.beans.BeanUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/20 15:27
 * @description TODO
 */
@Service
//@Cacheable(value = SpringCacheConstants.DEFAULT_CACHE_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR)
public class HbyAgencyServiceImpl extends ServiceImpl<HbyAgencyMapper, HbyAgency> implements HbyAgencyService {

    @Resource
    private AgencyMapper agencyMapper;
    @Resource
    private HbyAgencyMapper hbyAgencyMapper;

    @Override
    public List<BaseAgencyDTO.AgencyList> selectByBody(BaseAgencyDTO.AgencyReq req) {
        PageHelper.startPage(req.getPage(), req.getRows());
        return agencyMapper.selectByBody(req);
    }

    @Override
    public List<BaseAgencyDTO.AgencyList> selectByBody(BaseAgencyDTO.AgencyReq2 req2) {
        BaseAgencyDTO.AgencyReq req1 = new BaseAgencyDTO.AgencyReq();
        BeanUtils.copyProperties(req2, req1);
        return agencyMapper.selectByBody(req1);
    }

    @Override
    public List<HbyAgency> selectListByAreaCode(String provinceCode, String cityCode, String areaCode) {
        QueryWrapper<HbyAgency> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyAgency::getProvinceCode, provinceCode).eq(HbyAgency::getCityCode, cityCode).eq(HbyAgency::getAreaCode, areaCode);
        return this.hbyAgencyMapper.selectList(queryWrapper);
    }

    @Override
    @Cacheable(value = SpringCacheConstants.REDIS_CACHE_1MIN_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR, unless = "#result == null")
    public HbyAgency selectByAreaCode(String provinceCode, String cityCode, String areaCode, Integer platformId) {
        HbyAgencyExample example = new HbyAgencyExample();
        example.createCriteria().andPlatformIdEqualTo(platformId).andProvinceCodeEqualTo(provinceCode).andCityCodeEqualTo(cityCode).andAreaCodeEqualTo(areaCode);
        List<HbyAgency> hbyAgencies = this.hbyAgencyMapper.selectByExample(example);
        if (!hbyAgencies.isEmpty()) {
            return hbyAgencies.get(0);
        }
        return null;
    }
}