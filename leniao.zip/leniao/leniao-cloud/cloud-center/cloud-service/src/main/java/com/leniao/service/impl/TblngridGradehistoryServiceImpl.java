package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.entity.TblngridGradehistory;
import com.leniao.mapper.TblngridGradehistoryMapper;
import com.leniao.service.TblngridGradehistoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/31 9:47
 * @update
 * @description
 */
@Service
public class TblngridGradehistoryServiceImpl implements TblngridGradehistoryService {

    @Resource
    private TblngridGradehistoryMapper tblngridGradehistoryMapper;

    /**
     * 通过单位Id查询出单位的最新评分
     */
    @Override
    public Float findUnitGrade(Integer unitId) {
        //创建条件对象
        QueryWrapper<TblngridGradehistory> queryWrapper = new QueryWrapper<>();

        queryWrapper.select("totalgrade").lambda().eq(TblngridGradehistory::getUnitid,unitId).orderByDesc(TblngridGradehistory::getUnitid);

        List<TblngridGradehistory> tblngridGradehistoryList = tblngridGradehistoryMapper.selectList(queryWrapper);
        if (tblngridGradehistoryList.size()==0){
            return 0f;
        }else {
            return Float.parseFloat(String.valueOf(tblngridGradehistoryList.get(0).getTotalgrade()));
        }

    }
}
