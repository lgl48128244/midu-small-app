package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.TblnGroupInfo;
import com.leniao.mapper.TblnGroupInfoMapper;
import com.leniao.service.TblnGroupInfoService;
import org.springframework.stereotype.Service;

@Service
public class TblnGroupInfoServiceImpl extends ServiceImpl<TblnGroupInfoMapper, TblnGroupInfo> implements TblnGroupInfoService {
}
