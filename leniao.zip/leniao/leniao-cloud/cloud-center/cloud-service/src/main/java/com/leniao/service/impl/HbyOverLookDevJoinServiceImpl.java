package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.mapper.HbyOverLookDevJoinMapper;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/30 14:33
 * @description TODO
 */
@Service
public class HbyOverLookDevJoinServiceImpl extends ServiceImpl<HbyOverLookDevJoinMapper, HbyOverLookDevJoin> implements HbyOverLookDevJoinService {

    @Resource
    private HbyOverLookDevJoinMapper hbyOverLookDevJoinMapper;

    /**
     * 查询出监测点下的所有设备
     */
    @Override
    public List<HbyOverLookDevJoin> findAlldeviceByLookPointId(Long lookPointId) {
        //创建条件
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("dev_idpk").lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId);

        return list(queryWrapper);
    }

    /**
     * 添加设备监测点关联信息
     */
    @Override
    public boolean addLookPointDevJoin(Long lookPointId, Integer devId, Integer devProTy) {
        HbyOverLookDevJoin hbyOverlookDevJoin = new HbyOverLookDevJoin();
        hbyOverlookDevJoin.setLookId(lookPointId);
        hbyOverlookDevJoin.setDevIdpk(devId);
        hbyOverlookDevJoin.setDevProTy(devProTy);
        hbyOverlookDevJoin.setDevWorkState(0);

        return save(hbyOverlookDevJoin);
    }

    /**
     * 通过监测点id找出对应的设备Id
     */
    @Override
    public Integer findDevIdPkByLookPointId(Long lookPointId) {

        //创建条件
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("dev_idpk").lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevProTy,0);

        return getOne(queryWrapper).getDevIdpk();

    }

    /**
     * 通过设备Id,找出对应设备的工作状态
     */
    @Override
    public Integer findDevWorkStatus(Integer devIdpk) {

        //创建条件
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("dev_work_state").lambda().eq(HbyOverLookDevJoin::getDevIdpk,devIdpk);

        List<HbyOverLookDevJoin> hbyOverlookDevJoinList = list(queryWrapper);
        if (hbyOverlookDevJoinList ==null){
            return 5;
        }else {
            return hbyOverlookDevJoinList.get(0).getDevWorkState();
        }

    }

    /**
     * 通过设备Id查询出所有的监测点信息
     */
    @Override
    public List<HbyOverLookDevJoin> findLookPointInfoByDevId(Integer devIdpk) {
        //创建条件
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getDevIdpk,devIdpk);

        return list(queryWrapper);
    }

    /**
     * 删除监测点产污与治污设备管理关系
     */
    @Override
    public boolean removeLookDevJoin(Long lookPointId) {
        UpdateWrapper<HbyOverLookDevJoin> updateWrapper = new UpdateWrapper<>();
        updateWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId);

        return remove(updateWrapper);

    }

    /**
     * 删除监测点产污与治污设备管理关系
     */
    @Override
    public boolean removeLookDevJoin(Long lookPointId,Integer devIdpk) {
        UpdateWrapper<HbyOverLookDevJoin> updateWrapper = new UpdateWrapper<>();
        updateWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevIdpk,devIdpk);

        return remove(updateWrapper);

    }

    /**
     * 通过一个监测点找出产污设备总数
     */
    @Override
    public List<HbyOverLookDevJoin> findPollsNumByLookPointId(Long lookPointId) {
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevProTy,1);

        return hbyOverLookDevJoinMapper.selectList(queryWrapper);
    }

    /**
     * 通过一个监测点找出治污设备总数
     */
    @Override
    public List<HbyOverLookDevJoin> findConsNumByLookPointId(Long lookPointId) {
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevProTy,2);

        return hbyOverLookDevJoinMapper.selectList(queryWrapper);
    }

    @Override
    public List<Integer> findConsNumByLookPointId2(Long lookPointId) {
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevProTy,2);
        List<HbyOverLookDevJoin> hbyOverLookDevJoinList = hbyOverLookDevJoinMapper.selectList(queryWrapper);
        List<Integer> devIdList = new ArrayList<>();
        for (HbyOverLookDevJoin hbyOverLookDevJoin:hbyOverLookDevJoinList ) {
            devIdList.add(hbyOverLookDevJoin.getDevIdpk());
        }
        return devIdList;
    }

    @Override
    public List<Integer> findPollsNumByLookPointId2(Long lookPointId) {

        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getLookId,lookPointId).eq(HbyOverLookDevJoin::getDevProTy,1);
        List<HbyOverLookDevJoin> hbyOverLookDevJoinList = hbyOverLookDevJoinMapper.selectList(queryWrapper);
        List<Integer> devIdList = new ArrayList<>();
        for (HbyOverLookDevJoin hbyOverLookDevJoin:hbyOverLookDevJoinList ) {
            devIdList.add(hbyOverLookDevJoin.getDevIdpk());
        }
        return devIdList;
    }
}
