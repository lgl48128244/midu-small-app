package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.TbLnUserInfo;
import com.leniao.mapper.TbLnUserInfoMapper;
import com.leniao.model.constant.SpringCacheConstants;
import com.leniao.service.TbLnUserInfoService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * @author guoliang.li
 * @date 2020/1/2 10:02
 * @description TODO
 */
@Service
public class TbLnUserInfoServiceImpl extends ServiceImpl<TbLnUserInfoMapper, TbLnUserInfo> implements TbLnUserInfoService {

    @Cacheable(cacheNames = SpringCacheConstants.DEFAULT_CACHE_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR, unless = "#result == null")
    @Override
    public TbLnUserInfo getById(Integer userId) {
        return super.getById(userId);
    }
}