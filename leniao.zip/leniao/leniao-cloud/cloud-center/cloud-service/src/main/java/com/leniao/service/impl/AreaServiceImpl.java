package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.Area;
import com.leniao.mapper.AreaCustomMapper;
import com.leniao.mapper.AreaMapper;
import com.leniao.model.constant.SpringCacheConstants;
import com.leniao.service.AreaService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/20 16:32
 * @description TODO
 */
@Service
//@Cacheable(value = SpringCacheConstants.DEFAULT_CACHE_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR)
public class AreaServiceImpl extends ServiceImpl<AreaMapper, Area> implements AreaService {

    @Resource
    private AreaCustomMapper areaCustomMapper;

    @Override
    public List<Area> selectProvinceList(String areaId) {
        return areaCustomMapper.selectProvinceList(areaId);
    }

    @Override
    public List<Area> selectCityList(String provinceId) {
        return areaCustomMapper.selectCityList(provinceId);
    }

    @Override
    public List<Area> selectCountyList(String cityId) {
        return areaCustomMapper.selectCountyList(cityId);
    }
}