package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.mapper.BussinessExMapper;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.constant.RangeConstant;
import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.model.vo.Page;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyProjectErrorInfoService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.tomcat.util.security.Escape;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author guoliang.li
 * @date 2019/12/25 16:55
 * @description TODO
 */
@Service
//@Cacheable(cacheNames = SpringCacheConstants.REDIS_CACHE_30MIN_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR)
public class HbyProjectErrorInfoServiceImpl extends ServiceImpl<HbyProjectErrorInfoMapper, HbyProjectErrorInfo> implements HbyProjectErrorInfoService {

    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;

    @Resource
    private BussinessExMapper bussinessExMapper;

    @Resource
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<BaseBusinessExDTO.BusinessExSearchList> selectErrorSearchList(BaseBusinessExDTO.BusinessExSearchReq req) {
        // TODO 2020-02-27 修改，将多个名称搜索条件改为id搜索
        PageHelper.startPage(req.getPage(), req.getRows());
        return bussinessExMapper.selectErrorSearchList(req);
    }

    @Override
    public BaseBusinessExDTO.BusinessExSearchDetail selectErrorSearchDetail(Long id) {
        return bussinessExMapper.selectErrorSearchDetail(id);
    }

    @Override
    public BaseBusinessExDTO.BusinessExHandlerDetail selectErrorHandlerDetail(Long id) {
        return bussinessExMapper.selectErrorHandlerDetail(id);
    }

    @Override
    public BaseBusinessExDTO.BusinessExExamineDetail selectErrorExamineDetail(Long id) {
        return bussinessExMapper.selectErrorExamineDetail(id);
    }

    @Override
    public void updateErrorHandlerBatch(List<Long> ids, Integer status) {
        String sql = "update hby_project_errorinfo set deal_status =:status where id in (:ids)";
        Map<String, Object> params = new HashMap<>(2);
        UserInfo userInfo = GlobalConstant.getUserInfo();
        //批量处理，修改处理人和时间
        if (status.equals(2)) {
            sql = "update hby_project_errorinfo set deal_status =:status, " +
                    " check_user =:check_user, " +
                    " check_user_name =:check_user_name," +
                    " check_time =:check_time," +
                    " update_time =:update_time " +
                    " where id in (:ids)";
            params.put("check_user", userInfo.getUserId());
            params.put("check_user_name", userInfo.getUsername());
            params.put("check_time", new Date());
        } else if (status.equals(4)) {
            sql = "update hby_project_errorinfo set deal_status =:status, " +
                    " verify_user =:verify_user, " +
                    " verify_user_name =:verify_user_name, " +
                    " verify_time =:verify_time, " +
                    " update_time =:update_time, " +
                    " verify_result =:verify_result " +
                    " where id in (:ids)";
            params.put("verify_user", userInfo.getUserId());
            params.put("verify_user_name", userInfo.getUsername());
            params.put("verify_time", new Date());
            params.put("verify_result", 1);
        } else if (status.equals(5)) {
            sql = "update hby_project_errorinfo set deal_status =:status, " +
                    " verify_user =:verify_user, " +
                    " verify_user_name =:verify_user_name, " +
                    " verify_time =:verify_time, " +
                    " update_time =:update_time, " +
                    " verify_result =:verify_result " +
                    " where id in (:ids)";
            params.put("verify_user", userInfo.getUserId());
            params.put("verify_user_name", userInfo.getUsername());
            params.put("verify_time", new Date());
            params.put("verify_result", 2);
        }
        params.put("status", status);
        params.put("ids", ids);
        params.put("update_time", new Date());
        namedParameterJdbcTemplate.update(sql, params);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsList> selectErrorStatisticsList(BaseBusinessExDTO.BusinessExStatisticsReq req, Integer userGrade) {
        PageHelper.startPage(req.getPage(), req.getRows());
        return bussinessExMapper.selectErrorStatisticsList(req, userGrade);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsAgencyList(Page page) {
        //PageHelper.startPage(page.getPage(), page.getRows());
        return bussinessExMapper.selectErrorStatisticsAgencyList(page);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryList(Page page) {
        PageHelper.startPage(page.getPage(), page.getRows());
        return bussinessExMapper.selectErrorStatisticsIndustryList(page);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListByNormalUser(Integer userId, List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectErrorHomeRollingListByNormalUser(userId, projIdsAboutUser);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListBySpecifyUser(BaseBusinessExDTO.BusinessExRollingReq req) {
        return bussinessExMapper.selectErrorHomeRollingListBySpecifyUser(req);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExCuoFengList> selectErrorCuoFengList(Integer unitId) {
        return bussinessExMapper.selectErrorCuoFengList(unitId);
    }

    @Override
    public int selectTodayUnitCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectTodayUnitCount(projIdsAboutUser);
    }

    @Override
    public int selectTodayDeviceCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectTodayDeviceCount(projIdsAboutUser);
    }

    @Override
    public int selectYesTodayUnitCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectYesTodayUnitCount(projIdsAboutUser);
    }

    @Override
    public int selectYesTodayDeviceCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectYesTodayDeviceCount(projIdsAboutUser);
    }

    @Override
    public int selectTodayDeclareCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectTodayDeclareCount(projIdsAboutUser);
    }

    @Override
    public int selectYesTodayDeclareCount(List<Long> projIdsAboutUser) {
        return bussinessExMapper.selectYesTodayDeclareCount(projIdsAboutUser);
    }

    @Override
    public void updateIndustryOfUnit(Integer unitId, Integer industryId) {
        String sql = "update hby_project_errorinfo set industry_id = ? where unit_id = ?";
        this.jdbcTemplate.update(sql, industryId, unitId);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> findAgencyByAreaCode(Integer userGrade, UserInfo userInfo, String provinceCode, String cityCode, String areaCode, List<Long> projIds) {
        //全国账号，查看所有三级机构的数据
        List<String> zxsCodeList = Arrays.asList(RangeConstant.ZHIXIASHI_CODE);
        boolean isZXS = zxsCodeList.contains(provinceCode);
        if (userGrade == 0) {
            return this.bussinessExMapper.selectAgencyErrCountByCountryUser(userInfo.getPlatformId());
        } else if (userGrade == 1) {
            //省级机构 ，注意单独区分直辖市机构要直接查看所有三级机构(不显示自己，不显示市辖区和县辖区)
            if (isZXS) {
                return this.bussinessExMapper.selectAgencyErrCountByProvinceZXSUser(userInfo.getPlatformId(), provinceCode);
            } else {
                return this.bussinessExMapper.selectAgencyErrCountByProvinceUser(userInfo.getPlatformId(), provinceCode);
            }
        } else if (userGrade == 2) {
            //市级机构， 注意单独区分直辖市的机构，市辖区看所有区，县辖区看所有县
            if (isZXS) {
                return this.bussinessExMapper.selectAgencyErrCountByCityZXSUser(userInfo.getPlatformId(), provinceCode,cityCode);
            } else {
                return this.bussinessExMapper.selectAgencyErrCountByCityUser(userInfo.getPlatformId(), provinceCode,cityCode);
            }
        } else {
            //if (userGrade == 3)
            //三级机构，查看其下所有单位的的 数据
            if (CollectionUtils.isEmpty(projIds)) {
                return Collections.emptyList();
            }
            return this.bussinessExMapper.selectUnitErrCountByAreaUser(projIds);
        }
        //return this.bussinessExMapper.selectAgencyByAreaCode(userGrade, provinceCode, cityCode, areaCode);
    }

    @Override
    public Integer findRootPointDevIdpkOfUnit(Integer unitId) {
        return this.bussinessExMapper.findRootPointDevIdpkOfUnit(unitId);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsProjectList(Page page) {
        //查询个人用户异常单位的统计
        List<Long> projIds = page.getProjIds();
        if (CollectionUtils.isEmpty(projIds)) {
            return Collections.emptyList();
        }
        return this.bussinessExMapper.selectErrorStatisticsProjectList(projIds);
    }

    @Override
    public List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryList(String provinceCode, String cityCode, String areaCode, Integer userGrade, Page page) {
        /*List<String> zxsCodeList = Arrays.asList(RangeConstant.ZHIXIASHI_CODE);
        boolean isZXS = zxsCodeList.contains(provinceCode);*/
        PageHelper.startPage(page.getPage(), page.getRows());
        if (userGrade == 0) {
            return this.bussinessExMapper.selectErrorStatisticsIndustryListByCountryUser(page.getPlatformId());
        } else if (userGrade == 1) {
            //查询省code下的所有异常统计数据（包括省级单位，市级单位和区县单位）
            return this.bussinessExMapper.selectErrorStatisticsIndustryListByProZXSUser(page.getPlatformId(), provinceCode);
        } else if (userGrade == 2) {
            //查询市code下的所有异常统计数据（包括市级单位和区县单位）
            return this.bussinessExMapper.selectErrorStatisticsIndustryListBYCityUser(page.getPlatformId(),provinceCode, cityCode);
        } else if (userGrade == 3) {
            return this.bussinessExMapper.selectErrorStatisticsIndustryListBYAreaUser(page.getPlatformId(), provinceCode, cityCode, areaCode);
        } else {
            return Collections.emptyList();
        }
    }
}