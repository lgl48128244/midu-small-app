package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.leniao.entity.HbyIndustry;
import com.leniao.mapper.HbyIndustryMapper;
import com.leniao.mapper.IndustryMapper;
import com.leniao.model.dto.BaseIndustryDTO;
import com.leniao.service.HbyIndustryService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:39
 * @description TODO
 */
@Service
//@Cacheable(value = SpringCacheConstants.REDIS_CACHE_60MIN_NAME, keyGenerator = SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR)
public class HbyIndustryServiceImpl extends ServiceImpl<HbyIndustryMapper, HbyIndustry> implements HbyIndustryService {

    @Resource
    private IndustryMapper industryMapper;

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<BaseIndustryDTO.IndustryList> selectByBody(BaseIndustryDTO.IndustryReq req) {
        PageHelper.startPage(req.getPage(), req.getRows());
        return industryMapper.selectByBody(req);
    }

    @Override
    public void updateBatch() {
        String sql = "update hby_industry t1 set t1.bind_num=(select count(1) from tblnprojectinfo t2 where t1.id = t2.industryId)";
        jdbcTemplate.update(sql);
    }

    @Resource
    private HbyIndustryMapper hbyIndustryMapper;

    /**
     * 通过行业Id找出行业名称
     */
    @Override
    public String findIndustryNameById(Long id) {
        //创建条件
        QueryWrapper<HbyIndustry> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("industry_name").lambda().eq(HbyIndustry::getId, id);

        HbyIndustry hbyIndustry = hbyIndustryMapper.selectOne(queryWrapper);

        if (hbyIndustry == null) {
            return "";
        } else {
            return hbyIndustry.getIndustryName();
        }

    }

}