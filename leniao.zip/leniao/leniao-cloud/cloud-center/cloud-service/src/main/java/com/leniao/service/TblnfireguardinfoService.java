package com.leniao.service;

import com.leniao.entity.Tblnfireguardinfo;

public interface TblnfireguardinfoService {

    /**
     * 查出防火员信息
     * @return
     */
    String findfireguardInfo(Integer id);
}
