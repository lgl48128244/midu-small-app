package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.WebSiteInfo;

/**
 * @author guoliang.li
 * @date 2019/12/21 9:33
 * @description TODO
 */
public interface WebSiteInfoService extends IService<WebSiteInfo> {

}
