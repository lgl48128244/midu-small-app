package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyAgency;
import com.leniao.model.dto.BaseAgencyDTO;

import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/20 15:26
 * @description TODO
 */
public interface HbyAgencyService extends IService<HbyAgency> {

    /**
     * 分页查询
     * @param req
     * @return
     */
    List<BaseAgencyDTO.AgencyList> selectByBody(BaseAgencyDTO.AgencyReq req);

    /**
     * 不分页查询机构列表
     */
    List<BaseAgencyDTO.AgencyList> selectByBody(BaseAgencyDTO.AgencyReq2 req);

    /**
     * @description: 根据区域码和平台ID查询机构信息
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 13:22
     */
    HbyAgency selectByAreaCode(String provinceCode, String cityCode, String areaCode, Integer platfomrId);


    /**
     * 根据区域码查询各个平台的机构信息
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @return
     */
    List<HbyAgency> selectListByAreaCode(String provinceCode, String cityCode, String areaCode);
}