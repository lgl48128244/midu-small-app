package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.TblnGroupInfo;

public interface TblnGroupInfoService  extends IService<TblnGroupInfo> {
}
