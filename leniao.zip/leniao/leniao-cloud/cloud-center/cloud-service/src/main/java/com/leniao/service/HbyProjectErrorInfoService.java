package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.model.vo.Page;
import com.leniao.model.vo.UserInfo;

import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/25 16:50
 * @description TODO
 */
public interface HbyProjectErrorInfoService extends IService<HbyProjectErrorInfo> {

    List<BaseBusinessExDTO.BusinessExSearchList> selectErrorSearchList(BaseBusinessExDTO.BusinessExSearchReq req);

    BaseBusinessExDTO.BusinessExSearchDetail selectErrorSearchDetail(Long id);

    BaseBusinessExDTO.BusinessExHandlerDetail selectErrorHandlerDetail(Long id);

    BaseBusinessExDTO.BusinessExExamineDetail selectErrorExamineDetail(Long id);

    void updateErrorHandlerBatch(List<Long> ids, Integer status);

    List<BaseBusinessExDTO.BusinessExStatisticsList> selectErrorStatisticsList(BaseBusinessExDTO.BusinessExStatisticsReq req, Integer userGrade);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsAgencyList(Page page);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryList(Page page);

    List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListByNormalUser(Integer userId, List<Long> projIdsAboutUser);

    List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListBySpecifyUser(BaseBusinessExDTO.BusinessExRollingReq req);

    List<BaseBusinessExDTO.BusinessExCuoFengList> selectErrorCuoFengList(Integer unitId);

    /**
     * 今日单位数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayUnitCount(List<Long> projIdsAboutUser);

    /**
     * 今日设备数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayDeviceCount(List<Long> projIdsAboutUser);

    /**
     * 昨日单位数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayUnitCount(List<Long> projIdsAboutUser);

    /**
     * 昨日设备数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayDeviceCount(List<Long> projIdsAboutUser);

    /**
     * 今日企业已申报数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayDeclareCount(List<Long> projIdsAboutUser);

    /**
     * 昨日企业已申报数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayDeclareCount(List<Long> projIdsAboutUser);

    /**
     * 更新异常表中单位的所有行业字段
     * @param unitId
     * @param industryId
     */
    void updateIndustryOfUnit(Integer unitId, Integer industryId);

    /**
     * 区域用户查首页异常统计柱状图
     * @param userGrade
     * @param userInfo
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @param projIdsAboutUser
     * @return
     */
    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> findAgencyByAreaCode(Integer userGrade, UserInfo userInfo, String provinceCode, String cityCode, String areaCode, List<Long> projIdsAboutUser);

    /**
     * 查询单位的总监测点设备id
     * @author haosw
     * @param unitId
     * @return
     */
    Integer findRootPointDevIdpkOfUnit(Integer unitId);

    /**
     * 区域账号查询行业异常占比
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @param userGrade
     * @param page
     * @return
     */
    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryList(String provinceCode, String cityCode, String areaCode, Integer userGrade, Page page);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsProjectList(Page page);
}
