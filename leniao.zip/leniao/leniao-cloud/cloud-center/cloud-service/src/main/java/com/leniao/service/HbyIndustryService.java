package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyIndustry;
import com.leniao.model.dto.BaseIndustryDTO;

import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:39
 * @description TODO
 */
public interface HbyIndustryService extends IService<HbyIndustry> {

    List<BaseIndustryDTO.IndustryList> selectByBody(BaseIndustryDTO.IndustryReq req);

    void updateBatch();
    /**
     * 通过行业Id找出行业名称
     */
    String findIndustryNameById(Long id);
}
