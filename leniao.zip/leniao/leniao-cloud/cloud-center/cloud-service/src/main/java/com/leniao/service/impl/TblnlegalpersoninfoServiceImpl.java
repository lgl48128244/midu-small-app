package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.entity.Tblnlegalpersoninfo;
import com.leniao.mapper.TblnlegalpersoninfoMapper;
import com.leniao.service.TblnlegalpersoninfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author liudongshuai
 * @date 2020/1/7 10:18
 * @update
 */
@Service
public class TblnlegalpersoninfoServiceImpl implements TblnlegalpersoninfoService {

    @Resource
    private TblnlegalpersoninfoMapper tblnlegalpersoninfoMapper;

    /**
     * 通过id 找出负责人信息
     * @param id
     * @return
     */
    @Override
    public String findLegalPersonInfo(Integer id) {

        QueryWrapper<Tblnlegalpersoninfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Tblnlegalpersoninfo::getLegalpersonid,id);
        Tblnlegalpersoninfo tblnlegalpersoninfo = tblnlegalpersoninfoMapper.selectOne(queryWrapper);
        if(tblnlegalpersoninfo==null){
            return  "";
        }else {
            return tblnlegalpersoninfo.getLegalpersonname()+"  "+tblnlegalpersoninfo.getLegalpersonphone();
        }

    }

    /**
     * 通过id 找出负责人信息
     * @param id
     * @return
     */
    @Override
    public Tblnlegalpersoninfo findLegalPersonPhoneInfo(Integer id) {

        QueryWrapper<Tblnlegalpersoninfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Tblnlegalpersoninfo::getLegalpersonid,id);
        Tblnlegalpersoninfo tblnlegalpersoninfo = tblnlegalpersoninfoMapper.selectOne(queryWrapper);
        return tblnlegalpersoninfo;

    }
}
