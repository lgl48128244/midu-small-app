package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.ProjectInfo;
import com.leniao.mapper.ProjectInfoMapper;
import com.leniao.service.ProjectInfoService;
import org.springframework.stereotype.Service;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:09
 * @description TODO
 */
@Service
public class ProjectInfoServiceImpl extends ServiceImpl<ProjectInfoMapper, ProjectInfo> implements ProjectInfoService {

}