package com.leniao.service;

import com.leniao.entity.HbyAgencyJoinUser;
import com.leniao.entity.TbLnUserInfo;
import com.leniao.entity.TblnGroupAddress;
import com.leniao.entity.TblnGroupInfo;
import com.leniao.model.dto.BaseAgencyUserDTO;

import java.util.List;

public interface AgencyUserService {

    Object saveOrUpdateAgencyUser(TbLnUserInfo userInfo, TblnGroupInfo tblnGroupInfo, TblnGroupAddress tblnGroupAddress, HbyAgencyJoinUser agencyJoinUser);

    Object deleteAgencyUser(Integer userId);

    List<BaseAgencyUserDTO.AgencyUserList> findByPage(BaseAgencyUserDTO.AgencyUserPage page);

    Object findItemDesc(Integer userId, Integer platformId);
}
