package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.ProjectInfo;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:07
 * @description TODO
 */
public interface ProjectInfoService extends IService<ProjectInfo> {
    
}
