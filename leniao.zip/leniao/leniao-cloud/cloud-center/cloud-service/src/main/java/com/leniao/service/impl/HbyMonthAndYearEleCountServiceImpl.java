package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.HbyMonthAndYearEleCount;
import com.leniao.entity.HbyMonthAndYearEleCountExample;
import com.leniao.mapper.HbyMonthAndYearEleCountMapper;
import com.leniao.service.HbyMonthAndYearEleCountService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class HbyMonthAndYearEleCountServiceImpl
        extends ServiceImpl<HbyMonthAndYearEleCountMapper, HbyMonthAndYearEleCount>
        implements HbyMonthAndYearEleCountService {

    @Resource
    private HbyMonthAndYearEleCountMapper hbyMonthAndYearEleCountMapper;

    @Override
    public int countByExample(HbyMonthAndYearEleCountExample example) {
        return this.hbyMonthAndYearEleCountMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(HbyMonthAndYearEleCountExample example) {
        return this.hbyMonthAndYearEleCountMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Long id) {
        return this.hbyMonthAndYearEleCountMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insertSelective(HbyMonthAndYearEleCount record) {
        return this.insertSelective(record);
    }

    @Override
    public List<HbyMonthAndYearEleCount> selectByExample(HbyMonthAndYearEleCountExample example) {
        return this.hbyMonthAndYearEleCountMapper.selectByExample(example);
    }

    @Override
    public HbyMonthAndYearEleCount selectByPrimaryKey(Long id) {
        return this.hbyMonthAndYearEleCountMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(HbyMonthAndYearEleCount record, HbyMonthAndYearEleCountExample example) {
        return this.hbyMonthAndYearEleCountMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExample(HbyMonthAndYearEleCount record, HbyMonthAndYearEleCountExample example) {
        return this.hbyMonthAndYearEleCountMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(HbyMonthAndYearEleCount record) {
        return this.hbyMonthAndYearEleCountMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(HbyMonthAndYearEleCount record) {
        return this.hbyMonthAndYearEleCountMapper.updateByPrimaryKey(record);
    }

    /**
     * 通过年月找出对应的电量值
     * @param devId
     * @param year
     * @param month
     * @return
     */
    @Override
    public Double findEleTotalByYearAndMonth(Integer devId, Integer year, Integer month) {
        QueryWrapper<HbyMonthAndYearEleCount> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("ele_total").lambda().eq(HbyMonthAndYearEleCount::getDevIdpk,devId).eq(HbyMonthAndYearEleCount::getYear,year).eq(HbyMonthAndYearEleCount::getMonth,month);
        HbyMonthAndYearEleCount hbyMonthAndYearEleCount = hbyMonthAndYearEleCountMapper.selectOne(queryWrapper);
        if (hbyMonthAndYearEleCount==null){
            return 0D;
        }else {
            return Double.valueOf(String.valueOf(hbyMonthAndYearEleCount.getEleTotal()));
        }
    }
}
