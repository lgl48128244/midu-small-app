package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.entity.Tblnfireguardinfo;
import com.leniao.mapper.TblnfireguardinfoMapper;
import com.leniao.service.TblnfireguardinfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author liudongshuai
 * @date 2020/1/7 16:58
 * @update
 */
@Service
public class TblnfireguardinfoServiceImpl implements TblnfireguardinfoService {

    @Resource
    private TblnfireguardinfoMapper tblnfireguardinfoMapper;

    /**
     * 查出防火员信息
     * @return
     */
    @Override
    public String findfireguardInfo(Integer id) {
        QueryWrapper<Tblnfireguardinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Tblnfireguardinfo::getFireguardid,id);
        Tblnfireguardinfo tblnfireguardinfo = tblnfireguardinfoMapper.selectOne(queryWrapper);
        if (tblnfireguardinfo==null){
            return  "";
        }else {
            return tblnfireguardinfo.getFireguardname()+"  "+tblnfireguardinfo.getFireguardphone();
        }

    }
}
