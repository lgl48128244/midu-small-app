package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.TblnGroupAddress;

public interface TblngroupAddressService extends IService<TblnGroupAddress> {
}
