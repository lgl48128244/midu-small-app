package com.leniao.service;

/**
 * @author liudongshuai
 * @date 2019/12/31 9:46
 * @update
 * @description
 */

public interface TblngridGradehistoryService {
    /**
     * 通过单位Id查询出单位的最新评分
     */
    Float findUnitGrade(Integer unitId);

}
