package com.leniao.service;

import com.leniao.entity.Tblnlegalpersoninfo;

public interface TblnlegalpersoninfoService {

    /**
     * 通过id 找出负责人信息
     * @param id
     * @return
     */
    String findLegalPersonInfo(Integer id);

    /**
     * 通过id 找出负责人信息
     * @param id
     * @return
     */
    Tblnlegalpersoninfo findLegalPersonPhoneInfo(Integer id);

}
