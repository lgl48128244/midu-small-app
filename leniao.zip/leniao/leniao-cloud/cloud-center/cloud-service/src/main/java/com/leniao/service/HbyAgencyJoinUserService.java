package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyAgencyJoinUser;

public interface HbyAgencyJoinUserService extends IService<HbyAgencyJoinUser> {
}
