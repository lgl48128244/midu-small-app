package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.TbLnUserInfo;

/**
 * @author guoliang.li
 * @date 2020/1/2 10:02
 * @description TODO
 */
public interface TbLnUserInfoService extends IService<TbLnUserInfo> {

    TbLnUserInfo getById(Integer userId);
}
