/**
 * @author guoliang.li
 * @date 2019/12/23 9:52
 * @description TODO 公共业务接口实现类
 */
package com.leniao.service.impl;