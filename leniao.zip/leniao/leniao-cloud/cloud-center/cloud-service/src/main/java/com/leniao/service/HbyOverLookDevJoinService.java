package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyOverLookDevJoin;

import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/30 14:33
 * @description TODO
 */
public interface HbyOverLookDevJoinService extends IService<HbyOverLookDevJoin> {


    /**
     * 查询出监测点下的所有设备
     */
    List<HbyOverLookDevJoin> findAlldeviceByLookPointId(Long lookPointId);

    /**
     * 添加设备监测点关联信息
     */
    boolean addLookPointDevJoin(Long lookPointId,Integer devId,Integer devProTy);

    /**
     * 通过监测点id找出对应的设备Id
     */
    Integer findDevIdPkByLookPointId(Long lookPointId);

    /**
     * 通过设备Id,找出对应设备的工作状态
     */
    Integer findDevWorkStatus(Integer devIdpk);

    /**
     * 通过设备Id查询出所有的监测点信息
     */
    List<HbyOverLookDevJoin> findLookPointInfoByDevId(Integer devIdpk);

    /**
     * 删除监测点产污与治污设备管理关系
     */
    boolean removeLookDevJoin(Long lookPointId);

    boolean removeLookDevJoin(Long lookPointId,Integer devIdpk);

    /**
     * 通过一个监测点找出产污设备总数
     */
    List<HbyOverLookDevJoin> findPollsNumByLookPointId(Long lookPointId);

    /**
     * 通过一个监测点找出治污设备总数
     */
    List<HbyOverLookDevJoin> findConsNumByLookPointId(Long lookPointId);

    /**
     * 通过一个监测点找出治污设备id
     */
    List<Integer> findConsNumByLookPointId2(Long lookPointId);

    /**
     * 通过一个监测点找出产污设备id
     */
    List<Integer> findPollsNumByLookPointId2(Long lookPointId);

}
