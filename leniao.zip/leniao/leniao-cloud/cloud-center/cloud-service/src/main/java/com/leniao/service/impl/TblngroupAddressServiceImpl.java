package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.TblnGroupAddress;
import com.leniao.mapper.TblnGroupAddressMapper;
import com.leniao.service.TblngroupAddressService;
import org.springframework.stereotype.Service;

@Service
public class TblngroupAddressServiceImpl extends ServiceImpl<TblnGroupAddressMapper, TblnGroupAddress> implements TblngroupAddressService {
}
