package com.leniao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyMonthAndYearEleCount;
import com.leniao.entity.HbyMonthAndYearEleCountExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description:    单位总表用电量的统计service
 * @Author:         haosw
 * @CreateDate:     2020/1/8 17:51
 * @Version:        1.0
 */
public interface HbyMonthAndYearEleCountService extends IService<HbyMonthAndYearEleCount> {
    int countByExample(HbyMonthAndYearEleCountExample example);

    int deleteByExample(HbyMonthAndYearEleCountExample example);

    int deleteByPrimaryKey(Long id);

    //int insert(HbyMonthAndYearEleCount record);

    int insertSelective(HbyMonthAndYearEleCount record);

    List<HbyMonthAndYearEleCount> selectByExample(HbyMonthAndYearEleCountExample example);

    HbyMonthAndYearEleCount selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyMonthAndYearEleCount record, @Param("example") HbyMonthAndYearEleCountExample example);

    int updateByExample(@Param("record") HbyMonthAndYearEleCount record, @Param("example") HbyMonthAndYearEleCountExample example);

    int updateByPrimaryKeySelective(HbyMonthAndYearEleCount record);

    int updateByPrimaryKey(HbyMonthAndYearEleCount record);

    /**
     * 通过年月找出对应的值
     * @param devId
     * @param year
     * @param month
     * @return
     */
    Double findEleTotalByYearAndMonth(Integer devId,Integer year,Integer month);

}
