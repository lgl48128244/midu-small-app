package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.HbyAgencyJoinUser;
import com.leniao.mapper.HbyAgencyJoinUserMapper;
import com.leniao.service.HbyAgencyJoinUserService;
import com.leniao.service.HbyAgencyService;
import org.springframework.stereotype.Service;

@Service
public class HbyAgencyJoinUserServiceImpl extends ServiceImpl<HbyAgencyJoinUserMapper, HbyAgencyJoinUser> implements HbyAgencyJoinUserService {
}
