package com.leniao.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.pagehelper.PageHelper;
import com.leniao.entity.*;
import com.leniao.mapper.AgencyUserMapper;
import com.leniao.mapper.TbLnUserInfoMapper;
import com.leniao.model.dto.BaseAgencyUserDTO;
import com.leniao.service.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AgencyUserServiceImpl implements AgencyUserService {

    @Resource
    private TbLnUserInfoService tbLnUserInfoService;
    @Resource
    private TbLnUserInfoMapper tbLnUserInfoMapper;
    @Resource
    private TblngroupAddressService tblngroupAddressService;
    @Resource
    private TblnGroupInfoService tblnGroupInfoService;
    @Resource
    private AgencyUserMapper agencyUserMapper;
    @Resource
    private HbyAgencyJoinUserService hbyAgencyJoinUserService;
    @Resource
    private JdbcTemplate jdbcTemplate;


    @Override
    public Object saveOrUpdateAgencyUser(TbLnUserInfo userInfo, TblnGroupInfo tblnGroupInfo, TblnGroupAddress tblnGroupAddress, HbyAgencyJoinUser agencyJoinUser) {
        //先保存或修改userInfo
        this.tbLnUserInfoService.saveOrUpdate(userInfo);

        tblnGroupInfo.setUserid(userInfo.getUserid());
        tblnGroupAddress.setUserid(userInfo.getUserid());
        agencyJoinUser.setUserId(userInfo.getUserid());

        this.tblnGroupInfoService.saveOrUpdate(tblnGroupInfo);
        this.tblngroupAddressService.saveOrUpdate(tblnGroupAddress);
        this.hbyAgencyJoinUserService.saveOrUpdate(agencyJoinUser);
        return true;
    }

    @Override
    public Object deleteAgencyUser(Integer userId) {
        //逻辑删除 tblnuserinfo表，tblngroupinfo表， tblngroupaddress表
        UpdateWrapper<TbLnUserInfo> userInfoUpdateWrapper = new UpdateWrapper<>();
        userInfoUpdateWrapper.lambda().set(TbLnUserInfo::getIsdelete, 1).eq(TbLnUserInfo::getUserid,userId);
        this.tbLnUserInfoService.update(userInfoUpdateWrapper);

        UpdateWrapper<TblnGroupInfo> groupInfoUpdateWrapper = new UpdateWrapper<>();
        //没有下划线的字段不区分大小写
        groupInfoUpdateWrapper.set("isdel", 1).eq("userid", userId);
        this.tblnGroupInfoService.update(groupInfoUpdateWrapper);

        UpdateWrapper<TblnGroupAddress> groupAddressUpdateWrapper = new UpdateWrapper<>();
        groupAddressUpdateWrapper.set("isdel", 1).eq("userid",userId);
        this.tblngroupAddressService.update(groupAddressUpdateWrapper);
        Map<String, Object> map = new HashMap<>();
        //此处要跟数据库字段一致
        map.put("user_id",userId);
        this.hbyAgencyJoinUserService.removeByMap(map);
        return true;
    }

    @Override
    public List<BaseAgencyUserDTO.AgencyUserList> findByPage(BaseAgencyUserDTO.AgencyUserPage page) {
        PageHelper.startPage(page.getPage(), page.getRows());
        return this.agencyUserMapper.selectByPage(page);
    }

    @Override
    public BaseAgencyUserDTO.AgencyUserView findItemDesc(Integer userId, Integer platformId) {

        return this.agencyUserMapper.selectItemDesc(userId, platformId);
    }
}
