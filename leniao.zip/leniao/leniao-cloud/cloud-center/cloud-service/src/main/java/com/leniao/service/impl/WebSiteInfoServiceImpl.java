package com.leniao.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.WebSiteInfo;
import com.leniao.mapper.WebSiteInfoMapper;
import com.leniao.service.WebSiteInfoService;
import org.springframework.stereotype.Service;

/**
 * @author guoliang.li
 * @date 2019/12/21 9:35
 * @description TODO
 */
@Service
public class WebSiteInfoServiceImpl extends ServiceImpl<WebSiteInfoMapper, WebSiteInfo> implements WebSiteInfoService {

}
