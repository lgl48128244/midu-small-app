package com.leniao.admin;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.commons.AbstractOperation;
import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.commons.util.SpringUtils;
import com.leniao.entity.Area;
import com.leniao.entity.HbyAgency;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.mapper.TblndeviceinfoMapper;
import com.leniao.model.dto.BaseAgencyDTO;
import com.leniao.model.dto.BaseIndustryDTO;
import com.leniao.service.AreaService;
import com.leniao.service.HbyAgencyService;
import com.leniao.service.HbyIndustryService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

public class TestService extends BaseTest {

    @Resource
    private Environment environment;

    @Resource
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @Before
    public void before() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    public void test() {
        System.out.println(environment);
    }

    @Test
    public void test1() {
        //调用接口，传入添加的用户参数
      /*  mockMvc.perform(MockMvcRequestBuilders.get("/style/listStyleById")
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("")
                .andDo(MockMvcResultHandlers.print());*/
    }

    @Resource
    private TblndeviceinfoMapper tblndeviceinfoMapper;

    @Resource
    private DataSource dataSource;

    @Test
    public void test3() {

        System.out.println("数据源>>>>>>" + dataSource.getClass());

        DruidDataSource druidDataSource = (DruidDataSource) dataSource;
        System.out.println("druidDataSource 数据源最大连接数：" + druidDataSource.getMaxActive());
        System.out.println("druidDataSource 数据源初始化连接数：" + druidDataSource.getInitialSize());

    }

    @Test
    public void test4() {
//        util.hashOperations.put("hash","hashmap","value");
//        Object o = util.hashOperations.get("hash", "hashmap");
        List<String> keys = AbstractOperation.keys("*", 100);
//        Set<String> keys = redisTemplate.keys("*");

        keys.forEach(System.out::print);

    }

    @Test
    public void test5() {
        RedisTemplate bean = SpringUtils.getBean("redisTemplate", RedisTemplate.class);
        System.out.println(bean);
    }

    @Test
    public void test7() {
        DruidDataSource druidDataSource = (DruidDataSource) dataSource;
        int maxActive = druidDataSource.getMaxActive();
        int initialSize = druidDataSource.getInitialSize();
        int minIdle = druidDataSource.getMinIdle();
        long maxEvictableIdleTimeMillis = druidDataSource.getMaxEvictableIdleTimeMillis();
        System.out.println(maxActive);
        System.out.println(initialSize);
        System.out.println(minIdle);
        System.out.println(maxEvictableIdleTimeMillis);
        String url = druidDataSource.getUrl();
        System.out.println(url);
        String password = druidDataSource.getPassword();
        System.out.println(password);
    }

    @Resource
    private SnowflakeConfig snowflakeConfig;

    @Test
    public void test8() {
        for (int i = 0; i < 100; i++) {
            System.out.println(snowflakeConfig.nextId().toString());
        }
    }

    @Resource
    private HbyAgencyService hbyAgencyService;

    //    @After
    public void test10() {
        Page<HbyAgency> page = hbyAgencyService.page(new Page<>(1, 12), null);
        List<HbyAgency> records = page.getRecords();
        records.forEach(System.out::println);
    }

    @Resource
    private AreaService areaService;

    @Test
    public void test11() {
        List<Area> provinceList = areaService.selectProvinceList("000000");
        List<Area> cityList = areaService.selectCityList(provinceList.get(0).getAreaid());
        List<Area> countyList = areaService.selectCountyList(cityList.get(0).getAreaid());
        System.out.println("========省区域信息=========");
        System.out.println(provinceList.size());
        provinceList.forEach(System.out::println);
        System.out.println("========市区域信息=========");
        System.out.println(cityList.size());
        cityList.forEach(System.out::println);
        System.out.println("========县区域信息=========");
        System.out.println(countyList.size());
        countyList.forEach(System.out::println);
    }

    @Resource
    private HbyAgencyMapper hbyAgencyMapper;

    @Resource
    private HbyIndustryService hbyIndustryService;

    @Test
    public void test13() {
        BaseAgencyDTO.AgencyReq req = new BaseAgencyDTO.AgencyReq();
//        req.setPage(2);
//        req.setRows(2);
//        req.setSiteId(1);
//        req.setTelePhone("11111");
//        req.setProvinceId("4");
        List<BaseAgencyDTO.AgencyList> hbyAgencies = hbyAgencyService.selectByBody(req);
        hbyAgencies.forEach(System.out::println);
    }


    @Test
    public void test14() {
        HbyAgency byId = hbyAgencyService.getById(15L);
        set("test:id", byId);
        Object o = valueOperations.get("test:id");
        System.out.println(JSONUtil.toJsonStr(o));
    }

    @Test
    public void test15() {
        BaseIndustryDTO.IndustryReq req = new BaseIndustryDTO.IndustryReq();
        req.setPage(1);
        req.setRows(20);
        req.setNumStart(1);
        req.setNumEnd(6);
        List<BaseIndustryDTO.IndustryList> industryLists = hbyIndustryService.selectByBody(req);
        industryLists.forEach(System.out::println);
    }

    @Test
    public void test16() {
        String accessToken = "3DA8FA6A10D807839C805333DABF05CF";
        Integer userId = redisTemplate.execute((RedisConnection redisConnection) -> {
            String hashKey = "LN.IOT.User:" + accessToken;
            Integer id = null;
            byte[] bytes = redisConnection.hGet(hashKey.getBytes(), "LN.LoginUserList".getBytes());
            if (!ArrayUtil.isEmpty(bytes)) {
                String json = new String(bytes);
                JSONObject jsonObject = JSONUtil.parseObj(json);
                id = jsonObject.getInt("user_id");
                System.out.println(id);
            }
            return id;
        });
        System.out.println(userId);
    }
}