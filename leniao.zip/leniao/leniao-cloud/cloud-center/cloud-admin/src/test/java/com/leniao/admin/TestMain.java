package com.leniao.admin;

import cn.hutool.aop.ProxyUtil;
import cn.hutool.aop.aspects.TimeIntervalAspect;
import cn.hutool.core.lang.Console;
import cn.hutool.json.JSONUtil;
import cn.hutool.system.JavaInfo;
import cn.hutool.system.UserInfo;
import com.leniao.entity.Area;
import com.leniao.entity.HbyAgency;
import com.leniao.model.vo.ResultEcho;
import org.joda.time.DateTime;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.List;

public class TestMain {

    @Test
    public void test() {
        DateTime dateTime = new DateTime();
        DateTime now = DateTime.now();
        System.out.println(dateTime.plusDays(1).toString("yyyy-MM-dd"));
        System.out.println(now);
        JavaInfo javaInfo = new JavaInfo();
        String version = javaInfo.getVersion();
        System.out.println(version);
        UserInfo userInfo = new UserInfo();
        System.out.println(userInfo.getName());
        List<String> list = null;
    }

    public static void setValue(Object target, String fieldName, Object value) {
        Class<?> clazz = target.getClass();
        String[] fs = fieldName.split("\\.");
        try {
            for (int i = 0; i < fs.length - 1; i++) {
                Field f = clazz.getDeclaredField(fs[i]);
                f.setAccessible(true);
                Object val = f.get(target);
                if (val == null) {
                    Constructor<?> c = f.getType().getDeclaredConstructor();
                    c.setAccessible(true);
                    val = c.newInstance();
                    f.set(target, val);
                }
                target = val;
                clazz = target.getClass();
            }
            Field f = clazz.getDeclaredField(fs[fs.length - 1]);
            f.setAccessible(true);
            f.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void test2() throws NoSuchFieldException, IllegalAccessException {

        Area areaarea = new Area();
        areaarea.setArea("北京");
        System.out.println(areaarea);
//        setValue(areaarea,"area","上海");
        Class<? extends Area> aClass = areaarea.getClass();
        Field field = aClass.getDeclaredField("area");
        field.setAccessible(true);
        Object val = field.get(areaarea);
        System.out.println(val);
        field.set(areaarea,"上海");
        System.out.println(areaarea);
    }

    @Test
    public void test3(){
        int a = 127, b = 127, c = 666, d = 666;
        System.out.println(a == b);
        System.out.println(c == d);
    }

    @Test
    public void test4(){
        String json = "{\n" +
                "\t\"agcyId\":15,\n" +
                "\t\"platformId\":2,\n" +
                "\t\"provinceCode\":\"11\",\n" +
                "\t\"cityCode\":\"22\",\n" +
                "\t\"areaCode\":\"33\",\n" +
                "\t\"agcyAddress\":\"00001\",\n" +
                "\t\"agcyName\":\"00001\",\n" +
                "\t\"telePhone\":\"00001\"\n" +
                "}";
        HbyAgency hbyAgency = JSONUtil.toBean(json, HbyAgency.class);
        System.out.println(hbyAgency);
    }

    @Test
    public void test5(){
        ResultEcho resultEcho = new ResultEcho();
        System.out.println(JSONUtil.toJsonStr(resultEcho));
        Dog dog = ProxyUtil.proxy(new Dog(), TimeIntervalAspect.class);
        String result = dog.eat();
        System.out.println(result);
    }

    public class Dog {
        public String eat() {
            Console.log("狗吃肉");
            return "";
        }
    }
}
