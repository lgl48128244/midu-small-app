package com.leniao.admin.controller;

import cn.hutool.json.JSONUtil;
import com.baidu.unbiz.fluentvalidator.DefaultValidateCallback;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.baidu.unbiz.fluentvalidator.Result;
import com.baidu.unbiz.fluentvalidator.ResultCollectors;
import com.baidu.unbiz.fluentvalidator.ValidatorContext;
import com.baidu.unbiz.fluentvalidator.ValidatorHandler;
import com.baidu.unbiz.fluentvalidator.annotation.FluentValidate;
import com.baidu.unbiz.fluentvalidator.jsr303.HibernateSupportedValidator;
import com.baidu.unbiz.fluentvalidator.validator.element.ValidatorElementList;
import com.leniao.admin.scheduler.DynamicTask;
import com.leniao.admin.service.SystemService;
import com.leniao.commons.BaseController;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author guoliang.li
 * @date 2020/1/2 11:49
 * @description TODO 动态启动、停止定时任务
 */
@RestController
@RequestMapping("test")
public class TestController extends BaseController {

    @Resource
    private DynamicTask dynamicTask;

    @RequestMapping("/scheduler/start")
    public Object start(String name) {
        dynamicTask.startCron(name);
        return renderResult();
    }

    @RequestMapping("/scheduler/stop")
    public Object stop(String name) {
        dynamicTask.stop(name);
        return renderResult();
    }

    @RequestMapping("/scheduler/clear")
    public Object clear() {
        dynamicTask.clear();
        return renderResult();
    }

    @Resource
    private SystemService systemService;

    @RequestMapping("/read")
    public Object read() {
        return renderResult(systemService.getById(12L));
    }

    @RequestMapping("/write")
    public Object write() {
        return renderResult(systemService.updateById(12L));
    }

    @PostMapping(value = "/validator")
    public Object validator(@RequestBody Car car) {
        Result result = FluentValidator
                .checkAll(new Class<?>[]{Add.class})
                //跳过当前验证进入一次校验
                .failOver()
                //结束当前验证，默认选项
//                .failFast()
                .on(car, new HibernateSupportedValidator<Car>().setHiberanteValidator(validator))
                //验证器可回调验证后以信息，默认不回调。
                .doValidate(new DefaultValidateCallback() {
                    @Override
                    public void onSuccess(ValidatorElementList validatorElementList) {
                        System.out.println("all ok!");
                        System.out.println(JSONUtil.toJsonStr(validatorElementList));
                    }
                })
                .result(ResultCollectors.toSimple());
        if (!result.isSuccess()) {
            return renderResult(null, -1, result.getErrors().toString());
        }
        return renderResult();
    }

    public class CarManufacturerValidator extends ValidatorHandler<Car> {
        @Override
        public boolean validate(ValidatorContext context, Car car) {
            if (car == null) {
                context.addErrorMsg("car is null");
                return false;
            }
            if (StringUtils.isBlank(car.getColumn1())) {
                context.addErrorMsg("column1 is null");
                return false;
            }
            if (StringUtils.isBlank(car.getColumn2())) {
                context.addErrorMsg("column2 is null");
                return false;
            }
            if (StringUtils.isBlank(car.getColumn3())) {
                context.addErrorMsg("column3 is null");
                return false;
            }
            return true;
        }
    }

    @Data
    public class Car {

        @FluentValidate(value = {CarManufacturerValidator.class}, groups = {Add.class})
        private String column1;
        @FluentValidate(value = {CarManufacturerValidator.class}, groups = {Add.class})
        private String column2;
        @FluentValidate(value = {CarManufacturerValidator.class}, groups = {Add.class})
        private String column3;
    }

    interface Add {

    }
}