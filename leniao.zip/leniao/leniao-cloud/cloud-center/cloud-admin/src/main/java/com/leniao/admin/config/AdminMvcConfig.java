package com.leniao.admin.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * MVC全局配置
 *
 * @author guoliang.li
 */
@Configuration
public class AdminMvcConfig implements WebMvcConfigurer {

}