package com.leniao.admin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageInfo;
import com.leniao.admin.constant.ApiConstant;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyIndustry;
import com.leniao.model.dto.BaseIndustryDTO;
import com.leniao.service.HbyIndustryService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:20
 * @description TODO
 */
@RestController
@RequestMapping(ApiConstant.INDUSTRY_PREF)
public class IndustryController extends BaseController {

    @Resource
    private HbyIndustryService hbyIndustryService;

    @RequestMapping(ApiConstant.INDUSTRY_LIST)
    public Object area(@RequestBody BaseIndustryDTO.IndustryReq req) {
        super.checkArgs(req);
        taskExecutor.execute(hbyIndustryService::updateBatch);
        return renderResult(new PageInfo<>(hbyIndustryService.selectByBody(req)));
    }

    @RequestMapping(ApiConstant.INDUSTRY_SAVE_OR_UPDATE)
    public Object saveOrUpdate(@RequestBody BaseIndustryDTO.IndustrySave req) {
        super.checkArgs(req);
        HbyIndustry hbyIndustry;
        Long id = req.getId();
        if (id != null) {
            hbyIndustry = hbyIndustryService.getById(id);
        } else {
            QueryWrapper<HbyIndustry> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(HbyIndustry::getIndustryName, req.getIndustryName());
            hbyIndustry = hbyIndustryService.getOne(queryWrapper);
            if (hbyIndustry != null) {
                throw new CloudException(CloudErrorCode.PARAM_EXIST, "行业名称已存在");
            }
            hbyIndustry = new HbyIndustry();
        }
        BeanUtils.copyProperties(req, hbyIndustry);
        return renderResult(hbyIndustryService.saveOrUpdate(hbyIndustry));
    }

    @RequestMapping(ApiConstant.INDUSTRY_DELETE)
    public Object delete(@RequestBody List<Long> ids) {
        return renderResult(hbyIndustryService.removeByIds(ids));
    }
}