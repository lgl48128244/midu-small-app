package com.leniao.admin.controller;

import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageInfo;
import com.leniao.admin.constant.ApiConstant;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.*;
import com.leniao.model.dto.BaseAgencyUserDTO;
import com.leniao.service.*;
import org.joda.time.DateTime;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.UUID;

@RestController
@RequestMapping(ApiConstant.AGENCY_USER)
public class AgencyUserController extends BaseController {

    @Resource
    private AgencyUserService agencyUserService;
    @Resource
    private TbLnUserInfoService tbLnUserInfoService;
    @Resource
    private TblnGroupInfoService tblnGroupInfoService;
    @Resource
    private TblngroupAddressService tblngroupAddressService;
    @Resource
    private HbyAgencyService hbyAgencyService;
    @Resource
    private HbyAgencyJoinUserService hbyAgencyJoinUserService;



    /**
     * 保存或修改机构用户
     *
     * @param saveDTO
     * @return
     */
    @PostMapping(ApiConstant.AGENCY_USER_SAVE_OR_UPDATE)
    public Object saveAgencyUser(@RequestBody BaseAgencyUserDTO.AgencyUserSave saveDTO) {
        super.checkArgs(saveDTO);
        //获取机构
        HbyAgency hbyAgency = this.hbyAgencyService.selectByAreaCode(saveDTO.getProvinceCode(), saveDTO.getCityCode(), saveDTO.getAreaCode(),saveDTO.getPlatformId());
        if (hbyAgency == null) {
            return renderResult(null, 200, "当前机构不存在");
        }

        QueryWrapper<TbLnUserInfo> userInfoQueryWrapper = new QueryWrapper<>();
        userInfoQueryWrapper.lambda().eq(TbLnUserInfo::getUserphone, saveDTO.getUserPhone());
        TbLnUserInfo userInfo = this.tbLnUserInfoService.getOne(userInfoQueryWrapper);
        TblnGroupInfo tblnGroupInfo = null;
        TblnGroupAddress tblnGroupAddress = null;
        HbyAgencyJoinUser agencyJoinUser = null;
        if (userInfo != null) {
            //判断用户权限
            userInfo.setCode(saveDTO.getPosition());
            QueryWrapper<TblnGroupInfo> groupInfoQueryWrapper = new QueryWrapper<>();
            groupInfoQueryWrapper.lambda().eq(TblnGroupInfo::getUserid, userInfo.getUserid());
            tblnGroupInfo = this.tblnGroupInfoService.getOne(groupInfoQueryWrapper);
            if (tblnGroupInfo != null && tblnGroupInfo.getUsertype() == 1) {
                return renderResult(null, 200, "当前账号为个人权限组账号，暂不支持升级为环保云账号");
            }
            QueryWrapper<HbyAgencyJoinUser> joinUserQueryWrapper = new QueryWrapper<>();
            joinUserQueryWrapper.lambda().eq(HbyAgencyJoinUser::getUserId, userInfo.getUserid());
            agencyJoinUser = this.hbyAgencyJoinUserService.getOne(joinUserQueryWrapper);
            if (tblnGroupInfo != null) {
                tblnGroupInfo.setUsername(saveDTO.getUserName());
                tblnGroupInfo.setUsertel(saveDTO.getUserPhone());
                tblnGroupInfo.setAddtime(DateTime.now().toDate());
                tblnGroupInfo.setAdduser(saveDTO.getAddUser());
                tblnGroupInfo.setPlatformid(saveDTO.getPlatformId());
                tblnGroupInfo.setUsertype(3);
            }
            QueryWrapper<TblnGroupAddress> addressQueryWrapper = new QueryWrapper<>();
            addressQueryWrapper.lambda().eq(TblnGroupAddress::getUserid, userInfo.getUserid());
            tblnGroupAddress = this.tblngroupAddressService.getOne(addressQueryWrapper);
            if (tblnGroupAddress != null) {
                tblnGroupAddress.setAdprovince(saveDTO.getProvinceName());
                tblnGroupAddress.setAdcity(saveDTO.getCityName());
                tblnGroupAddress.setAdarea(saveDTO.getAreaName());
                tblnGroupAddress.setCprovincecode(saveDTO.getProvinceCode());
                tblnGroupAddress.setCcitycode(saveDTO.getCityCode());
                tblnGroupAddress.setCareacode(saveDTO.getAreaCode());
                tblnGroupAddress.setOnlyread(1);
                tblnGroupAddress.setAdduser(saveDTO.getAddUser());
                tblnGroupAddress.setAddtime(DateTime.now().toDate());
                //tblnGroupAddress.setIsdel(0);
                //tblnGroupAddress.setIslock(0);
            }

        }
        if (userInfo == null) {
            userInfo = new TbLnUserInfo();
            userInfo.setCode(saveDTO.getPosition());
            userInfo.setUsername(saveDTO.getUserName());
            userInfo.setUserpwd(UUID.randomUUID().toString().toUpperCase().substring(0,15));
            userInfo.setUsername(saveDTO.getUserName());
            userInfo.setPlatformid(saveDTO.getPlatformId());
            userInfo.setUserprovince(saveDTO.getProvinceName());
            userInfo.setUsercity(saveDTO.getCityName());
            userInfo.setUserarea(saveDTO.getAreaName());
            userInfo.setUserphone(saveDTO.getUserPhone());
            userInfo.setUserrightid(0);
            userInfo.setUsercreatetime(DateTime.now().toDate());
            userInfo.setUserisleave(0);
            userInfo.setUserremark("此账号为系统指定的环保机构权限账号");
            userInfo.setIsdelete(0);
            userInfo.setIssend(0);
        }

        String groupId = UUID.randomUUID().toString().toUpperCase().replace("-", "");
        if (tblnGroupInfo == null) {
            tblnGroupInfo = new TblnGroupInfo();
            tblnGroupInfo.setGroupid(groupId);
            tblnGroupInfo.setGroupname(saveDTO.getProvinceName() + "-" + saveDTO.getCityName() + "-" + saveDTO.getAreaName());
            tblnGroupInfo.setGrouptype(2);
            //TODO 在service层先保存用户数据后得到返回的userId再设置进去
            tblnGroupInfo.setUserid(null);
            tblnGroupInfo.setAdduser(saveDTO.getAddUser());
            tblnGroupInfo.setAddtime(DateTime.now().toDate());
            tblnGroupInfo.setIsdel(0);
            tblnGroupInfo.setUsername(saveDTO.getUserName());
            tblnGroupInfo.setUsertel(saveDTO.getUserPhone());
            tblnGroupInfo.setPlatformid(saveDTO.getPlatformId());
            tblnGroupInfo.setUsertype(3);
        }

        if (tblnGroupAddress == null) {
            tblnGroupAddress = new TblnGroupAddress();
            tblnGroupAddress.setAdid(UUID.randomUUID().toString().toUpperCase().replace("-", ""));
            //TODO 在service层先保存用户数据后得到返回的userId再设置进去
            tblnGroupAddress.setUserid(null);
            tblnGroupAddress.setAdprovince(saveDTO.getProvinceName());
            tblnGroupAddress.setAdcity(saveDTO.getCityName());
            tblnGroupAddress.setAdarea(saveDTO.getAreaName());
            tblnGroupAddress.setCprovincecode(saveDTO.getProvinceCode());
            tblnGroupAddress.setCcitycode(saveDTO.getCityCode());
            tblnGroupAddress.setCareacode(saveDTO.getAreaCode());
            tblnGroupAddress.setOnlyread(1);
            tblnGroupAddress.setAdduser(saveDTO.getAddUser());
            tblnGroupAddress.setAddtime(DateTime.now().toDate());
            tblnGroupAddress.setIsdel(0);
            tblnGroupAddress.setIslock(0);
            tblnGroupAddress.setGroupid(groupId);

        }
        if (agencyJoinUser == null) {
            agencyJoinUser = new HbyAgencyJoinUser();
            agencyJoinUser.setAgencyId(hbyAgency.getId());
            agencyJoinUser.setUserId(null);
        } else {
            agencyJoinUser.setAgencyId(hbyAgency.getId());
        }

        //放入service保存作为一个事务
        return renderResult(this.agencyUserService.saveOrUpdateAgencyUser(userInfo, tblnGroupInfo, tblnGroupAddress, agencyJoinUser));
    }

    @PostMapping(ApiConstant.AGENCY_USER_DELETE)
    public Object deleteAgencyUser(@RequestBody JSONObject jsonObject) {
        Integer userId = jsonObject.getInt("userId");
        if (userId == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(this.agencyUserService.deleteAgencyUser(userId));
    }

    @PostMapping(ApiConstant.AGENCY_USER_LIST)
    public Object list(@RequestBody BaseAgencyUserDTO.AgencyUserPage page) {
        super.checkArgs(page);
        return renderResult(new PageInfo<>(this.agencyUserService.findByPage(page)));
    }

    @PostMapping(ApiConstant.AGENCY_USER_VIEW)
    public Object view(@RequestBody JSONObject jsonObject) {
        Integer userId = jsonObject.getInt("userId");
        Integer platformId = jsonObject.getInt("platformId");
        if (userId == null || platformId == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(this.agencyUserService.findItemDesc(userId, platformId));
    }



}
