package com.leniao.admin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageInfo;
import com.leniao.admin.constant.ApiConstant;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.model.dto.BaseAgencyDTO;
import com.leniao.service.HbyAgencyService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/20 16:12
 * @description TODO 机构接口
 */
@RestController
@RequestMapping(ApiConstant.AGENCY_PREF)
public class AgencyController extends BaseController {

    @Resource
    private HbyAgencyService hbyAgencyService;

    @RequestMapping(ApiConstant.AGENCY_LIST)
    public Object area(@RequestBody BaseAgencyDTO.AgencyReq req) {
        super.checkArgs(req);
        return renderResult(new PageInfo<>(hbyAgencyService.selectByBody(req)));
    }
    @RequestMapping(ApiConstant.AGENCY_LIST_NOT_PAGE)
    public Object areaNotPage(@RequestBody BaseAgencyDTO.AgencyReq2 req){
        super.checkArgs(req);
        return renderResult(hbyAgencyService.selectByBody(req));
    }

    @RequestMapping(ApiConstant.AGENCY_SAVE_OR_UPDATE)
    public Object saveOrUpdate(@RequestBody BaseAgencyDTO.AgencySave req) {
        super.checkArgs(req);
        HbyAgency hbyAgency;
        List<HbyAgency> agencyList = null;
        Long id = req.getId();
        if (id != null) {
            QueryWrapper<HbyAgency> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(HbyAgency::getProvinceCode, req.getProvinceCode())
                    .eq(HbyAgency::getCityCode, req.getCityCode()).eq(HbyAgency::getAreaCode, req.getAreaCode());
            agencyList = hbyAgencyService.list(queryWrapper);
            for (HbyAgency agency : agencyList) {
                BeanUtils.copyProperties(req, agency, "id", "platformId", "provinceCode", "cityCode", "areaCode");
            }
        } else {
            QueryWrapper<HbyAgency> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(HbyAgency::getPlatformId, req.getPlatformId()).eq(HbyAgency::getProvinceCode, req.getProvinceCode())
                    .eq(HbyAgency::getCityCode, req.getCityCode()).eq(HbyAgency::getAreaCode, req.getAreaCode());
            hbyAgency = hbyAgencyService.getOne(queryWrapper);
            if (hbyAgency != null) {
                throw new CloudException(CloudErrorCode.PARAM_EXIST, "该平台已存在此机构");
            }
            hbyAgency = new HbyAgency();
            BeanUtils.copyProperties(req, hbyAgency);
            agencyList = new ArrayList<>();
            agencyList.add(hbyAgency);
        }
        return renderResult(hbyAgencyService.saveOrUpdateBatch(agencyList));
    }

    @RequestMapping(ApiConstant.AGENCY_DELETE)
    public Object delete(@RequestBody List<Long> ids) {
        return renderResult(hbyAgencyService.removeByIds(ids));
    }
}