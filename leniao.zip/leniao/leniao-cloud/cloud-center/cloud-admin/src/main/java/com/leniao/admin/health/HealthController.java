package com.leniao.admin.health;

import com.leniao.admin.annotation.CheckAge;
import com.leniao.commons.AppServerParams;
import com.leniao.model.vo.ResultEcho;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author guoliang.li
 * @date 2019/12/25 11:54
 * @description TODO 验证服务是否正常
 */
@RestController
public class HealthController {

    @Resource
    private AppServerParams appServerParams;

    @RequestMapping("/server/health")
    public String health() {
        return "I am ok!!!\t" + appServerParams.getAppName();
    }

    @CheckAge
    @RequestMapping("/test/annotation")
    public Object test(){
        return new ResultEcho();
    }
}