package com.leniao.admin.scheduler;

import com.leniao.commons.AbstractOperation;
import com.leniao.model.constant.GlobalConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import java.time.LocalTime;
import java.util.concurrent.ScheduledFuture;

/**
 * @author 乐鸟研发
 */
@Component
public class DynamicTask extends AbstractOperation {

    public void startCron(String name) {
        String cron = "0/5 * * * * ?";
        if (StringUtils.isBlank(name)) {
            name = Thread.currentThread().getName();
        }
        ScheduledFuture<?> scheduledFuture = (ScheduledFuture<?>) GlobalConstant.CONCURRENT_HASH_MAP.get(name);
        if (scheduledFuture == null) {
            scheduledFuture = taskScheduler.schedule(new MyTask(name), new CronTrigger(cron));
            GlobalConstant.CONCURRENT_HASH_MAP.put(name, scheduledFuture);
        }
    }

    public void stop(String name) {
        ScheduledFuture<?> scheduledFuture = (ScheduledFuture<?>) GlobalConstant.CONCURRENT_HASH_MAP.get(name);
        if (scheduledFuture != null) {
            // 查看任务是否在正常执行之前结束,正常true
            boolean cancelled = scheduledFuture.isCancelled();
            if (!cancelled) {
                scheduledFuture.cancel(true);
            }
        }
    }

    public void clear() {
        GlobalConstant.CONCURRENT_HASH_MAP.forEach((k, v) -> {
            if (v != null) {
                ((ScheduledFuture<?>) v).cancel(true);
            }
        });
    }

    static class MyTask implements Runnable {
        private String name;

        MyTask(String name) {
            this.name = name;
        }

        @Override
        public void run() {
            System.out.println("========" + name + "=======\t" + LocalTime.now());
        }
    }
}