package com.leniao.admin.service;

import com.leniao.entity.HbyAgency;
import com.leniao.mapper.HbyAgencyMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author 乐鸟研发
 */
@Service
public class SystemService {

    @Resource
    private HbyAgencyMapper hbyAgencyMapper;

    public HbyAgency getById(Long id) {
        return hbyAgencyMapper.selectByPrimaryKey(id);
    }

    public HbyAgency updateById(Long id) {
        HbyAgency hbyAgency = hbyAgencyMapper.selectByPrimaryKey(id);
        hbyAgency.setUpdateTime(new Date());
        hbyAgencyMapper.updateByPrimaryKey(hbyAgency);
        return hbyAgencyMapper.selectByPrimaryKey(id);
    }
}