package com.leniao.admin.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * @author guoliang.li
 * @date 2019/12/27 8:55
 * @description TODO
 */
@Component
@Aspect
public class CheckAgeAop {

    @Before("@annotation(com.leniao.admin.annotation.CheckAge) ")
    public void before(JoinPoint pjp){
        System.out.println("=========before==========");
    }
}