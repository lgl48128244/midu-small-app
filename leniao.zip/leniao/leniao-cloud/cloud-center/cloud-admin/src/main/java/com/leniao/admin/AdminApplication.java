package com.leniao.admin;

import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * @author guoliang.li
 * @date 2019/12/17 16:21
 * @description TODO
 * {@link org.springframework.boot.web.servlet.ServletComponentScan} 使servlet filter listener注解生效
 * {@link org.springframework.boot.context.properties.ConfigurationPropertiesScan} 使@ConfigurationProperties注解生效,不再需要@Component注入
 * TODO @ServletComponentScan @ConfigurationPropertiesScan 注解必须配置于各自的启动类里,否则不生效。
 */
@SpringBootApplication(scanBasePackages = "com.leniao", exclude = DruidDataSourceAutoConfigure.class)
@ConfigurationPropertiesScan
public class AdminApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(AdminApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(AdminApplication.class);
    }
}