package com.leniao.admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.leniao.admin.constant.ApiConstant;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.service.AreaService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author guoliang.li
 * @date 2019/12/20 17:53
 * @description TODO 区域接口
 */
@RestController
@RequestMapping(ApiConstant.AREA_PREF)
public class AreaController extends BaseController {

    @Resource
    private AreaService areaService;

    @RequestMapping(ApiConstant.AREA_PROVINCE)
    public Object province(){
        return renderResult(areaService.selectProvinceList(ApiConstant.AREA_DEFAULT_CODE));
    }

    @RequestMapping(ApiConstant.AREA_CITY)
    public Object city(@RequestBody JSONObject jsonObject){
        String provinceCode = jsonObject.getString("provinceCode");
        if (StringUtils.isBlank(provinceCode)){
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(areaService.selectCityList(provinceCode));
    }

    @RequestMapping(ApiConstant.AREA_COUNTY)
    public Object county(@RequestBody JSONObject jsonObject){
        String cityCode = jsonObject.getString("cityCode");
        if (StringUtils.isBlank(cityCode)){
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(areaService.selectCountyList(cityCode));
    }
}