package com.leniao.admin.constant;

/**
 * @author guoliang.li
 * @date 2019/12/19 10:45
 * @description TODO 接口常量
 */
public interface ApiConstant {

    /**
     * 区域接口
     */
    String AREA_PREF = "area";
    String AREA_PROVINCE = "province";
    String AREA_CITY = "city";
    String AREA_COUNTY = "county";
    String AREA_DEFAULT_CODE = "000000";

    /**
     * 机构接口
     */
    String AGENCY_PREF = "agency";
    String AGENCY_LIST = "list";
    String AGENCY_LIST_NOT_PAGE = "listNoPage";
    String AGENCY_SAVE_OR_UPDATE = "saveOrUpdate";
    String AGENCY_DELETE = "delete";

    /**
     * 平台接口
     */
    String PLATFORM_PREF = "platform";
    String PLATFORM_LIST = "list";

    /**
     * 行业接口
     */
    String INDUSTRY_PREF = "industry";
    String INDUSTRY_LIST = "list";
    String INDUSTRY_SAVE_OR_UPDATE = "saveOrUpdate";
    String INDUSTRY_DELETE = "delete";

    /**
     * 机构用户接口
     */
    String AGENCY_USER = "agencyUser";
    String AGENCY_USER_SAVE_OR_UPDATE = "saveOrUpdate";
    String AGENCY_USER_DELETE = "delete";
    String AGENCY_USER_LIST = "list";
    String AGENCY_USER_VIEW = "view";

}