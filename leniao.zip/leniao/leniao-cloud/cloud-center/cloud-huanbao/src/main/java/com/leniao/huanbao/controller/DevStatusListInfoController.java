package com.leniao.huanbao.controller;

import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.util.HbaseUtil;
import com.leniao.commons.util.thrift.realValueByNode1;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.entity.Tblndevicenodeinfo;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyDevalTimeStatus;
import com.leniao.huanbao.entity.HbyOverlookJoin;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.mapper.HbyDevalTimeStatusMapper;
import com.leniao.huanbao.mapper.HbyOverlookpointPlusMapper;
import com.leniao.huanbao.mapper.TbprojectInfoPlusMapper;
import com.leniao.huanbao.pojo.pagetopselecteneity.*;
import com.leniao.huanbao.pojo.receive.UnitRealTimeData;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.*;
import com.leniao.model.devlist.CountUnitAnalysisInfo;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * @author liudongshuai
 * @date 2019/12/25 16:42
 * @update
 * @description
 */
@CrossOrigin
@RequestMapping(EntranceConstant.DEVDATAINFO)
@RestController
public class DevStatusListInfoController extends BaseController {
    /**
     * 节点信息表
     */
    @Resource
    private TblndevicenodeinfoService tblndevicenodeinfoService;
    /**
     * 设备信息表
     */
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    /**
     * 节点阈值表
     */
    @Resource
    private TblndeviceparainfoService tblndeviceparainfoService;
    /**
     * 单位信息表
     */
    @Resource
    private TblnprojectinfoService tblnprojectinfoService;
    /**
     * 企业日信息详情表
     */
    @Resource
    private HbyDevalTimeStatusService hbyDevalTimeStatusService;
    /**
     * 设备监测点关联
     */
    @Resource
    private HbyOverLookDevJoinService hbyOverlookDevJoinService;
    /**
     * 监测点信息表
     */
    @Resource
    private HbyOverLookpointService hbyOverlookpointService;
    /**
     * 分组信息表
     */
    @Resource
    private TblngroupService tblngroupService;
    /**
     * 3*3关系表
     */
    @Resource
    private HbyOverlookJoinService hbyOverlookJoinService;
    /**
     * 单位停限产计划表
     */
    @Resource
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;
    @Resource
    private HbyOverlookpointPlusMapper hbyOverlookpointPlusMapper;
    @Resource
    private TbprojectInfoPlusMapper tbprojectInfoPlusMapper;
    @Resource
    private HbyDevalTimeStatusMapper hbyDevalTimeStatusMapper;
    @Resource
    private HbyAgencyService hbyAgencyService;
    @Resource
    private HbyReduceEmmissionService hbyReduceEmmissionService;
    @Resource
    private PermissionService permissionService;
    @Resource
    private HbyProjectstatusService hbyProjectstatusService;

    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyyMMddHHmmss");
    private SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyy-MM-dd");

    @RequestMapping(value=APIConstant.UNITDAYDEFAULTDATA)
    public Object runConditionsOperating(@RequestBody HashMap<String, Object> receiveMap){
        String dateStr;
        if (receiveMap.get("date")==null){
            dateStr = simpleDateFormat3.format(new Date());
        }else {
            dateStr = String.valueOf(receiveMap.get("date"));
        }
        //参数校验
        Map<String,Object> resultMap = new HashMap<>();
        if (!String.valueOf(receiveMap.get("lookId")).equals("")){
            Long lookId = Long.parseLong(String.valueOf(receiveMap.get("lookId")));
            if (hbyOverlookpointService.findOverLookPoint(lookId).getPointType()==0){
                return renderResult(false,-1,"该检测点为总检测点，暂无运行工况对比");
            }else {
                List<HbyOverLookDevJoin> hbyOverLookDevJoinPollList = hbyOverlookDevJoinService.findPollsNumByLookPointId(lookId);
                List<HbyOverLookDevJoin> hbyOverLookDevJoinConList= hbyOverlookDevJoinService.findConsNumByLookPointId(lookId);
                if ((hbyOverLookDevJoinConList.size()==0)||(hbyOverLookDevJoinPollList.size()==0)){
                    return renderResult(false,-1,"该检测点无产治污设备，暂无运行工况对比");
                }else {
                    Integer devPollId = hbyOverLookDevJoinPollList.get(0).getDevIdpk();
                    Integer devConId = hbyOverLookDevJoinConList.get(0).getDevIdpk();
                    resultMap.put("lookId",lookId);
                    List<DevInfos> polls = new ArrayList<>();
                    for (HbyOverLookDevJoin hbyOverLookDevJoin:hbyOverLookDevJoinPollList) {
                        DevInfos devInfos = new DevInfos();
                        devInfos.setDevsignature(tblndeviceinfoService.findDevSignById(hbyOverLookDevJoin.getDevIdpk()));
                        devInfos.setDevlocation(tblndeviceinfoService.findLocation(hbyOverLookDevJoin.getDevIdpk()));
                        try {
                            devInfos.setStatus(getRunStatusByDayTime(simpleDateFormat3.parse(dateStr),hbyOverLookDevJoin.getDevIdpk()));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        polls.add(devInfos);
                    }
                    HbyDevalTimeStatus hbyDevalTimePollsStatus = new HbyDevalTimeStatus();
                    List<HbyDevalTimeStatus> hbyDevalTimeStatusList = hbyDevalTimeStatusService.findHbyDevalTimeStatus(devPollId);
                    if (hbyDevalTimeStatusList.size()==0){
                    }else {
                        for (HbyDevalTimeStatus hbyDevalTime:hbyDevalTimeStatusList) {
                            if (dateStr.equals(simpleDateFormat3.format(hbyDevalTime.getAddtime()))){
                                hbyDevalTimePollsStatus=hbyDevalTimeStatusService.findHbyDevalTimeStatus(hbyDevalTime.getId());
                                break;
                            }
                        }
                    }
                    resultMap.put("polls",polls);
                    resultMap.put("defaultPolls",hbyDevalTimePollsStatus);
                    resultMap.put("pollLocation",tblndeviceinfoService.findLocation(devPollId));

                    List<DevInfos> cons = new ArrayList<>();
                    for (HbyOverLookDevJoin hbyOverLookDevJoin:hbyOverLookDevJoinConList) {
                        DevInfos devInfos = new DevInfos();
                        devInfos.setDevsignature(tblndeviceinfoService.findDevSignById(hbyOverLookDevJoin.getDevIdpk()));
                        devInfos.setDevlocation(tblndeviceinfoService.findLocation(devInfos.getDevsignature()));
                        try {
                            devInfos.setStatus(getRunStatusByDayTime(simpleDateFormat3.parse(dateStr),hbyOverLookDevJoin.getDevIdpk()));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        cons.add(devInfos);
                    }
                    HbyDevalTimeStatus hbyDevalTimeConsStatus = new HbyDevalTimeStatus();
                    List<HbyDevalTimeStatus> hbyDevalTimeStatusList2 = hbyDevalTimeStatusService.findHbyDevalTimeStatus(devConId);
                    if (hbyDevalTimeStatusList.size()==0){

                    }else {
                        for (HbyDevalTimeStatus hbyDevalTime:hbyDevalTimeStatusList2) {
                            if (dateStr.equals(simpleDateFormat3.format(hbyDevalTime.getAddtime()))){
                                hbyDevalTimeConsStatus=hbyDevalTimeStatusService.findHbyDevalTimeStatus(hbyDevalTime.getId());
                                break;
                            }
                        }
                    }
                    resultMap.put("cons",cons);
                    resultMap.put("defaultCons",hbyDevalTimeConsStatus);
                    resultMap.put("conLocation",tblndeviceinfoService.findLocation(devConId));
                    resultMap.put("dateTime",dateStr);
                    return renderResult(resultMap);
                }
                }
        }else {
            return renderResult(false,-1,"参数错误");
        }
    }

    @RequestMapping(value = APIConstant.UNITDAYREALDATA,method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object unitDayRealData(@RequestBody Map<String,Object> receiveMap){
        Map<String,Object> resultMap = new HashMap<>();
        List<Map<String,Object>> mapList = new ArrayList<>();
        Long lookId = Long.parseLong(String.valueOf(receiveMap.get("lookId")));
        String dateStr;
        if (receiveMap.get("dateDay")==null){
            dateStr = simpleDateFormat3.format(new Date());
        }else {
            dateStr = String.valueOf(receiveMap.get("dateDay"));
        }
        HbyDevalTimeStatus hbyDevalTimeStatus = new HbyDevalTimeStatus();
        String devSign = String.valueOf(receiveMap.get("devsignature"));
        Integer devIdpk = tblndeviceinfoService.findDevIdPk(devSign);
        Integer unitId = Integer.parseInt(String.valueOf(receiveMap.get("unitId")));
        Integer devTy = Integer.parseInt(String.valueOf(receiveMap.get("devTy")));
        UserInfo userInfo = this.getUserInfo();
        List<HbyDevalTimeStatus> hbyDevalTimeStatusList = hbyDevalTimeStatusService.findHbyDevalTimeStatus2(devIdpk,userInfo.getPlatformId());
        for (HbyDevalTimeStatus hbyDevalTime:hbyDevalTimeStatusList) {
            if (dateStr.equals(simpleDateFormat3.format(hbyDevalTime.getAddtime()))){
                hbyDevalTimeStatus=hbyDevalTimeStatusService.findHbyDevalTimeStatus(hbyDevalTime.getId());
                break;
            }
        }
        resultMap.put("data",hbyDevalTimeStatus);
        resultMap.put("location",tblndeviceinfoService.findLocation(String.valueOf(receiveMap.get("devsignature"))));

        if (devTy == 1) {
            List<Integer> conList = hbyOverlookDevJoinService.findConsNumByLookPointId2(lookId);
            for (Integer conDevId:conList ) {
                HbyDevalTimeStatus hbyDevalTimeStatusCon = new HbyDevalTimeStatus();
                List<HbyDevalTimeStatus> hbyOverLookDevJoinListCon = hbyDevalTimeStatusService.findHbyDevalTimeStatus2(conDevId,userInfo.getPlatformId());
                Map<String,Object> listMap = new HashMap<>();
                for (HbyDevalTimeStatus hbyDevalTime:hbyOverLookDevJoinListCon) {
                    if (dateStr.equals(simpleDateFormat3.format(hbyDevalTime.getAddtime()))){
                        hbyDevalTimeStatusCon = hbyDevalTimeStatusService.findHbyDevalTimeStatus(hbyDevalTime.getId());
                    }
                }
                listMap.put("data",hbyDevalTimeStatusCon);
                listMap.put("location",tblndeviceinfoService.findLocation(tblndeviceinfoService.findDevSignById(conDevId)));
                mapList.add(listMap);
            }
        }else {
            List<Integer> pollList = hbyOverlookDevJoinService.findPollsNumByLookPointId2(lookId);
            for (Integer pollDevId:pollList) {
                HbyDevalTimeStatus hbyDevalTimeStatusPoll = new HbyDevalTimeStatus();
                List<HbyDevalTimeStatus> hbyOverLookDevJoinListPoll = hbyDevalTimeStatusService.findHbyDevalTimeStatus2(pollDevId,userInfo.getPlatformId());
                Map<String,Object> listMap = new HashMap<>();
                for (HbyDevalTimeStatus hbyDevalTime : hbyOverLookDevJoinListPoll) {
                    if (dateStr.equals(simpleDateFormat3.format(hbyDevalTime.getAddtime()))) {
                        hbyDevalTimeStatusPoll = hbyDevalTimeStatusService.findHbyDevalTimeStatus(hbyDevalTime.getId());

                    }
                }
                listMap.put("data",hbyDevalTimeStatusPoll);
                listMap.put("location",tblndeviceinfoService.findLocation(tblndeviceinfoService.findDevSignById(pollDevId)));
                mapList.add(listMap);
            }
        }
        resultMap.put("list",mapList);
        return renderResult(resultMap);

    }

    @RequestMapping(value = APIConstant.DEVREALTIMEDATA,method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object deviceRealDataInfo(@RequestBody Map<String,Object> receiveMap){
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoService.findGroupIdProTyStatus(String.valueOf(receiveMap.get("devsignature")));
        DevRealDataInfo devRealDataInfo = new DevRealDataInfo();
        devRealDataInfo.setWorkStatus(String.valueOf(hbyOverlookDevJoinService.findDevWorkStatus(tblndeviceinfo.getDevidpk())));
        devRealDataInfo.setDevLocation(tblndeviceinfo.getInstalllocation());
        devRealDataInfo.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(tblndeviceinfo.getProjid()).getProjname());
        Integer devId = tblndeviceinfo.getDevidpk();
        List<realValueByNode1> realValueByNode1List = findRealTimeInfo(tblndeviceinfo.getDevidpk(),"Va-Vb-Vc-Ia-Ib-Ic-QA-QB-QC-PA-PB-PC-RPA-RPB-RPC-DA-DB-DC", String.valueOf(receiveMap.get("beginTime")), simpleDateFormat2.format(new Date()));
        devRealDataInfo.setUpdateTime(realValueByNode1List.get(0).addtime);
        ;
        devRealDataInfo.setVoltA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(0).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId0 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Va");
        devRealDataInfo.setVoltAStatus(DevUtils.compareRealValue(realValueByNode1List.get(0).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId0,devId))));

        devRealDataInfo.setVoltB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(1).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId1 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Vb");
        devRealDataInfo.setVoltBStatus(DevUtils.compareRealValue(realValueByNode1List.get(1).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId1,devId))));

        devRealDataInfo.setVoltC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(2).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId2 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Vc");
        devRealDataInfo.setVoltCStatus(DevUtils.compareRealValue(realValueByNode1List.get(2).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId2,devId))));

        devRealDataInfo.setCurrentA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(3).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId3 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Ia");
        devRealDataInfo.setCurrentAStatus(DevUtils.compareRealValue(realValueByNode1List.get(3).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId3,devId))));

        devRealDataInfo.setCurrentB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(4).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId4 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Ib");
        devRealDataInfo.setCurrentBStatus(DevUtils.compareRealValue(realValueByNode1List.get(4).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId4,devId))));

        devRealDataInfo.setCurrentC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(5).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId5 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"Ic");
        devRealDataInfo.setCurrentCStatus(DevUtils.compareRealValue(realValueByNode1List.get(5).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId5,devId))));

        devRealDataInfo.setPowerEle(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(6).val)).setScale(1, RoundingMode.DOWN)))+Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(7).val)).setScale(1, RoundingMode.DOWN)))+Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(8).val)).setScale(1, RoundingMode.DOWN))));
        //Integer nodeId6 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"QA");
        //devRealDataInfo.setPowerEleStatus(DevUtils.compareRealValue(realValueByNode1List.get(6).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId6,devId))));

        devRealDataInfo.setPowerOnA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(9).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId7 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"PA");
        devRealDataInfo.setPowerOnAStatus(DevUtils.compareRealValue(realValueByNode1List.get(9).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId7,devId))));

        devRealDataInfo.setPowerOnB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(10).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId8 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"PB");
        devRealDataInfo.setPowerOnBStatus(DevUtils.compareRealValue(realValueByNode1List.get(10).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId8,devId))));

        devRealDataInfo.setPowerOnC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(11).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId9 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"PC");
        devRealDataInfo.setPowerOnCStatus(DevUtils.compareRealValue(realValueByNode1List.get(11).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId9,devId))));

        devRealDataInfo.setPowerOutA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(12).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId10 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"RPA");
        devRealDataInfo.setPowerOutAStatus(DevUtils.compareRealValue(realValueByNode1List.get(12).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId10,devId))));

        devRealDataInfo.setPowerOutB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(13).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId11 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"RPB");
        devRealDataInfo.setPowerOutBStatus(DevUtils.compareRealValue(realValueByNode1List.get(13).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId11,devId))));

        devRealDataInfo.setPowerOutC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(14).val)).setScale(1, RoundingMode.DOWN))));
        Integer nodeId12 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"RPC");
        devRealDataInfo.setPowerOutCStatus(DevUtils.compareRealValue(realValueByNode1List.get(14).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId12,devId))));

        //devRealDataInfo.setPowerCount(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(15).val)).setScale(1, RoundingMode.DOWN)))+Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(16).val)).setScale(1, RoundingMode.DOWN)))+Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(17).val)).setScale(1, RoundingMode.DOWN))));
        //Integer nodeId13 = tblndevicenodeinfoService.findNodeIdPk(tblndeviceinfo.getDevtyid(),"DA");
        //devRealDataInfo.setPowerCountStatus(DevUtils.compareRealValue(realValueByNode1List.get(15).val, String.valueOf(tblndeviceparainfoService.findValue(nodeId13,devId))));
        Float powerOn = 0F;
        Float powerOut = 0F;
        if ((Float.valueOf(realValueByNode1List.get(15).val)==0)&&"1200-01-01 00:00:01".equals(realValueByNode1List.get(15).addtime)){

        }else {
            powerOn = powerOn + devRealDataInfo.getPowerOnA();
            powerOut = powerOut + devRealDataInfo.getPowerOutA();
        }
        if ((Float.valueOf(realValueByNode1List.get(16).val)==0)&&"1200-01-01 00:00:01".equals(realValueByNode1List.get(15).addtime)){

        }else {
            powerOn = powerOn + devRealDataInfo.getPowerOnB();
            powerOut = powerOut + devRealDataInfo.getPowerOutB();
        }
        if ((Float.valueOf(realValueByNode1List.get(17).val)==0)&&"1200-01-01 00:00:01".equals(realValueByNode1List.get(15).addtime)){

        }else {
            powerOn = powerOn + devRealDataInfo.getPowerOnC();
            powerOut = powerOut + devRealDataInfo.getPowerOutC();
        }

        devRealDataInfo.setPowerOn(powerOn);
        devRealDataInfo.setPowerOut(powerOut);
        Double totalNum = Math.sqrt(devRealDataInfo.getPowerOn()*devRealDataInfo.getPowerOn()+devRealDataInfo.getPowerOut()*devRealDataInfo.getPowerOut());
        if (totalNum==0){
            devRealDataInfo.setPowerCount(0D);
        }else {
            devRealDataInfo.setPowerCount(devRealDataInfo.getPowerOn()/totalNum);
        }
        return renderResult(devRealDataInfo);
    }

    @RequestMapping(value = APIConstant.UNITPOWERLOADINFO,method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object unitPowerLoadInfo(@RequestBody Map<String,Object> receiveMap){
        Map<String,Object> resultMap = new HashMap<>();
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoService.findGroupIdProTyStatus(String.valueOf(receiveMap.get("devsignature")));
        List<realValueList1> realValueList1List = new ArrayList<>();
        /*if (DevUtils.compareIsDay(String.valueOf(receiveMap.get("date")),new Date())){
            String dateStr = DevUtils.compareDayToDayTime1(String.valueOf(receiveMap.get("date")));
            String endStr = DevUtils.nextDayTime(dateStr);
            realValueList1List = findDayDevInfo(tblndeviceinfo.getDevidpk(),dateStr,PageConstant.NODESTR,simpleDateFormat2.format(new Date()),PageConstant.ROWS);
        }else {*/
            String dateStr = DevUtils.compareDayToDayTime1(String.valueOf(receiveMap.get("date")));
            String endDateStr = DevUtils.nextDayTime(dateStr);
            realValueList1List = findDayDevInfo(tblndeviceinfo.getDevidpk(),dateStr,PageConstant.NODESTR,endDateStr,PageConstant.ROWS);
        //}
        List<UnitElePowerDetailInfo> unitElePowerDetailInfoList = new ArrayList<>();
        for (Integer i = 0;i<realValueList1List.get(0).getRowsSize();i++) {
            Integer j = 0;
            UnitElePowerDetailInfo unitElePowerDetailInfo = new UnitElePowerDetailInfo();
            try {
                unitElePowerDetailInfo.setDate(simpleDateFormat.parse(realValueList1List.get(j).getRows().get(i).addtime));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            unitElePowerDetailInfo.setDevName(tblndeviceinfo.getInstalllocation());
            if (realValueList1List.get(0).getRowsSize()!=0){
                unitElePowerDetailInfo.setUa(Float.valueOf(realValueList1List.get(0).getRows().get(i).val));
            }
            if (realValueList1List.get(1).getRowsSize()!=0){
                unitElePowerDetailInfo.setUb(Float.valueOf(realValueList1List.get(1).getRows().get(i).val));
            }
            if (realValueList1List.get(2).getRowsSize()!=0){
                unitElePowerDetailInfo.setUc(Float.valueOf(realValueList1List.get(2).getRows().get(i).val));
            }
            if (realValueList1List.get(3).getRowsSize()!=0){
                unitElePowerDetailInfo.setIa(Float.valueOf(realValueList1List.get(3).getRows().get(i).val));
            }
            if (realValueList1List.get(4).getRowsSize()!=0){
                unitElePowerDetailInfo.setIb(Float.valueOf(realValueList1List.get(4).getRows().get(i).val));
            }
            if (realValueList1List.get(5).getRowsSize()!=0){
                unitElePowerDetailInfo.setIc(Float.valueOf(realValueList1List.get(5).getRows().get(i).val));
            }

            /**
             * 描述 功率因数为0 相应的有功功率无功功率不参与运算
             */

            Float p = 0F;
            Float q = 0F;
            if (realValueList1List.get(15).getRowsSize()!=0){
                //the = the + Float.valueOf(realValueList1List.get(15).getRows().get(i).val);
                if (realValueList1List.get(6).getRowsSize()!=0){
                    p = p + Float.valueOf(realValueList1List.get(6).getRows().get(i).val);
                }
                if (realValueList1List.get(9).getRowsSize()!=0){
                    q = q + Float.valueOf(realValueList1List.get(9).getRows().get(i).val);
                }
            }
            if (realValueList1List.get(16).getRowsSize()!=0){
                //the = the + Float.valueOf(realValueList1List.get(16).getRows().get(i).val);
                if (realValueList1List.get(7).getRowsSize()!=0){
                    p = p + Float.valueOf(realValueList1List.get(7).getRows().get(i).val);
                }
                if (realValueList1List.get(10).getRowsSize()!=0){
                    q = q + Float.valueOf(realValueList1List.get(10).getRows().get(i).val);
                }
            }
            if (realValueList1List.get(17).getRowsSize()!=0){
                //the = the + Float.valueOf(realValueList1List.get(17).getRows().get(i).val);
                if (realValueList1List.get(8).getRowsSize()!=0){
                    p = p + Float.valueOf(realValueList1List.get(8).getRows().get(i).val);
                }
                if (realValueList1List.get(11).getRowsSize()!=0){
                    q = q + Float.valueOf(realValueList1List.get(11).getRows().get(i).val);
                }
            }
            unitElePowerDetailInfo.setP(p);
            unitElePowerDetailInfo.setQ(q);

            Float pv = 0F;
            if (realValueList1List.get(12).getRowsSize()!=0){
                pv = pv + Float.valueOf(realValueList1List.get(12).getRows().get(i).val);
            }
            if (realValueList1List.get(13).getRowsSize()!=0){
                pv = pv + Float.valueOf(realValueList1List.get(13).getRows().get(i).val);
            }
            if (realValueList1List.get(14).getRowsSize()!=0){
                pv = pv + Float.valueOf(realValueList1List.get(14).getRows().get(i).val);
            }
            unitElePowerDetailInfo.setPv(pv);
            //Float the = 0F;
            /**/
            Double totalNum = Math.sqrt(unitElePowerDetailInfo.getP()*unitElePowerDetailInfo.getP()+unitElePowerDetailInfo.getQ()*unitElePowerDetailInfo.getQ());
            if (totalNum==0){
                unitElePowerDetailInfo.setThe(0D);
            }else {
                unitElePowerDetailInfo.setThe(unitElePowerDetailInfo.getP()/totalNum);
            }
            unitElePowerDetailInfoList.add(unitElePowerDetailInfo);
            //集合翻转
            //Collections.reverse(unitElePowerDetailInfoList);
            Collections.sort(unitElePowerDetailInfoList, new Comparator<UnitElePowerDetailInfo>() {
                @Override
                public int compare(UnitElePowerDetailInfo o1, UnitElePowerDetailInfo o2) {
                    //降序
                    return o2.getDate().compareTo(o1.getDate());
                }
            });
        }
        resultMap.put("list",unitElePowerDetailInfoList);
        resultMap.put("size",unitElePowerDetailInfoList.size());
        return renderResult(resultMap);
    }

    @RequestMapping(value=APIConstant.UNITLOOKPOINTRUNDATA)
    public Object unitLookpointRunDataNew(@RequestBody HashMap<String, Object> receiveMap){
        UserInfo userInfo = this.getUserInfo();
        String date = "2020-01-01";
        Map<String,Object> resultMap = new HashMap<>();
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        List<UnitDevRunDataInfo> unitDevRunDataInfoList = new ArrayList<>();
        List<HbyOverLookPoint> hbyOverlookpointList = hbyOverlookpointService.findLookPointInfo(Integer.parseInt(String.valueOf(receiveMap.get("unitId")))
                ,page,size,date,Integer.parseInt(String.valueOf(receiveMap.get("groupId"))));
        if (("".equals(receiveMap.get("lookPointId")))||(receiveMap.get("lookPointId")==null)){
            for (HbyOverLookPoint hbyOverlookpoint: hbyOverlookpointList) {
                Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(hbyOverlookpoint.getUnitId());
                if (hbyOverlookpoint.getPointType()==0){

                }else {
                    List<HbyOverlookJoin> hbyOverlookJoinList = hbyOverlookJoinService.finddevIdinfo(hbyOverlookpoint.getId());
                    for (HbyOverlookJoin hbyOverlookJoin : hbyOverlookJoinList) {
                        UnitDevRunDataInfo unitDevRunDataInfo = new UnitDevRunDataInfo();
                        unitDevRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                        unitDevRunDataInfo.setTime(simpleDateFormat.format(hbyOverlookpoint.getCreateTime()));
                        unitDevRunDataInfo.setArea(hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(), tblnprojectinfo.getProcitycode(), tblnprojectinfo.getProareacode(),userInfo.getPlatformId()).getAgcyName());
                        unitDevRunDataInfo.setUnitName(tblnprojectinfo.getProjname());
                        unitDevRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                        unitDevRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                        unitDevRunDataInfo.setPollsNum(tblndeviceinfoService.findLocation(hbyOverlookJoin.getPollDevId()));
                        unitDevRunDataInfo.setPollsPower(Float.valueOf(hbyOverlookpoint.getPollDevPowerSillVal()));
                        List<realValueByNode1> realValueByNode1List = findRealTimeInfo(hbyOverlookJoin.getPollDevId(), "PA-PB-PC",
                                PageConstant.BEGINDATETIME, simpleDateFormat2.format(new Date()));
                        unitDevRunDataInfo.setPollsReal(Float.parseFloat(realValueByNode1List.get(0).getVal()) + Float.parseFloat(realValueByNode1List.get(1).getVal()) + Float.parseFloat(realValueByNode1List.get(2).getVal()));

                        unitDevRunDataInfo.setConsNum(tblndeviceinfoService.findLocation(hbyOverlookJoin.getConDevId()));
                        unitDevRunDataInfo.setConsPower(Float.valueOf(hbyOverlookpoint.getConDevEleSillVal()));
                        List<realValueByNode1> realValueByNode1ListCon = findRealTimeInfo(hbyOverlookJoin.getConDevId(), "PA-PB-PC",
                                PageConstant.BEGINDATETIME, simpleDateFormat2.format(new Date()));
                        unitDevRunDataInfo.setConsReal(Float.parseFloat(realValueByNode1ListCon.get(0).getVal()) + Float.parseFloat(realValueByNode1ListCon.get(1).getVal()) + Float.parseFloat(realValueByNode1ListCon.get(2).getVal()));
                        unitDevRunDataInfo.setReducePlan(hbyReduceplanJoinProjectService.checkReducePlan(hbyOverlookpoint.getUnitId()));
                        unitDevRunDataInfoList.add(unitDevRunDataInfo);
                    }
                }
                Collections.reverse(unitDevRunDataInfoList);
            }
            if ((page-1)*size>unitDevRunDataInfoList.size()){
                return renderResult(false,-1,"无更多数据");
            }else {
                List<UnitDevRunDataInfo> unitDevRunDataInfos = new LinkedList<>();
                if (unitDevRunDataInfoList.size()>page*size){
                    for (Integer i = (page-1)*size; i <page*size ; i++){
                        unitDevRunDataInfos.add(unitDevRunDataInfoList.get(i));
                    }
                }else {
                    for (Integer i = (page-1)*size; i <unitDevRunDataInfoList.size() ; i++) {
                        unitDevRunDataInfos.add(unitDevRunDataInfoList.get(i));
                    }
                }
                resultMap.put("list",unitDevRunDataInfos);
                resultMap.put("pageNum",page);
                resultMap.put("pageSize",unitDevRunDataInfos.size());
                resultMap.put("total",unitDevRunDataInfoList.size());
                if (unitDevRunDataInfoList.size()%size==0){
                    resultMap.put("totalPage",unitDevRunDataInfoList.size()/size);
                }else {
                    resultMap.put("totalPage",(unitDevRunDataInfoList.size()/size)+1);
                }
                return renderResult(resultMap);
            }
        }else {
            Long lookId = Long.valueOf(String.valueOf(receiveMap.get("lookPointId")));
            HbyOverLookPoint hbyOverlookpoint = hbyOverlookpointService.findOverLookPoint(lookId);
            if (hbyOverlookpoint==null){
                return renderResult(false,-1,"该监测点已删除");
            }else {
                Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(hbyOverlookpoint.getUnitId());
                if (hbyOverlookpoint.getPointType()==0){

                }else {
                    List<HbyOverlookJoin> hbyOverlookJoinList = hbyOverlookJoinService.finddevIdinfo(hbyOverlookpoint.getId());
                    for (HbyOverlookJoin hbyOverlookJoin : hbyOverlookJoinList) {
                        UnitDevRunDataInfo unitDevRunDataInfo = new UnitDevRunDataInfo();

                        unitDevRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                        unitDevRunDataInfo.setTime(simpleDateFormat.format(hbyOverlookpoint.getCreateTime()));
                        unitDevRunDataInfo.setArea(hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(), tblnprojectinfo.getProcitycode(), tblnprojectinfo.getProareacode(), userInfo.getPlatformId()).getAgcyName());
                        unitDevRunDataInfo.setUnitName(tblnprojectinfo.getProjname());
                        unitDevRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                        unitDevRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                        unitDevRunDataInfo.setPollsNum(tblndeviceinfoService.findLocation(hbyOverlookJoin.getPollDevId()));
                        unitDevRunDataInfo.setPollsPower(Float.valueOf(hbyOverlookpoint.getPollDevPower()));
                        List<realValueByNode1> realValueByNode1List = findRealTimeInfo(hbyOverlookJoin.getPollDevId(), "PA-PB-PC",
                                PageConstant.BEGINDATETIME, simpleDateFormat2.format(new Date()));
                        unitDevRunDataInfo.setPollsReal(Float.parseFloat(realValueByNode1List.get(0).getVal()) + Float.parseFloat(realValueByNode1List.get(1).getVal()) + Float.parseFloat(realValueByNode1List.get(2).getVal()));

                        unitDevRunDataInfo.setConsNum(tblndeviceinfoService.findLocation(hbyOverlookJoin.getConDevId()));
                        unitDevRunDataInfo.setConsPower(Float.valueOf(hbyOverlookpoint.getConDevPower()));
                        List<realValueByNode1> realValueByNode1ListCon = findRealTimeInfo(hbyOverlookJoin.getConDevId(), "PA-PB-PC",
                                PageConstant.BEGINDATETIME, simpleDateFormat2.format(new Date()));
                        unitDevRunDataInfo.setConsReal(Float.parseFloat(realValueByNode1ListCon.get(0).getVal()) + Float.parseFloat(realValueByNode1ListCon.get(1).getVal()) + Float.parseFloat(realValueByNode1ListCon.get(2).getVal()));
                        unitDevRunDataInfo.setReducePlan(hbyReduceplanJoinProjectService.checkReducePlan(hbyOverlookpoint.getUnitId()));
                        unitDevRunDataInfoList.add(unitDevRunDataInfo);
                    }
                }

/*                resultMap.put("pageNum",page);
                resultMap.put("pageSize",unitDevRunDataInfoList.size());
                resultMap.put("total",unitDevRunDataInfoList.size());
                if (unitDevRunDataInfoList.size()>page*size){
                    resultMap.put("totalPage",unitDevRunDataInfoList.size()/size);
                }else {
                    resultMap.put("totalPage",(unitDevRunDataInfoList.size()/size)+1);
                }*/


                List<UnitDevRunDataInfo> unitDevRunDataInfos = new ArrayList<>();
                if (unitDevRunDataInfoList.size() > page * size) {
                    for (int i = size * (page - 1); i < size * page; i++) {
                        unitDevRunDataInfos.add(unitDevRunDataInfoList.get(i));
                    }
                } else {
                    for (int i = size * (page - 1); i < unitDevRunDataInfoList.size(); i++) {
                        unitDevRunDataInfos.add(unitDevRunDataInfoList.get(i));
                    }
                }
                resultMap.put("pageNum", page);
                resultMap.put("pageSize", unitDevRunDataInfos.size());
                resultMap.put("total", unitDevRunDataInfoList.size());
                if (unitDevRunDataInfoList.size() % size == 0) {
                    resultMap.put("totalPage", unitDevRunDataInfoList.size() / size);
                } else {
                    resultMap.put("totalPage", (unitDevRunDataInfoList.size() / size) + 1);
                }
                resultMap.put("list",unitDevRunDataInfos);

                return renderResult(resultMap);
            }
        }
    }

    @RequestMapping(value=APIConstant.UNITLOOKPOINTRUNDATACOUNTDEV)
    public Object unitLookpointRunDataCountDev(@RequestBody HashMap<String, Object> receiveMap){
        String date = "2020-01-01";
        Map<String,Object> resultMap = new HashMap<>();
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        List<UnitLookPointRunDataInfo> unitLookPointRunDataInfoList = new ArrayList<>();
        List<HbyOverLookPoint> hbyOverlookpointList = hbyOverlookpointService.findLookPointInfo(Integer.parseInt(String.valueOf(receiveMap.get("unitId")))
                ,page,size,date,Integer.parseInt(String.valueOf(receiveMap.get("groupId"))));
        if (("".equals(receiveMap.get("lookPointId")))||(receiveMap.get("lookPointId")==null)){
            for (HbyOverLookPoint hbyOverlookpoint: hbyOverlookpointList) {
                if (hbyOverlookpoint.getPointType()==0){
                    UnitLookPointRunDataInfo unitLookPointRunDataInfo = new UnitLookPointRunDataInfo();
                    unitLookPointRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                    unitLookPointRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                    unitLookPointRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                    unitLookPointRunDataInfo.setPollsNum(0);
                    unitLookPointRunDataInfo.setConsNum(0);
                    unitLookPointRunDataInfo.setLookPointType(0);
                    unitLookPointRunDataInfoList.add(unitLookPointRunDataInfo);
                }else {
                    UnitLookPointRunDataInfo unitLookPointRunDataInfo = new UnitLookPointRunDataInfo();
                    unitLookPointRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                    unitLookPointRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                    unitLookPointRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                    unitLookPointRunDataInfo.setPollsNum(hbyOverlookDevJoinService.findPollsNumByLookPointId(hbyOverlookpoint.getId()).size());
                    unitLookPointRunDataInfo.setConsNum(hbyOverlookDevJoinService.findConsNumByLookPointId(hbyOverlookpoint.getId()).size());
                    unitLookPointRunDataInfo.setLookPointType(1);
                    unitLookPointRunDataInfoList.add(unitLookPointRunDataInfo);

                }
                Collections.reverse(unitLookPointRunDataInfoList);
            }
            if ((page-1)*size>unitLookPointRunDataInfoList.size()){
                return renderResult(false,-1,"无更多数据");
            }else {
                List<UnitLookPointRunDataInfo> unitLookPointRunDataInfos = new ArrayList<>();
                if (unitLookPointRunDataInfoList.size()>page*size){
                    for (Integer i = (page-1)*size; i <page*size ; i++){
                        unitLookPointRunDataInfos.add(unitLookPointRunDataInfoList.get(i));
                    }
                }else {
                    for (Integer i = (page-1)*size; i <unitLookPointRunDataInfoList.size() ; i++) {
                        unitLookPointRunDataInfos.add(unitLookPointRunDataInfoList.get(i));
                    }
                }
                resultMap.put("list",unitLookPointRunDataInfos);
                resultMap.put("pageNum",page);
                resultMap.put("pageSize",unitLookPointRunDataInfos.size());
                resultMap.put("total",unitLookPointRunDataInfoList.size());
                if (unitLookPointRunDataInfoList.size()%size==0){
                    resultMap.put("totalPage",unitLookPointRunDataInfoList.size()/size);
                }else {
                    resultMap.put("totalPage",(unitLookPointRunDataInfoList.size()/size)+1);
                }
                return renderResult(resultMap);
            }
        }else {
            Long lookId = Long.valueOf(String.valueOf(receiveMap.get("lookPointId")));
            HbyOverLookPoint hbyOverlookpoint = hbyOverlookpointService.findOverLookPoint(lookId);
            if (hbyOverlookpoint==null){
                return renderResult(false,-1,"该监测点已删除");
            }else {
                if (hbyOverlookpoint.getPointType()==0){
                    UnitLookPointRunDataInfo unitLookPointRunDataInfo = new UnitLookPointRunDataInfo();
                    unitLookPointRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                    unitLookPointRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                    unitLookPointRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                    unitLookPointRunDataInfo.setPollsNum(0);
                    unitLookPointRunDataInfo.setConsNum(0);
                    unitLookPointRunDataInfo.setLookPointType(0);
                    unitLookPointRunDataInfoList.add(unitLookPointRunDataInfo);
                }else {
                    UnitLookPointRunDataInfo unitLookPointRunDataInfo = new UnitLookPointRunDataInfo();
                    unitLookPointRunDataInfo.setGroupName(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
                    unitLookPointRunDataInfo.setLookPointId(hbyOverlookpoint.getId());
                    unitLookPointRunDataInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
                    unitLookPointRunDataInfo.setPollsNum(hbyOverlookDevJoinService.findPollsNumByLookPointId(hbyOverlookpoint.getId()).size());
                    unitLookPointRunDataInfo.setConsNum(hbyOverlookDevJoinService.findConsNumByLookPointId(hbyOverlookpoint.getId()).size());
                    unitLookPointRunDataInfo.setLookPointType(1);
                    unitLookPointRunDataInfoList.add(unitLookPointRunDataInfo);
                }
                List<UnitLookPointRunDataInfo> unitDevRunDataInfos = new ArrayList<>();
                if (unitLookPointRunDataInfoList.size() > page * size) {
                    for (int i = size * (page - 1); i < size * page; i++) {
                        unitDevRunDataInfos.add(unitLookPointRunDataInfoList.get(i));
                    }
                } else {
                    for (int i = size * (page - 1); i < unitLookPointRunDataInfoList.size(); i++) {
                        unitDevRunDataInfos.add(unitLookPointRunDataInfoList.get(i));
                    }
                }
                resultMap.put("pageNum", page);
                resultMap.put("pageSize", unitDevRunDataInfos.size());
                resultMap.put("total", unitLookPointRunDataInfoList.size());
                if (unitLookPointRunDataInfoList.size() % size == 0) {
                    resultMap.put("totalPage", unitLookPointRunDataInfoList.size() / size);
                } else {
                    resultMap.put("totalPage", (unitLookPointRunDataInfoList.size() / size) + 1);
                }
                resultMap.put("list",unitDevRunDataInfos);

                return renderResult(resultMap);
            }
        }
    }

    @RequestMapping(value = APIConstant.DEVREALDATAINFO,method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object devRealDataInfo(@RequestBody Map<String,Object> receiveMap){
        Integer unitId = Integer.parseInt(String.valueOf(receiveMap.get("unitId")));
        List<Integer> devIdPkList = hbyOverlookpointPlusMapper.findTotalDevIdByUnitId(unitId);
        if (devIdPkList.size()==0){
            UnitRealTimeData unitRealTimeData = new UnitRealTimeData();
            unitRealTimeData.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(unitId).getProjname());
            unitRealTimeData.setUnitStatus(hbyProjectstatusService.findAllByUnitId(unitId,-1).getProducState());
            return renderResult(unitRealTimeData);
        }else {
            UnitRealTimeData unitRealTimeData = new UnitRealTimeData();
            Integer devId = devIdPkList.get(0);
            unitRealTimeData.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(unitId).getProjname());
            unitRealTimeData.setUnitStatus(hbyProjectstatusService.findAllByUnitId(unitId,-1).getProducState());
            List<realValueByNode1> realValueByNode1List = findRealTimeInfo(devIdPkList.get(0),"Va-Vb-Vc-Ia-Ib-Ic",PageConstant.BEGINTIME, simpleDateFormat2.format(new Date()));
            unitRealTimeData.setVoltA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(0).val)).setScale(1, RoundingMode.DOWN))));
            unitRealTimeData.setVoltB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(1).val)).setScale(1, RoundingMode.DOWN))));
            unitRealTimeData.setVoltC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(2).val)).setScale(1, RoundingMode.DOWN))));
            unitRealTimeData.setCurrentA(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(3).val)).setScale(1, RoundingMode.DOWN))));
            unitRealTimeData.setCurrentB(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(4).val)).setScale(1, RoundingMode.DOWN))));
            unitRealTimeData.setCurrentC(Float.valueOf(String.valueOf(new BigDecimal(Float.valueOf(realValueByNode1List.get(5).val)).setScale(1, RoundingMode.DOWN))));
            return renderResult(unitRealTimeData);
        }

    }

    /**
     * 在node节点集合中，通节点名称找出对应的节点Id
     * @param tblndevicenodeinfoList
     * @param node
     * @return
     */
    private Integer findeNodeIdPk(List<Tblndevicenodeinfo> tblndevicenodeinfoList,String node){
        Integer nodeIdPk = 0;

        for (Tblndevicenodeinfo tblndevicenodeinfo:tblndevicenodeinfoList ) {
            if (tblndevicenodeinfo.getDevnode1().equals(node)){
                nodeIdPk = tblndevicenodeinfo.getPkid();
            }else {
                continue;
            }
        }
        return nodeIdPk;
    }

    /**
     * 传入拼出的node节点
     * 设备编号
     * 在hbase中查出节点对应的实时数据
     * @param devIdpk
     * @param nodeStr
     * @return List<realValueByNode1>
     *
     */
    public List<realValueByNode1> findRealTimeInfo(Integer devIdpk, String nodeStr,String beginTime,String endTime){

        if ("".equals(nodeStr)){
            //如果节点字符串为空
            //不修改实时默认值
            List<realValueByNode1> list = new ArrayList<>();
            return list;
        }else {


            //通过调用HbaseUtil中的方法查出对应的实时信息
            List<realValueByNode1> realValueByNode1s = HbaseUtil.GetMaxSingleArrayByFilter(devIdpk+"", beginTime, endTime,nodeStr);

            return  realValueByNode1s;
        }
    }

    /**
     * 设备日运行
     * @param devIdpk
     * @param beginTime
     * @param nodeStr
     * @param endTime
     * @param rows
     * @return
     */
    public List<realValueList1> findDayDevInfo(Integer devIdpk, String beginTime,String nodeStr, String endTime, String rows){
        return HbaseUtil.GetListArrayByFilter(devIdpk+"", beginTime, endTime,nodeStr,rows);
    }

    /**
     * 功率
     * @param devIdpk
     * @param beginTime
     * @param endTime
     * @param rows
     * @return
     */
    public List<realValueList1> findDayDevPInfo(Integer devIdpk, String beginTime, String endTime, String rows){
        return HbaseUtil.GetListArrayByFilter(devIdpk+"", beginTime, endTime,"PA-PB-PC",rows);
    }

    /**
     * 传入一个当前的时间，转换出对应当前时间段的运行工况
     * @param date
     * @param devId
     * @return
     */
    public Integer getRunStatusByDayTime(Date date, Integer devId){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        int hourOfDay = date.getHours();
        int minuteOfHour = date.getMinutes();

        //判断更新哪一个时区的数据
        String filed = "H" + hourOfDay + "_" + this.timeArea(minuteOfHour);

        Date beforeDay = null;
        try {
            beforeDay = simpleDateFormat.parse(simpleDateFormat.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        long lt = new Long(beforeDay.getTime()+24*60*60*1000);
        Date afterDate = new Date(lt);
        String sql = "SELECT "+filed+" FROM hby_deval_time_status WHERE devIdpk = "+devId+" AND addtime BETWEEN "+"\'"+simpleDateFormat1.format(beforeDay)+"\'"+" AND "+"\'"+simpleDateFormat1.format(afterDate)+"\'";
        List<String> reslist = hbyDevalTimeStatusMapper.findDevStatus(sql);
        System.out.println(reslist);
        if ((reslist.size()==0)||(reslist==null)||reslist.get(0)==null){
            return 0;
        }else {
            return Integer.parseInt(reslist.get(0));
        }

    }

    /**
     * 判断时间区间的方法
     *
     * @param minuteOfHour:当前时间所在小时的分钟值
     * @author haosw
     */
    private String timeArea(int minuteOfHour) {
        if (minuteOfHour >= ScheduleConstant.TIME_AREA_0 && minuteOfHour < ScheduleConstant.TIME_AREA_20) {
            return "1";
        } else if (minuteOfHour >= ScheduleConstant.TIME_AREA_20 && minuteOfHour < ScheduleConstant.TIME_AREA_40) {
            return "2";
        } else {
            return "3";
        }
    }
}
