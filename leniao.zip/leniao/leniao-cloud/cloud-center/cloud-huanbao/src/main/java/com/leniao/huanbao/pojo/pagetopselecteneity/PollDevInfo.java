package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/23 17:12
 * @update
 * @description
 */
public class PollDevInfo {

    //产污设备额定功率
    private String pollDevPower;
    //产污设备功率启停阈值
    private String pollDevPowerSillVal;
    //产污设备功率门限时间
    private String pollDevPowerLiveTime;
    //产污设备电量阈值
    private String pollDevEleSillVal;
    //产污设备电量门限时间
    private String pollDevEleLiveTime;
    //产污设备分类
    private String pollDevType;

    @Override
    public String toString() {
        return "PollDevInfo{" +
                "pollDevPower='" + pollDevPower + '\'' +
                ", pollDevPowerSillVal='" + pollDevPowerSillVal + '\'' +
                ", pollDevPowerLiveTime='" + pollDevPowerLiveTime + '\'' +
                ", pollDevEleSillVal='" + pollDevEleSillVal + '\'' +
                ", pollDevEleLiveTime='" + pollDevEleLiveTime + '\'' +
                ", pollDevType='" + pollDevType + '\'' +
                '}';
    }

    public String getPollDevPower() {
        return pollDevPower;
    }

    public void setPollDevPower(String pollDevPower) {
        this.pollDevPower = pollDevPower;
    }

    public String getPollDevPowerSillVal() {
        return pollDevPowerSillVal;
    }

    public void setPollDevPowerSillVal(String pollDevPowerSillVal) {
        this.pollDevPowerSillVal = pollDevPowerSillVal;
    }

    public String getPollDevPowerLiveTime() {
        return pollDevPowerLiveTime;
    }

    public void setPollDevPowerLiveTime(String pollDevPowerLiveTime) {
        this.pollDevPowerLiveTime = pollDevPowerLiveTime;
    }

    public String getPollDevEleSillVal() {
        return pollDevEleSillVal;
    }

    public void setPollDevEleSillVal(String pollDevEleSillVal) {
        this.pollDevEleSillVal = pollDevEleSillVal;
    }

    public String getPollDevEleLiveTime() {
        return pollDevEleLiveTime;
    }

    public void setPollDevEleLiveTime(String pollDevEleLiveTime) {
        this.pollDevEleLiveTime = pollDevEleLiveTime;
    }

    public String getPollDevType() {
        return pollDevType;
    }

    public void setPollDevType(String pollDevType) {
        this.pollDevType = pollDevType;
    }
}
