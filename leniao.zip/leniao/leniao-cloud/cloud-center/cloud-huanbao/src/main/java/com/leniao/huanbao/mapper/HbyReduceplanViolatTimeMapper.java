package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyReduceplanViolatTime;
import com.leniao.huanbao.entity.HbyReduceplanViolatTimeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyReduceplanViolatTimeMapper extends BaseMapper<HbyReduceplanViolatTime> {
    int countByExample(HbyReduceplanViolatTimeExample example);

    int deleteByExample(HbyReduceplanViolatTimeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyReduceplanViolatTime record);

    int insertSelective(HbyReduceplanViolatTime record);

    List<HbyReduceplanViolatTime> selectByExample(HbyReduceplanViolatTimeExample example);

    HbyReduceplanViolatTime selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyReduceplanViolatTime record, @Param("example") HbyReduceplanViolatTimeExample example);

    int updateByExample(@Param("record") HbyReduceplanViolatTime record, @Param("example") HbyReduceplanViolatTimeExample example);

    int updateByPrimaryKeySelective(HbyReduceplanViolatTime record);

    int updateByPrimaryKey(HbyReduceplanViolatTime record);
}