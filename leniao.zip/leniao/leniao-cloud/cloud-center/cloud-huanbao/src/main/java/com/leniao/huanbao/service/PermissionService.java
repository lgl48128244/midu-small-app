package com.leniao.huanbao.service;

import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;

import java.util.List;
import java.util.Map;

public interface PermissionService {
    /**
     * 查询当前用户可见的单位
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return
     */
    List<TreeMenu> selectCanShowProjectByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params);

    /**
     * 查询当前用户可见的单位
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return
     */
    List<TreeMenu> selectCanShowProjectByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, HbyAgency agency, Map<String, Object> params);

    /**
     * 查询当前用户可见的单位 -----------------------------------------------------修改---------------------------------------------------
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return
     */
    List<TreeMenu> selectCanShowProjectByUserId2(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, HbyAgency agency, Map<String, Object> params,Integer platformId);

    /**
     * 查询用户所在区域的区域码，必须是区域用户，否则结果为null
     * @param userId 用户id
     * @return 用户所在区域的区域码
     */
    AreaCodeJoinOther selectAreaCodeByUserId(Integer userId);

    /**
     * 查询用户可见的所有机构
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行政机构id agencyId,key值严格要求相同
     * @return
     */
    List<TreeMenu> selectCanShowAgencyByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params);

    /**
     * 查询用户可见的所有机构 -------------------------------------------------修改--------------------------------------------------------
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行政机构id agencyId,key值严格要求相同
     * @return
     */
    List<TreeMenu> selectCanShowAgencyByUserId2(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params);

    /**
     * 检测用户是否有权限查询、操作该单位
     *
     * @param userId
     * @param projId
     * @return -1-无权限，0-被分享或下级单位（查询权），1-自己创建或权限组成员创建或区域用户管辖的单位（查询、操作权限）
     */
    Integer checkPermission(Integer userId, Integer projId);

    /**
     * 查询机构和单位
     * @param userId 用户id
     * @param params showAll 0
     * @return
     */
    List<TreeMenu> selectCanShowAgencyAndProjectByUser(Integer userId, Map<String, Object> params);
}
