package com.leniao.huanbao.utils;


import com.leniao.huanbao.mapper.HbyDevalTimeStatusMapper;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/25 19:03
 * @update
 * @description
 */
public class DevUtils {

    @Resource
    private HbyDevalTimeStatusMapper hbyDevalTimeStatusMapper;

    /**
     * 输入年月判断有多少天
     */
    public static Integer haveManyDay(Integer year,Integer month){
        Integer day = 31;
        switch(month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                day =  31;
            break;//每一个case后需要添加break跳出switch语句
            case 2:
                if ((((year%4)==0)&&((year%100)!= 0))||((year%400)==0)) {
                    day = 29;
                } else {
                    day = 28;
                }
                break;//此处break如果省略，将继续向下执行，一直到遇到break为止或者是switch语句结束
            case 4:
            case 6:
            case 9:
            case 11:
                day = 30;
            break;
            default:
                day = 31;
            //break;//default可以省略、此处的break也可以省略
        }
        return day;
    }

    /**
     * 集合去重
     */
    public static List removeDuplicate(List list) {
        HashSet h = new HashSet(list);
        list.clear();
        list.addAll(h);
        return list;
    }

    /**
     * 传入实时值，和阈值 判断大小，小于阈值返回0 大于阈值返回1
     */
    public static String compareRealValue(String realVal,String paraVal){

            Float real = Float.parseFloat(realVal);
            Float para = Float.parseFloat(paraVal);

            if (real<=para){
                return "0";
            }else{
                return "1";
            }

    }

    /**
     * 判断一个时间是否属于当天
     */
    public static boolean compareIsDay(String dayString,Date date){

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date day = format.parse(dayString);
            Long dayBefore = day.getTime();
            Long dayAfter = day.getTime()+24*60*60*1000;
            Long dayDate = date.getTime();
            return (dayBefore<=dayDate)&&(dayDate<=dayAfter);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 把日期转换为日期时间格式
     * @param dayString
     * @return
     */
    public static String compareDayToDayTime(String dayString){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date = simpleDateFormat.parse(dayString);
            Long dayDate = date.getTime()+24*60*60*1000;
            return simpleDateFormat1.format(new Date(dayDate));
        } catch (ParseException e) {
            e.printStackTrace();
            return simpleDateFormat1.format(new Date());
        }

    }

    /**
     * 传入日期计算出当天最后时间并返回
     * @param dayString
     * @return
     */
    public static String nextDayTime(String dayString){
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss");
        try {
            Date date = simpleDateFormat1.parse(dayString);
            Long dayDate = date.getTime()+24*60*60*1000;
            return simpleDateFormat1.format(dayDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return simpleDateFormat1.format(new Date());
        }
    }

    /**
     * 把日期yyyy-MM-dd转换为yyyyMMddHHmmss
     * @param dayString
     * @return
     */
    public static String compareDayToDayTime1(String dayString){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss");
        try {
            Date date = simpleDateFormat.parse(dayString);
            return simpleDateFormat1.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return simpleDateFormat1.format(new Date());
        }
    }

    /**
     * 两个list取重复
     * @param list1
     * @param list2
     * @return boolean
     */
    public static boolean getRepetition(List<String> list1, List<String> list2) {
        List<String> result = new ArrayList<>();
        for (String str : list2) {
            if (list1.contains(str)) {
                result.add(str);
            }
        }
        if (result.size()==0){
            return true;
        }else {
            return false;
        }
    }

}
