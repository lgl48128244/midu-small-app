package com.leniao.huanbao.schedule;

import com.alibaba.fastjson.annotation.JSONField;
import com.leniao.commons.AbstractOperation;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.huanbao.schedule.Device24hWorkDetailSchedule;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.context.annotation.Profile;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.text.DecimalFormat;

/**
 * 补充24小时工况的接口
 *
 * @author haosw
 */
//@Profile("DEV")
@Slf4j
@RestController
@Validated
@RequestMapping("/devDetail")
public class Device24hWorkDetailController extends BaseController {

    @Resource
    private Device24hWorkDetailSchedule device24hWorkDetailSchedule;

    @RequestMapping(value = "/updateByHour")
    public Object addWorkDetailsByHour(@NotBlank(message = "添加时间不能为空") @RequestParam String addtime,
                                       @Max(value = 23, message = "小时最大23") @Min(value = 0, message = "小时最小0") @RequestParam Integer hour) {
        long start = System.currentTimeMillis();
        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");
        DateTime time = DateTime.parse(addtime);
        DateTime toRunTime = time.withTime(hour, 0, 0, 0);

        try {
            for (int i = 0; i < 3; i++) {
                toRunTime = toRunTime.plusMinutes(20);
                if (toRunTime.isAfter(DateTime.now())) {
                    break;
                }
                device24hWorkDetailSchedule.run(toRunTime.toDate());
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new CloudException(CloudErrorCode.BIZ_EXCEPTION);
        }
        long end = System.currentTimeMillis();
        double with = BigDecimalUtils.calculate(end - start).div(1000).div(60).getBigDecimal().doubleValue();
        return renderResult(new DecimalFormat("#.00").format(with));
    }


    /**
     * 根据日期和小时数更新当天的数据
     * @param addtime
     * @param hour
     * @return
     */
    @RequestMapping(value = "/updateByDayStartFromHour")
    public Object addWorkDetailsByDay(@NotBlank(message = "添加时间不能为空") @RequestParam String addtime, @RequestParam Integer hour) {
        long start = System.currentTimeMillis();
        if (hour == null || hour < 0 || hour > 23) {
            hour = 0;
        }
        int length = 72 - hour * 3;
        try {
            DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");
            DateTime time = DateTime.parse(addtime);
            DateTime toRunTime = time.withTime(hour, 0, 0, 0);
            for (int i = 0; i < length; i++) {
                toRunTime = toRunTime.plusMinutes(20);
                //增加不能超过当前时间的判断
                if (toRunTime.isAfter(DateTime.now())) {
                    break;
                }
                device24hWorkDetailSchedule.run(toRunTime.toDate());
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new CloudException(CloudErrorCode.BIZ_EXCEPTION);
        }
        long end = System.currentTimeMillis();
        double with = BigDecimalUtils.calculate(end - start).div(1000).div(60).getBigDecimal().doubleValue();
        return renderResult(new DecimalFormat("#.00").format(with));
    }


}
