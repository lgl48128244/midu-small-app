package com.leniao.huanbao.service;

import com.leniao.huanbao.entity.Tblngroup;

import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 17:51
 * @update
 */
public interface TblngroupService {
    /**
     * 通过设备分组id找出分组名称
     */
    String findGroupName(Integer groupId);

    /**
     * 通过单位id，找出对应的单位下的分组名称以及分组ID
     */
    List<Tblngroup> findGroupIdName(Integer unitId);
}
