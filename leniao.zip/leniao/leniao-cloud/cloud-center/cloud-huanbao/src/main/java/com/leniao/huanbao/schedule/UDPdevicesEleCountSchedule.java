package com.leniao.huanbao.schedule;

import com.leniao.commons.util.HbaseUtil;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.commons.util.thrift.realValueByNode1;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.schedule.udpbean.WebResult;
import com.leniao.huanbao.service.UDPdeviceEleCountService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@Component
@Slf4j
//@Profile("DEV")
public class UDPdevicesEleCountSchedule {


    @Resource
    private UDPdeviceEleCountService udPdeviceEleCountService;

    @Scheduled(cron = "0 0/13 * * * ?")
    protected void count() {
        //获取监测点中的udp设备
        List<Integer> devIdpkList = this.udPdeviceEleCountService.findAllUdpDeviceInOverLookPoint();
        if (CollectionUtils.isEmpty(devIdpkList)) {
            log.error("本次查询没有UDP的监测点设备");
            return;
        }
        DateTime sevenDayAgo = DateTime.now().minusDays(7);
        for (Integer devIdpk : devIdpkList) {
            try {
                //获取最新的一条电量数据
                List<realValueByNode1> maxSingleArrayByFilter = HbaseUtil.GetMaxSingleArrayByFilter(devIdpk.toString(),
                        sevenDayAgo.toString("yyyyMMddHHmmss"),
                        DateTime.now().toString("yyyyMMddHHmmss"),
                        ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY);
                double eleUse = 0;
                String addtime = DateTime.now().toString("yyyy-MM-dd HH:mm:ss");
                for (realValueByNode1 realValueByNode1 : maxSingleArrayByFilter) {
                    if (!realValueByNode1.getAddtime().startsWith("1200-01-01")) {
                        eleUse = BigDecimalUtils.calculate(eleUse).add(realValueByNode1.getVal()).getBigDecimal().doubleValue();
                        addtime = realValueByNode1.getAddtime();
                    }
                }
                int multip = (eleUse + "").length() - (eleUse + "").indexOf(".") - 1;
                int intEleUse = BigDecimalUtils.calculate(multip * 10).multiply(eleUse).getBigDecimal().intValue();
                WebResult webResult = this.udPdeviceEleCountService.saveDevicePower_v20191214(devIdpk, intEleUse, addtime, multip * 10);
                //log.error(webResult.toString());

            } catch (Exception e) {
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~计算UDP设备电量异常~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                log.error(e.getMessage(), e);
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                e.printStackTrace();
            }
        }

    }


}
