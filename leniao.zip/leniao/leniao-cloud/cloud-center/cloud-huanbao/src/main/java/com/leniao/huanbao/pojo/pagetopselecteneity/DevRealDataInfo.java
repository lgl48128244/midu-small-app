package com.leniao.huanbao.pojo.pagetopselecteneity;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author liudongshuai
 * @date 2019/12/26 9:36
 * @update
 * @description
 */
public class DevRealDataInfo {
    //单位名称
    private String unitName;
    //设备安装位置
    private String devLocation = "";
    //设备状态
    private String workStatus;
    //数据更新时间
    private String updateTime;
    //A相电压
    private Float voltA = 0f;
    //A相电压状态
    private String voltAStatus = "0";
    //B相电压
    private Float voltB = 0f;
    //B相电压状态
    private String voltBStatus = "0";
    //C相电压
    private Float voltC = 0f;
    //C相电压状态
    private String voltCStatus = "0";
    //A相电流
    private Float currentA =  0f;
    //A相电流状态
    private String currentAStatus = "0";
    //B相电流
    private Float currentB =  0f;
    //B相电流状态
    private String currentBStatus = "0";
    //C相电流
    private Float currentC =  0f;
    //C相电流状态
    private String currentCStatus = "0";
    //有功电能
    private Float powerEle =  0f;
    //有功电能状态
    private String powerEleStatus = "0";
    //总功有功功率
    private Float powerOn =  0f;
    //总共功率状态
    private String powerOnStatus = "0";
    //总共无功功率
    private Float powerOut =  0f;
    //总共无功功率状态
    private String powerOutStatus = "0";
    //总功功率因数
    private Double powerCount =  0D;
    //总功功率因数状态
    private String powerCountStatus = "0";
    //A相有功功率
    private Float powerOnA = 0f;
    //A相有功功率状态
    private String powerOnAStatus = "0";
    //B相有功功率
    private Float powerOnB =  0f;
    //B相有功功率状态
    private String powerOnBStatus = "0";
    //C相有功功率
    private Float powerOnC =  0f;
    //C相有功功率状态
    private String powerOnCStatus = "0";
    //A相无功功率
    private Float powerOutA = 0f;
    //A相无功功率状态
    private String powerOutAStatus = "0";
    //B相无功功率
    private Float powerOutB =  0f;
    //B相无功功率状态
    private String powerOutBStatus = "0";
    //C相无功功率
    private Float powerOutC =  0f;
    //C相无功功率状态
    private String powerOutCStatus = "0";
    //A相线电压
    private Float voltLineA =  0f;
    //A相线电压状态
    private String voltLineAStatus = "0";
    //B相线电压
    private Float voltLineB =  0f;
    //B相线电压状态
    private String voltLineBStatus = "0";
    //C相线电压
    private Float voltLineC =  0f;
    //C相线电压状态
    private String voltLineCStatus = "0";

    @Override
    public String toString() {
        return "DevRealDataInfo{" +
                "unitName='" + unitName + '\'' +
                ", devLocation='" + devLocation + '\'' +
                ", workStatus='" + workStatus + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", voltA=" + voltA +
                ", voltAStatus='" + voltAStatus + '\'' +
                ", voltB=" + voltB +
                ", voltBStatus='" + voltBStatus + '\'' +
                ", voltC=" + voltC +
                ", voltCStatus='" + voltCStatus + '\'' +
                ", currentA=" + currentA +
                ", currentAStatus='" + currentAStatus + '\'' +
                ", currentB=" + currentB +
                ", currentBStatus='" + currentBStatus + '\'' +
                ", currentC=" + currentC +
                ", currentCStatus='" + currentCStatus + '\'' +
                ", powerEle=" + powerEle +
                ", powerEleStatus='" + powerEleStatus + '\'' +
                ", powerOn=" + powerOn +
                ", powerOnStatus='" + powerOnStatus + '\'' +
                ", powerOut=" + powerOut +
                ", powerOutStatus='" + powerOutStatus + '\'' +
                ", powerCount=" + powerCount +
                ", powerCountStatus='" + powerCountStatus + '\'' +
                ", powerOnA=" + powerOnA +
                ", powerOnAStatus='" + powerOnAStatus + '\'' +
                ", powerOnB=" + powerOnB +
                ", powerOnBStatus='" + powerOnBStatus + '\'' +
                ", powerOnC=" + powerOnC +
                ", powerOnCStatus='" + powerOnCStatus + '\'' +
                ", powerOutA=" + powerOutA +
                ", powerOutAStatus='" + powerOutAStatus + '\'' +
                ", powerOutB=" + powerOutB +
                ", powerOutBStatus='" + powerOutBStatus + '\'' +
                ", powerOutC=" + powerOutC +
                ", powerOutCStatus='" + powerOutCStatus + '\'' +
                ", voltLineA=" + voltLineA +
                ", voltLineAStatus='" + voltLineAStatus + '\'' +
                ", voltLineB=" + voltLineB +
                ", voltLineBStatus='" + voltLineBStatus + '\'' +
                ", voltLineC=" + voltLineC +
                ", voltLineCStatus='" + voltLineCStatus + '\'' +
                '}';
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getDevLocation() {
        return devLocation;
    }

    public void setDevLocation(String devLocation) {
        this.devLocation = devLocation;
    }

    public String getWorkStatus() {
        return workStatus;
    }

    public void setWorkStatus(String workStatus) {
        this.workStatus = workStatus;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public Float getVoltA() {
        return voltA;
    }

    public void setVoltA(Float voltA) {
        this.voltA = voltA;
    }

    public String getVoltAStatus() {
        return voltAStatus;
    }

    public void setVoltAStatus(String voltAStatus) {
        this.voltAStatus = voltAStatus;
    }

    public Float getVoltB() {
        return voltB;
    }

    public void setVoltB(Float voltB) {
        this.voltB = voltB;
    }

    public String getVoltBStatus() {
        return voltBStatus;
    }

    public void setVoltBStatus(String voltBStatus) {
        this.voltBStatus = voltBStatus;
    }

    public Float getVoltC() {
        return voltC;
    }

    public void setVoltC(Float voltC) {
        this.voltC = voltC;
    }

    public String getVoltCStatus() {
        return voltCStatus;
    }

    public void setVoltCStatus(String voltCStatus) {
        this.voltCStatus = voltCStatus;
    }

    public Float getCurrentA() {
        return currentA;
    }

    public void setCurrentA(Float currentA) {
        this.currentA = currentA;
    }

    public String getCurrentAStatus() {
        return currentAStatus;
    }

    public void setCurrentAStatus(String currentAStatus) {
        this.currentAStatus = currentAStatus;
    }

    public Float getCurrentB() {
        return currentB;
    }

    public void setCurrentB(Float currentB) {
        this.currentB = currentB;
    }

    public String getCurrentBStatus() {
        return currentBStatus;
    }

    public void setCurrentBStatus(String currentBStatus) {
        this.currentBStatus = currentBStatus;
    }

    public Float getCurrentC() {
        return currentC;
    }

    public void setCurrentC(Float currentC) {
        this.currentC = currentC;
    }

    public String getCurrentCStatus() {
        return currentCStatus;
    }

    public void setCurrentCStatus(String currentCStatus) {
        this.currentCStatus = currentCStatus;
    }

    public Float getPowerEle() {
        return powerEle;
    }

    public void setPowerEle(Float powerEle) {
        this.powerEle = Float.valueOf(String.valueOf(new BigDecimal(powerEle).setScale(1, RoundingMode.DOWN)));
    }

    public String getPowerEleStatus() {
        return powerEleStatus;
    }

    public void setPowerEleStatus(String powerEleStatus) {
        this.powerEleStatus = powerEleStatus;
    }

    public Float getPowerOn() {
        return powerOn;
    }

    public void setPowerOn(Float powerOn) {
        this.powerOn = powerOn;
    }

    public String getPowerOnStatus() {
        return powerOnStatus;
    }

    public void setPowerOnStatus(String powerOnStatus) {
        this.powerOnStatus = powerOnStatus;
    }

    public Float getPowerOut() {
        return powerOut;
    }

    public void setPowerOut(Float powerOut) {
        this.powerOut = powerOut;
    }

    public String getPowerOutStatus() {
        return powerOutStatus;
    }

    public void setPowerOutStatus(String powerOutStatus) {
        this.powerOutStatus = powerOutStatus;
    }

    public Double getPowerCount() {
        return powerCount;
    }

    public void setPowerCount(Double powerCount) {
        this.powerCount = Double.valueOf(String.valueOf(new BigDecimal(powerCount).setScale(1, RoundingMode.DOWN)));
    }

    public String getPowerCountStatus() {
        return powerCountStatus;
    }

    public void setPowerCountStatus(String powerCountStatus) {
        this.powerCountStatus = powerCountStatus;
    }

    public Float getPowerOnA() {
        return powerOnA;
    }

    public void setPowerOnA(Float powerOnA) {
        this.powerOnA = powerOnA;
    }

    public String getPowerOnAStatus() {
        return powerOnAStatus;
    }

    public void setPowerOnAStatus(String powerOnAStatus) {
        this.powerOnAStatus = powerOnAStatus;
    }

    public Float getPowerOnB() {
        return powerOnB;
    }

    public void setPowerOnB(Float powerOnB) {
        this.powerOnB = powerOnB;
    }

    public String getPowerOnBStatus() {
        return powerOnBStatus;
    }

    public void setPowerOnBStatus(String powerOnBStatus) {
        this.powerOnBStatus = powerOnBStatus;
    }

    public Float getPowerOnC() {
        return powerOnC;
    }

    public void setPowerOnC(Float powerOnC) {
        this.powerOnC = powerOnC;
    }

    public String getPowerOnCStatus() {
        return powerOnCStatus;
    }

    public void setPowerOnCStatus(String powerOnCStatus) {
        this.powerOnCStatus = powerOnCStatus;
    }

    public Float getPowerOutA() {
        return powerOutA;
    }

    public void setPowerOutA(Float powerOutA) {
        this.powerOutA = powerOutA;
    }

    public String getPowerOutAStatus() {
        return powerOutAStatus;
    }

    public void setPowerOutAStatus(String powerOutAStatus) {
        this.powerOutAStatus = powerOutAStatus;
    }

    public Float getPowerOutB() {
        return powerOutB;
    }

    public void setPowerOutB(Float powerOutB) {
        this.powerOutB = powerOutB;
    }

    public String getPowerOutBStatus() {
        return powerOutBStatus;
    }

    public void setPowerOutBStatus(String powerOutBStatus) {
        this.powerOutBStatus = powerOutBStatus;
    }

    public Float getPowerOutC() {
        return powerOutC;
    }

    public void setPowerOutC(Float powerOutC) {
        this.powerOutC = powerOutC;
    }

    public String getPowerOutCStatus() {
        return powerOutCStatus;
    }

    public void setPowerOutCStatus(String powerOutCStatus) {
        this.powerOutCStatus = powerOutCStatus;
    }

    public Float getVoltLineA() {
        return voltLineA;
    }

    public void setVoltLineA(Float voltLineA) {
        this.voltLineA = voltLineA;
    }

    public String getVoltLineAStatus() {
        return voltLineAStatus;
    }

    public void setVoltLineAStatus(String voltLineAStatus) {
        this.voltLineAStatus = voltLineAStatus;
    }

    public Float getVoltLineB() {
        return voltLineB;
    }

    public void setVoltLineB(Float voltLineB) {
        this.voltLineB = voltLineB;
    }

    public String getVoltLineBStatus() {
        return voltLineBStatus;
    }

    public void setVoltLineBStatus(String voltLineBStatus) {
        this.voltLineBStatus = voltLineBStatus;
    }

    public Float getVoltLineC() {
        return voltLineC;
    }

    public void setVoltLineC(Float voltLineC) {
        this.voltLineC = voltLineC;
    }

    public String getVoltLineCStatus() {
        return voltLineCStatus;
    }

    public void setVoltLineCStatus(String voltLineCStatus) {
        this.voltLineCStatus = voltLineCStatus;
    }
}
