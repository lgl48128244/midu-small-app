package com.leniao.huanbao.service;


import com.leniao.huanbao.entity.Areaprovince;

import java.util.List;

public interface AreaprovinceService {

    /**
     * 显示出所有省份
     */

    List<Areaprovince> findAllProvince();
}
