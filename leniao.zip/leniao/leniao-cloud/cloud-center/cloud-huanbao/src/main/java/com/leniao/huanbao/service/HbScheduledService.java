package com.leniao.huanbao.service;

import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.dto.schedule.OverLookPointWithDevlist;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import org.joda.time.DateTime;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

public interface HbScheduledService {


    /**
     * @description: 查询监测点以及监测点中的设备集合
     * @author: haosw
     * @date: 2019/12/20 15:45
     */
    List<OverLookPointWithDevlist> findOverLookPointsWithDevlist();

    /**
     * @description: 根据时间获取设备的实时功率数据 (PA-PB-PC)
     * @author: haosw
     * @param: sBeginTime: 开始时间, eEndTime:结束时间, devIdpk:设备主键Id
     * @return: 指定时间段内设备的功率数据包
     * @date: 2019/12/21 9:14
     */
    List<realValueList1> getDataPackagesOfTimeArea(DateTime sBeginTime, DateTime eEndTime, Integer devIdpk);

    /**
     * @description: 根据时间获取设备的实时功率数据 (PA-PB-PC)
     * @author: haosw
     * @param: sBeginTime: 开始时间, eEndTime:结束时间, devIdpk:设备主键Id
     * @return: 指定时间段内设备的功率数据包
     * @date: 2019/12/21 9:14
     */
    List<realValueList1> getDataPackagesMuchOfTimeArea(DateTime sBeginTime, DateTime eEndTime, Integer devIdpk);

    /**
     * @description: 根据设备的功率数据包, 计算平均功率值
     * @author: haosw
     * @param: 实时数据集合
     * @return: 实时数据包中所有数据的平均值
     * @date: 2019/12/21 10:54
     */
    double getAvgPower(List<realValueList1> dataPackages, Integer devIdpk);

    /**
     * @description: 判断设备的工况状态, 1:运行,2:低负荷,3:停机  0:不满足前三者任意条件,属于逻辑漏洞 -> 0 改为4 失联
     * @author: haosw
     * @param: devSillVal:设备的阈值(启停功率阈值,额定功率阈值,电量阈值...), avgVlaue:阈值对应的设备的实时数据平均值
     * @return: 设备的状态state:
     * @date: 2019/12/21 11:45
     */
    int countJudgeDevWorkStatus(Integer devSillVal, double avgValue, Integer devPower);

    /**
     * @description: 更新或新增设备工况
     * @author: haosw
     * @param: now:上一个时间区间的结束时间点, dev:设备的基本信息, sBeginTime:上一个时间区间的开始时间
     * @return: void
     * @date: 2019/12/21 13:58
     * TODO 后期需要优化成批量操作
     */
    //void updateOrInsertWorkStatus(Date beforEndTime, DevDto dev, DateTime sBeginTime, int state);
    void updateOrInsertWorkStatus(DateTime beforEndTime, DevDto dev, int state);

    /**
     * @description: 更新或插入单位的基本信息数据到单位实时信息表
     * @author: haosw
     * @param: 单位基本信息数据, 包含了单位Id, 单位名称, 单位平台, 单位区域码
     * @return: void
     * @date: 2019/12/23 13:55
     */
    void updateOrInsertUnitInfo(List<UnitBasicInfoDto> unitBasicInfoDtoList);

    /**
     * @description: 查询环保云异常表中已在原119异常表中不存在异常数据
     * @author: haosw
     * @param:
     * @return: 已经自动恢复正常的异常数据
     * @date: 2019/12/26 14:08
     */
    List<HbyProjectErrorInfo> findHasBeenNormalErrInfo();

    /**
     * @description:
     * @author: haosw
     * @param: Hby产治污设备异常数据集合
     * @return:
     * @date: 2019/12/26 14:40
     */
    void updateHbyErrorDealStatus(List<HbyProjectErrorInfo> errorInfos);

    /**
     * 产治污设备的电量异常处理接口
     *
     * @param frontTimeArea 需要进行判断时间区间(单前时间的上一个区间)
     * @param lookPoint
     * @param devDto
     * @param //devProTy      1:产污, 2:治污
     * @author: haosw
     */
    void executeCatchLookPointDevEleErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto devDto) throws Exception;

    /**
     * @description: 处理治污设备电量异常
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/8 13:27
     */
    //void catchPollDevEleErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto devDto);

    /**
     * @description: 治污设备电量异常判断处理
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/8 14:41
     */
    //void catchConDevEleErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto conDev);

    /**
     * 产治污设备的功率异常,治污设备停机异常,停限产异常
     *
     * @param frontTimeArea
     * @param lookPoint
     * @param devDto
     * @param devProTy
     */
    void executeCatchLookPointDevPowerErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto devDto, Integer devProTy, boolean isConRun);

    /**
     * 获取单位关联的为启用状态的减产减排方案(缓存)
     *
     * @param unitId
     * @return
     */
    HbyReduceEmmissionPlan findReduceEmmPlanByUnitId(Integer unitId);

    /**
     * 保存或修改一条停产异常
     *
     * @param dev
     * @param plan
     * @param stopProErrChargeDto
     */
    void saveOrUpdateStopProPlanErr(DevDto dev, HbyReduceEmmissionPlan plan, HbyErrorDto.StopProErrChargeDto stopProErrChargeDto);

    /**
     * @description: 获取单位和减排方案的关联数据
     * @author: haosw
     * @param:
     * @return:
     * @date: 2019/12/31 17:08
     */
    HbyReduceplanJoinProject findReducePlanJoinUnitByUnitId(Integer unitId);


    /**
     * @description: 新增或修改一个限产异常
     * @author: haosw
     * @param:
     * @return:
     * @date: 2019/12/31 19:06
     */
    void saveOrUpdateLimitProPlanErr(DevDto dev, HbyReduceEmmissionPlan plan, double hourSum);

    /**
     * @description: 获取产污和治污设备的当前时间的用的量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 16:26
     */
    HashMap<String, Object> getPollAndConDevEleQ(Integer unitId, Date now);

    /**
     * @description: 缓存总检测点设备的用电量和功率的峰值
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/6 11:35
     */
    void executeCachRootPointDevEleAndPower(DateTime[] frontTimeArea, DevDto devDto) throws Exception;


    /**
     * @description:    方法的作用描述
     * @author:         haosw
     * @param:          year：年  monthOfYear：月
     * @return:
     * @date:           2020/1/8 17:25
     */
    List<HashMap<String, Object>> findUnitCurrentMonthEleUse(int year, int monthOfYear);

    /**
     * 获取有需要推送的异常
     * @param unitId
     * @return
     */
    List<HashMap<String, Object>> findErrSimpInfoList(Integer unitId);

    /**
     * 批量更新异常为推送状态
     * @param errIds
     */
    void updateErrInfoIsPush(List<Long> errIds);


    /**
     * 获取单位总表设备当天最大电量及时间
     * @param unitId
     * @return
     */
    HbyErrorDto.EleMaxDto  findMaxEleUseOfUnitOneDay(Integer unitId);

    HbyErrorDto.PowerMaxDto getMaxPower(List<realValueList1> powerList);
}
