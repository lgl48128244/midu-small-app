package com.leniao.huanbao.pojo.pagetopselecteneity;

import com.leniao.model.devlist.CountUnitAnalysisInfo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

/**
 * @author liudongshuai
 * @date 2020/1/16 15:54
 * @update
 */
public class UnitElePowerDetailInfo implements Comparable<UnitElePowerDetailInfo>{
    //设备名称=设备安装位置
    private String devName;
    //时间
    private Date date;
    //A相电压
    private Float Ua = 0f;
    //B相电压
    private Float Ub = 0f;
    //C相电压
    private Float Uc = 0f;
    //A相电流
    private Float Ia = 0f;
    //B相电流
    private Float Ib = 0f;
    //C相电流
    private Float Ic = 0f;
    //有相功率
    private Float P = 0f;
    //无相功率
    private Float Q = 0f;
    //功率
    private Float Pv = 0f;
    //功率因数
    private Double the = 0D;

    @Override
    public int compareTo(UnitElePowerDetailInfo o) {
        return this.date.compareTo(o.getDate());
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Float getUa() {
        return Ua;
    }

    public void setUa(Float ua) {
        Ua = Float.valueOf(String.valueOf(new BigDecimal(ua).setScale(1, RoundingMode.DOWN)));
    }

    public Float getUb() {
        return Ub;
    }

    public void setUb(Float ub) {
        Ub = Float.valueOf(String.valueOf(new BigDecimal(ub).setScale(1, RoundingMode.DOWN)));
    }

    public Float getUc() {
        return Uc;
    }

    public void setUc(Float uc) {
        Uc = Float.valueOf(String.valueOf(new BigDecimal(uc).setScale(1, RoundingMode.DOWN)));
    }

    public Float getIa() {
        return Ia;
    }

    public void setIa(Float ia) {
        Ia = Float.valueOf(String.valueOf(new BigDecimal(ia).setScale(1, RoundingMode.DOWN)));
    }

    public Float getIb() {
        return Ib;
    }

    public void setIb(Float ib) {
        Ib = Float.valueOf(String.valueOf(new BigDecimal(ib).setScale(1, RoundingMode.DOWN)));
    }

    public Float getIc() {
        return Ic;
    }

    public void setIc(Float ic) {
        Ic = Float.valueOf(String.valueOf(new BigDecimal(ic).setScale(1, RoundingMode.DOWN)));
    }

    public Float getP() {
        return P;
    }

    public void setP(Float p) {
        P = Float.valueOf(String.valueOf(new BigDecimal(p).setScale(1, RoundingMode.DOWN)));
    }

    public Float getQ() {
        return Q;
    }

    public void setQ(Float q) {
        Q = Float.valueOf(String.valueOf(new BigDecimal(q).setScale(1, RoundingMode.DOWN)));
    }

    public Float getPv() {
        return Pv;
    }

    public void setPv(Float pv) {
        Pv = Float.valueOf(String.valueOf(new BigDecimal(pv).setScale(1, RoundingMode.DOWN)));
    }

    public Double getThe() {
        return the;
    }

    public void setThe(Double the) {
        this.the = Double.valueOf(String.valueOf(new BigDecimal(the).setScale(1, RoundingMode.DOWN)));
    }
}
