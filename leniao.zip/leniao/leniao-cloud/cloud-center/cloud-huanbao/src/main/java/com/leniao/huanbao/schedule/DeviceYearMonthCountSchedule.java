package com.leniao.huanbao.schedule;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.commons.AbstractOperation;
import com.leniao.entity.HbyMonthAndYearEleCount;
import com.leniao.huanbao.dto.schedule.DeviceEleUseDto;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import com.leniao.service.HbyMonthAndYearEleCountService;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @Description: 统计设备年、月数据的定时任务
 * @Author: haosw
 * @CreateDate: 2020/1/7 10:02
 * @Version: 1.0
 */
@Slf4j
@Component
//@Profile("DEV")
public class DeviceYearMonthCountSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;
    @Resource
    private HbyProjectDayCountinfoService hbyProjectDayCountinfoService;
    @Resource
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;
    @Resource
    private HbyMonthAndYearEleCountService hbyMonthAndYearEleCountService;

    /**
     * @description: 计算设备年月数据的定时任务
     * @author: haosw
     * @date: 2020/1/7 14:03
     */
    @Scheduled(cron = "0 0/30 * * * ?")
    protected void begin() {
        log.info("============================================统计单位月度用电量定时任务开始运行======================================================");
        //获取当前年月
        DateTime now = DateTime.now();
        int year = now.getYear();
        int monthOfYear = now.getMonthOfYear();
        //获取监测点设备的当月用电量
        List<DeviceEleUseDto> eleUseList = this.commonSimpleBeanInfoService.findMonthEleUseOfDevice(year, monthOfYear);
        List<HbyMonthAndYearEleCount> toDbList = new ArrayList<>();
        for (DeviceEleUseDto eleUseDto : eleUseList) {
            //查询设备的月用电量
            HbyMonthAndYearEleCount monthEleCount = this.dealWithMonthEleUse(eleUseDto, year, monthOfYear);
            toDbList.add(monthEleCount);
        }
        this.hbyMonthAndYearEleCountService.saveOrUpdateBatch(toDbList);
        log.info("============================================统计单位月度用电量定时任务运行结束======================================================");
    }

    @Scheduled(cron = "0 0/30 * * * ?")
    protected void start() {
        log.info("============================================统计单位年度用电量定时任务开始运行======================================================");
        //获取当前年月
        DateTime now = DateTime.now();
        int year = now.getYear();
        int monthOfYear = now.getMonthOfYear();
        //获取监测点设备的当月用电量
        List<DeviceEleUseDto> eleUseList = this.commonSimpleBeanInfoService.findMonthEleUseOfDevice(year, 0);
        List<HbyMonthAndYearEleCount> toDbList = new ArrayList<>();
        for (DeviceEleUseDto eleUseDto : eleUseList) {
            //查询设备的月用电量
            try {
                HbyMonthAndYearEleCount monthEleCount = this.dealWithMonthEleUse(eleUseDto, year, 0);
                toDbList.add(monthEleCount);
            } catch (Exception e) {
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~设备年月统计程序异常：~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                log.error(e.getMessage(), e);
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
        }
        if (toDbList.size() > 0) {
            this.hbyMonthAndYearEleCountService.saveOrUpdateBatch(toDbList);
        }
    }

    /**
     * @description: 根据年，月查询并返回设备的年月用电量数据
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/15 14:31
     */
    private HbyMonthAndYearEleCount dealWithMonthEleUse(DeviceEleUseDto eleUseDto, int year, int monthOfYear) {
        QueryWrapper<HbyMonthAndYearEleCount> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyMonthAndYearEleCount::getDevIdpk, eleUseDto.getDevIdpk()).eq(HbyMonthAndYearEleCount::getYear, year)
                .eq(HbyMonthAndYearEleCount::getMonth, monthOfYear);
        HbyMonthAndYearEleCount devMonthEleUse = this.hbyMonthAndYearEleCountService.getOne(queryWrapper);
        if (devMonthEleUse == null) {
            devMonthEleUse = new HbyMonthAndYearEleCount();
            BeanUtils.copyProperties(eleUseDto, devMonthEleUse);
            devMonthEleUse.setYear(year);
            devMonthEleUse.setMonth(monthOfYear);
        }
        devMonthEleUse.setEleTotal(eleUseDto.getTotalQ());
        return devMonthEleUse;
    }


}
