package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.huanbao.entity.Tblnprojectinfo;


import com.leniao.huanbao.mapper.TbprojectInfoPlusMapper;
import com.leniao.huanbao.service.TblnprojectinfoService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/17 9:05
 */

@Service
public class TblnprojectinfoServiceImpl extends ServiceImpl<TbprojectInfoPlusMapper, Tblnprojectinfo> implements TblnprojectinfoService {

    @Resource
    private TbprojectInfoPlusMapper tbprojectInfoPlusMapper;


    /**
     *  通过省市县三级对应的编号，找出所有单位
     * */
    @Override
    public List<Tblnprojectinfo> findUnitInfo(Integer areaId) {

        //创建条件对象
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("projid","projName").lambda().eq(Tblnprojectinfo::getProareacode,areaId);

        List<Tblnprojectinfo> tblnprojectinfoList = tbprojectInfoPlusMapper.selectList(queryWrapper);

        if (tblnprojectinfoList==null){
            List<Tblnprojectinfo> tblnprojectinfo = new ArrayList<>();
            return tblnprojectinfo;
        }else {
            return tblnprojectinfoList;
        }

    }

    /**
     * 通过单位Id查出单位对应的信息
     * 行政区域=省+市+县
     * */
    @Override
    public Tblnprojectinfo findUnitAreaNameInfo(Integer unitId) {
        //创建条件对象
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.lambda().eq(Tblnprojectinfo::getProjid,unitId);

        Tblnprojectinfo tblnprojectinfo = tbprojectInfoPlusMapper.selectOne(queryWrapper);


        return tblnprojectinfo;
    }

    /**
     * 通过省级编号查询出所有的单位id 单位名称 单位行政区域
     * 只有省级，显示第一个单位，为默认
     */
    @Override
    public Page<Map<String,Object>> findDefaultProvinceUnit(String provinceId) {

        /*//创建条件对象
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("proprovince","procity","proarea","projname").lambda().eq(Tblnprojectinfo::getProprovincecode,provinceId);*/

        // 新建分页
        Page<Map<String,Object>> page = new Page<Map<String,Object>>(1, 1);

        // 返回分页结果
        return page.setRecords(this.tbprojectInfoPlusMapper.findDefaultProvinceUnit(page,provinceId));


        /*List<Tblnprojectinfo> tblnprojectinfoList = tblnprojectinfoMapper.selectList(queryWrapper);


        if (tblnprojectinfoList==null){
            List<Tblnprojectinfo> tblnprojectinfos = new ArrayList<>();
            return tblnprojectinfos;
        }else {
            return tblnprojectinfoList;
        }*/

    }

    /**
     * 通过市级编号查询出所有的单位id 单位名称 单位行政区域
     */
    @Override
    public Page<Map<String,Object>> findDefaultCityUnit(String cityId) {
        // 新建分页
        Page<Map<String,Object>> page = new Page<Map<String,Object>>(1, 1);

        // 返回分页结果
        return page.setRecords(this.tbprojectInfoPlusMapper.findDefaultCityUnit(page,cityId));

        /*//创建条件对象
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("proprovince","procity","proarea","projname").lambda().eq(Tblnprojectinfo::getProcitycode,cityId);

        List<Tblnprojectinfo> tblnprojectinfoList = tblnprojectinfoMapper.selectList(queryWrapper);

        if (tblnprojectinfoList==null){
            List<Tblnprojectinfo> tblnprojectinfos = new ArrayList<>();
            return tblnprojectinfos;
        }else {
            return tblnprojectinfoList;
        }*/
    }

    /**
     * 通过县级编号查询出所有的单位id 单位名称 单位行政区域
     */
    @Override
    public Page<Map<String,Object>> findDefaultAreaUnit(String areaId) {

        // 新建分页
        Page<Map<String,Object>> page = new Page<Map<String,Object>>(1, 1);

        // 返回分页结果
        return page.setRecords(this.tbprojectInfoPlusMapper.findDefaultAreaUnit(page,areaId));

    }

    /**
     * 直接找出省级下的单位
     */
    @Override
    public List<Tblnprojectinfo> findProvinceUnit(String provinceId) {
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("projname","projid").lambda().eq(Tblnprojectinfo::getProprovincecode,provinceId);

        List<Tblnprojectinfo> tblnprojectinfoList = tbprojectInfoPlusMapper.selectList(queryWrapper);

        if (tblnprojectinfoList==null){
            List<Tblnprojectinfo> tblnprojectinfos = new ArrayList<>();
            return tblnprojectinfos;
        }else {
            return tblnprojectinfoList;
        }
    }

    /**
     * 直接找出市级下的单位
     */
    @Override
    public List<Tblnprojectinfo> findCityUnit(String cityId) {
        QueryWrapper<Tblnprojectinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("projname","projid").lambda().eq(Tblnprojectinfo::getProcitycode,cityId);

        List<Tblnprojectinfo> tblnprojectinfoList = tbprojectInfoPlusMapper.selectList(queryWrapper);

        if (tblnprojectinfoList==null){
            List<Tblnprojectinfo> tblnprojectinfos = new ArrayList<>();
            return tblnprojectinfos;
        }else {
            return tblnprojectinfoList;
        }
    }

}
