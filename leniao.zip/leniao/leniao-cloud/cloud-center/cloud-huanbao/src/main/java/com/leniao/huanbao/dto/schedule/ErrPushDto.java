package com.leniao.huanbao.dto.schedule;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 需要推送的数据结构
 */
public class ErrPushDto {
/*
    {
        "err": {
                "DevId": 0,  // 设备号
                "DevIdpk": 249083, // 设备主键id
                "ErrList": [  // 报警信息集合
                         {
                            "ErrIsFg": 1, // 报警状态 1-报警 0-恢复
                            "ErrType": 0, // 报警类型 tblnerrordescinfo 表的id
                            "ErrVal": 0, // 报警值
                            "IsSave": 0, // 是否需要保存，0不保存 1保存，写0就行
                            "Node": "0", // 报警的节点 如：Va，Ia
                            "SaveType": 3, // 3-故障，2-隐患， 1-是操作（主要是3和2）
                            "Time": "2020-02-17 18:40:00", // 时间
                            "ValUin": "--", // 单位 V，mA
                            "Xh": 1 // 序号 每次从0开始累加就行，没发现有啥用
                          }
                 ],
                "FaultCount": 1, // 报警集合中故障数量
                "IsDele": 0, // 设备是否删除
                "IsMaskNet": 0, //设备是否被屏蔽 写0就行，不知道是啥
                "Level": 0, // 写0就行
                "OperationCount": 0, // 报警集合中操作类型数量
                "Project": 0, // 写0，没发现是啥
                "R_Id": "0000000000000000000000000000000", // 这个设备的伪地址，独立的设备默认为这一串0
                "Road": 0, // 回路号，独立的设备默认0，写0
                "Sig": "39FFD8054E4E313926880343", // 设备编号
                "TroubleCount": 0, // 集合中隐患数量
                "Type": 304 // 设备型号
                },
        "fgTimeStaple": 1581964800 // 时间戳
    }

*/

    @Data
    public static class PushMsgV2 {
        private Err err;
        private Long fgTimeStaple;
    }

    @Data
    public static class ErrIfon {
        private Integer errIsFg;
        private Integer errType;
        private String errVal;
        private Integer isSave;
        private String node;
        private Integer saveType;
        private String time;
        private String valUin;
        private Integer xh;
    }

    @Data
    public static class Err {
        private Integer devId;
        private Integer devIdpk;
        private List<ErrIfon> errList;
        private Integer faultCount;
        private Integer isDele;
        private Integer isMaskNet;
        private Integer level;
        private Integer operationCount;
        private Integer project;
        private String r_Id;
        private Integer road;
        private String sig;
        private Integer troubleCount;
        private Integer type;
    }

    @Data
    public static class UserConfig {
        private Integer userId;
        private String deviceId;
        private Integer deviceType;
        private Integer isApppush;
        private Integer isWebpush;
    }

    @Data
    public static class WebPushMsg {
        private int projId = 0;
        private int warntotal = 0;
        private int faulttotal = 0;
        private String projName = "";
        private String projLocationX = "";
        private String projLocationY = "";
        private int warncount = 0;
        private int falutcount = 0;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FaultCount {
        private Integer projId;
        private Integer faultcount;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class WarnCount {
        private Integer projId;
        private Integer troublecount;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProjectCoordinate {
        private Integer projId;
        private String projName;
        private String projLocationX;
        private String projLocationY;
    }
}
