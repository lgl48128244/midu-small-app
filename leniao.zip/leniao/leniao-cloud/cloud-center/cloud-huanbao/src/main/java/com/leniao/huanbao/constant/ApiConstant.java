package com.leniao.huanbao.constant;

/**
 * @author guoliang.li
 * @date 2019/12/19 14:26
 * @description TODO 接口常量定义
 */
public interface ApiConstant {

    /**
     * 减产减排接口
     */
    String REDUCE_EMMISSION = "/reduceemmission";

    /**
     * 减产减排方案添加
     */
    String ADD_PLAN = "/plan/insert";

    /**
     * 减产减排方案修改
     */
    String MODIFY_PLAN = "/plan/modify";

    /**
     * 减产减排方案删除
     */
    String DELETE_PLAN = "/plan/delete";

    /**
     * 减产减排方案查询
     */
    String SELECT_PLAN = "/plan/select";

    /**
     * 方案绑定
     */
    String UNBIND_PLAN = "/plan/unbind";

    /**
     * 方案解绑
     */
    String BIND_PLAN = "/plan/bind";

    /**
     * 错峰生产接口
     */
    String PRODUCTION_SITUATION = "/productionsituation";

    /**
     * 查询
     */
    String SELECT_PRODUCTION = "/production/select";

    /**
     * 错峰生产-单位查询
     */
    String SELECT_PROJECT = "/project/select";

    /**
     * 树形菜单接口
     */
    String TREEMENU = "/treemenu";
    String TREEMENU_SELECT = "/select";
    String TREEMENU_SELECT_CHILD = "/selectchild";
    String TREEMENU_SELECT_AGENCY = "/selectagency";
    String TREEMENU_SELECT_PROJECT = "/selectproject";
    String TREEMENU_SELECT_PROJECT2 = "/selectproject2";
    String TREEMENU_SELECT_OVERLOOKPOINT = "/overlookpoint";
    String TREEMENU_SELECT_AGENCY_AND_PROJECT = "/agencyandproj";

    /**
     * 减产减排分析
     */
    String REDUCE_EM_ANALYZE = "reduce";
    String REDUCE_EM_ANALYZE_LIST = "list";
    String REDUCE_EM_ANALYZE_ELECTRIC = "electric";

    /**
     * 能耗统计（企业日统计数据) 行业
     */
    String PROJECT_DAY_COUNTINFO = "countinfo";
    String PEAK_VALUE = "peakvalue";
    String CURVE_CHART = "curvechart";
    String PROJECT_LINK_RELATIVE = "project/linkrelative";
    String PROJECT_ELE_RANKING = "project/ranking";
    String PROJECT_ELE_BARGRAPH = "project/bargraph";
    String INDUSTRY_LINK_RELATIVE = "industry/linkrelative";
    String INDUSTRY_ELE_RANKING = "industry/ranking";
    String INDUSTRY_ELE_BARGRAPH = "industry/bargraph";
    String AGENCY_LINK_RELATIVE = "agency/linkrelative";
    String AGENCY_ELE_RANKING = "agency/ranking";
    String AGENCY_ELE_BARGRAPH = "agency/bargraph";
    String HOME_ELE_BARGRAPH = "home/bargraph";
    String HOME_PLAN_BIND = "home/planbind";

    /**
     * 企业异常接口
     */
    String BUSINESS_EX_PREF = "business";
    String BUSINESS_EX_DETAIL = "/detail";
    String BUSINESS_EX_BATCH = "/batch";
    String BUSINESS_EX_LIST = "/list";
    String BUSINESS_EX_POLL = "/poll";
    /**
     * 查询
     */
    String BUSINESS_EX_SEARCH = "search";
    String BUSINESS_EX_SEARCH_LIST = BUSINESS_EX_SEARCH + BUSINESS_EX_LIST;
    String BUSINESS_EX_SEARCH_DETAIL = BUSINESS_EX_SEARCH + BUSINESS_EX_DETAIL;
    String BUSINESS_EX_SEARCH_POLL_LIST = BUSINESS_EX_SEARCH + BUSINESS_EX_POLL + BUSINESS_EX_LIST;
    /**
     * 处理
     */
    String BUSINESS_EX_HANDLE = "handle";
    String BUSINESS_EX_HANDLE_DETAIL = BUSINESS_EX_HANDLE + BUSINESS_EX_DETAIL;
    String BUSINESS_EX_HANDLE_BATCH = BUSINESS_EX_HANDLE + BUSINESS_EX_BATCH;
    /**
     * 申报
     */
    String BUSINESS_EX_DECLARE = "declare";
    String BUSINESS_EX_DECLARE_DETAIL = BUSINESS_EX_DECLARE + BUSINESS_EX_DETAIL;
    String BUSINESS_EX_DECLARE_BATCH = BUSINESS_EX_DECLARE + BUSINESS_EX_BATCH;
    /**
     * 审核
     */
    String BUSINESS_EX_EXAMINE = "examine";
    String BUSINESS_EX_EXAMINE_DETAIL = BUSINESS_EX_EXAMINE + BUSINESS_EX_DETAIL;
    String BUSINESS_EX_EXAMINE_BATCH_PASS = BUSINESS_EX_EXAMINE + BUSINESS_EX_BATCH;
    String BUSINESS_EX_EXAMINE_BATCH_NOT_PASS = BUSINESS_EX_EXAMINE + BUSINESS_EX_BATCH + "/not/pass";
    /**
     * 滚动展示
     */
    String BUSINESS_EX_ROLLING = "rolling";
    /**
     * 普通用户
     */
    String BUSINESS_EX_ROLLING_NORMAL = BUSINESS_EX_ROLLING + "/normal";
    /**
     * 区域用户
     */
    String BUSINESS_EX_ROLLING_SPECIFY = BUSINESS_EX_ROLLING + "/specify";

    /**
     * 统计
     */
    String BUSINESS_EX_STATISTICS = "statistics";
    String BUSINESS_EX_STATISTICS_AGENCY_LIST = BUSINESS_EX_STATISTICS + "/agency/list";
    String BUSINESS_EX_STATISTICS_INDUSTRY_LIST = BUSINESS_EX_STATISTICS + "/industry/list";
    String BUSINESS_EX_STATISTICS_DEVICE_INFO = BUSINESS_EX_STATISTICS + "/device/info";
    String BUSINESS_EX_STATISTICS_MAX_POWER = BUSINESS_EX_STATISTICS + "/maxPower";
    /**
     * 错峰
     */
    String BUSINESS_EX_CUOFENG_LIST = "cuofeng";
}