package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/23 15:39
 * @update
 * @description
 */
public class DevSysNameIdInfo {
    //设备系统名称
    private String devsysName;
    //设备系统Id
    private String devsysId;

    @Override
    public String toString() {
        return "DevSysNameIdInfo{" +
                "devsysName='" + devsysName + '\'' +
                ", devsysId='" + devsysId + '\'' +
                '}';
    }

    public String getDevsysName() {
        return devsysName;
    }

    public void setDevsysName(String devsysName) {
        this.devsysName = devsysName;
    }

    public String getDevsysId() {
        return devsysId;
    }

    public void setDevsysId(String devsysId) {
        this.devsysId = devsysId;
    }
}
