package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/26 17:46
 * @update
 * @description
 */
public class AddLookPointDevSignInfo {
    //设备编号
    private String signature;
    //设备安装位置
    private String devLocation;

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getDevLocation() {
        return devLocation;
    }

    public void setDevLocation(String devLocation) {
        this.devLocation = devLocation;
    }
}
