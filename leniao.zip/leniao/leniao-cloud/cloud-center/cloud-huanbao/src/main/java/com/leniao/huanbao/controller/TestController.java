package com.leniao.huanbao.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.entity.HbyProjectErrorInfoExample;
import com.leniao.huanbao.service.TestServiceI;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import org.slf4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/17 9:08
 * @description TODO
 */
@RestController
@RequestMapping("/test")
public class TestController extends BaseController {

    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;

    @Resource
    private TestServiceI testService;

    @RequestMapping("/hello")
    public Object hello(String param){
        if (param == null){
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        PageHelper.startPage(1,14);
        HbyProjectErrorInfoExample example = new HbyProjectErrorInfoExample();
        List<HbyProjectErrorInfo> hbyProjectErrorinfos = hbyProjectErrorInfoMapper.selectByExample(example);
        return renderResult(hbyProjectErrorinfos);
    }

    @RequestMapping("/readDataSource")
    public Object readDataSource(Long param){
        return renderResult(testService.getById(param));
    }
    @RequestMapping("/writeDataSource")
    public Object writeDataSource(Long param){
        return renderResult(testService.updateById(param));
    }

    @RequestMapping("/logTest")
    public Object testLogLevel(@RequestBody JSONObject jsonObject){
        Class<? extends Logger> aClass = logger.getClass();
        logger.info(jsonObject.toJSONString());
        logger.debug(jsonObject.toJSONString());
        logger.warn(jsonObject.toJSONString());
        logger.error(jsonObject.toJSONString());
        return renderResult(true);
    }


}