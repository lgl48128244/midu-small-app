package com.leniao.huanbao.dto.alternateproduction;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减产减排方案
 * @author: jiangdy
 * @create: 2019-12-20 17:01
 **/
@Getter
@Setter
@ToString
public class ReduceEmmissionDto {

    /**
     * planId : 方案id
     */
    @JsonSerialize(using=ToStringSerializer.class)
    private Long planId;

    /**
     * planType : 方案类型-1:按时段停产, 2:按小时数限产
     */
    @Min(value = 1, message = "方案类型错误")
    @Max(value = 2, message = "方案类型错误")
    private Integer planType;

    /**
     * warnLevel : 预警等级，1:黄色预警, 2:橙色预警, 3: 红色预警
     */
    @Min(value = 1, message = "预警等级错误")
    @Max(value = 3, message = "预警等级错误")
    private Integer warnLevel;

    /**
     * isUsing : 是否启用 0-否,1-是
     */
    @Min(value = 0, message = "是否启用状态错误")
    @Max(value = 1, message = "是否启用状态错误")
    private Integer isUsing;

    /**
     * limitProducTimeCount : 限产小时数，只有方案类型为2时才有
     */
    private Integer limitProducTimeCount;

    /**
     * planName : 方案名称
     */
    @NotNull(message = "方案名称不能为空")
    private String planName;

    /**
     * remark : 备注信息
     */
    private String remark;

    /**
     * createUser : 创建人ID,当前登录的用户userId
     */
    private Integer createUser;

    /**
     * beginTime : 开始时间-方案生效开始时间
     */
    @NotNull(message = "开始时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date beginTime;

    /**
     * endTime : 结束时间-方案生效结束时间
     */
    @NotNull(message = "结束时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * stopProducTimeList : 停产小时区间集合["09:00-13:00","15:00-20:00"]，只有方案类型为1时才有
     */
    private List<String> stopProducTimeList;

    /**
     * 停产小时区间字符串
     */
    @JSONField(deserialize = false)
    private String stopProducTimeListStr;

    /**
     * 机构名称
     */
    private String agcyName;

    /**
     * 机构ID
     */
    private Integer belongAgency;

    /**
     * 绑定设备数
     */
    private Integer bindUnitCount;

    /**
     * 是否只读权限 0-只读， 1-可读可操作
     */
    private Integer onlyRead;

    /**
     * 已生产小时数
     */
    private int useHour;

    /**
     * 是否违规 0-正常 1-违规
     */
    private int isViolat;

    /**
     * 异常总数
     */
    private int errCount = 0;

    /**
     * 单位名称
     */
    private String projName;

    /**
     * 单位id
     */
    private Integer projId;

    /**
     * 行业id
     */
    private Integer industryId;

    /**
     * 行业名称
     */
    private String industryName;

    /**
     * 平台id
     */
    private Integer platformId;

    public void setStopProducTimeListStr(String stopProducTimeListStr) {
        this.stopProducTimeListStr = stopProducTimeListStr;
        List<String> list = JSON.parseObject(stopProducTimeListStr, List.class);
        this.setStopProducTimeList(list);
    }
}
