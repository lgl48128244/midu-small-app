package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyReduceplanJoinProjectMapper extends BaseMapper<HbyReduceplanJoinProject> {
    long countByExample(HbyReduceplanJoinProjectExample example);

    int deleteByExample(HbyReduceplanJoinProjectExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyReduceplanJoinProject record);

    int insertSelective(HbyReduceplanJoinProject record);

    List<HbyReduceplanJoinProject> selectByExample(HbyReduceplanJoinProjectExample example);

    HbyReduceplanJoinProject selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyReduceplanJoinProject record, @Param("example") HbyReduceplanJoinProjectExample example);

    int updateByExample(@Param("record") HbyReduceplanJoinProject record, @Param("example") HbyReduceplanJoinProjectExample example);

    int updateByPrimaryKeySelective(HbyReduceplanJoinProject record);

    int updateByPrimaryKey(HbyReduceplanJoinProject record);

    int updateBindUnitCount(@Param("planId") Long planId, @Param("count") int count);
}