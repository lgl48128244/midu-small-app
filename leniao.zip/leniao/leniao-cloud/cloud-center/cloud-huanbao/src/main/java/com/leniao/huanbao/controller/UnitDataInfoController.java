package com.leniao.huanbao.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.commons.BaseController;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.Tblnlegalpersoninfo;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.mapper.TbdeviceInfoPlusMapper;
import com.leniao.huanbao.mapper.TbprojectInfoPlusMapper;
import com.leniao.huanbao.pojo.pagetopselecteneity.UnitIndexRealDataInfo;
import com.leniao.huanbao.pojo.pagetopselecteneity.UnitOnOffStopRunInfo;
import com.leniao.huanbao.pojo.pagetopselecteneity.UnitRealDataInfo;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.huanbao.utils.APIConstant;
import com.leniao.huanbao.utils.EntranceConstant;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.*;
import org.checkerframework.checker.units.qual.A;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * @author liudongshuai
 * @date 2019/12/27 15:04
 * @update
 * @description
 */
@CrossOrigin
@RequestMapping(EntranceConstant.UNITDATAINFO)
@RestController
public class    UnitDataInfoController extends BaseController {
    /**
     * 账号用户处理
     */
    @Resource
    private PermissionService permissionService;
    /**
     * 账号树形关系
     */
    @Resource
    private TreeMenuService treeMenuService;
    /**
     * 单位统计信息表
     */
    @Resource
    private HbyProjectstatusService hbyProjectstatusService;
    /**
     * 单位信息表
     */
    @Resource
    private TblnprojectinfoService tblnprojectinfoService;
    @Resource
    private TbprojectInfoPlusMapper tbprojectInfoPlusMapper;
    /**
     * 行业信息表
     */
    @Resource
    private HbyIndustryService hbyIndustryService;
    /**
     * 状态信息表
     */
    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;
    /**
     * 监测点信息表
     */
    @Resource
    private HbyOverLookpointService hbyOverlookpointService;
    /**
     * 单位评分表
     */
    @Resource
    private TblngridGradehistoryService tblngridGradehistoryService;
    /**
     * 单位负责人表
     */
    @Resource
    private TblnlegalpersoninfoService tblnlegalpersoninfoService;
    /**
     * 防火员信息表
     */
    @Resource
    private TblnfireguardinfoService tblnfireguardinfoService;
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    @Resource
    private TbdeviceInfoPlusMapper tbdeviceInfoPlusMapper;
    @Resource
    private HbyAgencyService hbyAgencyService;

    @RequestMapping(value=APIConstant.UNITDEVINFOTOTALCOUNT,method = RequestMethod.POST)
    public Object unitDevInfoTotalCount(@RequestBody HashMap<String, Object> receiveMap){
        Integer userId = Integer.valueOf(String.valueOf(receiveMap.get("userId")));
        Map<String,Object> resultMap = new HashMap<>();
        Integer unitNum = 0;
        Integer pollNum = 0;
        Integer conNum = 0;
        Integer lookPointNum = 0;
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        //List<TreeMenu> menuList = permissionService.selectCanShowAgencyAndProjectByUser(userId,params);

            List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId, areaCodeJoinOther!=null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther), null,params,this.getUserInfo().getPlatformId());
            for (TreeMenu treeMenu:menuList) {
                    HbyProjectstatus hbyProjectstatus = hbyProjectstatusService.findAllByUnitId(Integer.parseInt(String.valueOf(treeMenu.getNodeId())), -1);
                    if (hbyProjectstatus==null){
                        continue;
                    }else {
                        pollNum = pollNum + hbyProjectstatus.getPollDevNum();
                        conNum = conNum + hbyProjectstatus.getConDevNum();
                        unitNum++;
                    }
                    lookPointNum = lookPointNum + hbyOverlookpointService.findLookPointInfo(Integer.parseInt(String.valueOf(treeMenu.getNodeId()))).size();
                }

        resultMap.put("unitNum",unitNum);
        resultMap.put("pollNum",pollNum);
        resultMap.put("conNum",conNum);
        resultMap.put("lookPointNum",lookPointNum);
        return renderResult(resultMap);
    }

    @RequestMapping(value=APIConstant.UNITINDEXINFO,method = RequestMethod.POST)
    public Object unitIndexInfo(@RequestParam("unitId") Integer unitId){
        Map<String,Object> resultMap = new HashMap<>();
        Tblnprojectinfo tblnprojectinfo =  tblnprojectinfoService.findUnitAreaNameInfo(unitId);
        resultMap.put("unitName",tblnprojectinfo.getProjname());
        resultMap.put("location",tblnprojectinfo.getProjlocation());
        resultMap.put("industry",hbyIndustryService.findIndustryNameById(tblnprojectinfo.getIndustryid()));
        resultMap.put("leader",tblnlegalpersoninfoService.findLegalPersonInfo(tblnprojectinfo.getLegalpersonid()));
        resultMap.put("firer",tblnfireguardinfoService.findfireguardInfo(tblnprojectinfo.getFireguardid()));
        List<HbyOverLookPoint> hbyOverLookPointList = hbyOverlookpointService.findLookPointInfo(unitId);
        resultMap.put("lookPointNum",hbyOverLookPointList.size());
        HbyProjectstatus hbyProjectstatus = hbyProjectstatusService.findAllByUnitId(unitId,-1);
            if (hbyProjectstatus==null){
                resultMap.put("pollNum",0);
                resultMap.put("conNum",0);
            }else {
                resultMap.put("pollNum",hbyProjectstatus.getPollDevNum());
                resultMap.put("conNum",hbyProjectstatus.getConDevNum());
            }

        return renderResult(resultMap);
    }

    @RequestMapping(value = APIConstant.UNITCOUNTINFO,method = RequestMethod.POST)
    public Object sendUnitCountInfo(@RequestParam("userId") Integer userId){
        UnitOnOffStopRunInfo unitOnOffStopRunInfo = new UnitOnOffStopRunInfo();
        //在线单位
        Integer onlineUnit = 0;
        //失联单位
        Integer outlineUnit = 0;
        //在线设备
        Integer onlineDev = 0;
        //失联设备
        Integer outlineDev = 0;
        //停机设备
        Integer stopDev = 0;
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);

            List<TreeMenu> menuList= permissionService.selectCanShowProjectByUserId2(userId,
                    areaCodeJoinOther != null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null,params,this.getUserInfo().getPlatformId());
            for (TreeMenu treeMenu:menuList) {
                HbyProjectstatus hbyProjectstatus = hbyProjectstatusService.findAllByUnitId(Integer.parseInt(String.valueOf(treeMenu.getNodeId())),-1);
                if (hbyProjectstatus==null){
                    continue;
                }else {
                    if (hbyProjectstatus.getProducState()==3){
                        outlineUnit++;
                    }else {
                        onlineUnit++;
                    }
                    onlineDev = onlineDev + hbyProjectstatus.getRunDevNum();
                    outlineDev = outlineDev + hbyProjectstatus.getLostDevNum();
                    stopDev = stopDev + hbyProjectstatus.getStopDevNum();
                }
            }
            unitOnOffStopRunInfo.setOnlineUnit(onlineUnit);
            unitOnOffStopRunInfo.setOutlineUnit(outlineUnit);
            unitOnOffStopRunInfo.setOnlineDev(onlineDev);
            unitOnOffStopRunInfo.setOutlineDev(outlineDev);
            unitOnOffStopRunInfo.setStopDev(stopDev);
            return renderResult(unitOnOffStopRunInfo);


    }

    @RequestMapping(value = APIConstant.UNITINDEXMAPINFO,method = RequestMethod.POST)
    public Object unitIndexMapInfo(@RequestParam("userId") Integer userId){
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        List<UnitIndexRealDataInfo> unitIndexRealDataInfoList = new ArrayList<>();
        List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId,areaCodeJoinOther != null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null,params,this.getUserInfo().getPlatformId());
        for (TreeMenu menu:menuList  ) {
            Integer unitId = Integer.parseInt(String.valueOf(menu.getNodeId()));
            UnitIndexRealDataInfo unitIndexRealDataInfo = new UnitIndexRealDataInfo();
            Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
            unitIndexRealDataInfo.setUnitId(unitId);
            unitIndexRealDataInfo.setUnitName(tblnprojectinfo.getProjname());
            unitIndexRealDataInfo.setLocation(tblnprojectinfo.getProjlocation());
            unitIndexRealDataInfo.setLocationX(tblnprojectinfo.getProjlocationx());
            unitIndexRealDataInfo.setLocationY(tblnprojectinfo.getProjlocationy());
            HbyProjectstatus hbyProjectstatus = hbyProjectstatusService.findAllByUnitId(unitId ,-1);
            unitIndexRealDataInfo.setErrStatus(hbyProjectstatus.getIsErrState());
            Tblnlegalpersoninfo tblnlegalpersoninfo = tblnlegalpersoninfoService.findLegalPersonPhoneInfo(tblnprojectinfo.getLegalpersonid());
            unitIndexRealDataInfo.setCreateName(tblnlegalpersoninfo.getLegalpersonname());
            unitIndexRealDataInfo.setCreatePhone(tblnlegalpersoninfo.getLegalpersonphone());
            unitIndexRealDataInfoList.add(unitIndexRealDataInfo);
        }
        return renderResult(unitIndexRealDataInfoList);
    }

    @RequestMapping(value = APIConstant.SENDUNITDATAINFO,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    public Object sendUnitRealInfo(@RequestBody HashMap<String, Object> receiveMap){
        UserInfo userInfo = this.getUserInfo();
        Map<String,Object> resultMap = new HashMap<>();
        Integer userId = Integer.parseInt(String.valueOf(receiveMap.get("userId")));
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        String provinceCode = String.valueOf(receiveMap.get("provinceCode"));
        String cityCode = String.valueOf(receiveMap.get("cityCode"));
        String araeCode = String.valueOf(receiveMap.get("areaCode"));
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        List<UnitRealDataInfo> unitRealDataInfoList = new ArrayList<>();

        String sql = "SELECT DISTINCT " +
                "tblnprojectinfo.projId AS unitId," +
                "tblnprojectinfo.projName AS unitName," +
                "hby_industry.industry_name AS industry," +
                "tblnprojectinfo.projLocation AS location," +
                "tblnprojectinfo.projLocationX AS locationX," +
                "tblnprojectinfo.projLocationY AS locationY, " +
                //"hby_agency.agcy_name AS area," +
                "hby_projectstatus.produc_state AS runStatus," +
                "hby_projectstatus.is_err_state AS errStatus," +
                "hby_projectstatus.poll_dev_num AS pollDevs," +
                "hby_projectstatus.con_dev_num AS conDevs," +
                "hby_projectstatus.run_dev_num AS runDevs," +
                "hby_projectstatus.stop_dev_num AS stopDevs," +
                "hby_projectstatus.lost_dev_num AS lostDevs " +
                "FROM " +
                "tblnprojectinfo,hby_industry,hby_agency,hby_projectstatus " +
                "WHERE " +
                "tblnprojectinfo.industryId = hby_industry.id "+
                "AND tblnprojectinfo.projId = hby_projectstatus.unit_id ";

        if (!"".equals(receiveMap.get("industryId"))){
            sql = sql + " AND hby_industry.id ="+Integer.parseInt(String.valueOf(receiveMap.get("industryId")));
        }
        if (!"".equals(receiveMap.get("runStatus"))){
            sql = sql + " AND hby_projectstatus.produc_state ="+Integer.parseInt(String.valueOf(receiveMap.get("runStatus")));
        }
        if (!"".equals(receiveMap.get("unitId"))){
            sql = sql + " AND tblnprojectinfo.projId="+Integer.parseInt(String.valueOf(receiveMap.get("unitId")));
            List<UnitRealDataInfo> unitRealDataInfoList1  = tbprojectInfoPlusMapper.findUnitStatusList(sql);
            if (unitRealDataInfoList1.size()==0){
            }else {
                unitRealDataInfoList1.get(0).setLookPoints(hbyOverlookpointService.findLookPointInfo(unitRealDataInfoList1.get(0).getUnitId()).size());
                unitRealDataInfoList1.get(0).setUnitGrade((int)(tbdeviceInfoPlusMapper.findUnitGrade(unitRealDataInfoList1.get(0).getUnitId())*100));
                Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(Integer.parseInt(String.valueOf(receiveMap.get("unitId"))));
                HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(), userInfo.getPlatformId());
                if (hbyAgency==null){
                    unitRealDataInfoList1.get(0).setArea("暂无环保局");
                }else {
                    unitRealDataInfoList1.get(0).setArea(hbyAgency.getAgcyName());
                }
                unitRealDataInfoList.add(unitRealDataInfoList1.get(0));
            }
            if ((page-1)*size>unitRealDataInfoList.size()){
                return renderResult(false,-1,"无更多数据");
            }else {
                resultMap.put("list",unitRealDataInfoList);
                resultMap.put("page",1);
                resultMap.put("size",unitRealDataInfoList.size());
                resultMap.put("total",unitRealDataInfoList.size());
                resultMap.put("totalpage",1);
                return renderResult(resultMap);
            }
        }else {

            Integer total = 0;
            List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId,areaCodeJoinOther != null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null,params,this.getUserInfo().getPlatformId());
            List<Integer> unitList = isAgencyUnit(menuList,provinceCode,cityCode,araeCode);
            String sqlsqlsql = sql + " AND tblnprojectinfo.projId IN ( 0 ";
            for (Integer unit:unitList ) {
                sqlsqlsql = sqlsqlsql +  ","+unit ;
            }
            sqlsqlsql =sqlsqlsql +")";
            List<UnitRealDataInfo> unitRealDataInfoList1 = tbprojectInfoPlusMapper.findUnitStatusList(sqlsqlsql);
            for (UnitRealDataInfo unitRealDataInfo:unitRealDataInfoList1 ) {
                unitRealDataInfo.setLookPoints(hbyOverlookpointService.findLookPointInfo(unitRealDataInfo.getUnitId()).size());
                unitRealDataInfo.setUnitGrade((int)(tbdeviceInfoPlusMapper.findUnitGrade(unitRealDataInfo.getUnitId())*100));
                Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitRealDataInfo.getUnitId());
                HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(), userInfo.getPlatformId());
                total++;
                if (hbyAgency==null){
                    unitRealDataInfo.setArea("暂无环保局");
                }else {
                    unitRealDataInfo.setArea(hbyAgency.getAgcyName());
                }
                unitRealDataInfoList.add(unitRealDataInfo);
            }


            List<UnitRealDataInfo> unitRealDataInfos = new ArrayList<>();
            if (unitRealDataInfoList.size()>page*size){
                for (Integer i = (page - 1) * size; i < page * size; i++) {
                    unitRealDataInfos.add(unitRealDataInfoList.get(i));
                }
            }else {
                for (Integer i = (page - 1) * size; i < unitRealDataInfoList.size(); i++) {
                    unitRealDataInfos.add(unitRealDataInfoList.get(i));
                }
            }
            if ((page-1)*size>unitRealDataInfoList.size()){
                return renderResult(false,-1,"别再划了，已经到底了");
            }else {
                resultMap.put("list", unitRealDataInfos);
                resultMap.put("page", page);
                resultMap.put("size", unitRealDataInfos.size());
                resultMap.put("total", total);
                if (unitRealDataInfoList.size()%size==0){
                    resultMap.put("totalPage",unitRealDataInfoList.size()/size);
                }else {
                    resultMap.put("totalPage",(unitRealDataInfoList.size()/size)+1);
                }
                return renderResult(resultMap);
            }

        }
    }

    /**
     * 传入两个参数，生产条件
     * @param obj1
     * @param obj2
     * @return
     */
    public Map<String,Object> isCheckNull(Object obj1,Object obj2){
        Map<String,Object> map = new HashMap<>();
        if(!"".equals(String.valueOf(obj1))){
            map.put("projId",Integer.parseInt(String.valueOf(obj1)));
        }
        if(!"".equals(String.valueOf(obj2))){
            map.put("industryId",Integer.parseInt(String.valueOf(obj1)));
        }
        return map;
    }

    /**
     * 查出属于该行政区域的单位
     * @param treeMenuList
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @return
     */
    public List<Integer> isAgencyUnit(List<TreeMenu> treeMenuList,String provinceCode,String cityCode,String areaCode){
        List<Integer> unitList = new ArrayList<>();
        for (TreeMenu menu:treeMenuList ) {
            Integer unitId = Integer.valueOf(String.valueOf(menu.getNodeId()));
            Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
            if ("000000".equals(provinceCode)|| "".equals(provinceCode)){
                unitList.add(unitId);
            }else {
                if (("000000".equals(cityCode)|| "".equals(cityCode))&&provinceCode.equals(tblnprojectinfo.getProprovincecode())){
                    unitList.add(unitId);
                }else {
                    if (("000000".equals(areaCode)|| "".equals(areaCode))
                            &&(cityCode.equals(tblnprojectinfo.getProcitycode()))
                            &&(provinceCode.equals(tblnprojectinfo.getProprovincecode()))
                    ){
                        unitList.add(unitId);
                    }else {
                        if (areaCode.equals(tblnprojectinfo.getProareacode())
                                &&cityCode.equals(tblnprojectinfo.getProcitycode())
                                &&provinceCode.equals(tblnprojectinfo.getProprovincecode())
                        ){
                            unitList.add(unitId);
                        }else {
                            continue;
                        }
                    }
                }
            }
        }
        return unitList;
    }
}
