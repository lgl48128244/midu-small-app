package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2020/1/3 13:27
 * @update
 * @description
 */
public class DevInfos {

    private String devsignature;

    private String devlocation;

    private Integer status;

    @Override
    public String toString() {
        return "DevInfos{" +
                "devsignature='" + devsignature + '\'' +
                ", devlocation='" + devlocation + '\'' +
                ", status=" + status +
                '}';
    }

    public String getDevlocation() {
        return devlocation;
    }

    public void setDevlocation(String devlocation) {
        this.devlocation = devlocation;
    }

    public String getDevsignature() {
        return devsignature;
    }

    public void setDevsignature(String devsignature) {
        this.devsignature = devsignature;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
