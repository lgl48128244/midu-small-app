package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyOverlookJoin;
import com.leniao.huanbao.entity.HbyOverlookJoinExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyOverlookJoinMapper extends BaseMapper<HbyOverlookJoin> {
    int countByExample(HbyOverlookJoinExample example);

    int deleteByExample(HbyOverlookJoinExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyOverlookJoin record);

    int insertSelective(HbyOverlookJoin record);

    List<HbyOverlookJoin> selectByExample(HbyOverlookJoinExample example);

    HbyOverlookJoin selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyOverlookJoin record, @Param("example") HbyOverlookJoinExample example);

    int updateByExample(@Param("record") HbyOverlookJoin record, @Param("example") HbyOverlookJoinExample example);

    int updateByPrimaryKeySelective(HbyOverlookJoin record);

    int updateByPrimaryKey(HbyOverlookJoin record);
}