package com.leniao.huanbao.service.impl;

import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.DeviceEleUseDto;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.mapper.CommonSimpleBeanInfoMapper;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;

import static com.leniao.model.constant.SpringCacheConstants.*;

@Service
public class CommonSimpleBeanInfoServiceImpl implements CommonSimpleBeanInfoService {

    @Resource
    private CommonSimpleBeanInfoMapper commonSimpleBeanInfoMapper;

    @Override
    //@Cacheable(cacheNames = REDIS_CACHE_1MIN_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public List<DevDto> findDevicesOfOverLookPointByUnitID(Integer unitId) {
        return  this.commonSimpleBeanInfoMapper.findDevicesOfOverLookPointByUnitID(unitId);
    }

    @Override
    public UnitBasicInfoDto findUnitBasicInfoByID(Integer unitId) {
        List<UnitBasicInfoDto> list = this.commonSimpleBeanInfoMapper.findUnitBasicInfoByID(unitId);
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0);
        }
        return null;
    }

    @Override
    //@Cacheable(cacheNames = REDIS_CACHE_1MIN_NAME,keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public List<UnitBasicInfoDto> findAllUnitBasicInfo() {
        return this.commonSimpleBeanInfoMapper.findUnitBasicInfoByID(null);
    }

    @Override
    public List<HbyProjectErrorInfo> findAllOverlookDevErrs(int maxWranId) {
        List<HbyErrorDto.ForwardSyncErrorDto>  list = this.commonSimpleBeanInfoMapper.findAllOverlookDevErrs(maxWranId);
        List<HbyProjectErrorInfo> errorInfos = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(list)) {
           /* IntSummaryStatistics longSummaryStatistics = list.stream().mapToInt(e -> e.getRawErrid()).summaryStatistics();
            maxWranId = longSummaryStatistics.getMax();*/
            //处理异常描述
            list.stream().forEach(err -> {
                StringBuffer sb = new StringBuffer();
                sb.append("设备: ")
                        .append(err.getInstallLocation())
                        .append(" ,在 ")
                        .append(new DateTime(err.getErrorTime()).toString("yyyy-MM-dd HH:mm:ss"))
                        .append(" 产生了 ")
                        .append(err.getErrorDesc())
                        .append(" 报警,报警节点: ")
                        .append(err.getNodeDesc())
                        .append("报警值：" ).append(err.getRawValue()).append(err.getRawUnit());
                err.setErrorDesc(sb.toString());
                HbyProjectErrorInfo errorInfo = new HbyProjectErrorInfo();
                BeanUtils.copyProperties(err,errorInfo);
                //1:企业单位异常 2:用电设备监管异常
                errorInfo.setCheckResult(2);
                errorInfos.add(errorInfo);
            });
        }

        return errorInfos;
    }

    @Override
    public HashMap<String, Object> findUnitEveryErrTypeNum(Integer unitId, Date now) {
        List<HashMap<String, Object>> numList = this.commonSimpleBeanInfoMapper.findUnitEveryErrTypeNum(unitId, now);
        //1:产污设备异常,2:治污设备异常(这两种设备的具体异常可查看同步过来的其他字段), 3:停产异常, 4:限产异常(治污设备没有3,4), 5:电量异常, 6:功率异常,7:治污设备停机异常
        long pollDevErrNum = 0;
        long conDevErrNum = 0;
        long stopProErrNum = 0;
        long limitProErrNum = 0;
        long eleErrNum = 0;
        long powerErrNum = 0;
        long stopDevErrNum = 0;
        for (HashMap<String, Object> item : numList) {
            Object type = item.get("type");
            long num = (long)item.get("num");
            if (type.equals(1)) {
                pollDevErrNum = num;
            }
            if (type.equals(2)) {
                pollDevErrNum = num;
            }
            if (type.equals(3)) {
                pollDevErrNum = num;
            }
            if (type.equals(4)) {
                pollDevErrNum = num;
            }
            if (type.equals(5)) {
                pollDevErrNum = num;
            }
            if (type.equals(6)) {
                pollDevErrNum = num;
            }
            if (type.equals(7)) {
                pollDevErrNum = num;
            }
        }

        HashMap<String, Object> map = new HashMap<>();
        map.put("pollDevErrNum", pollDevErrNum);
        map.put("conDevErrNum", conDevErrNum);
        map.put("stopProErrNum", stopProErrNum);
        map.put("limitProErrNum", limitProErrNum);
        map.put("eleErrNum", eleErrNum);
        map.put("powerErrNum", powerErrNum);
        map.put("stopDevErrNum", stopDevErrNum);
        return map;
    }

    @Override
    public List<DeviceEleUseDto> findMonthEleUseOfDevice(int year, int monthOfYear) {
        return this.commonSimpleBeanInfoMapper.findMonthEleUseOfDevice(year, monthOfYear);
    }
}
