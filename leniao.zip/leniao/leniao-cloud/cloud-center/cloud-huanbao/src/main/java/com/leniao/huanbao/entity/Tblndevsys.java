package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

@TableName("tblndevsys")
@ToString
public class Tblndevsys {
    private Integer devsysid;

    private String devsysname;

    private String remark;

    private Integer isdelete;

    public Integer getDevsysid() {
        return devsysid;
    }

    public void setDevsysid(Integer devsysid) {
        this.devsysid = devsysid;
    }

    public String getDevsysname() {
        return devsysname;
    }

    public void setDevsysname(String devsysname) {
        this.devsysname = devsysname == null ? null : devsysname.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }
}