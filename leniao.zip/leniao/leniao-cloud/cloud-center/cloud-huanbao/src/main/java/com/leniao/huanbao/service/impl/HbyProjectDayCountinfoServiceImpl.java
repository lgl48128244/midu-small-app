package com.leniao.huanbao.service.impl;

import com.alibaba.druid.util.StringUtils;
import com.google.common.collect.Lists;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.huanbao.dto.DeviceDayCountInfo;
import com.leniao.huanbao.dto.ExpendStatistic.ExecuteState;
import com.leniao.huanbao.dto.ExpendStatistic.UseEleRanking;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.entity.UshareDeviceElectricuseExample;
import com.leniao.huanbao.mapper.ProjectDayCountinfoMapper;
import com.leniao.huanbao.service.UshareDeviceElectricuseService;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import org.joda.time.Chronology;
import org.joda.time.DateTime;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.commons.util.HbaseUtil;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyOverLookDevJoinExample;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.entity.HbyProjectDayCountinfoExample;
import com.leniao.huanbao.dto.ExpendStatistic.LinkRelativeStatistic;
import com.leniao.huanbao.dto.ExpendStatistic.MaxStatistic;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import com.leniao.mapper.HbyProjectDayCountinfoMapper;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 企业数据统计
 * @author: jiangdy
 * @create: 2019-12-31 10:29
 **/
@Service
public class HbyProjectDayCountinfoServiceImpl extends ServiceImpl<HbyProjectDayCountinfoMapper, HbyProjectDayCountinfo> implements HbyProjectDayCountinfoService {

    @Resource
    private HbyProjectDayCountinfoMapper hbyProjectDayCountinfoMapper;

    @Resource
    private ProjectDayCountinfoMapper projectDayCountinfoMapper;

    @Autowired
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;

    @Autowired
    private UshareDeviceElectricuseService ushareDeviceElectricuseService;

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Override
    public long countByExample(HbyProjectDayCountinfoExample example) {
        return hbyProjectDayCountinfoMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(HbyProjectDayCountinfoExample example) {
        return hbyProjectDayCountinfoMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Long id) {
        return hbyProjectDayCountinfoMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(HbyProjectDayCountinfo record) {
        return hbyProjectDayCountinfoMapper.insert(record);
    }

    @Override
    public int insertSelective(HbyProjectDayCountinfo record) {
        return hbyProjectDayCountinfoMapper.insertSelective(record);
    }

    @Override
    public List<HbyProjectDayCountinfo> selectByExample(HbyProjectDayCountinfoExample example) {
        return hbyProjectDayCountinfoMapper.selectByExample(example);
    }

    @Override
    public HbyProjectDayCountinfo selectByPrimaryKey(Long id) {
        return hbyProjectDayCountinfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(HbyProjectDayCountinfo record, HbyProjectDayCountinfoExample example) {
        return hbyProjectDayCountinfoMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExample(HbyProjectDayCountinfo record, HbyProjectDayCountinfoExample example) {
        return hbyProjectDayCountinfoMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(HbyProjectDayCountinfo record) {
        return hbyProjectDayCountinfoMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(HbyProjectDayCountinfo record) {
        return hbyProjectDayCountinfoMapper.updateByPrimaryKey(record);
    }

    /**
     * 峰值统计
     * @param params
     * @return
     */
    @Override
    public List<MaxStatistic> selectPeakValue(JSONObject params) {

        UserInfo userInfo = GlobalConstant.getUserInfo();
        DateTime now = DateTime.now();
        HbyProjectDayCountinfoExample example = new HbyProjectDayCountinfoExample();
        HbyProjectDayCountinfoExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdEqualTo(params.getInteger("projId"));
        criteria.andYearEqualTo(now.year().get());
        criteria.andMonthEqualTo(now.monthOfYear().get());
        criteria.andDayEqualTo(now.dayOfMonth().get());
        criteria.andPlatformIdEqualTo(userInfo.getPlatformId());
        List<HbyProjectDayCountinfo> todayCountInfoList = this.selectByExample(example);

        // 上一天
        DateTime lastDay = now.minusDays(1);
        HbyProjectDayCountinfoExample example1 = new HbyProjectDayCountinfoExample();
        HbyProjectDayCountinfoExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andUnitIdEqualTo(params.getInteger("projId"));
        criteria1.andYearEqualTo(lastDay.year().get());
        criteria1.andMonthEqualTo(lastDay.monthOfYear().get());
        criteria1.andDayEqualTo(lastDay.dayOfMonth().get());
        criteria1.andPlatformIdEqualTo(userInfo.getPlatformId());
        List<HbyProjectDayCountinfo> yesterdayCountinfoList = this.selectByExample(example1);
        HbyProjectDayCountinfo todayCountInfo = null;
        HbyProjectDayCountinfo yesterdayCountinfo = null;
        if (todayCountInfoList != null && todayCountInfoList.size() != 0) {
            todayCountInfo = todayCountInfoList.get(0);
        }
        if (yesterdayCountinfoList != null && yesterdayCountinfoList.size() != 0) {
            yesterdayCountinfo = yesterdayCountinfoList.get(0);
        }
        return maxStatistics(todayCountInfo, yesterdayCountinfo);
    }

    @Override
    public List<realValueList1> selectCurveChart(Integer devIdpk, String beginTime, String endTime, String nodeArray, int totalRows) {
        return HbaseUtil.GetListArrayByFilter(devIdpk + "", beginTime, endTime, nodeArray, totalRows + "");
    }

    /**
     * 查询多个单位（单位、行业、区域） 本日、本月、本年总用电量和 上日、上月、上年总用电量
     * 并计算趋势
     * @param projIdList 单位id集合
     * @return
     */
    @Override
    public List<LinkRelativeStatistic> selectEleLinkRelative(List<Integer> projIdList) {

        List<LinkRelativeStatistic> linkRelativeList = new ArrayList<>(8);
        if (projIdList == null || projIdList.size() == 0) {
            return linkRelativeList;
        }
        DateTime now = DateTime.now();
        UserInfo userInfo = GlobalConstant.getUserInfo();
        // 查询所有监测点设备
        List<Integer> deviceIds = projectDayCountinfoMapper.selectTotalDeviceIdpk(projIdList, userInfo.getPlatformId());
        if (deviceIds == null || deviceIds.size() == 0) {
            return linkRelativeList;
        }
//        // 本日
//        List<HbyProjectDayCountinfo> thisDayInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, now.year().get(),
//                now.monthOfYear().get(), now.getDayOfMonth());
//        // 上日
//        List<HbyProjectDayCountinfo> lastDayInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, lastDay.year().get(),
//                lastDay.monthOfYear().get(), lastDay.getDayOfMonth());
        UshareDeviceElectricuse today = this.selectTotalDeviceH24UseEleByProjIds(projIdList, cn.hutool.core.date.DateTime.of(now.toString(), "yyyy-MM-dd"));
        UshareDeviceElectricuse yesterday = this.selectTotalDeviceH24UseEleByProjIds(projIdList, cn.hutool.core.date.DateTime.of(now.minusDays(1).toString(), "yyyy-MM-dd"));
        // 日数据
        this.getLinkRelativeList2(linkRelativeList, today, yesterday, 1);

//        // 本月
//        List<HbyProjectDayCountinfo> thisMonthInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, now.year().get(),
//                now.monthOfYear().get(), 0);
//        // 上月
//        List<HbyProjectDayCountinfo> lastMonthInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, lastMonth.year().get(),
//                lastMonth.monthOfYear().get(), 0);
        DateTime last = now.minusMonths(1);
        List<DeviceDayCountInfo> thisMonthInfo = this.selectTotalDeviceDayCountInfo(deviceIds, now.getYear(), now.getMonthOfYear());
        List<DeviceDayCountInfo> lastMonthInfo = this.selectTotalDeviceDayCountInfo(deviceIds, last.getYear(), last.getMonthOfYear());
        // 月数据
        this.getLinkRelativeList(linkRelativeList, thisMonthInfo, lastMonthInfo, 2);

//        // 本年
//        List<HbyProjectDayCountinfo> thisYearInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, now.year().get(), 0, 0);
//        // 上年
//        List<HbyProjectDayCountinfo> lastYearInfo = this.selectHbyProjectDayCountinfoByProjIds(projIdList, lastYear.year().get(), 0, 0);
        last = now.minusYears(1);
        List<DeviceDayCountInfo> thisYearInfo = this.selectTotalDeviceMonthCountInfo(deviceIds, now.getYear());
        List<DeviceDayCountInfo> lastYearInfo = this.selectTotalDeviceMonthCountInfo(deviceIds, last.getYear());
        // 年数据
        this.getLinkRelativeList(linkRelativeList, thisYearInfo, lastYearInfo, 3);
        return linkRelativeList;
    }

    /**
     * 环比数据统计
     * @param LinkRelativeList
     * @param thisInfo
     * @param lastInfo
     * @param timeType
     */
    private void getLinkRelativeList(List<LinkRelativeStatistic> LinkRelativeList,List<DeviceDayCountInfo> thisInfo,
                                     List<DeviceDayCountInfo> lastInfo, int timeType) {
        LinkRelativeStatistic statistic = new LinkRelativeStatistic();
        Double maxValue = 0.0;
        Double lastMaxValue = 0.0;
        for (DeviceDayCountInfo info : thisInfo) {
            maxValue += info.getValue();
        }
        for (DeviceDayCountInfo info : lastInfo) {
            lastMaxValue += info.getValue();
        }

        statistic.setMaxValue(maxValue);
        statistic.setLastMaxValue(lastMaxValue);
        BigDecimal thisTotal = new BigDecimal(maxValue);
        BigDecimal lastTotal = new BigDecimal(lastMaxValue);
        if (thisTotal.intValue() == 0) {
            statistic.setDifferenceValue("0.0");
            statistic.setTrend("0.0%");
        } else if (thisTotal.subtract(lastTotal).compareTo(new BigDecimal(0)) > 0) {
            statistic.setDifferenceValue("+" + String.format("%.1f", thisTotal.subtract(lastTotal)));
            statistic.setTrend("+" + String.format("%.1f", (thisTotal.subtract(lastTotal).divide(thisTotal, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)))) + "%");
        } else {
            statistic.setDifferenceValue(String.format("%.1f", thisTotal.subtract(lastTotal)));
            statistic.setTrend(String.format("%.1f", (thisTotal.subtract(lastTotal).divide(thisTotal, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)))) + "%");
        }
        statistic.setTimeType(timeType);
        LinkRelativeList.add(statistic);
    }

    /**
     * 环比数据统计
     * @param LinkRelativeList
     * @param thisInfo
     * @param lastInfo
     * @param timeType
     */
    private void getLinkRelativeList2(List<LinkRelativeStatistic> LinkRelativeList, UshareDeviceElectricuse thisInfo,
                                      UshareDeviceElectricuse lastInfo, int timeType) {
        LinkRelativeStatistic statistic = new LinkRelativeStatistic();
        Double maxValue = 0.0;
        Double lastMaxValue = 0.0;

        maxValue = thisInfo.getH1() + thisInfo.getH2() + thisInfo.getH3() + thisInfo.getH4() + thisInfo.getH5()
                + thisInfo.getH6() + thisInfo.getH7() + thisInfo.getH8() + thisInfo.getH9() + thisInfo.getH10() + thisInfo.getH11()
                + thisInfo.getH12() + thisInfo.getH13() + thisInfo.getH14() + thisInfo.getH15() + thisInfo.getH16() + thisInfo.getH17()
                + thisInfo.getH18() + thisInfo.getH19() + thisInfo.getH20() + thisInfo.getH21() + thisInfo.getH22() + thisInfo.getH23() + thisInfo.getH24();

        lastMaxValue = lastInfo.getH1() + lastInfo.getH2() + lastInfo.getH3() + lastInfo.getH4() + lastInfo.getH5()
                + lastInfo.getH6() + lastInfo.getH7() + lastInfo.getH8() + lastInfo.getH9() + lastInfo.getH10() + lastInfo.getH11()
                + lastInfo.getH12() + lastInfo.getH13() + lastInfo.getH14() + lastInfo.getH15() + lastInfo.getH16() + lastInfo.getH17()
                + lastInfo.getH18() + lastInfo.getH19() + lastInfo.getH20() + lastInfo.getH21() + lastInfo.getH22() + lastInfo.getH23() + lastInfo.getH24();
        statistic.setMaxValue(maxValue);
        statistic.setLastMaxValue(lastMaxValue);
        BigDecimal thisTotal = new BigDecimal(maxValue);
        BigDecimal lastTotal = new BigDecimal(lastMaxValue);
        if (thisTotal.intValue() == 0) {
            statistic.setDifferenceValue("0.0");
            statistic.setTrend("0.0%");
        } else if (thisTotal.subtract(lastTotal).compareTo(new BigDecimal(0)) > 0) {
            statistic.setDifferenceValue("+" + String.format("%.1f", thisTotal.subtract(lastTotal)));
            statistic.setTrend("+" + String.format("%.1f", (thisTotal.subtract(lastTotal).divide(thisTotal, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)))) + "%");
        } else {
            statistic.setDifferenceValue(String.format("%.1f", thisTotal.subtract(lastTotal)));
            statistic.setTrend(String.format("%.1f", (thisTotal.subtract(lastTotal).divide(thisTotal, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)))) + "%");
        }
        statistic.setTimeType(timeType);
        LinkRelativeList.add(statistic);
    }

    /**
     * 批量查询单位日数据
     * @param projIdList 单位id集合
     * @param year 年
     * @param month 月
     * @param day 日
     * @return
     */
    @Override
    public List<HbyProjectDayCountinfo> selectHbyProjectDayCountinfoByProjIds(List<Integer> projIdList, int year, int month, int day) {
        if (projIdList == null || projIdList.size() == 0) {
            return new ArrayList<>();
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        HbyProjectDayCountinfoExample example = new HbyProjectDayCountinfoExample();
        HbyProjectDayCountinfoExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdIn(projIdList);
        criteria.andYearEqualTo(year);
        criteria.andMonthEqualTo(month);
        criteria.andDayEqualTo(day);
        criteria.andPlatformIdEqualTo(userInfo.getPlatformId());
        return this.selectByExample(example);
    }

    /**
     * 批量查询单位日数据
     * @param projIdList 单位id集合
     * @return
     */
    @Override
    public List<UseEleRanking> selectHbyProjectDayCountinfoByProjIds2(List<Integer> projIdList) {
        if (projIdList == null || projIdList.size() == 0) {
            return new ArrayList<>();
        }
        return projectDayCountinfoMapper.selectDeviceUseEle3(projIdList);
    }

    /**
     * 获取单位当日的数据，不区分平台，用的时候请注意
     * @author haosw
     * @param unitId
     * @param year
     * @param month
     * @param day
     * @return
     */
    @Override
    public List<HbyProjectDayCountinfo> selectHbyProjectDayCountinfoByProjIds(Integer unitId, int year, int month, int day) {
        //此方法理论上只会返回一条数据，以防万一，返回一个集合，待使用的时候判断
        HbyProjectDayCountinfoExample example = new HbyProjectDayCountinfoExample();
        HbyProjectDayCountinfoExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdEqualTo(unitId)
                .andYearEqualTo(year)
                .andMonthEqualTo(month)
                .andDayEqualTo(day);
        return this.selectByExample(example);
    }

    /**
     * 单位下分组、设备用电量排名
     * @param projId 单位id
     * @param label 标签 1-分组，2-设备
     * @return
     */
    @Override
    public List<Map<String, Object>> findUseEleRankingProj(Integer projId, Integer label) {

        // 查询所有监测点设备
        List<DevDto> devices = commonSimpleBeanInfoService.findDevicesOfOverLookPointByUnitID(projId);
        if (devices == null || devices.size() == 0) {
            return null;
        }
        Map<Integer, String> deviceInfo = new HashMap<>();
        devices.stream().forEach(a -> {
            deviceInfo.put(a.getDevIdpk(), a.getInstallLocation());
        });
//        List<UseEleRanking> list = projectDayCountinfoMapper.selectDeviceUseEle(deviceInfo.keySet(), label, DateTime.now().toString("yyyy-MM-ddd"));
        List<UseEleRanking> list = projectDayCountinfoMapper.selectDeviceUseEle2(deviceInfo.keySet(), label);
        List<Map<String, Object>> rankingList = new ArrayList<>();
        if (label == 2) {
            list.stream().forEach(a -> {
                Map<String, Object> tem = new HashMap<>(4);
                tem.put("name", deviceInfo.get(a.getId().intValue()));
                tem.put("value", String.format("%.1f", a.getValue()));
                rankingList.add(tem);
            });
        } else {
            list.stream().forEach(a -> {
                Map<String, Object> tem = new HashMap<>(4);
                tem.put("name", a.getName());
                tem.put("value", String.format("%.1f", a.getValue()));
                rankingList.add(tem);
            });
        }
        return rankingList;
    }

    /**
     * 查询柱状图-同比
     * @param projIdList 单位id集合
     * @param timeType 时间类型 1-日 2-月 3-年
     * @return
     */
    @Override
    public Map<String, Object> selectEleBarGraphYoY(List<Integer> projIdList, Integer timeType, Date date) {
        Map<String, Object> yoy = new HashMap<>();
        if (date == null) {
            date = new Date();
        }
        if (projIdList == null || projIdList.size() == 0) {
            return yoy;
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        // 查询所有监测点设备
        List<Integer> deviceIds = projectDayCountinfoMapper.selectTotalDeviceIdpk(projIdList, userInfo.getPlatformId());
        if (deviceIds == null || deviceIds.size() == 0) {
            return yoy;
        }
        DateTime now = new DateTime(date);
        DateTime last = null;
        switch (timeType) {
            case 1:
                UshareDeviceElectricuse today = this.selectTotalDeviceH24UseEleByProjIds(projIdList, cn.hutool.core.date.DateTime.of(now.toString(), "yyyy-MM-dd"));
                UshareDeviceElectricuse yesterday = this.selectTotalDeviceH24UseEleByProjIds(projIdList, cn.hutool.core.date.DateTime.of(now.minusDays(1).toString(), "yyyy-MM-dd"));
                this.dealDayUseEle(yoy, today, yesterday, 1, now);
                break;
            case 2: {

                last = now.minusMonths(1);
                List<DeviceDayCountInfo> nowData = this.selectTotalDeviceDayCountInfo(deviceIds, now.getYear(), now.getMonthOfYear());
                List<DeviceDayCountInfo> lastData = this.selectTotalDeviceDayCountInfo(deviceIds, last.getYear(), last.getMonthOfYear());
                this.dealMonthOrYearUseEle(yoy, nowData, lastData, 1, timeType, now);
                break;
            }
            case 3: {
                last = now.minusYears(1);
                List<DeviceDayCountInfo> nowData = this.selectTotalDeviceMonthCountInfo(deviceIds, now.getYear());
                List<DeviceDayCountInfo> lastData = this.selectTotalDeviceMonthCountInfo(deviceIds, last.getYear());
                this.dealMonthOrYearUseEle(yoy, nowData, lastData, 1, timeType, now);
                break;
            }
            default:
                throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        return yoy;
    }

    /**
     * 查询柱状图-环比
     * @param projIdList 单位id集合
     * @param timeType 时间类型 1-日 2-月 3-年
     * @return
     */
    @Override
    public Map<String, Object> selectEleBarGraphLinkRelative(List<Integer> projIdList, Integer timeType, Date date) {
        Map<String, Object> LinkRelative = new HashMap<>();
        if (date == null) {
            date = new Date();
        }
        if (projIdList == null || projIdList.size() == 0) {
            return LinkRelative;
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        // 查询所有监测点设备
        List<Integer> deviceIds = projectDayCountinfoMapper.selectTotalDeviceIdpk(projIdList, userInfo.getPlatformId());
        if (deviceIds == null || deviceIds.size() == 0) {
            return LinkRelative;
        }
        DateTime now = new DateTime(date);
        HbyProjectDayCountinfoExample example = new HbyProjectDayCountinfoExample();
        HbyProjectDayCountinfoExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdIn(projIdList);
        switch (timeType) {
            case 1:
                UshareDeviceElectricuse today = this.selectTotalDeviceH24UseEleByProjIds(projIdList, cn.hutool.core.date.DateTime.of(now.toString(), "yyyy-MM-dd"));
                this.dealDayUseEle(LinkRelative, today, today, 2, now);
                break;
            case 2: {
                List<DeviceDayCountInfo> nowData = this.selectTotalDeviceDayCountInfo(deviceIds, now.getYear(), now.getMonthOfYear());
                this.dealMonthOrYearUseEle(LinkRelative, nowData, nowData, 2, timeType, now);
                break;
            }
            case 3: {
                List<DeviceDayCountInfo> nowData = this.selectTotalDeviceMonthCountInfo(deviceIds, now.getYear());
                this.dealMonthOrYearUseEle(LinkRelative, nowData, nowData, 2, timeType, now);
                break;
            }
            default:
                throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        return LinkRelative;
    }

    /**
     * 获取今日和昨日绑定方案的单位数量
     * @param projIdList 单位id集合
     * @return
     */
    @Override
    public ExecuteState findHomePlanBind(List<Integer> projIdList) {
        ExecuteState exe = new ExecuteState();
        if (projIdList == null || projIdList.size() == 0) {
            exe.setYdExecute(0);
            exe.setYdUnexecute(0);
            exe.setTdExecute(0);
            exe.setTdUnexecute(0);
            return exe;
        }
        Date lastDate = cn.hutool.core.date.DateTime.of(DateTime.now().toString("yyyy-MM-dd"), "yyyy-MM-dd").toJdkDate();
        Map<String, ExecuteState> count = projectDayCountinfoMapper.homePlanBind(projIdList, lastDate);
        exe.setYdExecute(count.get("yday").getTdExecute());
        exe.setYdUnexecute(projIdList.size() - count.get("yday").getTdExecute());
//        exe.setTdExecute(count.get("tday").getTdExecute() - count.get("yday").getTdExecute());
        exe.setTdExecute(count.get("tday").getTdExecute());
        exe.setTdUnexecute(projIdList.size() - count.get("tday").getTdExecute());
        return exe;
    }

    /**
     * 更新日统计表中关于单位的行业数据
     * @param unitId
     * @param industryId
     * @author haosw
     */
    @Override
    public void updateIndustryOfUnit(Integer unitId, Integer industryId) {
        String sql = "update hby_project_day_countinfo set industry_idpk = ? where unit_id = ?";
        /*List<Object[]> objects = Lists.newArrayListWithExpectedSize(1);
        objects.add(new Object[]{unitId, industryId});
        jdbcTemplate.batchUpdate(sql, objects);*/
        this.jdbcTemplate.update(sql, industryId, unitId);
    }

    /**
     * 查询所有传入单位总表 24小时用电量合计值 sum(h1),sum(h2)...
     * @param projIdList 单位id集合
     * @param addTime 统计日期 年月日
     * @return
     */
    private UshareDeviceElectricuse selectTotalDeviceH24UseEleByProjIds(List<Integer> projIdList, Date addTime) {
        if (projIdList == null || projIdList.size() == 0) {
            return null;
        }
        return projectDayCountinfoMapper.selectTotalDeviceH24UseEleByProjIds(projIdList, addTime);
    }

    private List<DeviceDayCountInfo> selectTotalDeviceDayCountInfo(List<Integer> devIdpks, Integer year, Integer month) {
        if (devIdpks == null || devIdpks.size() == 0) {
            return null;
        }
        return projectDayCountinfoMapper.selectTotalDeviceDayCountInfo(devIdpks, year, month);
    }

    private List<DeviceDayCountInfo> selectTotalDeviceMonthCountInfo(List<Integer> devIdpks, Integer year) {
        if (devIdpks == null || devIdpks.size() == 0) {
            return null;
        }
        return projectDayCountinfoMapper.selectTotalDeviceMonthCountInfo(devIdpks, year);
    }

    /**
     * 用电量、功率 峰值统计
     * @param todayCountInfo 今日峰值数据
     * @param yesterdayCountinfo 昨日峰值数据
     * @return
     */
    private List<MaxStatistic> maxStatistics(HbyProjectDayCountinfo todayCountInfo, HbyProjectDayCountinfo yesterdayCountinfo) {
        List<MaxStatistic> maxStatisticList = new ArrayList<>(4);
        // 用电量
        MaxStatistic eleMaxStatistic = new MaxStatistic();
        eleMaxStatistic.setTimeType(1);
        eleMaxStatistic.setValueType(1);
        if (todayCountInfo == null) {
            // 今日数据
            eleMaxStatistic.setMaxValue(0.0);
            eleMaxStatistic.setMaxValueTime("00:00:00");
        } else {
            eleMaxStatistic.setProjId(todayCountInfo.getUnitId());
            eleMaxStatistic.setAgcyId(todayCountInfo.getAgcyId());
            eleMaxStatistic.setIndustryId(todayCountInfo.getIndustryIdpk());
            // 今日数据
            eleMaxStatistic.setMaxValue(Double.valueOf(todayCountInfo.getEleMax()));
            eleMaxStatistic.setMaxValueTime(cn.hutool.core.date.DateTime.of(todayCountInfo.getMaxEleTime()).toString("HH:mm:ss"));
        }
        if (yesterdayCountinfo == null) {
            // 今日数据
            eleMaxStatistic.setLastMaxValue(0.0);
            eleMaxStatistic.setLastMaxValueTime("00:00:00");
        } else {
            eleMaxStatistic.setProjId(yesterdayCountinfo.getUnitId());
            eleMaxStatistic.setAgcyId(yesterdayCountinfo.getAgcyId());
            eleMaxStatistic.setIndustryId(yesterdayCountinfo.getIndustryIdpk());
            // 昨日数据
            eleMaxStatistic.setLastMaxValue(Double.valueOf(yesterdayCountinfo.getEleMax()));
            eleMaxStatistic.setLastMaxValueTime(cn.hutool.core.date.DateTime.of(yesterdayCountinfo.getMaxEleTime()).toString("HH:mm:ss"));
        }

        // 功率
        MaxStatistic powerMaxStatistic = new MaxStatistic();
        powerMaxStatistic.setTimeType(1);
        powerMaxStatistic.setValueType(2);
        if (todayCountInfo == null) {
            // 今日数据
            powerMaxStatistic.setMaxValue(0.0);
            powerMaxStatistic.setMaxValueTime("00:00:00");
        } else {
            powerMaxStatistic.setProjId(todayCountInfo.getUnitId());
            powerMaxStatistic.setAgcyId(todayCountInfo.getAgcyId());
            powerMaxStatistic.setIndustryId(todayCountInfo.getIndustryIdpk());
            // 今日数据
            powerMaxStatistic.setMaxValue(Double.valueOf(todayCountInfo.getPowerMax()));
            powerMaxStatistic.setMaxValueTime(cn.hutool.core.date.DateTime.of(todayCountInfo.getMaxPowerTime()).toString("HH:mm:ss"));
        }
        if (yesterdayCountinfo == null) {
            // 今日数据
            powerMaxStatistic.setLastMaxValue(0.0);
            powerMaxStatistic.setLastMaxValueTime("00:00:00");
        } else {
            powerMaxStatistic.setProjId(yesterdayCountinfo.getUnitId());
            powerMaxStatistic.setAgcyId(yesterdayCountinfo.getAgcyId());
            powerMaxStatistic.setIndustryId(yesterdayCountinfo.getIndustryIdpk());
            // 昨日数据
            powerMaxStatistic.setLastMaxValue(Double.valueOf(yesterdayCountinfo.getPowerMax()));
            powerMaxStatistic.setLastMaxValueTime(cn.hutool.core.date.DateTime.of(yesterdayCountinfo.getMaxPowerTime()).toString("HH:mm:ss"));
        }
        maxStatisticList.add(eleMaxStatistic);
        maxStatisticList.add(powerMaxStatistic);
        return maxStatisticList;
    }

    public static void main(String[] args) {
        String ss = "2020-02-15";
        System.out.println(ss.substring(8));
    }

    private void dealMonthOrYearUseEle(Map<String, Object> map, List<DeviceDayCountInfo> nowData, List<DeviceDayCountInfo> lastData, int type, int timeType, DateTime dateTime) {
        int nowTime = dateTime.getMonthOfYear();
        if (DateTime.now().getYear() - dateTime.getYear() > 0) {
            nowTime = 12;
        }
        int lastTime = nowTime;
        if (DateTime.now().getYear() - dateTime.getYear() > 0 || type == 1) {
            lastTime = 12;
        }

        if (timeType == 2) {
            nowTime = dateTime.getDayOfMonth();
            if (DateTime.now().getMonthOfYear() - dateTime.getMonthOfYear() > 0) {
                nowTime = dateTime.dayOfMonth().getMaximumValue();
            }
            lastTime = nowTime;
            if (DateTime.now().getMonthOfYear() - dateTime.getMonthOfYear() > 0 || type == 1) {
                lastTime = dateTime.minusMonths(1).dayOfMonth().getMaximumValue();
            }
        }
        Map<Integer, String> now = new HashMap<>();
        Map<Integer, String> last = new HashMap<>();
        for (DeviceDayCountInfo nowDatum : nowData) {
            if (timeType == 2) {
                now.put(Integer.parseInt(nowDatum.getAddTime().substring(8)), String.format("%.1f", nowDatum.getValue()));
            } else {
                now.put(Integer.parseInt(nowDatum.getAddTime()), String.format("%.1f", nowDatum.getValue()));
            }
        }
        for (DeviceDayCountInfo lastDatum : lastData) {
            if (timeType == 2) {
                last.put(Integer.parseInt(lastDatum.getAddTime().substring(8)), String.format("%.1f", lastDatum.getValue()));
            } else {
                last.put(Integer.parseInt(lastDatum.getAddTime()), String.format("%.1f", lastDatum.getValue()));
            }
        }

        int key = nowTime > lastTime ? nowTime : lastTime;
        String[] time = new String[key];
        String[] nowstr = new String[nowTime];
        String[] laststr = new String[lastTime];

        map.put("time", time);
        map.put("now", nowstr);
        map.put("last", laststr);

        for (int i = 0; i < key; i++) {
            time[i] = String.format("%02d", (i + 1));
            if (nowTime > i) {
                if (now.get(i + 1) == null) {
                    nowstr[i] = "0.0";
                } else {
                    nowstr[i] = now.get(i + 1);
                }
            }
            if (lastTime > i) {
                if (type == 1) {
                    if (last.get(i + 1) == null) {
                        laststr[i] = "0.0";
                    } else {
                        laststr[i] = last.get(i + 1);
                    }
                } else {
                    if (last.get(i) == null) {
                        laststr[i] = "0.0";
                    } else {
                        laststr[i] = last.get(i);
                    }
                }
            }
        }
        if (type == 2) {
            laststr[0] = "-";
        }
    }

    private void dealDayUseEle(Map<String, Object> yoy, UshareDeviceElectricuse thisValue, UshareDeviceElectricuse lastValue, int type, DateTime nowTime) {
        int size = DateTime.now().getHourOfDay();
        if (DateTime.now().getDayOfMonth() - nowTime.getDayOfMonth() > 0 || type != 2) {
            size = 23;
        }
        int hour = size;
        if (DateTime.now().getDayOfMonth() - nowTime.getDayOfMonth() == 0 && type != 2) {
            hour = DateTime.now().getHourOfDay();
        }
        List<String> time = new ArrayList<>();
        List<String> now = new ArrayList<>();
        List<String> last = new ArrayList<>();
        yoy.put("time", time);
        yoy.put("now", now);
        yoy.put("last", last);
        for (int i = 0; i <= size; i++) {
            switch (i) {
                case 0:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH1()));
                    }
                    if (type == 2) {
                        last.add("-");
                    } else {
                        last.add(String.format("%.1f", lastValue.getH1()));
                    }
                    break;
                case 1:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH2()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH1()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH2()));
                    }
                    break;
                case 2:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH3()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH2()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH3()));
                    }
                    break;
                case 3:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH4()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH3()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH4()));
                    }
                    break;
                case 4:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH5()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH4()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH5()));
                    }
                    break;
                case 5:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH6()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH5()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH6()));
                    }
                    break;
                case 6:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH7()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH6()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH7()));
                    }
                    break;
                case 7:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH8()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH7()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH8()));
                    }
                    break;
                case 8:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH9()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH8()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH9()));
                    }
                    break;
                case 9:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH10()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH9()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH10()));
                    }
                    break;
                case 10:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH11()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH10()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH11()));
                    }
                    break;
                case 11:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH12()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH11()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH12()));
                    }
                    break;
                case 12:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH13()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH12()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH13()));
                    }
                    break;
                case 13:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH14()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH13()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH14()));
                    }
                    break;
                case 14:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH15()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH14()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH15()));
                    }
                    break;
                case 15:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH16()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH15()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH16()));
                    }
                    break;
                case 16:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH17()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH16()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH17()));
                    }
                    break;
                case 17:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH18()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH17()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH18()));
                    }
                    break;
                case 18:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH19()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH18()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH19()));
                    }
                    break;
                case 19:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH20()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH19()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH20()));
                    }
                    break;
                case 20:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH21()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH20()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH21()));
                    }
                    break;
                case 21:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH22()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH21()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH22()));
                    }
                    break;
                case 22:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH23()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH22()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH23()));
                    }
                    break;
                case 23:
                    if (hour >= i) {
                        now.add(String.format("%.1f", thisValue.getH24()));
                    }
                    if (type == 2) {
                        last.add(String.format("%.1f", lastValue.getH23()));
                    } else {
                        last.add(String.format("%.1f", lastValue.getH24()));
                    }
                    break;
                default:
            }
            time.add(String.format("%02d", (i+1)));
        }
    }
}
