package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyDevalTimeStatus;
import com.leniao.huanbao.entity.HbyDevalTimeStatusExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyDevalTimeStatusMapper extends BaseMapper<HbyDevalTimeStatus> {
    long countByExample(HbyDevalTimeStatusExample example);

    int deleteByExample(HbyDevalTimeStatusExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyDevalTimeStatus record);

    int insertSelective(HbyDevalTimeStatus record);

    List<HbyDevalTimeStatus> selectByExample(HbyDevalTimeStatusExample example);

    HbyDevalTimeStatus selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyDevalTimeStatus record, @Param("example") HbyDevalTimeStatusExample example);

    int updateByExample(@Param("record") HbyDevalTimeStatus record, @Param("example") HbyDevalTimeStatusExample example);

    int updateByPrimaryKeySelective(HbyDevalTimeStatus record);

    int updateByPrimaryKey(HbyDevalTimeStatus record);

    List<String> findDevStatus(@Param("sql") String sql);

}