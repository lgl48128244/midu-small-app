package com.leniao.huanbao.service;

import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.statisticanalysis.StatisticAnalysisDto;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ReduceEmAnalyzeService {
    /**
     * 减产减排分析查询
     * @param projIds 单位id
     * @param params 条件参数
     * @return
     */
    List<StatisticAnalysisDto> selectStatisticAnalysisList(List<Long> projIds, Map<String, Object> params);

    /**
     * 减产减排分析查询
     * @param projIds 单位id
     * @param params 条件参数
     * @return
     */
    List<StatisticAnalysisDto> selectStatisticAnalysisList2(List<Long> projIds, AreaCodeJoinOther code, Integer grade, Map<String, Object> params);

    /**
     * 查询主表设备
     * @param projIds
     * @return
     */
    Map<Integer, StatisticAnalysisDto> selectMainDevice(List<Long> projIds);

    /**
     * 查询主表用电量排名
     * @param devIdpks
     * @return
     */
    Map<Integer, StatisticAnalysisDto> selectRanking(List<Integer> devIdpks, String addTime);

    /**
     * 条件查询单位
     * @param projIds
     * @param params
     * @return
     */
    List<StatisticAnalysisDto> selectStatisticAnalysisProjectList(List<Long> projIds, Map<String, Object> params);

}
