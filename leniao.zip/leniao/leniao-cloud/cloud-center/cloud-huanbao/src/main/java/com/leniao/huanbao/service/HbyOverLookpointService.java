package com.leniao.huanbao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyOverLookPoint;

import java.util.List;

public interface HbyOverLookpointService extends IService<HbyOverLookPoint> {

    /**
     * 通过单位id，找出对应的监测点信息
     *
     * @return*/
    List<HbyOverLookPoint> findLookPointInfo(Integer unitId, Integer pageCount, Integer pageSize, String date, Integer groupId);

    /**
     * 通过单位id，找出对应的监测点信息
     * */
    List<HbyOverLookPoint> findLookPointInfo(Integer unitId);

    /**
     * 通过单位id，找出对应的监测点id
     * 默认第一个
     */
    Long findLookPointId(Integer unitId);

    /**
     * 通过监测点id找出单位id
     */
    Integer findUnitId(Integer lookPointId);

    /**
     * 添加监测点信息
     */
    boolean addLookPoint(HbyOverLookPoint hbyOverlookpoint);

    /**
     * 删除监测点信息 逻辑删除
     */
    void removeLookPoint(List<Long> lookPointIds);

    /**
     * 删除监测点信息 逻辑删除
     */
    void updateLookPoint2(List<Long> lookPointIds,HbyOverLookPoint hbyOverlookpoint,List<String> pollList,List<String> conList);
    /**
     * 添加普通监测点信息
     */
    void addLookPoint2(HbyOverLookPoint hbyOverlookpoint,List<String> pollList,List<String> conList);

    /**
     * 添加总监测点
     * @param hbyOverlookpoint
     * @param devSign
     */
    void addLookPointTotal2(HbyOverLookPoint hbyOverlookpoint,String devSign);

    /**
     * 修改监测点信息
     */
    boolean updateLookPoint(HbyOverLookPoint hbyOverlookpoint);

    /**
     * 通过监测点Id查出监测点所有的信息
     */
    HbyOverLookPoint findOverLookPoint(Long lookPointId);

    /**
     * 找出单位下监测点的产污设备
     * @param unitId
     * @return
     */
    String findPollDevStrByUnit(Integer unitId);

    /**
     * 找出单位下监测点的治污设备
     * @param unitId
     * @return
     */
    String findConDevStrByUnit(Integer unitId);

    /**
     * 找出单位下监测点的总表设备
     * @param unitId
     * @return
     */
    String findTotalDevStrByUnit(Integer unitId);

}
