package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.huanbao.entity.Areaarea;
import com.leniao.huanbao.mapper.AreaareaMapper;
import com.leniao.huanbao.service.AreaareaService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 10:03
 */
@Service
public class AreaareaServiceImpl implements AreaareaService {

    @Resource
    private AreaareaMapper areaareaMapper;

    /**
     * 根据市级id 找出相对应的县级信息
     */
    @Override
    public List<Areaarea> findAllArea(String cityId) {
        //创建条件对象
        QueryWrapper<Areaarea> queryWrapper = new QueryWrapper<>();
        //存储条件
        queryWrapper.select("areaid","area").lambda().eq(Areaarea::getFather,cityId);

        List<Areaarea> areaareaList = areaareaMapper.selectList(queryWrapper);

        return areaareaList;
    }
}
