package com.leniao.huanbao.dto;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 树形结构菜单
 * @author: jiangdy
 * @create: 2019-12-23 11:46
 **/
@Setter
@Getter
@ToString
public class TreeMenu {

    /**
     * 节点类型，节点类型和节点id确定一个唯一的节点
     */
    private Integer nodeType;
    /**
     * 节点id （机构id、单位id、分组id、检测点id、设备id）
     */
    @JsonSerialize(using=ToStringSerializer.class)
    private Long nodeId;

    /**
     * 节点名称（机构名称、单位名称、分组名称、检测点名称、设备名称）
     */
    private String nodeName;

    /**
     * 设备编号
     */
    private String devSignature;

    /**
     * 是否只读 0-只读 1-可操作
     */
    private Integer onlyRead;

    /**
     * 是否已经绑定该方案 0-不绑定 1-绑定
     */
    private Integer isBind;

    /**
     * 所在区域码
     */
    private String provinceCode;
    private String cityCode;
    private String areaCode;

    /**
     * 上级节点类型，节点类型和节点id确定一个唯一的节点
     */
    private Integer parentNodeType = 1;

    /**
     * 上级节点
     */
    @JsonSerialize(using=ToStringSerializer.class)
    private Long parentNodeId = 0L;

    /**
     * 下级菜单
     */
    private List<TreeMenu> childTreeMenu = new ArrayList<>();
}
