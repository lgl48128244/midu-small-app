package com.leniao.huanbao.service.impl;

import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.statisticanalysis.StatisticAnalysisDto;
import com.leniao.huanbao.mapper.ReduceEmAnalyzeMapper;
import com.leniao.huanbao.service.ReduceEmAnalyzeService;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减排分析
 * @author: jiangdy
 * @create: 2019-12-27 14:58
 **/
@Service
public class ReduceEmAnalyzeServiceImpl implements ReduceEmAnalyzeService {

    @Resource
    private ReduceEmAnalyzeMapper reduceEmAnalyzeMapper;

    @Override
    public List<StatisticAnalysisDto> selectStatisticAnalysisList(List<Long> projIds, Map<String, Object> params) {
        if (CollectionUtils.isNotEmpty(projIds)) {
            UserInfo userInfo = GlobalConstant.getUserInfo();
            return reduceEmAnalyzeMapper.selectStatisticAnalysisList(projIds, userInfo.getPlatformId(), params);
        }
        return null;
    }

    @Override
    public List<StatisticAnalysisDto> selectStatisticAnalysisList2(List<Long> projIds, AreaCodeJoinOther code, Integer grade, Map<String, Object> params) {
        if (CollectionUtils.isNotEmpty(projIds)) {
            DateTime time = new DateTime(params.get("addTime"));
            if (time == null) {
                time = DateTime.now();
            }
            UserInfo userInfo = GlobalConstant.getUserInfo();
            return reduceEmAnalyzeMapper.selectStatisticAnalysisList2(projIds, userInfo.getPlatformId(), code, grade, time.getYear(), time.getMonthOfYear(), time.getDayOfMonth(), params);
        }
        return null;
    }

    @Override
    public Map<Integer, StatisticAnalysisDto> selectMainDevice(List<Long> projIds) {
        if (CollectionUtils.isNotEmpty(projIds)) {
            UserInfo userInfo = GlobalConstant.getUserInfo();
            return reduceEmAnalyzeMapper.selectMainDevice(projIds, userInfo.getPlatformId());
        }
        return null;
    }

    @Override
    public Map<Integer, StatisticAnalysisDto> selectRanking(List<Integer> devIdpks, String addTime) {
        if (CollectionUtils.isNotEmpty(devIdpks)) {
            return reduceEmAnalyzeMapper.selectRanking(devIdpks, addTime);
        }
        return null;
    }

    @Override
    public List<StatisticAnalysisDto> selectStatisticAnalysisProjectList(List<Long> projIds, Map<String, Object> params) {
        if (CollectionUtils.isNotEmpty(projIds)) {
            UserInfo userInfo = GlobalConstant.getUserInfo();
            return reduceEmAnalyzeMapper.selectStatisticAnalysisProjectList(projIds, userInfo.getPlatformId(), params);
        }
        return null;
    }

    public static void main(String[] args) {
        String ti = "2020-03-06";
        DateTime dateTime = new DateTime(ti);
        System.out.println(dateTime.getYear());
        System.out.println(dateTime.getMonthOfYear());
        System.out.println(dateTime.getDayOfMonth());
    }


}
