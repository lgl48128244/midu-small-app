package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.leniao.huanbao.utils.DoubleSerialize;
import lombok.ToString;

import java.util.Date;

@ToString
@TableName("ushare_device_electricuse")
public class UshareDeviceElectricuse {
    private Integer idpk;

    private Integer devidpk;

    private Integer unitid;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h1;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h2;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h3;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h4;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h5;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h6;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h7;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h8;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h9;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h10;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h11;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h12;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h13;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h14;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h15;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h16;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h17;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h18;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h19;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h20;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h21;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h22;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h23;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double h24;

    private Date addtime;

    private Integer elyear;

    private Integer elmonth;

    private Integer elweek;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double daytotalq;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double daytotalfee;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double daycharge;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double devtotalq;

    private Date updatetime;

    private Integer isreset;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double beforetodaytotalq;

    @JsonSerialize(using=DoubleSerialize.class)
    private Double beforetodaytotalfee;

    private Integer devrealtotalq;

    public Integer getIdpk() {
        return idpk;
    }

    public void setIdpk(Integer idpk) {
        this.idpk = idpk;
    }

    public Integer getDevidpk() {
        return devidpk;
    }

    public void setDevidpk(Integer devidpk) {
        this.devidpk = devidpk;
    }

    public Integer getUnitid() {
        return unitid;
    }

    public void setUnitid(Integer unitid) {
        this.unitid = unitid;
    }

    public Double getH1() {
        return h1;
    }

    public void setH1(Double h1) {
        this.h1 = h1;
    }

    public Double getH2() {
        return h2;
    }

    public void setH2(Double h2) {
        this.h2 = h2;
    }

    public Double getH3() {
        return h3;
    }

    public void setH3(Double h3) {
        this.h3 = h3;
    }

    public Double getH4() {
        return h4;
    }

    public void setH4(Double h4) {
        this.h4 = h4;
    }

    public Double getH5() {
        return h5;
    }

    public void setH5(Double h5) {
        this.h5 = h5;
    }

    public Double getH6() {
        return h6;
    }

    public void setH6(Double h6) {
        this.h6 = h6;
    }

    public Double getH7() {
        return h7;
    }

    public void setH7(Double h7) {
        this.h7 = h7;
    }

    public Double getH8() {
        return h8;
    }

    public void setH8(Double h8) {
        this.h8 = h8;
    }

    public Double getH9() {
        return h9;
    }

    public void setH9(Double h9) {
        this.h9 = h9;
    }

    public Double getH10() {
        return h10;
    }

    public void setH10(Double h10) {
        this.h10 = h10;
    }

    public Double getH11() {
        return h11;
    }

    public void setH11(Double h11) {
        this.h11 = h11;
    }

    public Double getH12() {
        return h12;
    }

    public void setH12(Double h12) {
        this.h12 = h12;
    }

    public Double getH13() {
        return h13;
    }

    public void setH13(Double h13) {
        this.h13 = h13;
    }

    public Double getH14() {
        return h14;
    }

    public void setH14(Double h14) {
        this.h14 = h14;
    }

    public Double getH15() {
        return h15;
    }

    public void setH15(Double h15) {
        this.h15 = h15;
    }

    public Double getH16() {
        return h16;
    }

    public void setH16(Double h16) {
        this.h16 = h16;
    }

    public Double getH17() {
        return h17;
    }

    public void setH17(Double h17) {
        this.h17 = h17;
    }

    public Double getH18() {
        return h18;
    }

    public void setH18(Double h18) {
        this.h18 = h18;
    }

    public Double getH19() {
        return h19;
    }

    public void setH19(Double h19) {
        this.h19 = h19;
    }

    public Double getH20() {
        return h20;
    }

    public void setH20(Double h20) {
        this.h20 = h20;
    }

    public Double getH21() {
        return h21;
    }

    public void setH21(Double h21) {
        this.h21 = h21;
    }

    public Double getH22() {
        return h22;
    }

    public void setH22(Double h22) {
        this.h22 = h22;
    }

    public Double getH23() {
        return h23;
    }

    public void setH23(Double h23) {
        this.h23 = h23;
    }

    public Double getH24() {
        return h24;
    }

    public void setH24(Double h24) {
        this.h24 = h24;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public Integer getElyear() {
        return elyear;
    }

    public void setElyear(Integer elyear) {
        this.elyear = elyear;
    }

    public Integer getElmonth() {
        return elmonth;
    }

    public void setElmonth(Integer elmonth) {
        this.elmonth = elmonth;
    }

    public Integer getElweek() {
        return elweek;
    }

    public void setElweek(Integer elweek) {
        this.elweek = elweek;
    }

    public Double getDaytotalq() {
        return daytotalq;
    }

    public void setDaytotalq(Double daytotalq) {
        this.daytotalq = daytotalq;
    }

    public Double getDaytotalfee() {
        return daytotalfee;
    }

    public void setDaytotalfee(Double daytotalfee) {
        this.daytotalfee = daytotalfee;
    }

    public Double getDaycharge() {
        return daycharge;
    }

    public void setDaycharge(Double daycharge) {
        this.daycharge = daycharge;
    }

    public Double getDevtotalq() {
        return devtotalq;
    }

    public void setDevtotalq(Double devtotalq) {
        this.devtotalq = devtotalq;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getIsreset() {
        return isreset;
    }

    public void setIsreset(Integer isreset) {
        this.isreset = isreset;
    }

    public Double getBeforetodaytotalq() {
        return beforetodaytotalq;
    }

    public void setBeforetodaytotalq(Double beforetodaytotalq) {
        this.beforetodaytotalq = beforetodaytotalq;
    }

    public Double getBeforetodaytotalfee() {
        return beforetodaytotalfee;
    }

    public void setBeforetodaytotalfee(Double beforetodaytotalfee) {
        this.beforetodaytotalfee = beforetodaytotalfee;
    }

    public Integer getDevrealtotalq() {
        return devrealtotalq;
    }

    public void setDevrealtotalq(Integer devrealtotalq) {
        this.devrealtotalq = devrealtotalq;
    }
}