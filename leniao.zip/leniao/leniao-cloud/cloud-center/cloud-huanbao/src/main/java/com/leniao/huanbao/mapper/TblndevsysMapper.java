package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.Tblndevsys;
import com.leniao.huanbao.entity.TblndevsysExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblndevsysMapper extends BaseMapper<Tblndevsys> {
    int countByExample(TblndevsysExample example);

    int deleteByExample(TblndevsysExample example);

    int deleteByPrimaryKey(Integer devsysid);

    int insert(Tblndevsys record);

    int insertSelective(Tblndevsys record);

    List<Tblndevsys> selectByExample(TblndevsysExample example);

    Tblndevsys selectByPrimaryKey(Integer devsysid);

    int updateByExampleSelective(@Param("record") Tblndevsys record, @Param("example") TblndevsysExample example);

    int updateByExample(@Param("record") Tblndevsys record, @Param("example") TblndevsysExample example);

    int updateByPrimaryKeySelective(Tblndevsys record);

    int updateByPrimaryKey(Tblndevsys record);
}