package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.huanbao.entity.Tblngroup;
import com.leniao.huanbao.mapper.TblngroupMapper;
import com.leniao.huanbao.service.TblngroupService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 17:54
 * @update
 */

@Service
public class TblngroupServiceImpl implements TblngroupService {

    @Resource
    private TblngroupMapper tblngroupMapper;

    /**
     * 通过设备分组id找出分组名称
     */
    @Override
    public String findGroupName(Integer groupId) {
        //创建条件
        QueryWrapper<Tblngroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("groupname").lambda().eq(Tblngroup::getGroupid,groupId);

        Tblngroup tblngroup = tblngroupMapper.selectOne(queryWrapper);

        if (tblngroup==null){
            return "";
        }else {
            return tblngroup.getGroupname();
        }

    }

    /**
     * 通过单位id，找出对应的单位下的分组名称以及分组ID
     */
    @Override
    public List<Tblngroup> findGroupIdName(Integer unitId) {

        //创建条件
        QueryWrapper<Tblngroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("groupname","groupid").lambda().eq(Tblngroup::getProjid,unitId);
        List<Tblngroup> tblngroupList = tblngroupMapper.selectList(queryWrapper);

        return tblngroupList;
    }
}
