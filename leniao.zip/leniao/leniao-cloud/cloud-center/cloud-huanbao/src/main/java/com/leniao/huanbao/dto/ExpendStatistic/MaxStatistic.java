package com.leniao.huanbao.dto.ExpendStatistic;

import lombok.Data;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 峰值统计
 * @author: jiangdy
 * @create: 2019-12-31 11:41
 **/
@Data
public class MaxStatistic extends ProjectDayCountInfo {

    /**
     * 当天峰值时间（时：分：秒）
     */
    private String maxValueTime;

    /**
     * 上一天峰值时间（时：分：秒）
     */
    private String lastMaxValueTime;

    /**
     * 峰值类型 1-用电量 2-功率
     */
    private int valueType;

}
