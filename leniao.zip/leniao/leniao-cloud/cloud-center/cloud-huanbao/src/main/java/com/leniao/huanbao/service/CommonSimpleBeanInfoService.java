package com.leniao.huanbao.service;

import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.DeviceEleUseDto;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @Description: 获取一些公共基本信息的接口类, 必要时, 使用缓存
 * @Author: haosw
 * @CreateDate: 2019/12/24 15:25
 * @Version: 1.0
 */
public interface CommonSimpleBeanInfoService {

    /**
     * @description: 根据单位ID查询其下监测点关联的所有设备的基本信息集合(放入缓存30分钟)
     * @author: haosw
     * @param: unitId: 单位id
     * @return:
     * @date: 2019/12/24 15:10
     */
    List<DevDto> findDevicesOfOverLookPointByUnitID(Integer unitId);

    /**
     * @description: 根据单位ID查询单位的基本信息
     * @author: haosw
     * @param: unitId: 单位ID
     * @return:
     * @date: 2019/12/23 14:54
     */
    UnitBasicInfoDto findUnitBasicInfoByID(Integer unitId);

    /**
     * @description: 查询所有建立了监测点的单位的基本信息
     * @author: haosw
     * @param:
     * @return: 单位基本信息
     * @date: 2019/12/23 11:18
     */
    List<UnitBasicInfoDto> findAllUnitBasicInfo();

    /**
     * @description: 查询所有监测点下的设备的报警数据, 并缓存最大报警ID
     * @author: haosw
     * @param: maxWranId:上一次缓存的最大原异常表ID
     * @return: List<HbyForwardSyncErrorDto>
     * @date: 2019/12/25 15:59
     */
    List<HbyProjectErrorInfo> findAllOverlookDevErrs(int maxWranId);

    /**
     * @description: 获取单位的各个数量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 17:33
     */
    HashMap<String, Object> findUnitEveryErrTypeNum(Integer unitId, Date now);

    /**
     * @description: 查询监测点设备的用电量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/15 13:19
     */
    List<DeviceEleUseDto> findMonthEleUseOfDevice(int year, int monthOfYear);
}
