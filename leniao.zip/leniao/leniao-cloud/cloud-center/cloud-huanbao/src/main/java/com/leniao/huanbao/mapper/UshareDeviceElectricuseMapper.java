package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.entity.UshareDeviceElectricuseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UshareDeviceElectricuseMapper extends BaseMapper<UshareDeviceElectricuse> {
    int countByExample(UshareDeviceElectricuseExample example);

    int deleteByExample(UshareDeviceElectricuseExample example);

    int deleteByPrimaryKey(Integer idpk);

    int insert(UshareDeviceElectricuse record);

    int insertSelective(UshareDeviceElectricuse record);

    List<UshareDeviceElectricuse> selectByExample(UshareDeviceElectricuseExample example);

    UshareDeviceElectricuse selectByPrimaryKey(Integer idpk);

    int updateByExampleSelective(@Param("record") UshareDeviceElectricuse record, @Param("example") UshareDeviceElectricuseExample example);

    int updateByExample(@Param("record") UshareDeviceElectricuse record, @Param("example") UshareDeviceElectricuseExample example);

    int updateByPrimaryKeySelective(UshareDeviceElectricuse record);

    int updateByPrimaryKey(UshareDeviceElectricuse record);
}