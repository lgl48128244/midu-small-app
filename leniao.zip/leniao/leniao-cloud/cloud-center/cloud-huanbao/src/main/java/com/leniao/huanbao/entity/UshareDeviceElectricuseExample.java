package com.leniao.huanbao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class UshareDeviceElectricuseExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UshareDeviceElectricuseExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdpkIsNull() {
            addCriterion("idPk is null");
            return (Criteria) this;
        }

        public Criteria andIdpkIsNotNull() {
            addCriterion("idPk is not null");
            return (Criteria) this;
        }

        public Criteria andIdpkEqualTo(Integer value) {
            addCriterion("idPk =", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkNotEqualTo(Integer value) {
            addCriterion("idPk <>", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkGreaterThan(Integer value) {
            addCriterion("idPk >", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("idPk >=", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkLessThan(Integer value) {
            addCriterion("idPk <", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkLessThanOrEqualTo(Integer value) {
            addCriterion("idPk <=", value, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkIn(List<Integer> values) {
            addCriterion("idPk in", values, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkNotIn(List<Integer> values) {
            addCriterion("idPk not in", values, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkBetween(Integer value1, Integer value2) {
            addCriterion("idPk between", value1, value2, "idpk");
            return (Criteria) this;
        }

        public Criteria andIdpkNotBetween(Integer value1, Integer value2) {
            addCriterion("idPk not between", value1, value2, "idpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNull() {
            addCriterion("devIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNotNull() {
            addCriterion("devIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevidpkEqualTo(Integer value) {
            addCriterion("devIdpk =", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotEqualTo(Integer value) {
            addCriterion("devIdpk <>", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThan(Integer value) {
            addCriterion("devIdpk >", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIdpk >=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThan(Integer value) {
            addCriterion("devIdpk <", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThanOrEqualTo(Integer value) {
            addCriterion("devIdpk <=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIn(List<Integer> values) {
            addCriterion("devIdpk in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotIn(List<Integer> values) {
            addCriterion("devIdpk not in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk not between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andUnitidIsNull() {
            addCriterion("unitId is null");
            return (Criteria) this;
        }

        public Criteria andUnitidIsNotNull() {
            addCriterion("unitId is not null");
            return (Criteria) this;
        }

        public Criteria andUnitidEqualTo(Integer value) {
            addCriterion("unitId =", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotEqualTo(Integer value) {
            addCriterion("unitId <>", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidGreaterThan(Integer value) {
            addCriterion("unitId >", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidGreaterThanOrEqualTo(Integer value) {
            addCriterion("unitId >=", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidLessThan(Integer value) {
            addCriterion("unitId <", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidLessThanOrEqualTo(Integer value) {
            addCriterion("unitId <=", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidIn(List<Integer> values) {
            addCriterion("unitId in", values, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotIn(List<Integer> values) {
            addCriterion("unitId not in", values, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidBetween(Integer value1, Integer value2) {
            addCriterion("unitId between", value1, value2, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotBetween(Integer value1, Integer value2) {
            addCriterion("unitId not between", value1, value2, "unitid");
            return (Criteria) this;
        }

        public Criteria andH1IsNull() {
            addCriterion("h1 is null");
            return (Criteria) this;
        }

        public Criteria andH1IsNotNull() {
            addCriterion("h1 is not null");
            return (Criteria) this;
        }

        public Criteria andH1EqualTo(Double value) {
            addCriterion("h1 =", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1NotEqualTo(Double value) {
            addCriterion("h1 <>", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1GreaterThan(Double value) {
            addCriterion("h1 >", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1GreaterThanOrEqualTo(Double value) {
            addCriterion("h1 >=", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1LessThan(Double value) {
            addCriterion("h1 <", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1LessThanOrEqualTo(Double value) {
            addCriterion("h1 <=", value, "h1");
            return (Criteria) this;
        }

        public Criteria andH1In(List<Double> values) {
            addCriterion("h1 in", values, "h1");
            return (Criteria) this;
        }

        public Criteria andH1NotIn(List<Double> values) {
            addCriterion("h1 not in", values, "h1");
            return (Criteria) this;
        }

        public Criteria andH1Between(Double value1, Double value2) {
            addCriterion("h1 between", value1, value2, "h1");
            return (Criteria) this;
        }

        public Criteria andH1NotBetween(Double value1, Double value2) {
            addCriterion("h1 not between", value1, value2, "h1");
            return (Criteria) this;
        }

        public Criteria andH2IsNull() {
            addCriterion("h2 is null");
            return (Criteria) this;
        }

        public Criteria andH2IsNotNull() {
            addCriterion("h2 is not null");
            return (Criteria) this;
        }

        public Criteria andH2EqualTo(Double value) {
            addCriterion("h2 =", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2NotEqualTo(Double value) {
            addCriterion("h2 <>", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2GreaterThan(Double value) {
            addCriterion("h2 >", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2GreaterThanOrEqualTo(Double value) {
            addCriterion("h2 >=", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2LessThan(Double value) {
            addCriterion("h2 <", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2LessThanOrEqualTo(Double value) {
            addCriterion("h2 <=", value, "h2");
            return (Criteria) this;
        }

        public Criteria andH2In(List<Double> values) {
            addCriterion("h2 in", values, "h2");
            return (Criteria) this;
        }

        public Criteria andH2NotIn(List<Double> values) {
            addCriterion("h2 not in", values, "h2");
            return (Criteria) this;
        }

        public Criteria andH2Between(Double value1, Double value2) {
            addCriterion("h2 between", value1, value2, "h2");
            return (Criteria) this;
        }

        public Criteria andH2NotBetween(Double value1, Double value2) {
            addCriterion("h2 not between", value1, value2, "h2");
            return (Criteria) this;
        }

        public Criteria andH3IsNull() {
            addCriterion("h3 is null");
            return (Criteria) this;
        }

        public Criteria andH3IsNotNull() {
            addCriterion("h3 is not null");
            return (Criteria) this;
        }

        public Criteria andH3EqualTo(Double value) {
            addCriterion("h3 =", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3NotEqualTo(Double value) {
            addCriterion("h3 <>", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3GreaterThan(Double value) {
            addCriterion("h3 >", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3GreaterThanOrEqualTo(Double value) {
            addCriterion("h3 >=", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3LessThan(Double value) {
            addCriterion("h3 <", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3LessThanOrEqualTo(Double value) {
            addCriterion("h3 <=", value, "h3");
            return (Criteria) this;
        }

        public Criteria andH3In(List<Double> values) {
            addCriterion("h3 in", values, "h3");
            return (Criteria) this;
        }

        public Criteria andH3NotIn(List<Double> values) {
            addCriterion("h3 not in", values, "h3");
            return (Criteria) this;
        }

        public Criteria andH3Between(Double value1, Double value2) {
            addCriterion("h3 between", value1, value2, "h3");
            return (Criteria) this;
        }

        public Criteria andH3NotBetween(Double value1, Double value2) {
            addCriterion("h3 not between", value1, value2, "h3");
            return (Criteria) this;
        }

        public Criteria andH4IsNull() {
            addCriterion("h4 is null");
            return (Criteria) this;
        }

        public Criteria andH4IsNotNull() {
            addCriterion("h4 is not null");
            return (Criteria) this;
        }

        public Criteria andH4EqualTo(Double value) {
            addCriterion("h4 =", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4NotEqualTo(Double value) {
            addCriterion("h4 <>", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4GreaterThan(Double value) {
            addCriterion("h4 >", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4GreaterThanOrEqualTo(Double value) {
            addCriterion("h4 >=", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4LessThan(Double value) {
            addCriterion("h4 <", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4LessThanOrEqualTo(Double value) {
            addCriterion("h4 <=", value, "h4");
            return (Criteria) this;
        }

        public Criteria andH4In(List<Double> values) {
            addCriterion("h4 in", values, "h4");
            return (Criteria) this;
        }

        public Criteria andH4NotIn(List<Double> values) {
            addCriterion("h4 not in", values, "h4");
            return (Criteria) this;
        }

        public Criteria andH4Between(Double value1, Double value2) {
            addCriterion("h4 between", value1, value2, "h4");
            return (Criteria) this;
        }

        public Criteria andH4NotBetween(Double value1, Double value2) {
            addCriterion("h4 not between", value1, value2, "h4");
            return (Criteria) this;
        }

        public Criteria andH5IsNull() {
            addCriterion("h5 is null");
            return (Criteria) this;
        }

        public Criteria andH5IsNotNull() {
            addCriterion("h5 is not null");
            return (Criteria) this;
        }

        public Criteria andH5EqualTo(Double value) {
            addCriterion("h5 =", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5NotEqualTo(Double value) {
            addCriterion("h5 <>", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5GreaterThan(Double value) {
            addCriterion("h5 >", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5GreaterThanOrEqualTo(Double value) {
            addCriterion("h5 >=", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5LessThan(Double value) {
            addCriterion("h5 <", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5LessThanOrEqualTo(Double value) {
            addCriterion("h5 <=", value, "h5");
            return (Criteria) this;
        }

        public Criteria andH5In(List<Double> values) {
            addCriterion("h5 in", values, "h5");
            return (Criteria) this;
        }

        public Criteria andH5NotIn(List<Double> values) {
            addCriterion("h5 not in", values, "h5");
            return (Criteria) this;
        }

        public Criteria andH5Between(Double value1, Double value2) {
            addCriterion("h5 between", value1, value2, "h5");
            return (Criteria) this;
        }

        public Criteria andH5NotBetween(Double value1, Double value2) {
            addCriterion("h5 not between", value1, value2, "h5");
            return (Criteria) this;
        }

        public Criteria andH6IsNull() {
            addCriterion("h6 is null");
            return (Criteria) this;
        }

        public Criteria andH6IsNotNull() {
            addCriterion("h6 is not null");
            return (Criteria) this;
        }

        public Criteria andH6EqualTo(Double value) {
            addCriterion("h6 =", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6NotEqualTo(Double value) {
            addCriterion("h6 <>", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6GreaterThan(Double value) {
            addCriterion("h6 >", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6GreaterThanOrEqualTo(Double value) {
            addCriterion("h6 >=", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6LessThan(Double value) {
            addCriterion("h6 <", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6LessThanOrEqualTo(Double value) {
            addCriterion("h6 <=", value, "h6");
            return (Criteria) this;
        }

        public Criteria andH6In(List<Double> values) {
            addCriterion("h6 in", values, "h6");
            return (Criteria) this;
        }

        public Criteria andH6NotIn(List<Double> values) {
            addCriterion("h6 not in", values, "h6");
            return (Criteria) this;
        }

        public Criteria andH6Between(Double value1, Double value2) {
            addCriterion("h6 between", value1, value2, "h6");
            return (Criteria) this;
        }

        public Criteria andH6NotBetween(Double value1, Double value2) {
            addCriterion("h6 not between", value1, value2, "h6");
            return (Criteria) this;
        }

        public Criteria andH7IsNull() {
            addCriterion("h7 is null");
            return (Criteria) this;
        }

        public Criteria andH7IsNotNull() {
            addCriterion("h7 is not null");
            return (Criteria) this;
        }

        public Criteria andH7EqualTo(Double value) {
            addCriterion("h7 =", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7NotEqualTo(Double value) {
            addCriterion("h7 <>", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7GreaterThan(Double value) {
            addCriterion("h7 >", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7GreaterThanOrEqualTo(Double value) {
            addCriterion("h7 >=", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7LessThan(Double value) {
            addCriterion("h7 <", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7LessThanOrEqualTo(Double value) {
            addCriterion("h7 <=", value, "h7");
            return (Criteria) this;
        }

        public Criteria andH7In(List<Double> values) {
            addCriterion("h7 in", values, "h7");
            return (Criteria) this;
        }

        public Criteria andH7NotIn(List<Double> values) {
            addCriterion("h7 not in", values, "h7");
            return (Criteria) this;
        }

        public Criteria andH7Between(Double value1, Double value2) {
            addCriterion("h7 between", value1, value2, "h7");
            return (Criteria) this;
        }

        public Criteria andH7NotBetween(Double value1, Double value2) {
            addCriterion("h7 not between", value1, value2, "h7");
            return (Criteria) this;
        }

        public Criteria andH8IsNull() {
            addCriterion("h8 is null");
            return (Criteria) this;
        }

        public Criteria andH8IsNotNull() {
            addCriterion("h8 is not null");
            return (Criteria) this;
        }

        public Criteria andH8EqualTo(Double value) {
            addCriterion("h8 =", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8NotEqualTo(Double value) {
            addCriterion("h8 <>", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8GreaterThan(Double value) {
            addCriterion("h8 >", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8GreaterThanOrEqualTo(Double value) {
            addCriterion("h8 >=", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8LessThan(Double value) {
            addCriterion("h8 <", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8LessThanOrEqualTo(Double value) {
            addCriterion("h8 <=", value, "h8");
            return (Criteria) this;
        }

        public Criteria andH8In(List<Double> values) {
            addCriterion("h8 in", values, "h8");
            return (Criteria) this;
        }

        public Criteria andH8NotIn(List<Double> values) {
            addCriterion("h8 not in", values, "h8");
            return (Criteria) this;
        }

        public Criteria andH8Between(Double value1, Double value2) {
            addCriterion("h8 between", value1, value2, "h8");
            return (Criteria) this;
        }

        public Criteria andH8NotBetween(Double value1, Double value2) {
            addCriterion("h8 not between", value1, value2, "h8");
            return (Criteria) this;
        }

        public Criteria andH9IsNull() {
            addCriterion("h9 is null");
            return (Criteria) this;
        }

        public Criteria andH9IsNotNull() {
            addCriterion("h9 is not null");
            return (Criteria) this;
        }

        public Criteria andH9EqualTo(Double value) {
            addCriterion("h9 =", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9NotEqualTo(Double value) {
            addCriterion("h9 <>", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9GreaterThan(Double value) {
            addCriterion("h9 >", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9GreaterThanOrEqualTo(Double value) {
            addCriterion("h9 >=", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9LessThan(Double value) {
            addCriterion("h9 <", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9LessThanOrEqualTo(Double value) {
            addCriterion("h9 <=", value, "h9");
            return (Criteria) this;
        }

        public Criteria andH9In(List<Double> values) {
            addCriterion("h9 in", values, "h9");
            return (Criteria) this;
        }

        public Criteria andH9NotIn(List<Double> values) {
            addCriterion("h9 not in", values, "h9");
            return (Criteria) this;
        }

        public Criteria andH9Between(Double value1, Double value2) {
            addCriterion("h9 between", value1, value2, "h9");
            return (Criteria) this;
        }

        public Criteria andH9NotBetween(Double value1, Double value2) {
            addCriterion("h9 not between", value1, value2, "h9");
            return (Criteria) this;
        }

        public Criteria andH10IsNull() {
            addCriterion("h10 is null");
            return (Criteria) this;
        }

        public Criteria andH10IsNotNull() {
            addCriterion("h10 is not null");
            return (Criteria) this;
        }

        public Criteria andH10EqualTo(Double value) {
            addCriterion("h10 =", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10NotEqualTo(Double value) {
            addCriterion("h10 <>", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10GreaterThan(Double value) {
            addCriterion("h10 >", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10GreaterThanOrEqualTo(Double value) {
            addCriterion("h10 >=", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10LessThan(Double value) {
            addCriterion("h10 <", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10LessThanOrEqualTo(Double value) {
            addCriterion("h10 <=", value, "h10");
            return (Criteria) this;
        }

        public Criteria andH10In(List<Double> values) {
            addCriterion("h10 in", values, "h10");
            return (Criteria) this;
        }

        public Criteria andH10NotIn(List<Double> values) {
            addCriterion("h10 not in", values, "h10");
            return (Criteria) this;
        }

        public Criteria andH10Between(Double value1, Double value2) {
            addCriterion("h10 between", value1, value2, "h10");
            return (Criteria) this;
        }

        public Criteria andH10NotBetween(Double value1, Double value2) {
            addCriterion("h10 not between", value1, value2, "h10");
            return (Criteria) this;
        }

        public Criteria andH11IsNull() {
            addCriterion("h11 is null");
            return (Criteria) this;
        }

        public Criteria andH11IsNotNull() {
            addCriterion("h11 is not null");
            return (Criteria) this;
        }

        public Criteria andH11EqualTo(Double value) {
            addCriterion("h11 =", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11NotEqualTo(Double value) {
            addCriterion("h11 <>", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11GreaterThan(Double value) {
            addCriterion("h11 >", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11GreaterThanOrEqualTo(Double value) {
            addCriterion("h11 >=", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11LessThan(Double value) {
            addCriterion("h11 <", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11LessThanOrEqualTo(Double value) {
            addCriterion("h11 <=", value, "h11");
            return (Criteria) this;
        }

        public Criteria andH11In(List<Double> values) {
            addCriterion("h11 in", values, "h11");
            return (Criteria) this;
        }

        public Criteria andH11NotIn(List<Double> values) {
            addCriterion("h11 not in", values, "h11");
            return (Criteria) this;
        }

        public Criteria andH11Between(Double value1, Double value2) {
            addCriterion("h11 between", value1, value2, "h11");
            return (Criteria) this;
        }

        public Criteria andH11NotBetween(Double value1, Double value2) {
            addCriterion("h11 not between", value1, value2, "h11");
            return (Criteria) this;
        }

        public Criteria andH12IsNull() {
            addCriterion("h12 is null");
            return (Criteria) this;
        }

        public Criteria andH12IsNotNull() {
            addCriterion("h12 is not null");
            return (Criteria) this;
        }

        public Criteria andH12EqualTo(Double value) {
            addCriterion("h12 =", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12NotEqualTo(Double value) {
            addCriterion("h12 <>", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12GreaterThan(Double value) {
            addCriterion("h12 >", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12GreaterThanOrEqualTo(Double value) {
            addCriterion("h12 >=", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12LessThan(Double value) {
            addCriterion("h12 <", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12LessThanOrEqualTo(Double value) {
            addCriterion("h12 <=", value, "h12");
            return (Criteria) this;
        }

        public Criteria andH12In(List<Double> values) {
            addCriterion("h12 in", values, "h12");
            return (Criteria) this;
        }

        public Criteria andH12NotIn(List<Double> values) {
            addCriterion("h12 not in", values, "h12");
            return (Criteria) this;
        }

        public Criteria andH12Between(Double value1, Double value2) {
            addCriterion("h12 between", value1, value2, "h12");
            return (Criteria) this;
        }

        public Criteria andH12NotBetween(Double value1, Double value2) {
            addCriterion("h12 not between", value1, value2, "h12");
            return (Criteria) this;
        }

        public Criteria andH13IsNull() {
            addCriterion("h13 is null");
            return (Criteria) this;
        }

        public Criteria andH13IsNotNull() {
            addCriterion("h13 is not null");
            return (Criteria) this;
        }

        public Criteria andH13EqualTo(Double value) {
            addCriterion("h13 =", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13NotEqualTo(Double value) {
            addCriterion("h13 <>", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13GreaterThan(Double value) {
            addCriterion("h13 >", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13GreaterThanOrEqualTo(Double value) {
            addCriterion("h13 >=", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13LessThan(Double value) {
            addCriterion("h13 <", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13LessThanOrEqualTo(Double value) {
            addCriterion("h13 <=", value, "h13");
            return (Criteria) this;
        }

        public Criteria andH13In(List<Double> values) {
            addCriterion("h13 in", values, "h13");
            return (Criteria) this;
        }

        public Criteria andH13NotIn(List<Double> values) {
            addCriterion("h13 not in", values, "h13");
            return (Criteria) this;
        }

        public Criteria andH13Between(Double value1, Double value2) {
            addCriterion("h13 between", value1, value2, "h13");
            return (Criteria) this;
        }

        public Criteria andH13NotBetween(Double value1, Double value2) {
            addCriterion("h13 not between", value1, value2, "h13");
            return (Criteria) this;
        }

        public Criteria andH14IsNull() {
            addCriterion("h14 is null");
            return (Criteria) this;
        }

        public Criteria andH14IsNotNull() {
            addCriterion("h14 is not null");
            return (Criteria) this;
        }

        public Criteria andH14EqualTo(Double value) {
            addCriterion("h14 =", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14NotEqualTo(Double value) {
            addCriterion("h14 <>", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14GreaterThan(Double value) {
            addCriterion("h14 >", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14GreaterThanOrEqualTo(Double value) {
            addCriterion("h14 >=", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14LessThan(Double value) {
            addCriterion("h14 <", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14LessThanOrEqualTo(Double value) {
            addCriterion("h14 <=", value, "h14");
            return (Criteria) this;
        }

        public Criteria andH14In(List<Double> values) {
            addCriterion("h14 in", values, "h14");
            return (Criteria) this;
        }

        public Criteria andH14NotIn(List<Double> values) {
            addCriterion("h14 not in", values, "h14");
            return (Criteria) this;
        }

        public Criteria andH14Between(Double value1, Double value2) {
            addCriterion("h14 between", value1, value2, "h14");
            return (Criteria) this;
        }

        public Criteria andH14NotBetween(Double value1, Double value2) {
            addCriterion("h14 not between", value1, value2, "h14");
            return (Criteria) this;
        }

        public Criteria andH15IsNull() {
            addCriterion("h15 is null");
            return (Criteria) this;
        }

        public Criteria andH15IsNotNull() {
            addCriterion("h15 is not null");
            return (Criteria) this;
        }

        public Criteria andH15EqualTo(Double value) {
            addCriterion("h15 =", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15NotEqualTo(Double value) {
            addCriterion("h15 <>", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15GreaterThan(Double value) {
            addCriterion("h15 >", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15GreaterThanOrEqualTo(Double value) {
            addCriterion("h15 >=", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15LessThan(Double value) {
            addCriterion("h15 <", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15LessThanOrEqualTo(Double value) {
            addCriterion("h15 <=", value, "h15");
            return (Criteria) this;
        }

        public Criteria andH15In(List<Double> values) {
            addCriterion("h15 in", values, "h15");
            return (Criteria) this;
        }

        public Criteria andH15NotIn(List<Double> values) {
            addCriterion("h15 not in", values, "h15");
            return (Criteria) this;
        }

        public Criteria andH15Between(Double value1, Double value2) {
            addCriterion("h15 between", value1, value2, "h15");
            return (Criteria) this;
        }

        public Criteria andH15NotBetween(Double value1, Double value2) {
            addCriterion("h15 not between", value1, value2, "h15");
            return (Criteria) this;
        }

        public Criteria andH16IsNull() {
            addCriterion("h16 is null");
            return (Criteria) this;
        }

        public Criteria andH16IsNotNull() {
            addCriterion("h16 is not null");
            return (Criteria) this;
        }

        public Criteria andH16EqualTo(Double value) {
            addCriterion("h16 =", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16NotEqualTo(Double value) {
            addCriterion("h16 <>", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16GreaterThan(Double value) {
            addCriterion("h16 >", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16GreaterThanOrEqualTo(Double value) {
            addCriterion("h16 >=", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16LessThan(Double value) {
            addCriterion("h16 <", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16LessThanOrEqualTo(Double value) {
            addCriterion("h16 <=", value, "h16");
            return (Criteria) this;
        }

        public Criteria andH16In(List<Double> values) {
            addCriterion("h16 in", values, "h16");
            return (Criteria) this;
        }

        public Criteria andH16NotIn(List<Double> values) {
            addCriterion("h16 not in", values, "h16");
            return (Criteria) this;
        }

        public Criteria andH16Between(Double value1, Double value2) {
            addCriterion("h16 between", value1, value2, "h16");
            return (Criteria) this;
        }

        public Criteria andH16NotBetween(Double value1, Double value2) {
            addCriterion("h16 not between", value1, value2, "h16");
            return (Criteria) this;
        }

        public Criteria andH17IsNull() {
            addCriterion("h17 is null");
            return (Criteria) this;
        }

        public Criteria andH17IsNotNull() {
            addCriterion("h17 is not null");
            return (Criteria) this;
        }

        public Criteria andH17EqualTo(Double value) {
            addCriterion("h17 =", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17NotEqualTo(Double value) {
            addCriterion("h17 <>", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17GreaterThan(Double value) {
            addCriterion("h17 >", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17GreaterThanOrEqualTo(Double value) {
            addCriterion("h17 >=", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17LessThan(Double value) {
            addCriterion("h17 <", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17LessThanOrEqualTo(Double value) {
            addCriterion("h17 <=", value, "h17");
            return (Criteria) this;
        }

        public Criteria andH17In(List<Double> values) {
            addCriterion("h17 in", values, "h17");
            return (Criteria) this;
        }

        public Criteria andH17NotIn(List<Double> values) {
            addCriterion("h17 not in", values, "h17");
            return (Criteria) this;
        }

        public Criteria andH17Between(Double value1, Double value2) {
            addCriterion("h17 between", value1, value2, "h17");
            return (Criteria) this;
        }

        public Criteria andH17NotBetween(Double value1, Double value2) {
            addCriterion("h17 not between", value1, value2, "h17");
            return (Criteria) this;
        }

        public Criteria andH18IsNull() {
            addCriterion("h18 is null");
            return (Criteria) this;
        }

        public Criteria andH18IsNotNull() {
            addCriterion("h18 is not null");
            return (Criteria) this;
        }

        public Criteria andH18EqualTo(Double value) {
            addCriterion("h18 =", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18NotEqualTo(Double value) {
            addCriterion("h18 <>", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18GreaterThan(Double value) {
            addCriterion("h18 >", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18GreaterThanOrEqualTo(Double value) {
            addCriterion("h18 >=", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18LessThan(Double value) {
            addCriterion("h18 <", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18LessThanOrEqualTo(Double value) {
            addCriterion("h18 <=", value, "h18");
            return (Criteria) this;
        }

        public Criteria andH18In(List<Double> values) {
            addCriterion("h18 in", values, "h18");
            return (Criteria) this;
        }

        public Criteria andH18NotIn(List<Double> values) {
            addCriterion("h18 not in", values, "h18");
            return (Criteria) this;
        }

        public Criteria andH18Between(Double value1, Double value2) {
            addCriterion("h18 between", value1, value2, "h18");
            return (Criteria) this;
        }

        public Criteria andH18NotBetween(Double value1, Double value2) {
            addCriterion("h18 not between", value1, value2, "h18");
            return (Criteria) this;
        }

        public Criteria andH19IsNull() {
            addCriterion("h19 is null");
            return (Criteria) this;
        }

        public Criteria andH19IsNotNull() {
            addCriterion("h19 is not null");
            return (Criteria) this;
        }

        public Criteria andH19EqualTo(Double value) {
            addCriterion("h19 =", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19NotEqualTo(Double value) {
            addCriterion("h19 <>", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19GreaterThan(Double value) {
            addCriterion("h19 >", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19GreaterThanOrEqualTo(Double value) {
            addCriterion("h19 >=", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19LessThan(Double value) {
            addCriterion("h19 <", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19LessThanOrEqualTo(Double value) {
            addCriterion("h19 <=", value, "h19");
            return (Criteria) this;
        }

        public Criteria andH19In(List<Double> values) {
            addCriterion("h19 in", values, "h19");
            return (Criteria) this;
        }

        public Criteria andH19NotIn(List<Double> values) {
            addCriterion("h19 not in", values, "h19");
            return (Criteria) this;
        }

        public Criteria andH19Between(Double value1, Double value2) {
            addCriterion("h19 between", value1, value2, "h19");
            return (Criteria) this;
        }

        public Criteria andH19NotBetween(Double value1, Double value2) {
            addCriterion("h19 not between", value1, value2, "h19");
            return (Criteria) this;
        }

        public Criteria andH20IsNull() {
            addCriterion("h20 is null");
            return (Criteria) this;
        }

        public Criteria andH20IsNotNull() {
            addCriterion("h20 is not null");
            return (Criteria) this;
        }

        public Criteria andH20EqualTo(Double value) {
            addCriterion("h20 =", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20NotEqualTo(Double value) {
            addCriterion("h20 <>", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20GreaterThan(Double value) {
            addCriterion("h20 >", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20GreaterThanOrEqualTo(Double value) {
            addCriterion("h20 >=", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20LessThan(Double value) {
            addCriterion("h20 <", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20LessThanOrEqualTo(Double value) {
            addCriterion("h20 <=", value, "h20");
            return (Criteria) this;
        }

        public Criteria andH20In(List<Double> values) {
            addCriterion("h20 in", values, "h20");
            return (Criteria) this;
        }

        public Criteria andH20NotIn(List<Double> values) {
            addCriterion("h20 not in", values, "h20");
            return (Criteria) this;
        }

        public Criteria andH20Between(Double value1, Double value2) {
            addCriterion("h20 between", value1, value2, "h20");
            return (Criteria) this;
        }

        public Criteria andH20NotBetween(Double value1, Double value2) {
            addCriterion("h20 not between", value1, value2, "h20");
            return (Criteria) this;
        }

        public Criteria andH21IsNull() {
            addCriterion("h21 is null");
            return (Criteria) this;
        }

        public Criteria andH21IsNotNull() {
            addCriterion("h21 is not null");
            return (Criteria) this;
        }

        public Criteria andH21EqualTo(Double value) {
            addCriterion("h21 =", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21NotEqualTo(Double value) {
            addCriterion("h21 <>", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21GreaterThan(Double value) {
            addCriterion("h21 >", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21GreaterThanOrEqualTo(Double value) {
            addCriterion("h21 >=", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21LessThan(Double value) {
            addCriterion("h21 <", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21LessThanOrEqualTo(Double value) {
            addCriterion("h21 <=", value, "h21");
            return (Criteria) this;
        }

        public Criteria andH21In(List<Double> values) {
            addCriterion("h21 in", values, "h21");
            return (Criteria) this;
        }

        public Criteria andH21NotIn(List<Double> values) {
            addCriterion("h21 not in", values, "h21");
            return (Criteria) this;
        }

        public Criteria andH21Between(Double value1, Double value2) {
            addCriterion("h21 between", value1, value2, "h21");
            return (Criteria) this;
        }

        public Criteria andH21NotBetween(Double value1, Double value2) {
            addCriterion("h21 not between", value1, value2, "h21");
            return (Criteria) this;
        }

        public Criteria andH22IsNull() {
            addCriterion("h22 is null");
            return (Criteria) this;
        }

        public Criteria andH22IsNotNull() {
            addCriterion("h22 is not null");
            return (Criteria) this;
        }

        public Criteria andH22EqualTo(Double value) {
            addCriterion("h22 =", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22NotEqualTo(Double value) {
            addCriterion("h22 <>", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22GreaterThan(Double value) {
            addCriterion("h22 >", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22GreaterThanOrEqualTo(Double value) {
            addCriterion("h22 >=", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22LessThan(Double value) {
            addCriterion("h22 <", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22LessThanOrEqualTo(Double value) {
            addCriterion("h22 <=", value, "h22");
            return (Criteria) this;
        }

        public Criteria andH22In(List<Double> values) {
            addCriterion("h22 in", values, "h22");
            return (Criteria) this;
        }

        public Criteria andH22NotIn(List<Double> values) {
            addCriterion("h22 not in", values, "h22");
            return (Criteria) this;
        }

        public Criteria andH22Between(Double value1, Double value2) {
            addCriterion("h22 between", value1, value2, "h22");
            return (Criteria) this;
        }

        public Criteria andH22NotBetween(Double value1, Double value2) {
            addCriterion("h22 not between", value1, value2, "h22");
            return (Criteria) this;
        }

        public Criteria andH23IsNull() {
            addCriterion("h23 is null");
            return (Criteria) this;
        }

        public Criteria andH23IsNotNull() {
            addCriterion("h23 is not null");
            return (Criteria) this;
        }

        public Criteria andH23EqualTo(Double value) {
            addCriterion("h23 =", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23NotEqualTo(Double value) {
            addCriterion("h23 <>", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23GreaterThan(Double value) {
            addCriterion("h23 >", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23GreaterThanOrEqualTo(Double value) {
            addCriterion("h23 >=", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23LessThan(Double value) {
            addCriterion("h23 <", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23LessThanOrEqualTo(Double value) {
            addCriterion("h23 <=", value, "h23");
            return (Criteria) this;
        }

        public Criteria andH23In(List<Double> values) {
            addCriterion("h23 in", values, "h23");
            return (Criteria) this;
        }

        public Criteria andH23NotIn(List<Double> values) {
            addCriterion("h23 not in", values, "h23");
            return (Criteria) this;
        }

        public Criteria andH23Between(Double value1, Double value2) {
            addCriterion("h23 between", value1, value2, "h23");
            return (Criteria) this;
        }

        public Criteria andH23NotBetween(Double value1, Double value2) {
            addCriterion("h23 not between", value1, value2, "h23");
            return (Criteria) this;
        }

        public Criteria andH24IsNull() {
            addCriterion("h24 is null");
            return (Criteria) this;
        }

        public Criteria andH24IsNotNull() {
            addCriterion("h24 is not null");
            return (Criteria) this;
        }

        public Criteria andH24EqualTo(Double value) {
            addCriterion("h24 =", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24NotEqualTo(Double value) {
            addCriterion("h24 <>", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24GreaterThan(Double value) {
            addCriterion("h24 >", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24GreaterThanOrEqualTo(Double value) {
            addCriterion("h24 >=", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24LessThan(Double value) {
            addCriterion("h24 <", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24LessThanOrEqualTo(Double value) {
            addCriterion("h24 <=", value, "h24");
            return (Criteria) this;
        }

        public Criteria andH24In(List<Double> values) {
            addCriterion("h24 in", values, "h24");
            return (Criteria) this;
        }

        public Criteria andH24NotIn(List<Double> values) {
            addCriterion("h24 not in", values, "h24");
            return (Criteria) this;
        }

        public Criteria andH24Between(Double value1, Double value2) {
            addCriterion("h24 between", value1, value2, "h24");
            return (Criteria) this;
        }

        public Criteria andH24NotBetween(Double value1, Double value2) {
            addCriterion("h24 not between", value1, value2, "h24");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNull() {
            addCriterion("addtime is null");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNotNull() {
            addCriterion("addtime is not null");
            return (Criteria) this;
        }

        public Criteria andAddtimeEqualTo(Date value) {
            addCriterionForJDBCDate("addtime =", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("addtime <>", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThan(Date value) {
            addCriterionForJDBCDate("addtime >", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("addtime >=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThan(Date value) {
            addCriterionForJDBCDate("addtime <", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("addtime <=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeIn(List<Date> values) {
            addCriterionForJDBCDate("addtime in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("addtime not in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("addtime between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("addtime not between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andElyearIsNull() {
            addCriterion("elYear is null");
            return (Criteria) this;
        }

        public Criteria andElyearIsNotNull() {
            addCriterion("elYear is not null");
            return (Criteria) this;
        }

        public Criteria andElyearEqualTo(Integer value) {
            addCriterion("elYear =", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearNotEqualTo(Integer value) {
            addCriterion("elYear <>", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearGreaterThan(Integer value) {
            addCriterion("elYear >", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearGreaterThanOrEqualTo(Integer value) {
            addCriterion("elYear >=", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearLessThan(Integer value) {
            addCriterion("elYear <", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearLessThanOrEqualTo(Integer value) {
            addCriterion("elYear <=", value, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearIn(List<Integer> values) {
            addCriterion("elYear in", values, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearNotIn(List<Integer> values) {
            addCriterion("elYear not in", values, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearBetween(Integer value1, Integer value2) {
            addCriterion("elYear between", value1, value2, "elyear");
            return (Criteria) this;
        }

        public Criteria andElyearNotBetween(Integer value1, Integer value2) {
            addCriterion("elYear not between", value1, value2, "elyear");
            return (Criteria) this;
        }

        public Criteria andElmonthIsNull() {
            addCriterion("elMonth is null");
            return (Criteria) this;
        }

        public Criteria andElmonthIsNotNull() {
            addCriterion("elMonth is not null");
            return (Criteria) this;
        }

        public Criteria andElmonthEqualTo(Integer value) {
            addCriterion("elMonth =", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthNotEqualTo(Integer value) {
            addCriterion("elMonth <>", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthGreaterThan(Integer value) {
            addCriterion("elMonth >", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthGreaterThanOrEqualTo(Integer value) {
            addCriterion("elMonth >=", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthLessThan(Integer value) {
            addCriterion("elMonth <", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthLessThanOrEqualTo(Integer value) {
            addCriterion("elMonth <=", value, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthIn(List<Integer> values) {
            addCriterion("elMonth in", values, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthNotIn(List<Integer> values) {
            addCriterion("elMonth not in", values, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthBetween(Integer value1, Integer value2) {
            addCriterion("elMonth between", value1, value2, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElmonthNotBetween(Integer value1, Integer value2) {
            addCriterion("elMonth not between", value1, value2, "elmonth");
            return (Criteria) this;
        }

        public Criteria andElweekIsNull() {
            addCriterion("elWeek is null");
            return (Criteria) this;
        }

        public Criteria andElweekIsNotNull() {
            addCriterion("elWeek is not null");
            return (Criteria) this;
        }

        public Criteria andElweekEqualTo(Integer value) {
            addCriterion("elWeek =", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekNotEqualTo(Integer value) {
            addCriterion("elWeek <>", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekGreaterThan(Integer value) {
            addCriterion("elWeek >", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekGreaterThanOrEqualTo(Integer value) {
            addCriterion("elWeek >=", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekLessThan(Integer value) {
            addCriterion("elWeek <", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekLessThanOrEqualTo(Integer value) {
            addCriterion("elWeek <=", value, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekIn(List<Integer> values) {
            addCriterion("elWeek in", values, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekNotIn(List<Integer> values) {
            addCriterion("elWeek not in", values, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekBetween(Integer value1, Integer value2) {
            addCriterion("elWeek between", value1, value2, "elweek");
            return (Criteria) this;
        }

        public Criteria andElweekNotBetween(Integer value1, Integer value2) {
            addCriterion("elWeek not between", value1, value2, "elweek");
            return (Criteria) this;
        }

        public Criteria andDaytotalqIsNull() {
            addCriterion("dayTotalQ is null");
            return (Criteria) this;
        }

        public Criteria andDaytotalqIsNotNull() {
            addCriterion("dayTotalQ is not null");
            return (Criteria) this;
        }

        public Criteria andDaytotalqEqualTo(Double value) {
            addCriterion("dayTotalQ =", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqNotEqualTo(Double value) {
            addCriterion("dayTotalQ <>", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqGreaterThan(Double value) {
            addCriterion("dayTotalQ >", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqGreaterThanOrEqualTo(Double value) {
            addCriterion("dayTotalQ >=", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqLessThan(Double value) {
            addCriterion("dayTotalQ <", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqLessThanOrEqualTo(Double value) {
            addCriterion("dayTotalQ <=", value, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqIn(List<Double> values) {
            addCriterion("dayTotalQ in", values, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqNotIn(List<Double> values) {
            addCriterion("dayTotalQ not in", values, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqBetween(Double value1, Double value2) {
            addCriterion("dayTotalQ between", value1, value2, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalqNotBetween(Double value1, Double value2) {
            addCriterion("dayTotalQ not between", value1, value2, "daytotalq");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeIsNull() {
            addCriterion("dayTotalFee is null");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeIsNotNull() {
            addCriterion("dayTotalFee is not null");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeEqualTo(Double value) {
            addCriterion("dayTotalFee =", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeNotEqualTo(Double value) {
            addCriterion("dayTotalFee <>", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeGreaterThan(Double value) {
            addCriterion("dayTotalFee >", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeGreaterThanOrEqualTo(Double value) {
            addCriterion("dayTotalFee >=", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeLessThan(Double value) {
            addCriterion("dayTotalFee <", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeLessThanOrEqualTo(Double value) {
            addCriterion("dayTotalFee <=", value, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeIn(List<Double> values) {
            addCriterion("dayTotalFee in", values, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeNotIn(List<Double> values) {
            addCriterion("dayTotalFee not in", values, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeBetween(Double value1, Double value2) {
            addCriterion("dayTotalFee between", value1, value2, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaytotalfeeNotBetween(Double value1, Double value2) {
            addCriterion("dayTotalFee not between", value1, value2, "daytotalfee");
            return (Criteria) this;
        }

        public Criteria andDaychargeIsNull() {
            addCriterion("dayCharge is null");
            return (Criteria) this;
        }

        public Criteria andDaychargeIsNotNull() {
            addCriterion("dayCharge is not null");
            return (Criteria) this;
        }

        public Criteria andDaychargeEqualTo(Double value) {
            addCriterion("dayCharge =", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeNotEqualTo(Double value) {
            addCriterion("dayCharge <>", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeGreaterThan(Double value) {
            addCriterion("dayCharge >", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeGreaterThanOrEqualTo(Double value) {
            addCriterion("dayCharge >=", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeLessThan(Double value) {
            addCriterion("dayCharge <", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeLessThanOrEqualTo(Double value) {
            addCriterion("dayCharge <=", value, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeIn(List<Double> values) {
            addCriterion("dayCharge in", values, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeNotIn(List<Double> values) {
            addCriterion("dayCharge not in", values, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeBetween(Double value1, Double value2) {
            addCriterion("dayCharge between", value1, value2, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDaychargeNotBetween(Double value1, Double value2) {
            addCriterion("dayCharge not between", value1, value2, "daycharge");
            return (Criteria) this;
        }

        public Criteria andDevtotalqIsNull() {
            addCriterion("devTotalQ is null");
            return (Criteria) this;
        }

        public Criteria andDevtotalqIsNotNull() {
            addCriterion("devTotalQ is not null");
            return (Criteria) this;
        }

        public Criteria andDevtotalqEqualTo(Double value) {
            addCriterion("devTotalQ =", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqNotEqualTo(Double value) {
            addCriterion("devTotalQ <>", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqGreaterThan(Double value) {
            addCriterion("devTotalQ >", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqGreaterThanOrEqualTo(Double value) {
            addCriterion("devTotalQ >=", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqLessThan(Double value) {
            addCriterion("devTotalQ <", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqLessThanOrEqualTo(Double value) {
            addCriterion("devTotalQ <=", value, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqIn(List<Double> values) {
            addCriterion("devTotalQ in", values, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqNotIn(List<Double> values) {
            addCriterion("devTotalQ not in", values, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqBetween(Double value1, Double value2) {
            addCriterion("devTotalQ between", value1, value2, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andDevtotalqNotBetween(Double value1, Double value2) {
            addCriterion("devTotalQ not between", value1, value2, "devtotalq");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andIsresetIsNull() {
            addCriterion("isReset is null");
            return (Criteria) this;
        }

        public Criteria andIsresetIsNotNull() {
            addCriterion("isReset is not null");
            return (Criteria) this;
        }

        public Criteria andIsresetEqualTo(Integer value) {
            addCriterion("isReset =", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetNotEqualTo(Integer value) {
            addCriterion("isReset <>", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetGreaterThan(Integer value) {
            addCriterion("isReset >", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetGreaterThanOrEqualTo(Integer value) {
            addCriterion("isReset >=", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetLessThan(Integer value) {
            addCriterion("isReset <", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetLessThanOrEqualTo(Integer value) {
            addCriterion("isReset <=", value, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetIn(List<Integer> values) {
            addCriterion("isReset in", values, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetNotIn(List<Integer> values) {
            addCriterion("isReset not in", values, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetBetween(Integer value1, Integer value2) {
            addCriterion("isReset between", value1, value2, "isreset");
            return (Criteria) this;
        }

        public Criteria andIsresetNotBetween(Integer value1, Integer value2) {
            addCriterion("isReset not between", value1, value2, "isreset");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqIsNull() {
            addCriterion("beforeTodayTotalQ is null");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqIsNotNull() {
            addCriterion("beforeTodayTotalQ is not null");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqEqualTo(Double value) {
            addCriterion("beforeTodayTotalQ =", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqNotEqualTo(Double value) {
            addCriterion("beforeTodayTotalQ <>", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqGreaterThan(Double value) {
            addCriterion("beforeTodayTotalQ >", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqGreaterThanOrEqualTo(Double value) {
            addCriterion("beforeTodayTotalQ >=", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqLessThan(Double value) {
            addCriterion("beforeTodayTotalQ <", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqLessThanOrEqualTo(Double value) {
            addCriterion("beforeTodayTotalQ <=", value, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqIn(List<Double> values) {
            addCriterion("beforeTodayTotalQ in", values, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqNotIn(List<Double> values) {
            addCriterion("beforeTodayTotalQ not in", values, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqBetween(Double value1, Double value2) {
            addCriterion("beforeTodayTotalQ between", value1, value2, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalqNotBetween(Double value1, Double value2) {
            addCriterion("beforeTodayTotalQ not between", value1, value2, "beforetodaytotalq");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeIsNull() {
            addCriterion("beforeTodayTotalFee is null");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeIsNotNull() {
            addCriterion("beforeTodayTotalFee is not null");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeEqualTo(Double value) {
            addCriterion("beforeTodayTotalFee =", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeNotEqualTo(Double value) {
            addCriterion("beforeTodayTotalFee <>", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeGreaterThan(Double value) {
            addCriterion("beforeTodayTotalFee >", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeGreaterThanOrEqualTo(Double value) {
            addCriterion("beforeTodayTotalFee >=", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeLessThan(Double value) {
            addCriterion("beforeTodayTotalFee <", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeLessThanOrEqualTo(Double value) {
            addCriterion("beforeTodayTotalFee <=", value, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeIn(List<Double> values) {
            addCriterion("beforeTodayTotalFee in", values, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeNotIn(List<Double> values) {
            addCriterion("beforeTodayTotalFee not in", values, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeBetween(Double value1, Double value2) {
            addCriterion("beforeTodayTotalFee between", value1, value2, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andBeforetodaytotalfeeNotBetween(Double value1, Double value2) {
            addCriterion("beforeTodayTotalFee not between", value1, value2, "beforetodaytotalfee");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqIsNull() {
            addCriterion("devRealTotalQ is null");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqIsNotNull() {
            addCriterion("devRealTotalQ is not null");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqEqualTo(Integer value) {
            addCriterion("devRealTotalQ =", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqNotEqualTo(Integer value) {
            addCriterion("devRealTotalQ <>", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqGreaterThan(Integer value) {
            addCriterion("devRealTotalQ >", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqGreaterThanOrEqualTo(Integer value) {
            addCriterion("devRealTotalQ >=", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqLessThan(Integer value) {
            addCriterion("devRealTotalQ <", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqLessThanOrEqualTo(Integer value) {
            addCriterion("devRealTotalQ <=", value, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqIn(List<Integer> values) {
            addCriterion("devRealTotalQ in", values, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqNotIn(List<Integer> values) {
            addCriterion("devRealTotalQ not in", values, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqBetween(Integer value1, Integer value2) {
            addCriterion("devRealTotalQ between", value1, value2, "devrealtotalq");
            return (Criteria) this;
        }

        public Criteria andDevrealtotalqNotBetween(Integer value1, Integer value2) {
            addCriterion("devRealTotalQ not between", value1, value2, "devrealtotalq");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}