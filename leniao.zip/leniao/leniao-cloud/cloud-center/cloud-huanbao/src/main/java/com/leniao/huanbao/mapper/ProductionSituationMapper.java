package com.leniao.huanbao.mapper;

import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ProductionSituationMapper {

    List<ReduceEmmissionDto> selectProductionSituationByNotAreaUser(@Param("projIds") List<Long> projIds, @Param("platformId") Integer platformId,
                                                                    @Param("endTime") String endTime, @Param("areaCode") AreaCodeJoinOther areaCode,
                                                                    @Param("userGrade") Integer userGrade, @Param("params") Map<String,Object> params);

    List<ReduceEmmissionDto> selectProductionSituationByAreaUser(@Param("agencyIds") List<Long> agencyIds, @Param("platformId") Integer platformId, @Param("params") Map<String,Object> params);
}
