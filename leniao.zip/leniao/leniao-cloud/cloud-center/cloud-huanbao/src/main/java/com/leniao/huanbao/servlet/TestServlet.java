package com.leniao.huanbao.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * @author guoliang.li
 * @date 2019/12/19 13:31
 * @description TODO
 */
@WebServlet(urlPatterns = "/testServlet", name = "这是一个测试Servlet")
public class TestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("=========这是Servlet GET 请求=========");
        resp.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setHeader("content-type", "text/html;charset=UTF-8");
        resp.getWriter().println("=========这是Servlet GET 请求=========");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("=========这是Servlet POST 请求=========");
        resp.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setHeader("content-type", "text/html;charset=UTF-8");
        resp.getWriter().println("=========这是Servlet POST 请求=========");
    }
}