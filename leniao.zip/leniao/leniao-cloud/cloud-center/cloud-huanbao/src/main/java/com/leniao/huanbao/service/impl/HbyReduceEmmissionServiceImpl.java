package com.leniao.huanbao.service.impl;

import cn.hutool.core.date.DateTime;
import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyAgencyExample;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlanExample;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;
import com.leniao.huanbao.mapper.AlternateProductionMapper;
import com.leniao.huanbao.mapper.HbyReduceEmmissionPlanMapper;
import com.leniao.huanbao.service.HbyReduceEmmissionService;
import com.leniao.huanbao.service.HbyReduceplanJoinProjectService;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减产减排方案service
 * @author: jiangdy
 * @create: 2019-12-20 18:20
 **/
@Service
public class HbyReduceEmmissionServiceImpl extends ServiceImpl<HbyReduceEmmissionPlanMapper, HbyReduceEmmissionPlan> implements HbyReduceEmmissionService {

    private static final Logger logger = LoggerFactory.getLogger(HbyReduceEmmissionServiceImpl.class);

    @Autowired
    private PermissionService permissionService;

    @Resource
    private HbyAgencyMapper hbyAgencyMapper;

    @Resource
    private AlternateProductionMapper alternateProductionMapper;

    @Resource
    private HbyReduceEmmissionPlanMapper hbyReduceEmmissionPlanMapper;

    @Autowired
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;

    @Override
    public long countByExample(HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Long planId) {
        return hbyReduceEmmissionPlanMapper.deleteByPrimaryKey(planId);
    }

    @Override
    public int insert(HbyReduceEmmissionPlan record) {
        return hbyReduceEmmissionPlanMapper.insert(record);
    }

    @Override
    public int insertSelective(HbyReduceEmmissionPlan record) {
        return hbyReduceEmmissionPlanMapper.insertSelective(record);
    }

    @Override
    public List<HbyReduceEmmissionPlan> selectByExampleWithBLOBs(HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.selectByExampleWithBLOBs(example);
    }

    @Override
    public List<HbyReduceEmmissionPlan> selectByExample(HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.selectByExample(example);
    }

    @Override
    public HbyReduceEmmissionPlan selectByPrimaryKey(Long planId) {
        return hbyReduceEmmissionPlanMapper.selectByPrimaryKey(planId);
    }

    @Override
    public int updateByExampleSelective(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExampleWithBLOBs(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.updateByExampleWithBLOBs(record, example);
    }

    @Override
    public int updateByExample(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example) {
        return hbyReduceEmmissionPlanMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(HbyReduceEmmissionPlan record) {
        return hbyReduceEmmissionPlanMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(HbyReduceEmmissionPlan record) {
        return hbyReduceEmmissionPlanMapper.updateByPrimaryKeyWithBLOBs(record);
    }

    @Override
    public int updateByPrimaryKey(HbyReduceEmmissionPlan record) {
        return hbyReduceEmmissionPlanMapper.updateByPrimaryKey(record);
    }

    /**
     * 添加减产减排方案
     *
     * @param userId             用户userID
     * @param reduceEmmissionDto 减产减排方案信息
     * @return
     */
    @Override
    public Long insertReduceEmmissionPlan(int userId, ReduceEmmissionDto reduceEmmissionDto) {

        // 获取区域码
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userId);
        if (areaCode == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        // 查询机构信息
        List<HbyAgency> agencyList = this.getAgencyInfo(areaCode);
        if (agencyList == null || agencyList.size() == 0) {
            logger.error("用户所在的行政机构不存在");
            throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
        }

        Long planId = new SnowflakeConfig().nextId();
        reduceEmmissionDto.setPlanId(planId);
        HbyReduceEmmissionPlan record = this.getHbyReduceEmmissionPlan(userId, agencyList.get(0).getId(), areaCode, reduceEmmissionDto, true);
        // 添加方案
        if (this.insertSelective(record) == 0) {
            return 0L;
        }
        return planId;
    }

    /**
     * 修改减产减排方案
     *
     * @param userId             用户userID
     * @param reduceEmmissionDto 减产减排方案信息
     * @return
     */
    @Override
    public Long updateReduceEmmissionPlan(int userId, ReduceEmmissionDto reduceEmmissionDto) {

        HbyReduceEmmissionPlan record = this.getHbyReduceEmmissionPlan(userId, 0, null, reduceEmmissionDto, false);
        // 修改方案
        if (this.updateByPrimaryKeySelective(record) == 0) {
            return 0L;
        }
        return record.getPlanId();
    }

    /**
     * 根据减排方案id删除方案，假删除
     *
     * @param userId 用户userID
     * @param planId 方案id
     * @return
     */
    @Override
    public boolean deleteReduceEmmissionPlan(int userId, Long planId) {

        return alternateProductionMapper.updateReduceEmmissionPlanState(userId, planId) > 0;
    }

    /**
     * 可变条件查询减排方案
     *
     * @param userGrade 区域用户等
     * @param areaCode  区域码
     * @param agcyId 机构id 非必须
     * @param beginTime 方案生效开始时间 非必须
     * @param endTime 方案生效结束时间 非必须
     * @param warnLevel 预警等级 非必须
     * @param isUsing 仅仅显示正在启用的方案 0-否， 1-是 非必须(默认0)
     * @return
     */
    @Override
    public List<ReduceEmmissionDto> selectReduceEmmissionPlan(Long agencyId, Integer userGrade, AreaCodeJoinOther areaCode,
                                                              Integer agcyId, Integer warnLevel, Integer isUsing, Date nowTime, Date beginTime, Date endTime) {
        UserInfo userInfo = GlobalConstant.getUserInfo();
        List<ReduceEmmissionDto> dto = alternateProductionMapper.selectReduceEmmissionDto(agencyId, userGrade, userInfo.getPlatformId(), areaCode, agcyId, warnLevel, isUsing, nowTime, beginTime, endTime);
        if (areaCode != null && areaCode.getProvinceCode().equals("000000")) {
            dto = UserUtil.setPermission2(areaCode, dto);
        }
        return dto;
    }

    @Override
    public Integer selectBindCount(Long planId) {
        return alternateProductionMapper.selectBindCount(planId);
    }

    /**
     * 查询行政机构id
     *
     * @param areaCode
     * @return
     */
    @Override
    public List<HbyAgency> getAgencyInfo(AreaCodeJoinOther areaCode) {

        UserInfo userInfo = GlobalConstant.getUserInfo();
        HbyAgencyExample example = new HbyAgencyExample();
        HbyAgencyExample.Criteria criteria = example.createCriteria();
        criteria.andAreaCodeEqualTo(areaCode.getAreaCode());
        criteria.andCityCodeEqualTo(areaCode.getCityCode());
        criteria.andPlatformIdEqualTo(userInfo.getPlatformId());
        criteria.andProvinceCodeEqualTo(areaCode.getProvinceCode());
        List<HbyAgency> agencyList = hbyAgencyMapper.selectByExample(example);
        return agencyList;
    }


    /**
     * 方案绑定
     *
     * @param planId     方案id
     * @param projIdList 单位id集合
     * @return
     */
    @Override
    public boolean updateBindReduceEmmissionPlan(Long planId, List<Integer> projIdList) {

        if (projIdList == null || projIdList.size() == 0) {
            return false;
        }

        HbyReduceplanJoinProjectExample example2 = new HbyReduceplanJoinProjectExample();
        HbyReduceplanJoinProjectExample.Criteria criteria2 = example2.createCriteria();
        criteria2.andPlanIdEqualTo(planId);
        criteria2.andUnitIdNotIn(projIdList);
        hbyReduceplanJoinProjectService.deleteByExample(example2);

        HbyReduceplanJoinProjectExample example1 = new HbyReduceplanJoinProjectExample();
        HbyReduceplanJoinProjectExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andUnitIdIn(projIdList);
        criteria1.andPlanIdEqualTo(planId);
        List<HbyReduceplanJoinProject> list = hbyReduceplanJoinProjectService.selectByExample(example1);
        for (HbyReduceplanJoinProject project : list) {
            System.out.println(project.getPlanId().equals(planId));
            if (project.getPlanId().equals(planId)) {
                ListIterator<Integer> iterator = projIdList.listIterator();
                while (iterator.hasNext()){
                    if (iterator.next().equals(project.getUnitId().intValue())) {
                        iterator.remove();
                    }
                }
            }
        }
        if (projIdList == null || projIdList.size() == 0) {
            return true;
        }
        HbyReduceplanJoinProjectExample example = new HbyReduceplanJoinProjectExample();
        HbyReduceplanJoinProjectExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdIn(projIdList);
        hbyReduceplanJoinProjectService.deleteByExample(example);

        List<HbyReduceplanJoinProject> joinList = new ArrayList<>();
        joinList = this.createHbyReduceplanJoinProject(planId, projIdList, joinList);
        boolean b = hbyReduceplanJoinProjectService.saveBatch(joinList);
//        if (b) {
//            // 更新绑定数量
//            hbyReduceplanJoinProjectService.updateBindUnitCount(planId, projIdList.size());
//        }
        return b;
    }

    /**
     * 方案解除绑定
     *
     * @param planId     方案id
     * @param projIdList 单位id集合
     * @return
     */
    @Override
    public boolean updateUnBindReduceEmmissionPlan(Long planId, ArrayList<Integer> projIdList) {
        if (projIdList == null || projIdList.size() == 0) {
            return false;
        }
        HbyReduceplanJoinProjectExample example = new HbyReduceplanJoinProjectExample();
        HbyReduceplanJoinProjectExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdIn(projIdList);
        criteria.andPlanIdEqualTo(planId);
        int i = hbyReduceplanJoinProjectService.deleteByExample(example);
//        if (i > 0) {
//            // 更新绑定数量
//            hbyReduceplanJoinProjectService.updateBindUnitCount(planId, 0 - i);
//        }
        return i > 0;
//        UpdateWrapper<HbyReduceplanJoinProject> wrapper = new UpdateWrapper<>();
//        wrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId, projIdList);
//        for (Integer projId : projIdList) {
//            wrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId, projId);
//            hbyReduceplanJoinProjectService.remove(wrapper);
//        }
//        return true;
    }

    private List<HbyReduceplanJoinProject> createHbyReduceplanJoinProject(Long planId, List<Integer> projIdList, List<HbyReduceplanJoinProject> joinList) {
        HbyReduceplanJoinProject join;
        for (Integer projId : projIdList) {
            join = new HbyReduceplanJoinProject();
            join.setBindTime(DateTime.now());
            join.setPlanId(planId);
            join.setUnitId(projId);
            join.setIsViolat(2);
            join.setId(new SnowflakeConfig().nextId());
            joinList.add(join);
        }
        return joinList;
    }

    /**
     * 获取减产减排方案实体类
     * 适用于方案添加和修改
     *
     * @param userId             用户id
     * @param agencyId           绑定机构id 更新时不需要传入
     * @param areaCode           区域码实体 更新时不需要传入
     * @param reduceEmmissionDto 减排方案dto实体
     * @param isInsert           是否是insert操作
     * @return 减产减排方案表对应的实体
     */
    private HbyReduceEmmissionPlan getHbyReduceEmmissionPlan(int userId, long agencyId, AreaCodeJoinOther areaCode, ReduceEmmissionDto reduceEmmissionDto, boolean isInsert) {
        HbyReduceEmmissionPlan record = new HbyReduceEmmissionPlan();

        UserInfo userInfo = GlobalConstant.getUserInfo();
        // 仅当是添加操作时，需要设置一下几个属性
        if (isInsert) {
            record.setProvinceCode(areaCode.getProvinceCode());
            record.setCityCode(areaCode.getCityCode());
            record.setAreaCode(areaCode.getAreaCode());
            record.setCreateUser(userId);
            record.setCreateTime(DateTime.now());
            record.setBelongAgency(agencyId);
        }

        record.setPlanId(reduceEmmissionDto.getPlanId());
        record.setPlanName(reduceEmmissionDto.getPlanName());
        record.setPlanType(reduceEmmissionDto.getPlanType());
        record.setBeginTime(reduceEmmissionDto.getBeginTime());
        record.setEndTime(reduceEmmissionDto.getEndTime());
        record.setLimitProducTimeCount(reduceEmmissionDto.getLimitProducTimeCount());
        record.setWarnLevel(reduceEmmissionDto.getWarnLevel());
        record.setRemark(reduceEmmissionDto.getRemark());
        record.setIsUsing(reduceEmmissionDto.getIsUsing());
        record.setStopProducTimeList(JSON.toJSONString(reduceEmmissionDto.getStopProducTimeList()));
        record.setUpdateUser(userId);
        record.setUpdateTime(DateTime.now());
        record.setIsDelete(0);
        record.setPlatformId(userInfo.getPlatformId());
        return record;
    }


}
