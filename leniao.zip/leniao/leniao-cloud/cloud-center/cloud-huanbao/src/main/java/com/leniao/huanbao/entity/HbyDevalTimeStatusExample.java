package com.leniao.huanbao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HbyDevalTimeStatusExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public HbyDevalTimeStatusExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNull() {
            addCriterion("unitId is null");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNotNull() {
            addCriterion("unitId is not null");
            return (Criteria) this;
        }

        public Criteria andUnitIdEqualTo(Integer value) {
            addCriterion("unitId =", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotEqualTo(Integer value) {
            addCriterion("unitId <>", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThan(Integer value) {
            addCriterion("unitId >", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("unitId >=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThan(Integer value) {
            addCriterion("unitId <", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThanOrEqualTo(Integer value) {
            addCriterion("unitId <=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdIn(List<Integer> values) {
            addCriterion("unitId in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotIn(List<Integer> values) {
            addCriterion("unitId not in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdBetween(Integer value1, Integer value2) {
            addCriterion("unitId between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotBetween(Integer value1, Integer value2) {
            addCriterion("unitId not between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIsNull() {
            addCriterion("devIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIsNotNull() {
            addCriterion("devIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevIdpkEqualTo(Integer value) {
            addCriterion("devIdpk =", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotEqualTo(Integer value) {
            addCriterion("devIdpk <>", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkGreaterThan(Integer value) {
            addCriterion("devIdpk >", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIdpk >=", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkLessThan(Integer value) {
            addCriterion("devIdpk <", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkLessThanOrEqualTo(Integer value) {
            addCriterion("devIdpk <=", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIn(List<Integer> values) {
            addCriterion("devIdpk in", values, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotIn(List<Integer> values) {
            addCriterion("devIdpk not in", values, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk between", value1, value2, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk not between", value1, value2, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevProTyIsNull() {
            addCriterion("devProTy is null");
            return (Criteria) this;
        }

        public Criteria andDevProTyIsNotNull() {
            addCriterion("devProTy is not null");
            return (Criteria) this;
        }

        public Criteria andDevProTyEqualTo(Integer value) {
            addCriterion("devProTy =", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyNotEqualTo(Integer value) {
            addCriterion("devProTy <>", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyGreaterThan(Integer value) {
            addCriterion("devProTy >", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyGreaterThanOrEqualTo(Integer value) {
            addCriterion("devProTy >=", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyLessThan(Integer value) {
            addCriterion("devProTy <", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyLessThanOrEqualTo(Integer value) {
            addCriterion("devProTy <=", value, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyIn(List<Integer> values) {
            addCriterion("devProTy in", values, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyNotIn(List<Integer> values) {
            addCriterion("devProTy not in", values, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyBetween(Integer value1, Integer value2) {
            addCriterion("devProTy between", value1, value2, "devProTy");
            return (Criteria) this;
        }

        public Criteria andDevProTyNotBetween(Integer value1, Integer value2) {
            addCriterion("devProTy not between", value1, value2, "devProTy");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("platformId is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("platformId is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Integer value) {
            addCriterion("platformId =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Integer value) {
            addCriterion("platformId <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Integer value) {
            addCriterion("platformId >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("platformId >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Integer value) {
            addCriterion("platformId <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Integer value) {
            addCriterion("platformId <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Integer> values) {
            addCriterion("platformId in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Integer> values) {
            addCriterion("platformId not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Integer value1, Integer value2) {
            addCriterion("platformId between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Integer value1, Integer value2) {
            addCriterion("platformId not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("updateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("updateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("updateTime =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("updateTime <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("updateTime >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updateTime >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("updateTime <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("updateTime <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("updateTime in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("updateTime not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("updateTime between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("updateTime not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNull() {
            addCriterion("addtime is null");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNotNull() {
            addCriterion("addtime is not null");
            return (Criteria) this;
        }

        public Criteria andAddtimeEqualTo(Date value) {
            addCriterion("addtime =", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotEqualTo(Date value) {
            addCriterion("addtime <>", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThan(Date value) {
            addCriterion("addtime >", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("addtime >=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThan(Date value) {
            addCriterion("addtime <", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThanOrEqualTo(Date value) {
            addCriterion("addtime <=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeIn(List<Date> values) {
            addCriterion("addtime in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotIn(List<Date> values) {
            addCriterion("addtime not in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeBetween(Date value1, Date value2) {
            addCriterion("addtime between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotBetween(Date value1, Date value2) {
            addCriterion("addtime not between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andH0_1IsNull() {
            addCriterion("H0_1 is null");
            return (Criteria) this;
        }

        public Criteria andH0_1IsNotNull() {
            addCriterion("H0_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH0_1EqualTo(Integer value) {
            addCriterion("H0_1 =", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1NotEqualTo(Integer value) {
            addCriterion("H0_1 <>", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1GreaterThan(Integer value) {
            addCriterion("H0_1 >", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H0_1 >=", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1LessThan(Integer value) {
            addCriterion("H0_1 <", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1LessThanOrEqualTo(Integer value) {
            addCriterion("H0_1 <=", value, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1In(List<Integer> values) {
            addCriterion("H0_1 in", values, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1NotIn(List<Integer> values) {
            addCriterion("H0_1 not in", values, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1Between(Integer value1, Integer value2) {
            addCriterion("H0_1 between", value1, value2, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H0_1 not between", value1, value2, "h0_1");
            return (Criteria) this;
        }

        public Criteria andH0_2IsNull() {
            addCriterion("H0_2 is null");
            return (Criteria) this;
        }

        public Criteria andH0_2IsNotNull() {
            addCriterion("H0_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH0_2EqualTo(Integer value) {
            addCriterion("H0_2 =", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2NotEqualTo(Integer value) {
            addCriterion("H0_2 <>", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2GreaterThan(Integer value) {
            addCriterion("H0_2 >", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H0_2 >=", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2LessThan(Integer value) {
            addCriterion("H0_2 <", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2LessThanOrEqualTo(Integer value) {
            addCriterion("H0_2 <=", value, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2In(List<Integer> values) {
            addCriterion("H0_2 in", values, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2NotIn(List<Integer> values) {
            addCriterion("H0_2 not in", values, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2Between(Integer value1, Integer value2) {
            addCriterion("H0_2 between", value1, value2, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H0_2 not between", value1, value2, "h0_2");
            return (Criteria) this;
        }

        public Criteria andH0_3IsNull() {
            addCriterion("H0_3 is null");
            return (Criteria) this;
        }

        public Criteria andH0_3IsNotNull() {
            addCriterion("H0_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH0_3EqualTo(Integer value) {
            addCriterion("H0_3 =", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3NotEqualTo(Integer value) {
            addCriterion("H0_3 <>", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3GreaterThan(Integer value) {
            addCriterion("H0_3 >", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H0_3 >=", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3LessThan(Integer value) {
            addCriterion("H0_3 <", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3LessThanOrEqualTo(Integer value) {
            addCriterion("H0_3 <=", value, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3In(List<Integer> values) {
            addCriterion("H0_3 in", values, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3NotIn(List<Integer> values) {
            addCriterion("H0_3 not in", values, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3Between(Integer value1, Integer value2) {
            addCriterion("H0_3 between", value1, value2, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH0_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H0_3 not between", value1, value2, "h0_3");
            return (Criteria) this;
        }

        public Criteria andH1_1IsNull() {
            addCriterion("H1_1 is null");
            return (Criteria) this;
        }

        public Criteria andH1_1IsNotNull() {
            addCriterion("H1_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH1_1EqualTo(Integer value) {
            addCriterion("H1_1 =", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1NotEqualTo(Integer value) {
            addCriterion("H1_1 <>", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1GreaterThan(Integer value) {
            addCriterion("H1_1 >", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H1_1 >=", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1LessThan(Integer value) {
            addCriterion("H1_1 <", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1LessThanOrEqualTo(Integer value) {
            addCriterion("H1_1 <=", value, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1In(List<Integer> values) {
            addCriterion("H1_1 in", values, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1NotIn(List<Integer> values) {
            addCriterion("H1_1 not in", values, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1Between(Integer value1, Integer value2) {
            addCriterion("H1_1 between", value1, value2, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H1_1 not between", value1, value2, "h1_1");
            return (Criteria) this;
        }

        public Criteria andH1_2IsNull() {
            addCriterion("H1_2 is null");
            return (Criteria) this;
        }

        public Criteria andH1_2IsNotNull() {
            addCriterion("H1_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH1_2EqualTo(Integer value) {
            addCriterion("H1_2 =", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2NotEqualTo(Integer value) {
            addCriterion("H1_2 <>", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2GreaterThan(Integer value) {
            addCriterion("H1_2 >", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H1_2 >=", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2LessThan(Integer value) {
            addCriterion("H1_2 <", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2LessThanOrEqualTo(Integer value) {
            addCriterion("H1_2 <=", value, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2In(List<Integer> values) {
            addCriterion("H1_2 in", values, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2NotIn(List<Integer> values) {
            addCriterion("H1_2 not in", values, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2Between(Integer value1, Integer value2) {
            addCriterion("H1_2 between", value1, value2, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H1_2 not between", value1, value2, "h1_2");
            return (Criteria) this;
        }

        public Criteria andH1_3IsNull() {
            addCriterion("H1_3 is null");
            return (Criteria) this;
        }

        public Criteria andH1_3IsNotNull() {
            addCriterion("H1_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH1_3EqualTo(Integer value) {
            addCriterion("H1_3 =", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3NotEqualTo(Integer value) {
            addCriterion("H1_3 <>", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3GreaterThan(Integer value) {
            addCriterion("H1_3 >", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H1_3 >=", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3LessThan(Integer value) {
            addCriterion("H1_3 <", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3LessThanOrEqualTo(Integer value) {
            addCriterion("H1_3 <=", value, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3In(List<Integer> values) {
            addCriterion("H1_3 in", values, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3NotIn(List<Integer> values) {
            addCriterion("H1_3 not in", values, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3Between(Integer value1, Integer value2) {
            addCriterion("H1_3 between", value1, value2, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH1_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H1_3 not between", value1, value2, "h1_3");
            return (Criteria) this;
        }

        public Criteria andH2_1IsNull() {
            addCriterion("H2_1 is null");
            return (Criteria) this;
        }

        public Criteria andH2_1IsNotNull() {
            addCriterion("H2_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH2_1EqualTo(Integer value) {
            addCriterion("H2_1 =", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1NotEqualTo(Integer value) {
            addCriterion("H2_1 <>", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1GreaterThan(Integer value) {
            addCriterion("H2_1 >", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H2_1 >=", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1LessThan(Integer value) {
            addCriterion("H2_1 <", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1LessThanOrEqualTo(Integer value) {
            addCriterion("H2_1 <=", value, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1In(List<Integer> values) {
            addCriterion("H2_1 in", values, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1NotIn(List<Integer> values) {
            addCriterion("H2_1 not in", values, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1Between(Integer value1, Integer value2) {
            addCriterion("H2_1 between", value1, value2, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H2_1 not between", value1, value2, "h2_1");
            return (Criteria) this;
        }

        public Criteria andH2_2IsNull() {
            addCriterion("H2_2 is null");
            return (Criteria) this;
        }

        public Criteria andH2_2IsNotNull() {
            addCriterion("H2_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH2_2EqualTo(Integer value) {
            addCriterion("H2_2 =", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2NotEqualTo(Integer value) {
            addCriterion("H2_2 <>", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2GreaterThan(Integer value) {
            addCriterion("H2_2 >", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H2_2 >=", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2LessThan(Integer value) {
            addCriterion("H2_2 <", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2LessThanOrEqualTo(Integer value) {
            addCriterion("H2_2 <=", value, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2In(List<Integer> values) {
            addCriterion("H2_2 in", values, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2NotIn(List<Integer> values) {
            addCriterion("H2_2 not in", values, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2Between(Integer value1, Integer value2) {
            addCriterion("H2_2 between", value1, value2, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H2_2 not between", value1, value2, "h2_2");
            return (Criteria) this;
        }

        public Criteria andH2_3IsNull() {
            addCriterion("H2_3 is null");
            return (Criteria) this;
        }

        public Criteria andH2_3IsNotNull() {
            addCriterion("H2_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH2_3EqualTo(Integer value) {
            addCriterion("H2_3 =", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3NotEqualTo(Integer value) {
            addCriterion("H2_3 <>", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3GreaterThan(Integer value) {
            addCriterion("H2_3 >", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H2_3 >=", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3LessThan(Integer value) {
            addCriterion("H2_3 <", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3LessThanOrEqualTo(Integer value) {
            addCriterion("H2_3 <=", value, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3In(List<Integer> values) {
            addCriterion("H2_3 in", values, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3NotIn(List<Integer> values) {
            addCriterion("H2_3 not in", values, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3Between(Integer value1, Integer value2) {
            addCriterion("H2_3 between", value1, value2, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH2_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H2_3 not between", value1, value2, "h2_3");
            return (Criteria) this;
        }

        public Criteria andH3_1IsNull() {
            addCriterion("H3_1 is null");
            return (Criteria) this;
        }

        public Criteria andH3_1IsNotNull() {
            addCriterion("H3_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH3_1EqualTo(Integer value) {
            addCriterion("H3_1 =", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1NotEqualTo(Integer value) {
            addCriterion("H3_1 <>", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1GreaterThan(Integer value) {
            addCriterion("H3_1 >", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H3_1 >=", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1LessThan(Integer value) {
            addCriterion("H3_1 <", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1LessThanOrEqualTo(Integer value) {
            addCriterion("H3_1 <=", value, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1In(List<Integer> values) {
            addCriterion("H3_1 in", values, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1NotIn(List<Integer> values) {
            addCriterion("H3_1 not in", values, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1Between(Integer value1, Integer value2) {
            addCriterion("H3_1 between", value1, value2, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H3_1 not between", value1, value2, "h3_1");
            return (Criteria) this;
        }

        public Criteria andH3_2IsNull() {
            addCriterion("H3_2 is null");
            return (Criteria) this;
        }

        public Criteria andH3_2IsNotNull() {
            addCriterion("H3_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH3_2EqualTo(Integer value) {
            addCriterion("H3_2 =", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2NotEqualTo(Integer value) {
            addCriterion("H3_2 <>", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2GreaterThan(Integer value) {
            addCriterion("H3_2 >", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H3_2 >=", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2LessThan(Integer value) {
            addCriterion("H3_2 <", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2LessThanOrEqualTo(Integer value) {
            addCriterion("H3_2 <=", value, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2In(List<Integer> values) {
            addCriterion("H3_2 in", values, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2NotIn(List<Integer> values) {
            addCriterion("H3_2 not in", values, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2Between(Integer value1, Integer value2) {
            addCriterion("H3_2 between", value1, value2, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H3_2 not between", value1, value2, "h3_2");
            return (Criteria) this;
        }

        public Criteria andH3_3IsNull() {
            addCriterion("H3_3 is null");
            return (Criteria) this;
        }

        public Criteria andH3_3IsNotNull() {
            addCriterion("H3_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH3_3EqualTo(Integer value) {
            addCriterion("H3_3 =", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3NotEqualTo(Integer value) {
            addCriterion("H3_3 <>", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3GreaterThan(Integer value) {
            addCriterion("H3_3 >", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H3_3 >=", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3LessThan(Integer value) {
            addCriterion("H3_3 <", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3LessThanOrEqualTo(Integer value) {
            addCriterion("H3_3 <=", value, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3In(List<Integer> values) {
            addCriterion("H3_3 in", values, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3NotIn(List<Integer> values) {
            addCriterion("H3_3 not in", values, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3Between(Integer value1, Integer value2) {
            addCriterion("H3_3 between", value1, value2, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH3_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H3_3 not between", value1, value2, "h3_3");
            return (Criteria) this;
        }

        public Criteria andH4_1IsNull() {
            addCriterion("H4_1 is null");
            return (Criteria) this;
        }

        public Criteria andH4_1IsNotNull() {
            addCriterion("H4_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH4_1EqualTo(Integer value) {
            addCriterion("H4_1 =", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1NotEqualTo(Integer value) {
            addCriterion("H4_1 <>", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1GreaterThan(Integer value) {
            addCriterion("H4_1 >", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H4_1 >=", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1LessThan(Integer value) {
            addCriterion("H4_1 <", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1LessThanOrEqualTo(Integer value) {
            addCriterion("H4_1 <=", value, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1In(List<Integer> values) {
            addCriterion("H4_1 in", values, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1NotIn(List<Integer> values) {
            addCriterion("H4_1 not in", values, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1Between(Integer value1, Integer value2) {
            addCriterion("H4_1 between", value1, value2, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H4_1 not between", value1, value2, "h4_1");
            return (Criteria) this;
        }

        public Criteria andH4_2IsNull() {
            addCriterion("H4_2 is null");
            return (Criteria) this;
        }

        public Criteria andH4_2IsNotNull() {
            addCriterion("H4_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH4_2EqualTo(Integer value) {
            addCriterion("H4_2 =", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2NotEqualTo(Integer value) {
            addCriterion("H4_2 <>", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2GreaterThan(Integer value) {
            addCriterion("H4_2 >", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H4_2 >=", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2LessThan(Integer value) {
            addCriterion("H4_2 <", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2LessThanOrEqualTo(Integer value) {
            addCriterion("H4_2 <=", value, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2In(List<Integer> values) {
            addCriterion("H4_2 in", values, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2NotIn(List<Integer> values) {
            addCriterion("H4_2 not in", values, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2Between(Integer value1, Integer value2) {
            addCriterion("H4_2 between", value1, value2, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H4_2 not between", value1, value2, "h4_2");
            return (Criteria) this;
        }

        public Criteria andH4_3IsNull() {
            addCriterion("H4_3 is null");
            return (Criteria) this;
        }

        public Criteria andH4_3IsNotNull() {
            addCriterion("H4_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH4_3EqualTo(Integer value) {
            addCriterion("H4_3 =", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3NotEqualTo(Integer value) {
            addCriterion("H4_3 <>", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3GreaterThan(Integer value) {
            addCriterion("H4_3 >", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H4_3 >=", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3LessThan(Integer value) {
            addCriterion("H4_3 <", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3LessThanOrEqualTo(Integer value) {
            addCriterion("H4_3 <=", value, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3In(List<Integer> values) {
            addCriterion("H4_3 in", values, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3NotIn(List<Integer> values) {
            addCriterion("H4_3 not in", values, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3Between(Integer value1, Integer value2) {
            addCriterion("H4_3 between", value1, value2, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH4_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H4_3 not between", value1, value2, "h4_3");
            return (Criteria) this;
        }

        public Criteria andH5_1IsNull() {
            addCriterion("H5_1 is null");
            return (Criteria) this;
        }

        public Criteria andH5_1IsNotNull() {
            addCriterion("H5_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH5_1EqualTo(Integer value) {
            addCriterion("H5_1 =", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1NotEqualTo(Integer value) {
            addCriterion("H5_1 <>", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1GreaterThan(Integer value) {
            addCriterion("H5_1 >", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H5_1 >=", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1LessThan(Integer value) {
            addCriterion("H5_1 <", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1LessThanOrEqualTo(Integer value) {
            addCriterion("H5_1 <=", value, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1In(List<Integer> values) {
            addCriterion("H5_1 in", values, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1NotIn(List<Integer> values) {
            addCriterion("H5_1 not in", values, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1Between(Integer value1, Integer value2) {
            addCriterion("H5_1 between", value1, value2, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H5_1 not between", value1, value2, "h5_1");
            return (Criteria) this;
        }

        public Criteria andH5_2IsNull() {
            addCriterion("H5_2 is null");
            return (Criteria) this;
        }

        public Criteria andH5_2IsNotNull() {
            addCriterion("H5_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH5_2EqualTo(Integer value) {
            addCriterion("H5_2 =", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2NotEqualTo(Integer value) {
            addCriterion("H5_2 <>", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2GreaterThan(Integer value) {
            addCriterion("H5_2 >", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H5_2 >=", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2LessThan(Integer value) {
            addCriterion("H5_2 <", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2LessThanOrEqualTo(Integer value) {
            addCriterion("H5_2 <=", value, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2In(List<Integer> values) {
            addCriterion("H5_2 in", values, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2NotIn(List<Integer> values) {
            addCriterion("H5_2 not in", values, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2Between(Integer value1, Integer value2) {
            addCriterion("H5_2 between", value1, value2, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H5_2 not between", value1, value2, "h5_2");
            return (Criteria) this;
        }

        public Criteria andH5_3IsNull() {
            addCriterion("H5_3 is null");
            return (Criteria) this;
        }

        public Criteria andH5_3IsNotNull() {
            addCriterion("H5_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH5_3EqualTo(Integer value) {
            addCriterion("H5_3 =", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3NotEqualTo(Integer value) {
            addCriterion("H5_3 <>", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3GreaterThan(Integer value) {
            addCriterion("H5_3 >", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H5_3 >=", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3LessThan(Integer value) {
            addCriterion("H5_3 <", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3LessThanOrEqualTo(Integer value) {
            addCriterion("H5_3 <=", value, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3In(List<Integer> values) {
            addCriterion("H5_3 in", values, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3NotIn(List<Integer> values) {
            addCriterion("H5_3 not in", values, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3Between(Integer value1, Integer value2) {
            addCriterion("H5_3 between", value1, value2, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH5_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H5_3 not between", value1, value2, "h5_3");
            return (Criteria) this;
        }

        public Criteria andH6_1IsNull() {
            addCriterion("H6_1 is null");
            return (Criteria) this;
        }

        public Criteria andH6_1IsNotNull() {
            addCriterion("H6_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH6_1EqualTo(Integer value) {
            addCriterion("H6_1 =", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1NotEqualTo(Integer value) {
            addCriterion("H6_1 <>", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1GreaterThan(Integer value) {
            addCriterion("H6_1 >", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H6_1 >=", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1LessThan(Integer value) {
            addCriterion("H6_1 <", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1LessThanOrEqualTo(Integer value) {
            addCriterion("H6_1 <=", value, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1In(List<Integer> values) {
            addCriterion("H6_1 in", values, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1NotIn(List<Integer> values) {
            addCriterion("H6_1 not in", values, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1Between(Integer value1, Integer value2) {
            addCriterion("H6_1 between", value1, value2, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H6_1 not between", value1, value2, "h6_1");
            return (Criteria) this;
        }

        public Criteria andH6_2IsNull() {
            addCriterion("H6_2 is null");
            return (Criteria) this;
        }

        public Criteria andH6_2IsNotNull() {
            addCriterion("H6_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH6_2EqualTo(Integer value) {
            addCriterion("H6_2 =", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2NotEqualTo(Integer value) {
            addCriterion("H6_2 <>", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2GreaterThan(Integer value) {
            addCriterion("H6_2 >", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H6_2 >=", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2LessThan(Integer value) {
            addCriterion("H6_2 <", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2LessThanOrEqualTo(Integer value) {
            addCriterion("H6_2 <=", value, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2In(List<Integer> values) {
            addCriterion("H6_2 in", values, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2NotIn(List<Integer> values) {
            addCriterion("H6_2 not in", values, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2Between(Integer value1, Integer value2) {
            addCriterion("H6_2 between", value1, value2, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H6_2 not between", value1, value2, "h6_2");
            return (Criteria) this;
        }

        public Criteria andH6_3IsNull() {
            addCriterion("H6_3 is null");
            return (Criteria) this;
        }

        public Criteria andH6_3IsNotNull() {
            addCriterion("H6_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH6_3EqualTo(Integer value) {
            addCriterion("H6_3 =", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3NotEqualTo(Integer value) {
            addCriterion("H6_3 <>", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3GreaterThan(Integer value) {
            addCriterion("H6_3 >", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H6_3 >=", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3LessThan(Integer value) {
            addCriterion("H6_3 <", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3LessThanOrEqualTo(Integer value) {
            addCriterion("H6_3 <=", value, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3In(List<Integer> values) {
            addCriterion("H6_3 in", values, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3NotIn(List<Integer> values) {
            addCriterion("H6_3 not in", values, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3Between(Integer value1, Integer value2) {
            addCriterion("H6_3 between", value1, value2, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH6_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H6_3 not between", value1, value2, "h6_3");
            return (Criteria) this;
        }

        public Criteria andH7_1IsNull() {
            addCriterion("H7_1 is null");
            return (Criteria) this;
        }

        public Criteria andH7_1IsNotNull() {
            addCriterion("H7_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH7_1EqualTo(Integer value) {
            addCriterion("H7_1 =", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1NotEqualTo(Integer value) {
            addCriterion("H7_1 <>", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1GreaterThan(Integer value) {
            addCriterion("H7_1 >", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H7_1 >=", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1LessThan(Integer value) {
            addCriterion("H7_1 <", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1LessThanOrEqualTo(Integer value) {
            addCriterion("H7_1 <=", value, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1In(List<Integer> values) {
            addCriterion("H7_1 in", values, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1NotIn(List<Integer> values) {
            addCriterion("H7_1 not in", values, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1Between(Integer value1, Integer value2) {
            addCriterion("H7_1 between", value1, value2, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H7_1 not between", value1, value2, "h7_1");
            return (Criteria) this;
        }

        public Criteria andH7_2IsNull() {
            addCriterion("H7_2 is null");
            return (Criteria) this;
        }

        public Criteria andH7_2IsNotNull() {
            addCriterion("H7_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH7_2EqualTo(Integer value) {
            addCriterion("H7_2 =", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2NotEqualTo(Integer value) {
            addCriterion("H7_2 <>", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2GreaterThan(Integer value) {
            addCriterion("H7_2 >", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H7_2 >=", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2LessThan(Integer value) {
            addCriterion("H7_2 <", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2LessThanOrEqualTo(Integer value) {
            addCriterion("H7_2 <=", value, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2In(List<Integer> values) {
            addCriterion("H7_2 in", values, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2NotIn(List<Integer> values) {
            addCriterion("H7_2 not in", values, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2Between(Integer value1, Integer value2) {
            addCriterion("H7_2 between", value1, value2, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H7_2 not between", value1, value2, "h7_2");
            return (Criteria) this;
        }

        public Criteria andH7_3IsNull() {
            addCriterion("H7_3 is null");
            return (Criteria) this;
        }

        public Criteria andH7_3IsNotNull() {
            addCriterion("H7_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH7_3EqualTo(Integer value) {
            addCriterion("H7_3 =", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3NotEqualTo(Integer value) {
            addCriterion("H7_3 <>", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3GreaterThan(Integer value) {
            addCriterion("H7_3 >", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H7_3 >=", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3LessThan(Integer value) {
            addCriterion("H7_3 <", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3LessThanOrEqualTo(Integer value) {
            addCriterion("H7_3 <=", value, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3In(List<Integer> values) {
            addCriterion("H7_3 in", values, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3NotIn(List<Integer> values) {
            addCriterion("H7_3 not in", values, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3Between(Integer value1, Integer value2) {
            addCriterion("H7_3 between", value1, value2, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH7_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H7_3 not between", value1, value2, "h7_3");
            return (Criteria) this;
        }

        public Criteria andH8_1IsNull() {
            addCriterion("H8_1 is null");
            return (Criteria) this;
        }

        public Criteria andH8_1IsNotNull() {
            addCriterion("H8_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH8_1EqualTo(Integer value) {
            addCriterion("H8_1 =", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1NotEqualTo(Integer value) {
            addCriterion("H8_1 <>", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1GreaterThan(Integer value) {
            addCriterion("H8_1 >", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H8_1 >=", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1LessThan(Integer value) {
            addCriterion("H8_1 <", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1LessThanOrEqualTo(Integer value) {
            addCriterion("H8_1 <=", value, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1In(List<Integer> values) {
            addCriterion("H8_1 in", values, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1NotIn(List<Integer> values) {
            addCriterion("H8_1 not in", values, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1Between(Integer value1, Integer value2) {
            addCriterion("H8_1 between", value1, value2, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H8_1 not between", value1, value2, "h8_1");
            return (Criteria) this;
        }

        public Criteria andH8_2IsNull() {
            addCriterion("H8_2 is null");
            return (Criteria) this;
        }

        public Criteria andH8_2IsNotNull() {
            addCriterion("H8_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH8_2EqualTo(Integer value) {
            addCriterion("H8_2 =", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2NotEqualTo(Integer value) {
            addCriterion("H8_2 <>", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2GreaterThan(Integer value) {
            addCriterion("H8_2 >", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H8_2 >=", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2LessThan(Integer value) {
            addCriterion("H8_2 <", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2LessThanOrEqualTo(Integer value) {
            addCriterion("H8_2 <=", value, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2In(List<Integer> values) {
            addCriterion("H8_2 in", values, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2NotIn(List<Integer> values) {
            addCriterion("H8_2 not in", values, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2Between(Integer value1, Integer value2) {
            addCriterion("H8_2 between", value1, value2, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H8_2 not between", value1, value2, "h8_2");
            return (Criteria) this;
        }

        public Criteria andH8_3IsNull() {
            addCriterion("H8_3 is null");
            return (Criteria) this;
        }

        public Criteria andH8_3IsNotNull() {
            addCriterion("H8_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH8_3EqualTo(Integer value) {
            addCriterion("H8_3 =", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3NotEqualTo(Integer value) {
            addCriterion("H8_3 <>", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3GreaterThan(Integer value) {
            addCriterion("H8_3 >", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H8_3 >=", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3LessThan(Integer value) {
            addCriterion("H8_3 <", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3LessThanOrEqualTo(Integer value) {
            addCriterion("H8_3 <=", value, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3In(List<Integer> values) {
            addCriterion("H8_3 in", values, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3NotIn(List<Integer> values) {
            addCriterion("H8_3 not in", values, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3Between(Integer value1, Integer value2) {
            addCriterion("H8_3 between", value1, value2, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH8_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H8_3 not between", value1, value2, "h8_3");
            return (Criteria) this;
        }

        public Criteria andH9_1IsNull() {
            addCriterion("H9_1 is null");
            return (Criteria) this;
        }

        public Criteria andH9_1IsNotNull() {
            addCriterion("H9_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH9_1EqualTo(Integer value) {
            addCriterion("H9_1 =", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1NotEqualTo(Integer value) {
            addCriterion("H9_1 <>", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1GreaterThan(Integer value) {
            addCriterion("H9_1 >", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H9_1 >=", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1LessThan(Integer value) {
            addCriterion("H9_1 <", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1LessThanOrEqualTo(Integer value) {
            addCriterion("H9_1 <=", value, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1In(List<Integer> values) {
            addCriterion("H9_1 in", values, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1NotIn(List<Integer> values) {
            addCriterion("H9_1 not in", values, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1Between(Integer value1, Integer value2) {
            addCriterion("H9_1 between", value1, value2, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H9_1 not between", value1, value2, "h9_1");
            return (Criteria) this;
        }

        public Criteria andH9_2IsNull() {
            addCriterion("H9_2 is null");
            return (Criteria) this;
        }

        public Criteria andH9_2IsNotNull() {
            addCriterion("H9_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH9_2EqualTo(Integer value) {
            addCriterion("H9_2 =", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2NotEqualTo(Integer value) {
            addCriterion("H9_2 <>", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2GreaterThan(Integer value) {
            addCriterion("H9_2 >", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H9_2 >=", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2LessThan(Integer value) {
            addCriterion("H9_2 <", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2LessThanOrEqualTo(Integer value) {
            addCriterion("H9_2 <=", value, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2In(List<Integer> values) {
            addCriterion("H9_2 in", values, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2NotIn(List<Integer> values) {
            addCriterion("H9_2 not in", values, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2Between(Integer value1, Integer value2) {
            addCriterion("H9_2 between", value1, value2, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H9_2 not between", value1, value2, "h9_2");
            return (Criteria) this;
        }

        public Criteria andH9_3IsNull() {
            addCriterion("H9_3 is null");
            return (Criteria) this;
        }

        public Criteria andH9_3IsNotNull() {
            addCriterion("H9_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH9_3EqualTo(Integer value) {
            addCriterion("H9_3 =", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3NotEqualTo(Integer value) {
            addCriterion("H9_3 <>", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3GreaterThan(Integer value) {
            addCriterion("H9_3 >", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H9_3 >=", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3LessThan(Integer value) {
            addCriterion("H9_3 <", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3LessThanOrEqualTo(Integer value) {
            addCriterion("H9_3 <=", value, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3In(List<Integer> values) {
            addCriterion("H9_3 in", values, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3NotIn(List<Integer> values) {
            addCriterion("H9_3 not in", values, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3Between(Integer value1, Integer value2) {
            addCriterion("H9_3 between", value1, value2, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH9_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H9_3 not between", value1, value2, "h9_3");
            return (Criteria) this;
        }

        public Criteria andH10_1IsNull() {
            addCriterion("H10_1 is null");
            return (Criteria) this;
        }

        public Criteria andH10_1IsNotNull() {
            addCriterion("H10_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH10_1EqualTo(Integer value) {
            addCriterion("H10_1 =", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1NotEqualTo(Integer value) {
            addCriterion("H10_1 <>", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1GreaterThan(Integer value) {
            addCriterion("H10_1 >", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H10_1 >=", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1LessThan(Integer value) {
            addCriterion("H10_1 <", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1LessThanOrEqualTo(Integer value) {
            addCriterion("H10_1 <=", value, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1In(List<Integer> values) {
            addCriterion("H10_1 in", values, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1NotIn(List<Integer> values) {
            addCriterion("H10_1 not in", values, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1Between(Integer value1, Integer value2) {
            addCriterion("H10_1 between", value1, value2, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H10_1 not between", value1, value2, "h10_1");
            return (Criteria) this;
        }

        public Criteria andH10_2IsNull() {
            addCriterion("H10_2 is null");
            return (Criteria) this;
        }

        public Criteria andH10_2IsNotNull() {
            addCriterion("H10_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH10_2EqualTo(Integer value) {
            addCriterion("H10_2 =", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2NotEqualTo(Integer value) {
            addCriterion("H10_2 <>", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2GreaterThan(Integer value) {
            addCriterion("H10_2 >", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H10_2 >=", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2LessThan(Integer value) {
            addCriterion("H10_2 <", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2LessThanOrEqualTo(Integer value) {
            addCriterion("H10_2 <=", value, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2In(List<Integer> values) {
            addCriterion("H10_2 in", values, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2NotIn(List<Integer> values) {
            addCriterion("H10_2 not in", values, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2Between(Integer value1, Integer value2) {
            addCriterion("H10_2 between", value1, value2, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H10_2 not between", value1, value2, "h10_2");
            return (Criteria) this;
        }

        public Criteria andH10_3IsNull() {
            addCriterion("H10_3 is null");
            return (Criteria) this;
        }

        public Criteria andH10_3IsNotNull() {
            addCriterion("H10_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH10_3EqualTo(Integer value) {
            addCriterion("H10_3 =", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3NotEqualTo(Integer value) {
            addCriterion("H10_3 <>", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3GreaterThan(Integer value) {
            addCriterion("H10_3 >", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H10_3 >=", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3LessThan(Integer value) {
            addCriterion("H10_3 <", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3LessThanOrEqualTo(Integer value) {
            addCriterion("H10_3 <=", value, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3In(List<Integer> values) {
            addCriterion("H10_3 in", values, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3NotIn(List<Integer> values) {
            addCriterion("H10_3 not in", values, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3Between(Integer value1, Integer value2) {
            addCriterion("H10_3 between", value1, value2, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH10_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H10_3 not between", value1, value2, "h10_3");
            return (Criteria) this;
        }

        public Criteria andH11_1IsNull() {
            addCriterion("H11_1 is null");
            return (Criteria) this;
        }

        public Criteria andH11_1IsNotNull() {
            addCriterion("H11_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH11_1EqualTo(Integer value) {
            addCriterion("H11_1 =", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1NotEqualTo(Integer value) {
            addCriterion("H11_1 <>", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1GreaterThan(Integer value) {
            addCriterion("H11_1 >", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H11_1 >=", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1LessThan(Integer value) {
            addCriterion("H11_1 <", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1LessThanOrEqualTo(Integer value) {
            addCriterion("H11_1 <=", value, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1In(List<Integer> values) {
            addCriterion("H11_1 in", values, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1NotIn(List<Integer> values) {
            addCriterion("H11_1 not in", values, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1Between(Integer value1, Integer value2) {
            addCriterion("H11_1 between", value1, value2, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H11_1 not between", value1, value2, "h11_1");
            return (Criteria) this;
        }

        public Criteria andH11_2IsNull() {
            addCriterion("H11_2 is null");
            return (Criteria) this;
        }

        public Criteria andH11_2IsNotNull() {
            addCriterion("H11_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH11_2EqualTo(Integer value) {
            addCriterion("H11_2 =", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2NotEqualTo(Integer value) {
            addCriterion("H11_2 <>", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2GreaterThan(Integer value) {
            addCriterion("H11_2 >", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H11_2 >=", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2LessThan(Integer value) {
            addCriterion("H11_2 <", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2LessThanOrEqualTo(Integer value) {
            addCriterion("H11_2 <=", value, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2In(List<Integer> values) {
            addCriterion("H11_2 in", values, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2NotIn(List<Integer> values) {
            addCriterion("H11_2 not in", values, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2Between(Integer value1, Integer value2) {
            addCriterion("H11_2 between", value1, value2, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H11_2 not between", value1, value2, "h11_2");
            return (Criteria) this;
        }

        public Criteria andH11_3IsNull() {
            addCriterion("H11_3 is null");
            return (Criteria) this;
        }

        public Criteria andH11_3IsNotNull() {
            addCriterion("H11_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH11_3EqualTo(Integer value) {
            addCriterion("H11_3 =", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3NotEqualTo(Integer value) {
            addCriterion("H11_3 <>", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3GreaterThan(Integer value) {
            addCriterion("H11_3 >", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H11_3 >=", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3LessThan(Integer value) {
            addCriterion("H11_3 <", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3LessThanOrEqualTo(Integer value) {
            addCriterion("H11_3 <=", value, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3In(List<Integer> values) {
            addCriterion("H11_3 in", values, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3NotIn(List<Integer> values) {
            addCriterion("H11_3 not in", values, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3Between(Integer value1, Integer value2) {
            addCriterion("H11_3 between", value1, value2, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH11_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H11_3 not between", value1, value2, "h11_3");
            return (Criteria) this;
        }

        public Criteria andH12_1IsNull() {
            addCriterion("H12_1 is null");
            return (Criteria) this;
        }

        public Criteria andH12_1IsNotNull() {
            addCriterion("H12_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH12_1EqualTo(Integer value) {
            addCriterion("H12_1 =", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1NotEqualTo(Integer value) {
            addCriterion("H12_1 <>", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1GreaterThan(Integer value) {
            addCriterion("H12_1 >", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H12_1 >=", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1LessThan(Integer value) {
            addCriterion("H12_1 <", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1LessThanOrEqualTo(Integer value) {
            addCriterion("H12_1 <=", value, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1In(List<Integer> values) {
            addCriterion("H12_1 in", values, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1NotIn(List<Integer> values) {
            addCriterion("H12_1 not in", values, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1Between(Integer value1, Integer value2) {
            addCriterion("H12_1 between", value1, value2, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H12_1 not between", value1, value2, "h12_1");
            return (Criteria) this;
        }

        public Criteria andH12_2IsNull() {
            addCriterion("H12_2 is null");
            return (Criteria) this;
        }

        public Criteria andH12_2IsNotNull() {
            addCriterion("H12_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH12_2EqualTo(Integer value) {
            addCriterion("H12_2 =", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2NotEqualTo(Integer value) {
            addCriterion("H12_2 <>", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2GreaterThan(Integer value) {
            addCriterion("H12_2 >", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H12_2 >=", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2LessThan(Integer value) {
            addCriterion("H12_2 <", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2LessThanOrEqualTo(Integer value) {
            addCriterion("H12_2 <=", value, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2In(List<Integer> values) {
            addCriterion("H12_2 in", values, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2NotIn(List<Integer> values) {
            addCriterion("H12_2 not in", values, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2Between(Integer value1, Integer value2) {
            addCriterion("H12_2 between", value1, value2, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H12_2 not between", value1, value2, "h12_2");
            return (Criteria) this;
        }

        public Criteria andH12_3IsNull() {
            addCriterion("H12_3 is null");
            return (Criteria) this;
        }

        public Criteria andH12_3IsNotNull() {
            addCriterion("H12_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH12_3EqualTo(Integer value) {
            addCriterion("H12_3 =", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3NotEqualTo(Integer value) {
            addCriterion("H12_3 <>", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3GreaterThan(Integer value) {
            addCriterion("H12_3 >", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H12_3 >=", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3LessThan(Integer value) {
            addCriterion("H12_3 <", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3LessThanOrEqualTo(Integer value) {
            addCriterion("H12_3 <=", value, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3In(List<Integer> values) {
            addCriterion("H12_3 in", values, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3NotIn(List<Integer> values) {
            addCriterion("H12_3 not in", values, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3Between(Integer value1, Integer value2) {
            addCriterion("H12_3 between", value1, value2, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH12_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H12_3 not between", value1, value2, "h12_3");
            return (Criteria) this;
        }

        public Criteria andH13_1IsNull() {
            addCriterion("H13_1 is null");
            return (Criteria) this;
        }

        public Criteria andH13_1IsNotNull() {
            addCriterion("H13_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH13_1EqualTo(Integer value) {
            addCriterion("H13_1 =", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1NotEqualTo(Integer value) {
            addCriterion("H13_1 <>", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1GreaterThan(Integer value) {
            addCriterion("H13_1 >", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H13_1 >=", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1LessThan(Integer value) {
            addCriterion("H13_1 <", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1LessThanOrEqualTo(Integer value) {
            addCriterion("H13_1 <=", value, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1In(List<Integer> values) {
            addCriterion("H13_1 in", values, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1NotIn(List<Integer> values) {
            addCriterion("H13_1 not in", values, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1Between(Integer value1, Integer value2) {
            addCriterion("H13_1 between", value1, value2, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H13_1 not between", value1, value2, "h13_1");
            return (Criteria) this;
        }

        public Criteria andH13_2IsNull() {
            addCriterion("H13_2 is null");
            return (Criteria) this;
        }

        public Criteria andH13_2IsNotNull() {
            addCriterion("H13_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH13_2EqualTo(Integer value) {
            addCriterion("H13_2 =", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2NotEqualTo(Integer value) {
            addCriterion("H13_2 <>", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2GreaterThan(Integer value) {
            addCriterion("H13_2 >", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H13_2 >=", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2LessThan(Integer value) {
            addCriterion("H13_2 <", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2LessThanOrEqualTo(Integer value) {
            addCriterion("H13_2 <=", value, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2In(List<Integer> values) {
            addCriterion("H13_2 in", values, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2NotIn(List<Integer> values) {
            addCriterion("H13_2 not in", values, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2Between(Integer value1, Integer value2) {
            addCriterion("H13_2 between", value1, value2, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H13_2 not between", value1, value2, "h13_2");
            return (Criteria) this;
        }

        public Criteria andH13_3IsNull() {
            addCriterion("H13_3 is null");
            return (Criteria) this;
        }

        public Criteria andH13_3IsNotNull() {
            addCriterion("H13_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH13_3EqualTo(Integer value) {
            addCriterion("H13_3 =", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3NotEqualTo(Integer value) {
            addCriterion("H13_3 <>", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3GreaterThan(Integer value) {
            addCriterion("H13_3 >", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H13_3 >=", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3LessThan(Integer value) {
            addCriterion("H13_3 <", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3LessThanOrEqualTo(Integer value) {
            addCriterion("H13_3 <=", value, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3In(List<Integer> values) {
            addCriterion("H13_3 in", values, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3NotIn(List<Integer> values) {
            addCriterion("H13_3 not in", values, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3Between(Integer value1, Integer value2) {
            addCriterion("H13_3 between", value1, value2, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH13_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H13_3 not between", value1, value2, "h13_3");
            return (Criteria) this;
        }

        public Criteria andH14_1IsNull() {
            addCriterion("H14_1 is null");
            return (Criteria) this;
        }

        public Criteria andH14_1IsNotNull() {
            addCriterion("H14_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH14_1EqualTo(Integer value) {
            addCriterion("H14_1 =", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1NotEqualTo(Integer value) {
            addCriterion("H14_1 <>", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1GreaterThan(Integer value) {
            addCriterion("H14_1 >", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H14_1 >=", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1LessThan(Integer value) {
            addCriterion("H14_1 <", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1LessThanOrEqualTo(Integer value) {
            addCriterion("H14_1 <=", value, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1In(List<Integer> values) {
            addCriterion("H14_1 in", values, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1NotIn(List<Integer> values) {
            addCriterion("H14_1 not in", values, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1Between(Integer value1, Integer value2) {
            addCriterion("H14_1 between", value1, value2, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H14_1 not between", value1, value2, "h14_1");
            return (Criteria) this;
        }

        public Criteria andH14_2IsNull() {
            addCriterion("H14_2 is null");
            return (Criteria) this;
        }

        public Criteria andH14_2IsNotNull() {
            addCriterion("H14_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH14_2EqualTo(Integer value) {
            addCriterion("H14_2 =", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2NotEqualTo(Integer value) {
            addCriterion("H14_2 <>", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2GreaterThan(Integer value) {
            addCriterion("H14_2 >", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H14_2 >=", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2LessThan(Integer value) {
            addCriterion("H14_2 <", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2LessThanOrEqualTo(Integer value) {
            addCriterion("H14_2 <=", value, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2In(List<Integer> values) {
            addCriterion("H14_2 in", values, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2NotIn(List<Integer> values) {
            addCriterion("H14_2 not in", values, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2Between(Integer value1, Integer value2) {
            addCriterion("H14_2 between", value1, value2, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H14_2 not between", value1, value2, "h14_2");
            return (Criteria) this;
        }

        public Criteria andH14_3IsNull() {
            addCriterion("H14_3 is null");
            return (Criteria) this;
        }

        public Criteria andH14_3IsNotNull() {
            addCriterion("H14_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH14_3EqualTo(Integer value) {
            addCriterion("H14_3 =", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3NotEqualTo(Integer value) {
            addCriterion("H14_3 <>", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3GreaterThan(Integer value) {
            addCriterion("H14_3 >", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H14_3 >=", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3LessThan(Integer value) {
            addCriterion("H14_3 <", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3LessThanOrEqualTo(Integer value) {
            addCriterion("H14_3 <=", value, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3In(List<Integer> values) {
            addCriterion("H14_3 in", values, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3NotIn(List<Integer> values) {
            addCriterion("H14_3 not in", values, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3Between(Integer value1, Integer value2) {
            addCriterion("H14_3 between", value1, value2, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH14_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H14_3 not between", value1, value2, "h14_3");
            return (Criteria) this;
        }

        public Criteria andH15_1IsNull() {
            addCriterion("H15_1 is null");
            return (Criteria) this;
        }

        public Criteria andH15_1IsNotNull() {
            addCriterion("H15_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH15_1EqualTo(Integer value) {
            addCriterion("H15_1 =", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1NotEqualTo(Integer value) {
            addCriterion("H15_1 <>", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1GreaterThan(Integer value) {
            addCriterion("H15_1 >", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H15_1 >=", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1LessThan(Integer value) {
            addCriterion("H15_1 <", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1LessThanOrEqualTo(Integer value) {
            addCriterion("H15_1 <=", value, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1In(List<Integer> values) {
            addCriterion("H15_1 in", values, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1NotIn(List<Integer> values) {
            addCriterion("H15_1 not in", values, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1Between(Integer value1, Integer value2) {
            addCriterion("H15_1 between", value1, value2, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H15_1 not between", value1, value2, "h15_1");
            return (Criteria) this;
        }

        public Criteria andH15_2IsNull() {
            addCriterion("H15_2 is null");
            return (Criteria) this;
        }

        public Criteria andH15_2IsNotNull() {
            addCriterion("H15_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH15_2EqualTo(Integer value) {
            addCriterion("H15_2 =", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2NotEqualTo(Integer value) {
            addCriterion("H15_2 <>", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2GreaterThan(Integer value) {
            addCriterion("H15_2 >", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H15_2 >=", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2LessThan(Integer value) {
            addCriterion("H15_2 <", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2LessThanOrEqualTo(Integer value) {
            addCriterion("H15_2 <=", value, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2In(List<Integer> values) {
            addCriterion("H15_2 in", values, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2NotIn(List<Integer> values) {
            addCriterion("H15_2 not in", values, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2Between(Integer value1, Integer value2) {
            addCriterion("H15_2 between", value1, value2, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H15_2 not between", value1, value2, "h15_2");
            return (Criteria) this;
        }

        public Criteria andH15_3IsNull() {
            addCriterion("H15_3 is null");
            return (Criteria) this;
        }

        public Criteria andH15_3IsNotNull() {
            addCriterion("H15_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH15_3EqualTo(Integer value) {
            addCriterion("H15_3 =", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3NotEqualTo(Integer value) {
            addCriterion("H15_3 <>", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3GreaterThan(Integer value) {
            addCriterion("H15_3 >", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H15_3 >=", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3LessThan(Integer value) {
            addCriterion("H15_3 <", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3LessThanOrEqualTo(Integer value) {
            addCriterion("H15_3 <=", value, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3In(List<Integer> values) {
            addCriterion("H15_3 in", values, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3NotIn(List<Integer> values) {
            addCriterion("H15_3 not in", values, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3Between(Integer value1, Integer value2) {
            addCriterion("H15_3 between", value1, value2, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH15_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H15_3 not between", value1, value2, "h15_3");
            return (Criteria) this;
        }

        public Criteria andH16_1IsNull() {
            addCriterion("H16_1 is null");
            return (Criteria) this;
        }

        public Criteria andH16_1IsNotNull() {
            addCriterion("H16_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH16_1EqualTo(Integer value) {
            addCriterion("H16_1 =", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1NotEqualTo(Integer value) {
            addCriterion("H16_1 <>", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1GreaterThan(Integer value) {
            addCriterion("H16_1 >", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H16_1 >=", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1LessThan(Integer value) {
            addCriterion("H16_1 <", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1LessThanOrEqualTo(Integer value) {
            addCriterion("H16_1 <=", value, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1In(List<Integer> values) {
            addCriterion("H16_1 in", values, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1NotIn(List<Integer> values) {
            addCriterion("H16_1 not in", values, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1Between(Integer value1, Integer value2) {
            addCriterion("H16_1 between", value1, value2, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H16_1 not between", value1, value2, "h16_1");
            return (Criteria) this;
        }

        public Criteria andH16_2IsNull() {
            addCriterion("H16_2 is null");
            return (Criteria) this;
        }

        public Criteria andH16_2IsNotNull() {
            addCriterion("H16_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH16_2EqualTo(Integer value) {
            addCriterion("H16_2 =", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2NotEqualTo(Integer value) {
            addCriterion("H16_2 <>", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2GreaterThan(Integer value) {
            addCriterion("H16_2 >", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H16_2 >=", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2LessThan(Integer value) {
            addCriterion("H16_2 <", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2LessThanOrEqualTo(Integer value) {
            addCriterion("H16_2 <=", value, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2In(List<Integer> values) {
            addCriterion("H16_2 in", values, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2NotIn(List<Integer> values) {
            addCriterion("H16_2 not in", values, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2Between(Integer value1, Integer value2) {
            addCriterion("H16_2 between", value1, value2, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H16_2 not between", value1, value2, "h16_2");
            return (Criteria) this;
        }

        public Criteria andH16_3IsNull() {
            addCriterion("H16_3 is null");
            return (Criteria) this;
        }

        public Criteria andH16_3IsNotNull() {
            addCriterion("H16_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH16_3EqualTo(Integer value) {
            addCriterion("H16_3 =", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3NotEqualTo(Integer value) {
            addCriterion("H16_3 <>", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3GreaterThan(Integer value) {
            addCriterion("H16_3 >", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H16_3 >=", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3LessThan(Integer value) {
            addCriterion("H16_3 <", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3LessThanOrEqualTo(Integer value) {
            addCriterion("H16_3 <=", value, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3In(List<Integer> values) {
            addCriterion("H16_3 in", values, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3NotIn(List<Integer> values) {
            addCriterion("H16_3 not in", values, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3Between(Integer value1, Integer value2) {
            addCriterion("H16_3 between", value1, value2, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH16_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H16_3 not between", value1, value2, "h16_3");
            return (Criteria) this;
        }

        public Criteria andH17_1IsNull() {
            addCriterion("H17_1 is null");
            return (Criteria) this;
        }

        public Criteria andH17_1IsNotNull() {
            addCriterion("H17_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH17_1EqualTo(Integer value) {
            addCriterion("H17_1 =", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1NotEqualTo(Integer value) {
            addCriterion("H17_1 <>", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1GreaterThan(Integer value) {
            addCriterion("H17_1 >", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H17_1 >=", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1LessThan(Integer value) {
            addCriterion("H17_1 <", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1LessThanOrEqualTo(Integer value) {
            addCriterion("H17_1 <=", value, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1In(List<Integer> values) {
            addCriterion("H17_1 in", values, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1NotIn(List<Integer> values) {
            addCriterion("H17_1 not in", values, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1Between(Integer value1, Integer value2) {
            addCriterion("H17_1 between", value1, value2, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H17_1 not between", value1, value2, "h17_1");
            return (Criteria) this;
        }

        public Criteria andH17_2IsNull() {
            addCriterion("H17_2 is null");
            return (Criteria) this;
        }

        public Criteria andH17_2IsNotNull() {
            addCriterion("H17_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH17_2EqualTo(Integer value) {
            addCriterion("H17_2 =", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2NotEqualTo(Integer value) {
            addCriterion("H17_2 <>", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2GreaterThan(Integer value) {
            addCriterion("H17_2 >", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H17_2 >=", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2LessThan(Integer value) {
            addCriterion("H17_2 <", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2LessThanOrEqualTo(Integer value) {
            addCriterion("H17_2 <=", value, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2In(List<Integer> values) {
            addCriterion("H17_2 in", values, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2NotIn(List<Integer> values) {
            addCriterion("H17_2 not in", values, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2Between(Integer value1, Integer value2) {
            addCriterion("H17_2 between", value1, value2, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H17_2 not between", value1, value2, "h17_2");
            return (Criteria) this;
        }

        public Criteria andH17_3IsNull() {
            addCriterion("H17_3 is null");
            return (Criteria) this;
        }

        public Criteria andH17_3IsNotNull() {
            addCriterion("H17_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH17_3EqualTo(Integer value) {
            addCriterion("H17_3 =", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3NotEqualTo(Integer value) {
            addCriterion("H17_3 <>", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3GreaterThan(Integer value) {
            addCriterion("H17_3 >", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H17_3 >=", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3LessThan(Integer value) {
            addCriterion("H17_3 <", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3LessThanOrEqualTo(Integer value) {
            addCriterion("H17_3 <=", value, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3In(List<Integer> values) {
            addCriterion("H17_3 in", values, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3NotIn(List<Integer> values) {
            addCriterion("H17_3 not in", values, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3Between(Integer value1, Integer value2) {
            addCriterion("H17_3 between", value1, value2, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH17_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H17_3 not between", value1, value2, "h17_3");
            return (Criteria) this;
        }

        public Criteria andH18_1IsNull() {
            addCriterion("H18_1 is null");
            return (Criteria) this;
        }

        public Criteria andH18_1IsNotNull() {
            addCriterion("H18_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH18_1EqualTo(Integer value) {
            addCriterion("H18_1 =", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1NotEqualTo(Integer value) {
            addCriterion("H18_1 <>", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1GreaterThan(Integer value) {
            addCriterion("H18_1 >", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H18_1 >=", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1LessThan(Integer value) {
            addCriterion("H18_1 <", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1LessThanOrEqualTo(Integer value) {
            addCriterion("H18_1 <=", value, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1In(List<Integer> values) {
            addCriterion("H18_1 in", values, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1NotIn(List<Integer> values) {
            addCriterion("H18_1 not in", values, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1Between(Integer value1, Integer value2) {
            addCriterion("H18_1 between", value1, value2, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H18_1 not between", value1, value2, "h18_1");
            return (Criteria) this;
        }

        public Criteria andH18_2IsNull() {
            addCriterion("H18_2 is null");
            return (Criteria) this;
        }

        public Criteria andH18_2IsNotNull() {
            addCriterion("H18_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH18_2EqualTo(Integer value) {
            addCriterion("H18_2 =", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2NotEqualTo(Integer value) {
            addCriterion("H18_2 <>", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2GreaterThan(Integer value) {
            addCriterion("H18_2 >", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H18_2 >=", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2LessThan(Integer value) {
            addCriterion("H18_2 <", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2LessThanOrEqualTo(Integer value) {
            addCriterion("H18_2 <=", value, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2In(List<Integer> values) {
            addCriterion("H18_2 in", values, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2NotIn(List<Integer> values) {
            addCriterion("H18_2 not in", values, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2Between(Integer value1, Integer value2) {
            addCriterion("H18_2 between", value1, value2, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H18_2 not between", value1, value2, "h18_2");
            return (Criteria) this;
        }

        public Criteria andH18_3IsNull() {
            addCriterion("H18_3 is null");
            return (Criteria) this;
        }

        public Criteria andH18_3IsNotNull() {
            addCriterion("H18_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH18_3EqualTo(Integer value) {
            addCriterion("H18_3 =", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3NotEqualTo(Integer value) {
            addCriterion("H18_3 <>", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3GreaterThan(Integer value) {
            addCriterion("H18_3 >", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H18_3 >=", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3LessThan(Integer value) {
            addCriterion("H18_3 <", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3LessThanOrEqualTo(Integer value) {
            addCriterion("H18_3 <=", value, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3In(List<Integer> values) {
            addCriterion("H18_3 in", values, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3NotIn(List<Integer> values) {
            addCriterion("H18_3 not in", values, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3Between(Integer value1, Integer value2) {
            addCriterion("H18_3 between", value1, value2, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH18_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H18_3 not between", value1, value2, "h18_3");
            return (Criteria) this;
        }

        public Criteria andH19_1IsNull() {
            addCriterion("H19_1 is null");
            return (Criteria) this;
        }

        public Criteria andH19_1IsNotNull() {
            addCriterion("H19_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH19_1EqualTo(Integer value) {
            addCriterion("H19_1 =", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1NotEqualTo(Integer value) {
            addCriterion("H19_1 <>", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1GreaterThan(Integer value) {
            addCriterion("H19_1 >", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H19_1 >=", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1LessThan(Integer value) {
            addCriterion("H19_1 <", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1LessThanOrEqualTo(Integer value) {
            addCriterion("H19_1 <=", value, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1In(List<Integer> values) {
            addCriterion("H19_1 in", values, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1NotIn(List<Integer> values) {
            addCriterion("H19_1 not in", values, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1Between(Integer value1, Integer value2) {
            addCriterion("H19_1 between", value1, value2, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H19_1 not between", value1, value2, "h19_1");
            return (Criteria) this;
        }

        public Criteria andH19_2IsNull() {
            addCriterion("H19_2 is null");
            return (Criteria) this;
        }

        public Criteria andH19_2IsNotNull() {
            addCriterion("H19_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH19_2EqualTo(Integer value) {
            addCriterion("H19_2 =", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2NotEqualTo(Integer value) {
            addCriterion("H19_2 <>", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2GreaterThan(Integer value) {
            addCriterion("H19_2 >", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H19_2 >=", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2LessThan(Integer value) {
            addCriterion("H19_2 <", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2LessThanOrEqualTo(Integer value) {
            addCriterion("H19_2 <=", value, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2In(List<Integer> values) {
            addCriterion("H19_2 in", values, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2NotIn(List<Integer> values) {
            addCriterion("H19_2 not in", values, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2Between(Integer value1, Integer value2) {
            addCriterion("H19_2 between", value1, value2, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H19_2 not between", value1, value2, "h19_2");
            return (Criteria) this;
        }

        public Criteria andH19_3IsNull() {
            addCriterion("H19_3 is null");
            return (Criteria) this;
        }

        public Criteria andH19_3IsNotNull() {
            addCriterion("H19_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH19_3EqualTo(Integer value) {
            addCriterion("H19_3 =", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3NotEqualTo(Integer value) {
            addCriterion("H19_3 <>", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3GreaterThan(Integer value) {
            addCriterion("H19_3 >", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H19_3 >=", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3LessThan(Integer value) {
            addCriterion("H19_3 <", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3LessThanOrEqualTo(Integer value) {
            addCriterion("H19_3 <=", value, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3In(List<Integer> values) {
            addCriterion("H19_3 in", values, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3NotIn(List<Integer> values) {
            addCriterion("H19_3 not in", values, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3Between(Integer value1, Integer value2) {
            addCriterion("H19_3 between", value1, value2, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH19_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H19_3 not between", value1, value2, "h19_3");
            return (Criteria) this;
        }

        public Criteria andH20_1IsNull() {
            addCriterion("H20_1 is null");
            return (Criteria) this;
        }

        public Criteria andH20_1IsNotNull() {
            addCriterion("H20_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH20_1EqualTo(Integer value) {
            addCriterion("H20_1 =", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1NotEqualTo(Integer value) {
            addCriterion("H20_1 <>", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1GreaterThan(Integer value) {
            addCriterion("H20_1 >", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H20_1 >=", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1LessThan(Integer value) {
            addCriterion("H20_1 <", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1LessThanOrEqualTo(Integer value) {
            addCriterion("H20_1 <=", value, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1In(List<Integer> values) {
            addCriterion("H20_1 in", values, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1NotIn(List<Integer> values) {
            addCriterion("H20_1 not in", values, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1Between(Integer value1, Integer value2) {
            addCriterion("H20_1 between", value1, value2, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H20_1 not between", value1, value2, "h20_1");
            return (Criteria) this;
        }

        public Criteria andH20_2IsNull() {
            addCriterion("H20_2 is null");
            return (Criteria) this;
        }

        public Criteria andH20_2IsNotNull() {
            addCriterion("H20_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH20_2EqualTo(Integer value) {
            addCriterion("H20_2 =", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2NotEqualTo(Integer value) {
            addCriterion("H20_2 <>", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2GreaterThan(Integer value) {
            addCriterion("H20_2 >", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H20_2 >=", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2LessThan(Integer value) {
            addCriterion("H20_2 <", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2LessThanOrEqualTo(Integer value) {
            addCriterion("H20_2 <=", value, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2In(List<Integer> values) {
            addCriterion("H20_2 in", values, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2NotIn(List<Integer> values) {
            addCriterion("H20_2 not in", values, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2Between(Integer value1, Integer value2) {
            addCriterion("H20_2 between", value1, value2, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H20_2 not between", value1, value2, "h20_2");
            return (Criteria) this;
        }

        public Criteria andH20_3IsNull() {
            addCriterion("H20_3 is null");
            return (Criteria) this;
        }

        public Criteria andH20_3IsNotNull() {
            addCriterion("H20_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH20_3EqualTo(Integer value) {
            addCriterion("H20_3 =", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3NotEqualTo(Integer value) {
            addCriterion("H20_3 <>", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3GreaterThan(Integer value) {
            addCriterion("H20_3 >", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H20_3 >=", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3LessThan(Integer value) {
            addCriterion("H20_3 <", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3LessThanOrEqualTo(Integer value) {
            addCriterion("H20_3 <=", value, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3In(List<Integer> values) {
            addCriterion("H20_3 in", values, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3NotIn(List<Integer> values) {
            addCriterion("H20_3 not in", values, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3Between(Integer value1, Integer value2) {
            addCriterion("H20_3 between", value1, value2, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH20_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H20_3 not between", value1, value2, "h20_3");
            return (Criteria) this;
        }

        public Criteria andH21_1IsNull() {
            addCriterion("H21_1 is null");
            return (Criteria) this;
        }

        public Criteria andH21_1IsNotNull() {
            addCriterion("H21_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH21_1EqualTo(Integer value) {
            addCriterion("H21_1 =", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1NotEqualTo(Integer value) {
            addCriterion("H21_1 <>", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1GreaterThan(Integer value) {
            addCriterion("H21_1 >", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H21_1 >=", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1LessThan(Integer value) {
            addCriterion("H21_1 <", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1LessThanOrEqualTo(Integer value) {
            addCriterion("H21_1 <=", value, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1In(List<Integer> values) {
            addCriterion("H21_1 in", values, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1NotIn(List<Integer> values) {
            addCriterion("H21_1 not in", values, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1Between(Integer value1, Integer value2) {
            addCriterion("H21_1 between", value1, value2, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H21_1 not between", value1, value2, "h21_1");
            return (Criteria) this;
        }

        public Criteria andH21_2IsNull() {
            addCriterion("H21_2 is null");
            return (Criteria) this;
        }

        public Criteria andH21_2IsNotNull() {
            addCriterion("H21_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH21_2EqualTo(Integer value) {
            addCriterion("H21_2 =", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2NotEqualTo(Integer value) {
            addCriterion("H21_2 <>", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2GreaterThan(Integer value) {
            addCriterion("H21_2 >", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H21_2 >=", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2LessThan(Integer value) {
            addCriterion("H21_2 <", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2LessThanOrEqualTo(Integer value) {
            addCriterion("H21_2 <=", value, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2In(List<Integer> values) {
            addCriterion("H21_2 in", values, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2NotIn(List<Integer> values) {
            addCriterion("H21_2 not in", values, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2Between(Integer value1, Integer value2) {
            addCriterion("H21_2 between", value1, value2, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H21_2 not between", value1, value2, "h21_2");
            return (Criteria) this;
        }

        public Criteria andH21_3IsNull() {
            addCriterion("H21_3 is null");
            return (Criteria) this;
        }

        public Criteria andH21_3IsNotNull() {
            addCriterion("H21_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH21_3EqualTo(Integer value) {
            addCriterion("H21_3 =", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3NotEqualTo(Integer value) {
            addCriterion("H21_3 <>", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3GreaterThan(Integer value) {
            addCriterion("H21_3 >", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H21_3 >=", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3LessThan(Integer value) {
            addCriterion("H21_3 <", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3LessThanOrEqualTo(Integer value) {
            addCriterion("H21_3 <=", value, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3In(List<Integer> values) {
            addCriterion("H21_3 in", values, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3NotIn(List<Integer> values) {
            addCriterion("H21_3 not in", values, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3Between(Integer value1, Integer value2) {
            addCriterion("H21_3 between", value1, value2, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH21_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H21_3 not between", value1, value2, "h21_3");
            return (Criteria) this;
        }

        public Criteria andH22_1IsNull() {
            addCriterion("H22_1 is null");
            return (Criteria) this;
        }

        public Criteria andH22_1IsNotNull() {
            addCriterion("H22_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH22_1EqualTo(Integer value) {
            addCriterion("H22_1 =", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1NotEqualTo(Integer value) {
            addCriterion("H22_1 <>", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1GreaterThan(Integer value) {
            addCriterion("H22_1 >", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H22_1 >=", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1LessThan(Integer value) {
            addCriterion("H22_1 <", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1LessThanOrEqualTo(Integer value) {
            addCriterion("H22_1 <=", value, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1In(List<Integer> values) {
            addCriterion("H22_1 in", values, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1NotIn(List<Integer> values) {
            addCriterion("H22_1 not in", values, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1Between(Integer value1, Integer value2) {
            addCriterion("H22_1 between", value1, value2, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H22_1 not between", value1, value2, "h22_1");
            return (Criteria) this;
        }

        public Criteria andH22_2IsNull() {
            addCriterion("H22_2 is null");
            return (Criteria) this;
        }

        public Criteria andH22_2IsNotNull() {
            addCriterion("H22_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH22_2EqualTo(Integer value) {
            addCriterion("H22_2 =", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2NotEqualTo(Integer value) {
            addCriterion("H22_2 <>", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2GreaterThan(Integer value) {
            addCriterion("H22_2 >", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H22_2 >=", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2LessThan(Integer value) {
            addCriterion("H22_2 <", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2LessThanOrEqualTo(Integer value) {
            addCriterion("H22_2 <=", value, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2In(List<Integer> values) {
            addCriterion("H22_2 in", values, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2NotIn(List<Integer> values) {
            addCriterion("H22_2 not in", values, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2Between(Integer value1, Integer value2) {
            addCriterion("H22_2 between", value1, value2, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H22_2 not between", value1, value2, "h22_2");
            return (Criteria) this;
        }

        public Criteria andH22_3IsNull() {
            addCriterion("H22_3 is null");
            return (Criteria) this;
        }

        public Criteria andH22_3IsNotNull() {
            addCriterion("H22_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH22_3EqualTo(Integer value) {
            addCriterion("H22_3 =", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3NotEqualTo(Integer value) {
            addCriterion("H22_3 <>", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3GreaterThan(Integer value) {
            addCriterion("H22_3 >", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H22_3 >=", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3LessThan(Integer value) {
            addCriterion("H22_3 <", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3LessThanOrEqualTo(Integer value) {
            addCriterion("H22_3 <=", value, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3In(List<Integer> values) {
            addCriterion("H22_3 in", values, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3NotIn(List<Integer> values) {
            addCriterion("H22_3 not in", values, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3Between(Integer value1, Integer value2) {
            addCriterion("H22_3 between", value1, value2, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH22_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H22_3 not between", value1, value2, "h22_3");
            return (Criteria) this;
        }

        public Criteria andH23_1IsNull() {
            addCriterion("H23_1 is null");
            return (Criteria) this;
        }

        public Criteria andH23_1IsNotNull() {
            addCriterion("H23_1 is not null");
            return (Criteria) this;
        }

        public Criteria andH23_1EqualTo(Integer value) {
            addCriterion("H23_1 =", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1NotEqualTo(Integer value) {
            addCriterion("H23_1 <>", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1GreaterThan(Integer value) {
            addCriterion("H23_1 >", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1GreaterThanOrEqualTo(Integer value) {
            addCriterion("H23_1 >=", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1LessThan(Integer value) {
            addCriterion("H23_1 <", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1LessThanOrEqualTo(Integer value) {
            addCriterion("H23_1 <=", value, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1In(List<Integer> values) {
            addCriterion("H23_1 in", values, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1NotIn(List<Integer> values) {
            addCriterion("H23_1 not in", values, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1Between(Integer value1, Integer value2) {
            addCriterion("H23_1 between", value1, value2, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_1NotBetween(Integer value1, Integer value2) {
            addCriterion("H23_1 not between", value1, value2, "h23_1");
            return (Criteria) this;
        }

        public Criteria andH23_2IsNull() {
            addCriterion("H23_2 is null");
            return (Criteria) this;
        }

        public Criteria andH23_2IsNotNull() {
            addCriterion("H23_2 is not null");
            return (Criteria) this;
        }

        public Criteria andH23_2EqualTo(Integer value) {
            addCriterion("H23_2 =", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2NotEqualTo(Integer value) {
            addCriterion("H23_2 <>", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2GreaterThan(Integer value) {
            addCriterion("H23_2 >", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2GreaterThanOrEqualTo(Integer value) {
            addCriterion("H23_2 >=", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2LessThan(Integer value) {
            addCriterion("H23_2 <", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2LessThanOrEqualTo(Integer value) {
            addCriterion("H23_2 <=", value, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2In(List<Integer> values) {
            addCriterion("H23_2 in", values, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2NotIn(List<Integer> values) {
            addCriterion("H23_2 not in", values, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2Between(Integer value1, Integer value2) {
            addCriterion("H23_2 between", value1, value2, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_2NotBetween(Integer value1, Integer value2) {
            addCriterion("H23_2 not between", value1, value2, "h23_2");
            return (Criteria) this;
        }

        public Criteria andH23_3IsNull() {
            addCriterion("H23_3 is null");
            return (Criteria) this;
        }

        public Criteria andH23_3IsNotNull() {
            addCriterion("H23_3 is not null");
            return (Criteria) this;
        }

        public Criteria andH23_3EqualTo(Integer value) {
            addCriterion("H23_3 =", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3NotEqualTo(Integer value) {
            addCriterion("H23_3 <>", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3GreaterThan(Integer value) {
            addCriterion("H23_3 >", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3GreaterThanOrEqualTo(Integer value) {
            addCriterion("H23_3 >=", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3LessThan(Integer value) {
            addCriterion("H23_3 <", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3LessThanOrEqualTo(Integer value) {
            addCriterion("H23_3 <=", value, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3In(List<Integer> values) {
            addCriterion("H23_3 in", values, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3NotIn(List<Integer> values) {
            addCriterion("H23_3 not in", values, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3Between(Integer value1, Integer value2) {
            addCriterion("H23_3 between", value1, value2, "h23_3");
            return (Criteria) this;
        }

        public Criteria andH23_3NotBetween(Integer value1, Integer value2) {
            addCriterion("H23_3 not between", value1, value2, "h23_3");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}