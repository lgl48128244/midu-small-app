package com.leniao.huanbao.service;

import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ProductionSituationService {
    /**
     * 根据单位id查询绑定的方案信息
     * @param projIds 单位id集合
     * @param params 查询参数 有效参数 机构id agencyId， 方案生效开始时间 begin， 方案生效结束时间 end
     * @return
     */
    List<ReduceEmmissionDto> selectProductionSituationByNotAreaUser(List<Long> projIds, AreaCodeJoinOther areaCode, Integer userGrade, Map<String,Object> params);

    /**
     * 区域用户查询机构下所有单位的错峰生产方案执行情况
     * @param agencyIds 机构id集合
     * @param params 查询参数 有效参数 单位id projId，行业id industryId， 机构id agencyId， 方案生效开始时间 begin， 方案生效结束时间 end
     * @return
     */
    List<ReduceEmmissionDto> selectProductionSituationByAreaUser(List<Long> agencyIds, Map<String,Object> params);
}
