package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;


@ToString
@TableName("tblngroup")
public class Tblngroup {
    private Integer groupid;

    private String groupname;

    private Integer devsysid;

    private Integer projid;

    public Integer getGroupid() {
        return groupid;
    }

    public void setGroupid(Integer groupid) {
        this.groupid = groupid;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname == null ? null : groupname.trim();
    }

    public Integer getDevsysid() {
        return devsysid;
    }

    public void setDevsysid(Integer devsysid) {
        this.devsysid = devsysid;
    }

    public Integer getProjid() {
        return projid;
    }

    public void setProjid(Integer projid) {
        this.projid = projid;
    }
}