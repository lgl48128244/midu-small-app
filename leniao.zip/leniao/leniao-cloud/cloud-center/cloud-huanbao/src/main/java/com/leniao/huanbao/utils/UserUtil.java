package com.leniao.huanbao.utils;

import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;

import java.util.List;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 区域用户信息获取工具
 * @author: jiangdy
 * @create: 2019-12-23 15:11
 **/
public class UserUtil {

    /**
     * 获取区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
     * @param areaCode
     * @return
     */
    public static Integer getUserGrade(AreaCodeJoinOther areaCode) {

        if (areaCode == null) {
            return null;
        }
        if (!"000000".equals(areaCode.getAreaCode())) {
            return 3;
        }
        if (!"000000".equals(areaCode.getCityCode())) {
            return 2;
        }
        if (!"000000".equals(areaCode.getProvinceCode())) {
            return 1;
        }
        return 0;
    }

    public static Integer getAgencyGrade(HbyAgency areaCode) {

        if (areaCode == null) {
            return null;
        }
        if (!"000000".equals(areaCode.getAreaCode())) {
            return 3;
        }
        if (!"000000".equals(areaCode.getCityCode())) {
            return 2;
        }
        if (!"000000".equals(areaCode.getProvinceCode())) {
            return 1;
        }

        return 0;
    }

    /**
     * 判断该方案所在区域是否是当前用户所管理的区域
     * @param areaCode 用户所在区域的区域码
     * @param plan 方案信息
     * @return
     */
    public static boolean isManagementArea(AreaCodeJoinOther areaCode, HbyReduceEmmissionPlan plan) {

        // 全国账号的权限只由它的类型决定，有操作权的可以操作所有，无操作可以查看所有
        if (areaCode.getProvinceCode().equals("000000")) {
            return true;
        }
        // 省份
        if (!areaCode.getProvinceCode().equals(plan.getProvinceCode())) {
            return false;
        }
        // 市区
        if (!areaCode.getCityCode().equals(plan.getCityCode())) {
            return false;
        }
        // 县区
        if (!areaCode.getAreaCode().equals(plan.getAreaCode())) {
            return false;
        }

        return true;
    }

    /**
     * 判断该方案所在区域是否是当前用户所管理的区域
     * @param areaCode 用户所在区域的区域码
     * @param plan 方案信息
     * @return
     */
    public static boolean isManagementArea(AreaCodeJoinOther areaCode, HbyAgency plan) {

        // 省份
        if (!areaCode.getProvinceCode().equals(plan.getProvinceCode())) {
            return false;
        }
        // 市区
        if (!areaCode.getCityCode().equals(plan.getCityCode())) {
            return false;
        }
        // 县区
        if (!areaCode.getAreaCode().equals(plan.getAreaCode())) {
            return false;
        }

        return true;
    }


    public static List<TreeMenu> setPermission(AreaCodeJoinOther areaCode, List<TreeMenu> treeMenuList) {
        if (treeMenuList == null || treeMenuList.size() == 0) {
            return treeMenuList;
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        if (areaCode.getProvinceCode().equals("000000") || (userInfo.getGroupType() == 2 && userInfo.getGroupOnlyRead() == 0)) {
            treeMenuList.forEach(tree -> {
                tree.setOnlyRead(userInfo.getGroupOnlyRead());
                // 全国用户具有最高权限，权限需要穿透到子集
                UserUtil.setPermission(areaCode, tree.getChildTreeMenu());
            });
        }
        return treeMenuList;
    }

    public static List<ReduceEmmissionDto> setPermission2(AreaCodeJoinOther areaCode, List<ReduceEmmissionDto> treeMenuList) {
        UserInfo userInfo = GlobalConstant.getUserInfo();
        if (areaCode.getProvinceCode().equals("000000") || (userInfo.getGroupType() == 2 && userInfo.getGroupOnlyRead() == 0)) {
            treeMenuList.forEach(tree -> {
                tree.setOnlyRead(userInfo.getGroupOnlyRead());
            });
        }
        return treeMenuList;
    }
}
