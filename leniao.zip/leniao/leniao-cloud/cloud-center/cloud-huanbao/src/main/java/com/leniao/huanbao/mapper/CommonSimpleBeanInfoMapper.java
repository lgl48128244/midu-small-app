package com.leniao.huanbao.mapper;

import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.DeviceEleUseDto;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

public interface CommonSimpleBeanInfoMapper {

    /**
     * @description: 根据单位ID查询其下监测点关联的设备基本信息集合
     * @author: haosw
     * @param:
     * @return:
     * @date: 2019/12/23 14:48
     */
    List<DevDto> findDevicesOfOverLookPointByUnitID(Integer unitId);

    /**
     * @description: 根据单位ID查询单位的基本信息, unitId==NULL时,查所有建立了监测点的单位基本信息
     * @author: haosw
     * @param: unitId:单位ID
     * @return:
     * @date: 2019/12/24 15:31
     */
    List<UnitBasicInfoDto> findUnitBasicInfoByID(Integer unitId);

    /**
     * @description: 查询所有监测点下的设备的报警数据, 并缓存最大报警ID
     * @author: haosw
     * @param:
     * @return: List<HbyForwardSyncErrorDto>
     * @date: 2019/12/25 15:59
     */
    List<HbyErrorDto.ForwardSyncErrorDto> findAllOverlookDevErrs(int maxWranId);

    /**
     * @description: 查询单位指定时间的各个类型异常的数量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 17:40
     */
    List<HashMap<String, Object>> findUnitEveryErrTypeNum(@Param("unitId") Integer unitId, @Param("errTime") Date errTime);

    /**
     * @description: 方法的作用描述
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/15 13:23
     */
    List<DeviceEleUseDto> findMonthEleUseOfDevice(@Param("year") int year, @Param("month") int monthOfYear);
}
