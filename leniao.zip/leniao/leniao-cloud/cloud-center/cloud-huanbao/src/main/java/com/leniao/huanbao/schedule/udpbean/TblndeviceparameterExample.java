package com.leniao.huanbao.schedule.udpbean;

import java.util.ArrayList;
import java.util.List;

public class TblndeviceparameterExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblndeviceparameterExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andPidIsNull() {
            addCriterion("PID is null");
            return (Criteria) this;
        }

        public Criteria andPidIsNotNull() {
            addCriterion("PID is not null");
            return (Criteria) this;
        }

        public Criteria andPidEqualTo(String value) {
            addCriterion("PID =", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotEqualTo(String value) {
            addCriterion("PID <>", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThan(String value) {
            addCriterion("PID >", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThanOrEqualTo(String value) {
            addCriterion("PID >=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThan(String value) {
            addCriterion("PID <", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThanOrEqualTo(String value) {
            addCriterion("PID <=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLike(String value) {
            addCriterion("PID like", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotLike(String value) {
            addCriterion("PID not like", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidIn(List<String> values) {
            addCriterion("PID in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotIn(List<String> values) {
            addCriterion("PID not in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidBetween(String value1, String value2) {
            addCriterion("PID between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotBetween(String value1, String value2) {
            addCriterion("PID not between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNull() {
            addCriterion("devIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNotNull() {
            addCriterion("devIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevidpkEqualTo(Integer value) {
            addCriterion("devIdpk =", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotEqualTo(Integer value) {
            addCriterion("devIdpk <>", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThan(Integer value) {
            addCriterion("devIdpk >", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIdpk >=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThan(Integer value) {
            addCriterion("devIdpk <", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThanOrEqualTo(Integer value) {
            addCriterion("devIdpk <=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIn(List<Integer> values) {
            addCriterion("devIdpk in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotIn(List<Integer> values) {
            addCriterion("devIdpk not in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk not between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIsNull() {
            addCriterion("devSignature is null");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIsNotNull() {
            addCriterion("devSignature is not null");
            return (Criteria) this;
        }

        public Criteria andDevsignatureEqualTo(String value) {
            addCriterion("devSignature =", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotEqualTo(String value) {
            addCriterion("devSignature <>", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureGreaterThan(String value) {
            addCriterion("devSignature >", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureGreaterThanOrEqualTo(String value) {
            addCriterion("devSignature >=", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLessThan(String value) {
            addCriterion("devSignature <", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLessThanOrEqualTo(String value) {
            addCriterion("devSignature <=", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLike(String value) {
            addCriterion("devSignature like", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotLike(String value) {
            addCriterion("devSignature not like", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIn(List<String> values) {
            addCriterion("devSignature in", values, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotIn(List<String> values) {
            addCriterion("devSignature not in", values, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureBetween(String value1, String value2) {
            addCriterion("devSignature between", value1, value2, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotBetween(String value1, String value2) {
            addCriterion("devSignature not between", value1, value2, "devsignature");
            return (Criteria) this;
        }

        public Criteria andsetNameIsNull() {
            addCriterion("setName is null");
            return (Criteria) this;
        }

        public Criteria andsetNameIsNotNull() {
            addCriterion("setName is not null");
            return (Criteria) this;
        }

        public Criteria andsetNameEqualTo(String value) {
            addCriterion("setName =", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameNotEqualTo(String value) {
            addCriterion("setName <>", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameGreaterThan(String value) {
            addCriterion("setName >", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameGreaterThanOrEqualTo(String value) {
            addCriterion("setName >=", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameLessThan(String value) {
            addCriterion("setName <", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameLessThanOrEqualTo(String value) {
            addCriterion("setName <=", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameLike(String value) {
            addCriterion("setName like", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameNotLike(String value) {
            addCriterion("setName not like", value, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameIn(List<String> values) {
            addCriterion("setName in", values, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameNotIn(List<String> values) {
            addCriterion("setName not in", values, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameBetween(String value1, String value2) {
            addCriterion("setName between", value1, value2, "setName");
            return (Criteria) this;
        }

        public Criteria andsetNameNotBetween(String value1, String value2) {
            addCriterion("setName not between", value1, value2, "setName");
            return (Criteria) this;
        }

        public Criteria andSetmodelIsNull() {
            addCriterion("setModel is null");
            return (Criteria) this;
        }

        public Criteria andSetmodelIsNotNull() {
            addCriterion("setModel is not null");
            return (Criteria) this;
        }

        public Criteria andSetmodelEqualTo(String value) {
            addCriterion("setModel =", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelNotEqualTo(String value) {
            addCriterion("setModel <>", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelGreaterThan(String value) {
            addCriterion("setModel >", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelGreaterThanOrEqualTo(String value) {
            addCriterion("setModel >=", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelLessThan(String value) {
            addCriterion("setModel <", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelLessThanOrEqualTo(String value) {
            addCriterion("setModel <=", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelLike(String value) {
            addCriterion("setModel like", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelNotLike(String value) {
            addCriterion("setModel not like", value, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelIn(List<String> values) {
            addCriterion("setModel in", values, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelNotIn(List<String> values) {
            addCriterion("setModel not in", values, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelBetween(String value1, String value2) {
            addCriterion("setModel between", value1, value2, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSetmodelNotBetween(String value1, String value2) {
            addCriterion("setModel not between", value1, value2, "setmodel");
            return (Criteria) this;
        }

        public Criteria andSwitch1IsNull() {
            addCriterion("Switch1 is null");
            return (Criteria) this;
        }

        public Criteria andSwitch1IsNotNull() {
            addCriterion("Switch1 is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch1EqualTo(String value) {
            addCriterion("Switch1 =", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1NotEqualTo(String value) {
            addCriterion("Switch1 <>", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1GreaterThan(String value) {
            addCriterion("Switch1 >", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1GreaterThanOrEqualTo(String value) {
            addCriterion("Switch1 >=", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1LessThan(String value) {
            addCriterion("Switch1 <", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1LessThanOrEqualTo(String value) {
            addCriterion("Switch1 <=", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1Like(String value) {
            addCriterion("Switch1 like", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1NotLike(String value) {
            addCriterion("Switch1 not like", value, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1In(List<String> values) {
            addCriterion("Switch1 in", values, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1NotIn(List<String> values) {
            addCriterion("Switch1 not in", values, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1Between(String value1, String value2) {
            addCriterion("Switch1 between", value1, value2, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch1NotBetween(String value1, String value2) {
            addCriterion("Switch1 not between", value1, value2, "switch1");
            return (Criteria) this;
        }

        public Criteria andSwitch2IsNull() {
            addCriterion("Switch2 is null");
            return (Criteria) this;
        }

        public Criteria andSwitch2IsNotNull() {
            addCriterion("Switch2 is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch2EqualTo(String value) {
            addCriterion("Switch2 =", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2NotEqualTo(String value) {
            addCriterion("Switch2 <>", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2GreaterThan(String value) {
            addCriterion("Switch2 >", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2GreaterThanOrEqualTo(String value) {
            addCriterion("Switch2 >=", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2LessThan(String value) {
            addCriterion("Switch2 <", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2LessThanOrEqualTo(String value) {
            addCriterion("Switch2 <=", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2Like(String value) {
            addCriterion("Switch2 like", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2NotLike(String value) {
            addCriterion("Switch2 not like", value, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2In(List<String> values) {
            addCriterion("Switch2 in", values, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2NotIn(List<String> values) {
            addCriterion("Switch2 not in", values, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2Between(String value1, String value2) {
            addCriterion("Switch2 between", value1, value2, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch2NotBetween(String value1, String value2) {
            addCriterion("Switch2 not between", value1, value2, "switch2");
            return (Criteria) this;
        }

        public Criteria andSwitch3IsNull() {
            addCriterion("Switch3 is null");
            return (Criteria) this;
        }

        public Criteria andSwitch3IsNotNull() {
            addCriterion("Switch3 is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch3EqualTo(String value) {
            addCriterion("Switch3 =", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3NotEqualTo(String value) {
            addCriterion("Switch3 <>", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3GreaterThan(String value) {
            addCriterion("Switch3 >", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3GreaterThanOrEqualTo(String value) {
            addCriterion("Switch3 >=", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3LessThan(String value) {
            addCriterion("Switch3 <", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3LessThanOrEqualTo(String value) {
            addCriterion("Switch3 <=", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3Like(String value) {
            addCriterion("Switch3 like", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3NotLike(String value) {
            addCriterion("Switch3 not like", value, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3In(List<String> values) {
            addCriterion("Switch3 in", values, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3NotIn(List<String> values) {
            addCriterion("Switch3 not in", values, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3Between(String value1, String value2) {
            addCriterion("Switch3 between", value1, value2, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch3NotBetween(String value1, String value2) {
            addCriterion("Switch3 not between", value1, value2, "switch3");
            return (Criteria) this;
        }

        public Criteria andSwitch4IsNull() {
            addCriterion("Switch4 is null");
            return (Criteria) this;
        }

        public Criteria andSwitch4IsNotNull() {
            addCriterion("Switch4 is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch4EqualTo(String value) {
            addCriterion("Switch4 =", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4NotEqualTo(String value) {
            addCriterion("Switch4 <>", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4GreaterThan(String value) {
            addCriterion("Switch4 >", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4GreaterThanOrEqualTo(String value) {
            addCriterion("Switch4 >=", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4LessThan(String value) {
            addCriterion("Switch4 <", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4LessThanOrEqualTo(String value) {
            addCriterion("Switch4 <=", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4Like(String value) {
            addCriterion("Switch4 like", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4NotLike(String value) {
            addCriterion("Switch4 not like", value, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4In(List<String> values) {
            addCriterion("Switch4 in", values, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4NotIn(List<String> values) {
            addCriterion("Switch4 not in", values, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4Between(String value1, String value2) {
            addCriterion("Switch4 between", value1, value2, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch4NotBetween(String value1, String value2) {
            addCriterion("Switch4 not between", value1, value2, "switch4");
            return (Criteria) this;
        }

        public Criteria andSwitch1cIsNull() {
            addCriterion("Switch1C is null");
            return (Criteria) this;
        }

        public Criteria andSwitch1cIsNotNull() {
            addCriterion("Switch1C is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch1cEqualTo(String value) {
            addCriterion("Switch1C =", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cNotEqualTo(String value) {
            addCriterion("Switch1C <>", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cGreaterThan(String value) {
            addCriterion("Switch1C >", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cGreaterThanOrEqualTo(String value) {
            addCriterion("Switch1C >=", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cLessThan(String value) {
            addCriterion("Switch1C <", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cLessThanOrEqualTo(String value) {
            addCriterion("Switch1C <=", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cLike(String value) {
            addCriterion("Switch1C like", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cNotLike(String value) {
            addCriterion("Switch1C not like", value, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cIn(List<String> values) {
            addCriterion("Switch1C in", values, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cNotIn(List<String> values) {
            addCriterion("Switch1C not in", values, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cBetween(String value1, String value2) {
            addCriterion("Switch1C between", value1, value2, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch1cNotBetween(String value1, String value2) {
            addCriterion("Switch1C not between", value1, value2, "switch1c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cIsNull() {
            addCriterion("Switch2C is null");
            return (Criteria) this;
        }

        public Criteria andSwitch2cIsNotNull() {
            addCriterion("Switch2C is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch2cEqualTo(String value) {
            addCriterion("Switch2C =", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cNotEqualTo(String value) {
            addCriterion("Switch2C <>", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cGreaterThan(String value) {
            addCriterion("Switch2C >", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cGreaterThanOrEqualTo(String value) {
            addCriterion("Switch2C >=", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cLessThan(String value) {
            addCriterion("Switch2C <", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cLessThanOrEqualTo(String value) {
            addCriterion("Switch2C <=", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cLike(String value) {
            addCriterion("Switch2C like", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cNotLike(String value) {
            addCriterion("Switch2C not like", value, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cIn(List<String> values) {
            addCriterion("Switch2C in", values, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cNotIn(List<String> values) {
            addCriterion("Switch2C not in", values, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cBetween(String value1, String value2) {
            addCriterion("Switch2C between", value1, value2, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch2cNotBetween(String value1, String value2) {
            addCriterion("Switch2C not between", value1, value2, "switch2c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cIsNull() {
            addCriterion("Switch3C is null");
            return (Criteria) this;
        }

        public Criteria andSwitch3cIsNotNull() {
            addCriterion("Switch3C is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch3cEqualTo(String value) {
            addCriterion("Switch3C =", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cNotEqualTo(String value) {
            addCriterion("Switch3C <>", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cGreaterThan(String value) {
            addCriterion("Switch3C >", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cGreaterThanOrEqualTo(String value) {
            addCriterion("Switch3C >=", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cLessThan(String value) {
            addCriterion("Switch3C <", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cLessThanOrEqualTo(String value) {
            addCriterion("Switch3C <=", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cLike(String value) {
            addCriterion("Switch3C like", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cNotLike(String value) {
            addCriterion("Switch3C not like", value, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cIn(List<String> values) {
            addCriterion("Switch3C in", values, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cNotIn(List<String> values) {
            addCriterion("Switch3C not in", values, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cBetween(String value1, String value2) {
            addCriterion("Switch3C between", value1, value2, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch3cNotBetween(String value1, String value2) {
            addCriterion("Switch3C not between", value1, value2, "switch3c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cIsNull() {
            addCriterion("Switch4C is null");
            return (Criteria) this;
        }

        public Criteria andSwitch4cIsNotNull() {
            addCriterion("Switch4C is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch4cEqualTo(String value) {
            addCriterion("Switch4C =", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cNotEqualTo(String value) {
            addCriterion("Switch4C <>", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cGreaterThan(String value) {
            addCriterion("Switch4C >", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cGreaterThanOrEqualTo(String value) {
            addCriterion("Switch4C >=", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cLessThan(String value) {
            addCriterion("Switch4C <", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cLessThanOrEqualTo(String value) {
            addCriterion("Switch4C <=", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cLike(String value) {
            addCriterion("Switch4C like", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cNotLike(String value) {
            addCriterion("Switch4C not like", value, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cIn(List<String> values) {
            addCriterion("Switch4C in", values, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cNotIn(List<String> values) {
            addCriterion("Switch4C not in", values, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cBetween(String value1, String value2) {
            addCriterion("Switch4C between", value1, value2, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch4cNotBetween(String value1, String value2) {
            addCriterion("Switch4C not between", value1, value2, "switch4c");
            return (Criteria) this;
        }

        public Criteria andSwitch1bIsNull() {
            addCriterion("Switch1B is null");
            return (Criteria) this;
        }

        public Criteria andSwitch1bIsNotNull() {
            addCriterion("Switch1B is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch1bEqualTo(Integer value) {
            addCriterion("Switch1B =", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bNotEqualTo(Integer value) {
            addCriterion("Switch1B <>", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bGreaterThan(Integer value) {
            addCriterion("Switch1B >", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bGreaterThanOrEqualTo(Integer value) {
            addCriterion("Switch1B >=", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bLessThan(Integer value) {
            addCriterion("Switch1B <", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bLessThanOrEqualTo(Integer value) {
            addCriterion("Switch1B <=", value, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bIn(List<Integer> values) {
            addCriterion("Switch1B in", values, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bNotIn(List<Integer> values) {
            addCriterion("Switch1B not in", values, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bBetween(Integer value1, Integer value2) {
            addCriterion("Switch1B between", value1, value2, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch1bNotBetween(Integer value1, Integer value2) {
            addCriterion("Switch1B not between", value1, value2, "switch1b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bIsNull() {
            addCriterion("Switch2B is null");
            return (Criteria) this;
        }

        public Criteria andSwitch2bIsNotNull() {
            addCriterion("Switch2B is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch2bEqualTo(Integer value) {
            addCriterion("Switch2B =", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bNotEqualTo(Integer value) {
            addCriterion("Switch2B <>", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bGreaterThan(Integer value) {
            addCriterion("Switch2B >", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bGreaterThanOrEqualTo(Integer value) {
            addCriterion("Switch2B >=", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bLessThan(Integer value) {
            addCriterion("Switch2B <", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bLessThanOrEqualTo(Integer value) {
            addCriterion("Switch2B <=", value, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bIn(List<Integer> values) {
            addCriterion("Switch2B in", values, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bNotIn(List<Integer> values) {
            addCriterion("Switch2B not in", values, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bBetween(Integer value1, Integer value2) {
            addCriterion("Switch2B between", value1, value2, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch2bNotBetween(Integer value1, Integer value2) {
            addCriterion("Switch2B not between", value1, value2, "switch2b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bIsNull() {
            addCriterion("Switch3B is null");
            return (Criteria) this;
        }

        public Criteria andSwitch3bIsNotNull() {
            addCriterion("Switch3B is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch3bEqualTo(Integer value) {
            addCriterion("Switch3B =", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bNotEqualTo(Integer value) {
            addCriterion("Switch3B <>", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bGreaterThan(Integer value) {
            addCriterion("Switch3B >", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bGreaterThanOrEqualTo(Integer value) {
            addCriterion("Switch3B >=", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bLessThan(Integer value) {
            addCriterion("Switch3B <", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bLessThanOrEqualTo(Integer value) {
            addCriterion("Switch3B <=", value, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bIn(List<Integer> values) {
            addCriterion("Switch3B in", values, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bNotIn(List<Integer> values) {
            addCriterion("Switch3B not in", values, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bBetween(Integer value1, Integer value2) {
            addCriterion("Switch3B between", value1, value2, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch3bNotBetween(Integer value1, Integer value2) {
            addCriterion("Switch3B not between", value1, value2, "switch3b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bIsNull() {
            addCriterion("Switch4B is null");
            return (Criteria) this;
        }

        public Criteria andSwitch4bIsNotNull() {
            addCriterion("Switch4B is not null");
            return (Criteria) this;
        }

        public Criteria andSwitch4bEqualTo(Integer value) {
            addCriterion("Switch4B =", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bNotEqualTo(Integer value) {
            addCriterion("Switch4B <>", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bGreaterThan(Integer value) {
            addCriterion("Switch4B >", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bGreaterThanOrEqualTo(Integer value) {
            addCriterion("Switch4B >=", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bLessThan(Integer value) {
            addCriterion("Switch4B <", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bLessThanOrEqualTo(Integer value) {
            addCriterion("Switch4B <=", value, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bIn(List<Integer> values) {
            addCriterion("Switch4B in", values, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bNotIn(List<Integer> values) {
            addCriterion("Switch4B not in", values, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bBetween(Integer value1, Integer value2) {
            addCriterion("Switch4B between", value1, value2, "switch4b");
            return (Criteria) this;
        }

        public Criteria andSwitch4bNotBetween(Integer value1, Integer value2) {
            addCriterion("Switch4B not between", value1, value2, "switch4b");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}