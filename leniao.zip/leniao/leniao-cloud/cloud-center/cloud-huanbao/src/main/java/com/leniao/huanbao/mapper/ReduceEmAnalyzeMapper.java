package com.leniao.huanbao.mapper;

import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.statisticanalysis.StatisticAnalysisDto;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ReduceEmAnalyzeMapper {

    List<StatisticAnalysisDto> selectStatisticAnalysisList(@Param("projIds")List<Long> projIds, @Param("platformId") Integer platformId, @Param("params") Map<String,Object> params);

    List<StatisticAnalysisDto> selectStatisticAnalysisList2(@Param("projIds")List<Long> projIds, @Param("platformId") Integer platformId, @Param("code") AreaCodeJoinOther code,
                                                            @Param("grade") Integer grade, @Param("year") int year,
                                                            @Param("month") int month, @Param("day") int day, @Param("params") Map<String,Object> params);

    @MapKey("projId")
    Map<Integer, StatisticAnalysisDto> selectMainDevice(@Param("projIds")List<Long> projIds, @Param("platformId") Integer platformId);

    @MapKey("projId")
    Map<Integer, StatisticAnalysisDto> selectRanking(@Param("devIdpks")List<Integer> devIdpks, @Param("addTime") String addTime);

    List<StatisticAnalysisDto> selectStatisticAnalysisProjectList(@Param("projIds")List<Long> projIds, @Param("platformId") Integer platformId, @Param("params") Map<String,Object> params);
}
