package com.leniao.huanbao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.entity.UshareDeviceElectricuseExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UshareDeviceElectricuseService extends IService<UshareDeviceElectricuse> {

    int countByExample(UshareDeviceElectricuseExample example);

    int deleteByExample(UshareDeviceElectricuseExample example);

    int deleteByPrimaryKey(Integer idpk);

    int insert(UshareDeviceElectricuse record);

    int insertSelective(UshareDeviceElectricuse record);

    List<UshareDeviceElectricuse> selectByExample(UshareDeviceElectricuseExample example);

    UshareDeviceElectricuse selectByPrimaryKey(Integer idpk);

    int updateByExampleSelective(@Param("record") UshareDeviceElectricuse record, @Param("example") UshareDeviceElectricuseExample example);

    int updateByExample(@Param("record") UshareDeviceElectricuse record, @Param("example") UshareDeviceElectricuseExample example);

    int updateByPrimaryKeySelective(UshareDeviceElectricuse record);

    int updateByPrimaryKey(UshareDeviceElectricuse record);

    /**
     * 设备日电量数据信息
     * @param date
     * @param unitId
     * @param devId
     * @return
     */
    Double findUsharEleByDateTimeUnitDevId(String date,Integer unitId,Integer devId);
}
