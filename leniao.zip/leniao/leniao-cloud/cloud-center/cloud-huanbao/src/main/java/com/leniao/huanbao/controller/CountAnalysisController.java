package com.leniao.huanbao.controller;

import com.leniao.commons.BaseController;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyIndustry;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.mapper.HbyOverlookpointPlusMapper;
import com.leniao.huanbao.mapper.PermissionMapper;
import com.leniao.huanbao.mapper.TbdeviceInfoPlusMapper;
import com.leniao.huanbao.mapper.TbprojectInfoPlusMapper;
import com.leniao.huanbao.pojo.receive.*;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.APIConstant;
import com.leniao.huanbao.utils.DevUtils;
import com.leniao.huanbao.utils.EntranceConstant;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.devlist.CountUnitAnalysisInfo;
import com.leniao.service.HbyAgencyService;
import com.leniao.service.HbyIndustryService;
import com.leniao.service.HbyMonthAndYearEleCountService;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * @author liudongshuai
 * @date 2020/1/9 16:40
 * @update
 */
@CrossOrigin
@RequestMapping(EntranceConstant.COUNTANALYSIS)
@RestController
public class CountAnalysisController extends BaseController {

    /**
     * 账号用户处理
     */
    @Resource
    private PermissionService permissionService;
    @Resource
    private TbprojectInfoPlusMapper tbprojectInfoPlusMapper;
    /**
     * 行业信息表
     */
    @Resource
    private HbyIndustryService hbyIndustryService;
    /**
     * 监测点信息表
     */
    @Resource
    private HbyOverLookpointService hbyOverLookpointService;
    @Resource
    private HbyOverlookpointPlusMapper hbyOverlookpointPlusMapper;
    /**
     * 设备用电量表
     */
    @Resource
    private UshareDeviceElectricuseService ushareDeviceElectricuseService;
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    /**
     * 设备用电量月年统计表
     */
    @Resource
    private HbyMonthAndYearEleCountService hbyMonthAndYearEleCountService;
    /**
     * 设备信息表
     */
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    @Resource
    private TbdeviceInfoPlusMapper tbdeviceInfoPlusMapper;
    /**
     * 环保局信息表
     */
    @Resource
    private HbyAgencyService hbyAgencyService;
    @Resource
    private TblnprojectinfoService tblnprojectinfoService;

    @RequestMapping(value = APIConstant.UNITUSEELECTRICITYCOMPANY, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object unitUseElectricityCompany(@RequestBody HashMap<String, Object> receiveMap) {
        Integer agencyId = Integer.parseInt(String.valueOf(receiveMap.get("agencyId")));
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        Integer userId = Integer.parseInt(String.valueOf(receiveMap.get("userId")));
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId, areaCodeJoinOther!=null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null, params,this.getUserInfo().getPlatformId());
        HbyAgency hbyAgency = hbyAgencyService.getById(agencyId);
        List<Integer> unitList = isAgencyUnitNew(menuList,hbyAgency.getProvinceCode(),hbyAgency.getCityCode(),hbyAgency.getAreaCode());

        if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 1) {
            List<UnitUseEleInfo> unitUseEleInfoList = new ArrayList<>();
            String beginYear = String.valueOf(receiveMap.get("beginYear"));
            String beginMonth = String.valueOf(receiveMap.get("beginMonth"));
            String beginDay = String.valueOf(receiveMap.get("beginDay"));
            String endYear = String.valueOf(receiveMap.get("endYear"));
            String endMonth = String.valueOf(receiveMap.get("endMonth"));
            String endDay = String.valueOf(receiveMap.get("endDay"));
            for (Integer unitId:unitList ) {
                String sqlsqlpoll = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findPollDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+beginDay+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+endDay+"\'";
                String sqlsqlcon = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findConDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+beginDay+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+endDay+"\'";
                String sqlsqltotal = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findTotalDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+beginDay+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+endDay+"\'";
                UnitUseEleInfo unitUseEleInfo = new UnitUseEleInfo();
                unitUseEleInfo.setPollDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlpoll));
                unitUseEleInfo.setConDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlcon));
                unitUseEleInfo.setTotalDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqltotal));
                unitUseEleInfo.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(unitId).getProjname());
                if (unitUseEleInfo.getConDevEleUse()==0D){
                    unitUseEleInfo.setConPollProportion(0D);
                }else {
                    unitUseEleInfo.setConPollProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getPollDevEleUse()*100/unitUseEleInfo.getConDevEleUse()))).setScale(1, RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo.getTotalDevEleUse()==0D){
                    unitUseEleInfo.setConTotalProportion(0D);
                }else {
                    unitUseEleInfo.setConTotalProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getConDevEleUse()*100/unitUseEleInfo.getTotalDevEleUse()))).setScale(1,RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo==null){
                    continue;
                }else {
                    unitUseEleInfoList.add(unitUseEleInfo);
                }

            }
            Collections.sort(unitUseEleInfoList, new Comparator<UnitUseEleInfo>() {
                @Override
                public int compare(UnitUseEleInfo o1, UnitUseEleInfo o2) {
                    //降序
                    return o2.getTotalDevEleUse().compareTo(o1.getTotalDevEleUse());
                }
            });
            if (unitUseEleInfoList.size() < (page - 1) * size) {
                return renderResult(false, -1, "无更多数据");
            } else {
                List<UnitUseEleInfo> unitUseEleInfos = new LinkedList<>();
                Map<String, Object> resultMap = new HashMap<>();
                if (unitUseEleInfoList.size() > page * size) {
                    for (int i = (page - 1) * size; i < page * size; i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                } else {
                    for (int i = (page - 1) * size; i < unitUseEleInfoList.size(); i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                }
                resultMap.put("list", unitUseEleInfos);
                resultMap.put("size", unitUseEleInfos.size());
                resultMap.put("page", page);
                resultMap.put("total", unitUseEleInfoList.size());
                if (unitUseEleInfoList.size() % size == 0) {
                    resultMap.put("totalPage", unitUseEleInfoList.size() / size);
                } else {
                    resultMap.put("totalPage", (unitUseEleInfoList.size() / size) + 1);
                }
                return renderResult(resultMap);
            }
        } else if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 2) {

            String beginYear = String.valueOf(receiveMap.get("beginYear"));
            Integer beginMonth = Integer.valueOf(String.valueOf(receiveMap.get("beginMonth")));
            String endYear = String.valueOf(receiveMap.get("endYear"));
            String endMonth = String.valueOf(receiveMap.get("endMonth"));
            List<UnitUseEleInfo> unitUseEleInfoList = new ArrayList<>();
            for (Integer unitId:unitList ) {
                Integer dayNum = DevUtils.haveManyDay(Integer.parseInt(endYear), Integer.valueOf(endMonth));
                String sqlsqlpoll = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findPollDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+01+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+dayNum+"\'";
                String sqlsqlcon = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findConDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+01+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+dayNum+"\'";
                String sqlsqltotal = "SELECT IFNULL(SUM(dayTotalQ),0)\n" +
                        "FROM ushare_device_electricuse \n" +
                        "WHERE devIdpk IN "+hbyOverLookpointService.findTotalDevStrByUnit(unitId)+" \n" +
                        "AND addtime BETWEEN "+"\'"+beginYear+"-"+beginMonth+"-"+01+"\'"+" AND "+"\'"+endYear+"-"+endMonth+"-"+dayNum+"\'";
                UnitUseEleInfo unitUseEleInfo = new UnitUseEleInfo();
                unitUseEleInfo.setPollDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlpoll));
                unitUseEleInfo.setConDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlcon));
                unitUseEleInfo.setTotalDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqltotal));

                unitUseEleInfo.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(unitId).getProjname());
                if (unitUseEleInfo.getConDevEleUse()==0D){
                    unitUseEleInfo.setConPollProportion(0D);
                }else {
                    unitUseEleInfo.setConPollProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getPollDevEleUse()*100/unitUseEleInfo.getConDevEleUse()))).setScale(1, RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo.getTotalDevEleUse()==0D){
                    unitUseEleInfo.setConTotalProportion(0D);
                }else {
                    unitUseEleInfo.setConTotalProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getConDevEleUse()*100/unitUseEleInfo.getTotalDevEleUse()))).setScale(1,RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo==null){
                    continue;
                }else {
                    unitUseEleInfoList.add(unitUseEleInfo);
                }
            }
            Collections.sort(unitUseEleInfoList, new Comparator<UnitUseEleInfo>() {
                @Override
                public int compare(UnitUseEleInfo o1, UnitUseEleInfo o2) {
                    //降序
                    return o2.getTotalDevEleUse().compareTo(o1.getTotalDevEleUse());
                }
            });

            if (unitUseEleInfoList.size() < (page - 1) * size) {
                return renderResult(false, -1, "无更多数据");
            } else {
                List<UnitUseEleInfo> unitUseEleInfos = new LinkedList<>();
                Map<String, Object> resultMap = new HashMap<>();
                if (unitUseEleInfoList.size() > page * size) {
                    for (int i = (page - 1) * size; i < page * size; i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                } else {
                    for (int i = (page - 1) * size; i < unitUseEleInfoList.size(); i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                }
                resultMap.put("list", unitUseEleInfos);
                resultMap.put("size", unitUseEleInfos.size());
                resultMap.put("page", page);
                resultMap.put("total", unitUseEleInfoList.size());
                if (unitUseEleInfoList.size() % size == 0) {
                    resultMap.put("totalPage", unitUseEleInfoList.size() / size);
                } else {
                    resultMap.put("totalPage", (unitUseEleInfoList.size() / size) + 1);
                }
                return renderResult(resultMap);
            }
        } else if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 3) {
            Integer beginYear = Integer.valueOf(String.valueOf(receiveMap.get("beginYear")));
            Integer endYear = Integer.valueOf(String.valueOf(receiveMap.get("endYear")));
            List<UnitUseEleInfo> unitUseEleInfoList = new ArrayList<>();
            for (Integer unitId:unitList ) {

                String sqlsqlpoll = "SELECT IFNULL(SUM(dayTotalQ),0) FROM ushare_device_electricuse WHERE devIdpk IN"+hbyOverLookpointService.findPollDevStrByUnit(unitId)+" AND elYear BETWEEN "+beginYear+" AND "+ endYear;
                String sqlsqlcon = "SELECT IFNULL(SUM(dayTotalQ),0) FROM ushare_device_electricuse WHERE devIdpk IN"+hbyOverLookpointService.findConDevStrByUnit(unitId)+" AND elYear BETWEEN "+beginYear+" AND "+ endYear;
                String sqlsqltotal = "SELECT IFNULL(SUM(dayTotalQ),0) FROM ushare_device_electricuse WHERE devIdpk IN"+hbyOverLookpointService.findTotalDevStrByUnit(unitId)+" AND elYear BETWEEN "+beginYear+" AND "+ endYear;
                UnitUseEleInfo unitUseEleInfo = new UnitUseEleInfo();
                unitUseEleInfo.setPollDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlpoll));
                unitUseEleInfo.setConDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqlcon));
                unitUseEleInfo.setTotalDevEleUse(hbyOverlookpointPlusMapper.findDevTotalQByUnitId(sqlsqltotal));
                unitUseEleInfo.setUnitName(tblnprojectinfoService.findUnitAreaNameInfo(unitId).getProjname());
                if (unitUseEleInfo.getConDevEleUse()==0D){
                    unitUseEleInfo.setConPollProportion(0D);
                }else {
                    unitUseEleInfo.setConPollProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getPollDevEleUse()*100/unitUseEleInfo.getConDevEleUse()))).setScale(1, RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo.getTotalDevEleUse()==0D){
                    unitUseEleInfo.setConTotalProportion(0D);
                }else {
                    unitUseEleInfo.setConTotalProportion(Double.valueOf(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(unitUseEleInfo.getConDevEleUse()*100/unitUseEleInfo.getTotalDevEleUse()))).setScale(1,RoundingMode.HALF_UP))));
                }
                if (unitUseEleInfo==null){
                    continue;
                }else {
                    unitUseEleInfoList.add(unitUseEleInfo);
                }
            }

            Collections.sort(unitUseEleInfoList, new Comparator<UnitUseEleInfo>() {
                @Override
                public int compare(UnitUseEleInfo o1, UnitUseEleInfo o2) {
                    //降序
                    return o2.getTotalDevEleUse().compareTo(o1.getTotalDevEleUse());
                }
            });

            if (unitUseEleInfoList.size() < (page - 1) * size) {
                return renderResult(false, -1, "无更多数据");
            } else {
                List<UnitUseEleInfo> unitUseEleInfos = new LinkedList<>();
                Map<String, Object> resultMap = new HashMap<>();
                if (unitUseEleInfoList.size() > page * size) {
                    for (int i = (page - 1) * size; i < page * size; i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                } else {
                    for (int i = (page - 1) * size; i < unitUseEleInfoList.size(); i++) {
                        unitUseEleInfos.add(unitUseEleInfoList.get(i));
                    }
                }
                resultMap.put("list", unitUseEleInfos);
                resultMap.put("size", unitUseEleInfos.size());
                resultMap.put("page", page);
                resultMap.put("total", unitUseEleInfoList.size());
                if (unitUseEleInfoList.size() % size == 0) {
                    resultMap.put("totalPage", unitUseEleInfoList.size() / size);
                } else {
                    resultMap.put("totalPage", (unitUseEleInfoList.size() / size) + 1);
                }
                return renderResult(resultMap);
            }
        } else {
            return renderResult(false, -1, "参数错误");
        }
    }

    @RequestMapping(value = APIConstant.UNITENERGYCONSUMPTION, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object unitEnergyConsumption(@RequestBody HashMap<String, Object> receiveMap) {
        Integer unitId = Integer.parseInt(String.valueOf(receiveMap.get("unitId")));
        Integer year = Integer.valueOf(String.valueOf(receiveMap.get("year")));
        Integer month = Integer.valueOf(String.valueOf(receiveMap.get("month")));
        String day = String.valueOf(receiveMap.get("day"));
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        String date = year + "-" + month + "-" + day;
        Map<String, Object> resultMap = new HashMap<>();
        List<HbyOverLookPoint> hbyOverLookPointList = hbyOverLookpointService.findLookPointInfo(unitId);
        String sql = "SELECT " +
                " hby_overlook_dev_join.dev_idpk " +
                "FROM " +
                " hby_overlookpoint, " +
                " hby_overlook_dev_join " +
                "WHERE " +
                " hby_overlookpoint.id = hby_overlook_dev_join.look_id " +
                "AND hby_overlookpoint.deleted = 0 " +
                "AND hby_overlookpoint.unit_id = "+unitId;
        List<Integer> devIdpkList = hbyOverlookpointPlusMapper.findDevIdByUnitId(sql);
        if ((page - 1) * size > devIdpkList.size()) {
            return renderResult(false, -1, "无更多数据");
        } else {
            List<Integer> devIdpks = new ArrayList<>();
            if (devIdpkList.size() > page * size) {
                for (int i = size * (page - 1); i < size * page; i++) {
                    devIdpks.add(devIdpkList.get(i));
                }
            } else {
                for (int i = size * (page - 1); i < devIdpkList.size(); i++) {
                    devIdpks.add(devIdpkList.get(i));
                }
            }
            resultMap.put("page", page);
            resultMap.put("size", devIdpks.size());
            resultMap.put("total", devIdpkList.size());
            if (devIdpkList.size() % size == 0) {
                resultMap.put("totalPage", devIdpkList.size() / size);
            } else {
                resultMap.put("totalPage", (devIdpkList.size() / size) + 1);
            }
            //日运行
            if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 1) {
                List<UnitEnergyConsumption> unitEnergyConsumptionLinkedList = new ArrayList<>();
                for (Integer devIdpk : devIdpks) {
                    UnitEnergyConsumption unitEnergyConsumption = tbprojectInfoPlusMapper.findUsharEleByDateTimeUnitDevId(date, devIdpk);
                    if (unitEnergyConsumption == null) {
                        UnitEnergyConsumption unitEnergyConsumption1 = new UnitEnergyConsumption();
                        unitEnergyConsumption1.setDevName(tblndeviceinfoService.findLocation(devIdpk));
                        unitEnergyConsumptionLinkedList.add(unitEnergyConsumption1);
                    }else {
                        unitEnergyConsumption.setDevName(tblndeviceinfoService.findLocation(devIdpk));
                        unitEnergyConsumptionLinkedList.add(unitEnergyConsumption);
                    }
                }
                Collections.sort(unitEnergyConsumptionLinkedList, new Comparator<UnitEnergyConsumption>() {
                    @Override
                    public int compare(UnitEnergyConsumption o1, UnitEnergyConsumption o2) {
                        //降序
                        return o2.getDayTotal().compareTo(o1.getDayTotal());
                    }
                });
                resultMap.put("list", unitEnergyConsumptionLinkedList);
                return renderResult(resultMap);
            } else if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 2) {//月运行
                List<UnitEnergyConsumptionMonth> unitEnergyConsumptionMonthList = new ArrayList<>();
                String devStr = "0";
                for (Integer devIdPk:devIdpks){
                    devStr = devStr + ","+devIdPk;
                }
                List<UnitEnergyMonthNew> unitEnergyMonthNewList = tbdeviceInfoPlusMapper.findUnitMonthNewData(devStr,month,year);
                //System.out.println(unitEnergyMonthNewList.toArray().toString());
                Integer dayNum = DevUtils.haveManyDay(year,month);
                for (Integer devIdpk : devIdpks) {
                    UnitEnergyConsumptionMonth unitEnergyConsumptionMonth = new UnitEnergyConsumptionMonth();
                    unitEnergyConsumptionMonth.setDevName(tblndeviceinfoService.findLocation(devIdpk));
                    for (UnitEnergyMonthNew unitEnergyMonthNew:unitEnergyMonthNewList ) {
                        if((1==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD1(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((2==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD2(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((3==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD3(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((4==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD4(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((5==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD5(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((6==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD6(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((7==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD7(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((8==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD8(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((9==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD9(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((10==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD10(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((11==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD11(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((12==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD12(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((13==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD13(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((14==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD14(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((15==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD15(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((16==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD16(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((17==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD17(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((18==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD18(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((19==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD19(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((20==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD20(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((21==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD21(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((22==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD22(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((23==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD23(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((24==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD24(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((25==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD25(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((26==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD26(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((27==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD27(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));continue; }
                        if((28==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD28(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue; }
                        if((29==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD29(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue;
                        }
                        if((30==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD30(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue;
                        }
                        if((31==Integer.parseInt(unitEnergyMonthNew.getAddtime()))&&(devIdpk.equals(unitEnergyMonthNew.getDevIdpk()))){
                            unitEnergyConsumptionMonth.setD31(Double.valueOf(String.valueOf(new BigDecimal(unitEnergyMonthNew.getDayTotalQ()).setScale(1, RoundingMode.HALF_UP))));
                            continue;
                        }
                    }
                    unitEnergyConsumptionMonth.setMonthTotal(sumMonthTotal(unitEnergyConsumptionMonth,dayNum));
                    unitEnergyConsumptionMonthList.add(unitEnergyConsumptionMonth);
                }
                Collections.sort(unitEnergyConsumptionMonthList, new Comparator<UnitEnergyConsumptionMonth>() {
                    @Override
                    public int compare(UnitEnergyConsumptionMonth o1, UnitEnergyConsumptionMonth o2) {
                        //降序
                        return o2.getMonthTotal().compareTo(o1.getMonthTotal());
                    }
                });
                resultMap.put("list", unitEnergyConsumptionMonthList);
                return renderResult(resultMap);
            } else if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 3) {//年运行
                List<UnitEnergyConsumptionYear> unitEnergyConsumptionYearList = new ArrayList<>();
                for (Integer devIdpk : devIdpks) {
                    unitEnergyConsumptionYearList.add(setUnitYearEleData(devIdpk, year));
                }
                Collections.sort(unitEnergyConsumptionYearList, new Comparator<UnitEnergyConsumptionYear>() {
                    @Override
                    public int compare(UnitEnergyConsumptionYear o1, UnitEnergyConsumptionYear o2) {
                        //降序
                        return o2.getYearTotal().compareTo(o1.getYearTotal());
                    }
                });
                resultMap.put("list", unitEnergyConsumptionYearList);
                return renderResult(resultMap);
            } else {
                return renderResult(false, -1, "参数错误");
            }
        }
    }

    @RequestMapping(value = APIConstant.UNITPOLLCONDEVCOUNT, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object unitPollConDevCount(@RequestBody HashMap<String, Object> receiveMap) {
        Map<String, Object> resultMap = new HashMap<>();
        Integer size = Integer.parseInt(String.valueOf(receiveMap.get("size")));
        Integer page = Integer.parseInt(String.valueOf(receiveMap.get("page")));
        List<CountUnitAnalysisInfo> countUnitAnalysisInfoList = new ArrayList<>();
        String provinceCode = String.valueOf(receiveMap.get("provinceCode"));
        String cityCode = String.valueOf(receiveMap.get("cityCode"));
        String araeCode = String.valueOf(receiveMap.get("areaCode"));
        Integer userId = Integer.parseInt(String.valueOf(receiveMap.get("userId")));
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId, areaCodeJoinOther!=null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null, params,this.getUserInfo().getPlatformId());

        List<Integer> unitList = isAgencyUnit(menuList,provinceCode,cityCode,araeCode);
        CountUnitAnalysisInfo countUnitAnalysisInfoTotal = new CountUnitAnalysisInfo();
        if (Integer.parseInt(String.valueOf(receiveMap.get("type"))) == 1) {

            //AreaCodeJoinOther areaCodeJoinOther = new AreaCodeJoinOther(, String.valueOf(receiveMap.get("cityCode")), String.valueOf(receiveMap.get("areaCode")));
            String sql = "SELECT " +
                    "hby_industry.industry_name AS industryName," +
                    "hby_projectstatus.unit_id AS unitId," +
                    "hby_projectstatus.produc_state AS runStatus," +
                    "hby_projectstatus.poll_dev_num AS pollNum," +
                    "hby_projectstatus.con_dev_num AS conNum," +
                    "hby_projectstatus.run_dev_num AS runNum," +
                    "hby_projectstatus.stop_dev_num AS stopNum," +
                    "hby_projectstatus.lost_dev_num AS lostNum " +
                    "FROM " +
                    "tblnprojectinfo,hby_industry,hby_projectstatus " +
                    "WHERE " +
                    "tblnprojectinfo.industryId = hby_industry.id " +
                    "AND hby_projectstatus.unit_id = tblnprojectinfo.projId ";
            if (!"".equals(receiveMap.get("runStatus"))) {
                sql = sql + "AND hby_projectstatus.produc_state = " + String.valueOf(receiveMap.get("runStatus"));
            }
            List<UnitAnalysisData> unitAnalysisDataList = new ArrayList<>();

            for (Integer unitId : unitList) {
                String sqlsql = sql + " AND tblnprojectinfo.projId =" + unitId;
                UnitAnalysisData unitAnalysisData = tbprojectInfoPlusMapper.unitPollConDevCount(sqlsql);
                if (unitAnalysisData == null) {
                    continue;
                } else {
                    unitAnalysisDataList.add(unitAnalysisData);
                    countUnitAnalysisInfoTotal.setUnitNum(countUnitAnalysisInfoTotal.getUnitNum()+1);
                    countUnitAnalysisInfoTotal.setPollDevNum(countUnitAnalysisInfoTotal.getPollDevNum()+unitAnalysisData.getPollNum());
                    countUnitAnalysisInfoTotal.setConDevNum(countUnitAnalysisInfoTotal.getConDevNum()+unitAnalysisData.getConNum());
                    if (unitAnalysisData.getRunStatus() == 3) {
                        countUnitAnalysisInfoTotal.setOutlineUnitNum(countUnitAnalysisInfoTotal.getOutlineUnitNum()+1);
                    } else {
                        countUnitAnalysisInfoTotal.setOnlineUnitNum(countUnitAnalysisInfoTotal.getOnlineUnitNum()+1);
                    }
                    //计算总和
                    countUnitAnalysisInfoTotal.setRunDevNum(countUnitAnalysisInfoTotal.getRunDevNum()+unitAnalysisData.getRunNum());
                    countUnitAnalysisInfoTotal.setStopDevNum(countUnitAnalysisInfoTotal.getStopDevNum()+unitAnalysisData.getStopNum());
                    countUnitAnalysisInfoTotal.setLostDevNum(countUnitAnalysisInfoTotal.getLostDevNum()+unitAnalysisData.getLostNum());
                }
            }

            List<HbyIndustry> hbyIndustryList= hbyIndustryService.list();

            for (HbyIndustry hbyIndustry:hbyIndustryList ) {
                String name = hbyIndustryService.findIndustryNameById(hbyIndustry.getId());
                Integer count = 0;
                Integer runUnitNum = 0;
                Integer lostUnitNum = 0;
                Integer pollDevNum = 0;
                Integer conDevNum = 0;
                Integer runDevNum = 0;
                Integer stopDevNum = 0;
                Integer lostDevNum = 0;
                for (UnitAnalysisData unitAnalysisData : unitAnalysisDataList) {
                    if (name.equals(unitAnalysisData.getIndustryName())){
                        String industrysql = sql + " AND tblnprojectinfo.industryId = " + hbyIndustry.getId() + " AND tblnprojectinfo.projId =" + unitAnalysisData.getUnitId();
                        UnitAnalysisData unitAnalysisDataNew = tbprojectInfoPlusMapper.unitPollConDevCount(industrysql);
                        if (unitAnalysisDataNew == null) {
                            continue;
                        } else {
                            count++;
                            if (unitAnalysisDataNew.getRunStatus() == 3) {
                                lostUnitNum++;
                            } else {
                                runUnitNum++;
                            }
                            pollDevNum = pollDevNum + unitAnalysisDataNew.getPollNum();
                            conDevNum = conDevNum + unitAnalysisDataNew.getConNum();
                            runDevNum = runDevNum + unitAnalysisDataNew.getRunNum();
                            stopDevNum = stopDevNum + unitAnalysisDataNew.getStopNum();
                            lostDevNum = lostDevNum + unitAnalysisDataNew.getLostNum();
                        }
                    }else {
                        continue;
                    }

                }
                CountUnitAnalysisInfo countUnitAnalysisInfo = new CountUnitAnalysisInfo();
                countUnitAnalysisInfo.setName(name);
                countUnitAnalysisInfo.setUnitNum(count);
                countUnitAnalysisInfo.setPollDevNum(pollDevNum);
                countUnitAnalysisInfo.setConDevNum(conDevNum);
                countUnitAnalysisInfo.setOnlineUnitNum(runUnitNum);
                countUnitAnalysisInfo.setOutlineUnitNum(lostUnitNum);
                countUnitAnalysisInfo.setRunDevNum(runDevNum);
                countUnitAnalysisInfo.setStopDevNum(stopDevNum);
                countUnitAnalysisInfo.setLostDevNum(lostDevNum);
                countUnitAnalysisInfo.setProportion((int) ((Float.parseFloat(String.valueOf(count)) / countUnitAnalysisInfoTotal.getUnitNum())* 100));
                countUnitAnalysisInfoList.add(countUnitAnalysisInfo);
                Collections.sort(countUnitAnalysisInfoList, new Comparator<CountUnitAnalysisInfo>() {
                    @Override
                    public int compare(CountUnitAnalysisInfo o1, CountUnitAnalysisInfo o2) {
                        //降序
                        return o2.getUnitNum().compareTo(o1.getUnitNum());
                    }
                });
            }

        } else {

            String sql = "SELECT " +
                    "hby_agency.agcy_name AS name," +
                    "hby_projectstatus.unit_id AS unitId," +
                    "hby_projectstatus.produc_state AS runStatus," +
                    "hby_projectstatus.poll_dev_num AS pollNum," +
                    "hby_projectstatus.con_dev_num AS conNum," +
                    "hby_projectstatus.run_dev_num AS runNum," +
                    "hby_projectstatus.stop_dev_num AS stopNum," +
                    "hby_projectstatus.lost_dev_num AS lostNum " +
                    "FROM " +
                    "tblnprojectinfo," +
                    "hby_industry," +
                    "hby_projectstatus," +
                    "hby_agency " +
                    "WHERE " +
                    "tblnprojectinfo.industryId = hby_industry.id " +
                    "AND hby_projectstatus.unit_id = tblnprojectinfo.projId " +
                    "AND tblnprojectinfo.proProvinceCode = hby_agency.province_code " +
                    "AND tblnprojectinfo.proCityCode = hby_agency.city_code " +
                    "AND tblnprojectinfo.proAreaCode = hby_agency.area_code ";
            if (!"".equals(receiveMap.get("runStatus"))) {
                sql = sql + " AND hby_projectstatus.produc_state = " + String.valueOf(receiveMap.get("runStatus"));
            }
            if (!"".equals(receiveMap.get("industryId"))) {
                sql = sql + " AND tblnprojectinfo.industryId = " + Long.parseLong(String.valueOf(receiveMap.get("industryId")));
            }
            List<UnitAnalysisData> unitAnalysisDataList = new ArrayList<>();
            for (Integer unitId : unitList) {
                String sqlsql = sql + " AND tblnprojectinfo.projId =" + unitId;
                UnitAnalysisData unitAnalysisData = tbprojectInfoPlusMapper.unitPollConDevCount(sqlsql);
                if (unitAnalysisData == null) {
                    continue;
                } else {
                    unitAnalysisDataList.add(unitAnalysisData);
                    countUnitAnalysisInfoTotal.setUnitNum(countUnitAnalysisInfoTotal.getUnitNum()+1);
                    countUnitAnalysisInfoTotal.setPollDevNum(countUnitAnalysisInfoTotal.getPollDevNum()+unitAnalysisData.getPollNum());
                    countUnitAnalysisInfoTotal.setConDevNum(countUnitAnalysisInfoTotal.getConDevNum()+unitAnalysisData.getConNum());
                    if (unitAnalysisData.getRunStatus() == 3) {
                        countUnitAnalysisInfoTotal.setOutlineUnitNum(countUnitAnalysisInfoTotal.getOutlineUnitNum()+1);
                    } else {
                        countUnitAnalysisInfoTotal.setOnlineUnitNum(countUnitAnalysisInfoTotal.getOnlineUnitNum()+1);
                    }
                    countUnitAnalysisInfoTotal.setRunDevNum(countUnitAnalysisInfoTotal.getRunDevNum()+unitAnalysisData.getRunNum());
                    countUnitAnalysisInfoTotal.setStopDevNum(countUnitAnalysisInfoTotal.getStopDevNum()+unitAnalysisData.getStopNum());
                    countUnitAnalysisInfoTotal.setLostDevNum(countUnitAnalysisInfoTotal.getLostDevNum()+unitAnalysisData.getLostNum());
                }
            }
            List<TreeMenu> agencyList = permissionService.selectCanShowAgencyByUserId2(userId, areaCodeJoinOther != null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther) ,params);
            for (TreeMenu treeMenu : agencyList) {
                String name = treeMenu.getNodeName();
                Integer count = 0;
                Integer runUnitNum = 0;
                Integer lostUnitNum = 0;
                Integer pollDevNum = 0;
                Integer conDevNum = 0;
                Integer runDevNum = 0;
                Integer stopDevNum = 0;
                Integer lostDevNum = 0;
                for (UnitAnalysisData unitAnalysisData : unitAnalysisDataList) {
                    String industrysql = sql + " AND hby_agency.id = " + treeMenu.getNodeId() + " AND tblnprojectinfo.projId =" + unitAnalysisData.getUnitId();
                    UnitAnalysisData unitAnalysisDataNew = tbprojectInfoPlusMapper.unitPollConDevCount(industrysql);
                    if (unitAnalysisDataNew == null) {
                        continue;
                    } else {
                        count++;
                        if (unitAnalysisDataNew.getRunStatus() == 3) {
                            lostUnitNum++;
                        } else {
                            runUnitNum++;
                        }
                        pollDevNum = pollDevNum + unitAnalysisDataNew.getPollNum();
                        conDevNum = conDevNum + unitAnalysisDataNew.getConNum();
                        runDevNum = runDevNum + unitAnalysisDataNew.getRunNum();
                        stopDevNum = stopDevNum + unitAnalysisDataNew.getStopNum();
                        lostDevNum = lostDevNum + unitAnalysisDataNew.getLostNum();
                    }
                }
                CountUnitAnalysisInfo countUnitAnalysisInfo = new CountUnitAnalysisInfo();
                countUnitAnalysisInfo.setName(name);
                countUnitAnalysisInfo.setUnitNum(count);
                countUnitAnalysisInfo.setPollDevNum(pollDevNum);
                countUnitAnalysisInfo.setConDevNum(conDevNum);
                countUnitAnalysisInfo.setOnlineUnitNum(runUnitNum);
                countUnitAnalysisInfo.setOutlineUnitNum(lostUnitNum);
                countUnitAnalysisInfo.setRunDevNum(runDevNum);
                countUnitAnalysisInfo.setStopDevNum(stopDevNum);
                countUnitAnalysisInfo.setLostDevNum(lostDevNum);
                countUnitAnalysisInfo.setProportion((int) ((Float.parseFloat(String.valueOf(count)) / countUnitAnalysisInfoTotal.getUnitNum()) * 100));
                countUnitAnalysisInfoList.add(countUnitAnalysisInfo);
                Collections.sort(countUnitAnalysisInfoList, new Comparator<CountUnitAnalysisInfo>() {
                    @Override
                    public int compare(CountUnitAnalysisInfo o1, CountUnitAnalysisInfo o2) {
                        //降序
                        return o2.getUnitNum().compareTo(o1.getUnitNum());
                    }
                });
            }
        }
        List<CountUnitAnalysisInfo> countUnitAnalysisInfoListResult = new ArrayList<>();
        if (countUnitAnalysisInfoList.size() > size * page) {
            for (int i = size * (page - 1); i < size * page; i++) {
                countUnitAnalysisInfoListResult.add(countUnitAnalysisInfoList.get(i));
            }
        } else {
            for (int i = size * (page - 1); i < countUnitAnalysisInfoList.size(); i++) {
                countUnitAnalysisInfoListResult.add(countUnitAnalysisInfoList.get(i));
            }
        }
        resultMap.put("list", countUnitAnalysisInfoListResult);
        resultMap.put("size", countUnitAnalysisInfoListResult.size());
        resultMap.put("page", page);
        resultMap.put("total", countUnitAnalysisInfoList.size());
        resultMap.put("sum",countUnitAnalysisInfoTotal);
        if (countUnitAnalysisInfoList.size() % size == 0) {
            resultMap.put("totalPage", countUnitAnalysisInfoList.size() / size);
        } else {
            resultMap.put("totalPage", (countUnitAnalysisInfoList.size() / size) + 1);
        }
        return renderResult(resultMap);
    }

    /**
     * 年级设备用电量总计信息
     *
     * @param devId
     * @param year
     * @return
     */
    public UnitEnergyConsumptionYear setUnitYearEleData(Integer devId, Integer year) {

        Integer i = 1;
        UnitEnergyConsumptionYear unitEnergyConsumptionYear = new UnitEnergyConsumptionYear();
        unitEnergyConsumptionYear.setDevName(tblndeviceinfoService.findLocation(devId));
        unitEnergyConsumptionYear.setM1(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM2(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM3(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM4(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM5(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM6(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM7(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM8(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM9(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM10(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM11(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setM12(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(hbyMonthAndYearEleCountService.findEleTotalByYearAndMonth(devId, year, i++))).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionYear.setYearTotal(unitEnergyConsumptionYear.getM1()+unitEnergyConsumptionYear.getM2()+unitEnergyConsumptionYear.getM3()+
                unitEnergyConsumptionYear.getM4()+unitEnergyConsumptionYear.getM5()+unitEnergyConsumptionYear.getM6()+
                unitEnergyConsumptionYear.getM7()+unitEnergyConsumptionYear.getM8()+unitEnergyConsumptionYear.getM9()+
                unitEnergyConsumptionYear.getM10()+unitEnergyConsumptionYear.getM11()+unitEnergyConsumptionYear.getM12());
        return unitEnergyConsumptionYear;
    }

    /**
     * 月级设备用电量总计信息
     * @param unitEnergyMonthList
     * @param devName
     * @return
     */
    public UnitEnergyConsumptionMonth setUnitMonthEleData(List<UnitEnergyMonth> unitEnergyMonthList,String devName) {
        Integer i = 0;
        UnitEnergyConsumptionMonth unitEnergyConsumptionMonth = new UnitEnergyConsumptionMonth();
        unitEnergyConsumptionMonth.setDevName(devName);

        unitEnergyConsumptionMonth.setD1(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD2(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD3(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD4(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD5(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD6(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD7(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD8(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD9(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD10(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD11(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD12(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD13(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD14(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD15(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD16(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD17(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD18(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD19(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD20(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD21(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD22(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD23(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD24(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD25(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD26(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD27(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        unitEnergyConsumptionMonth.setD28(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        if (unitEnergyMonthList.size()==31){
            unitEnergyConsumptionMonth.setD29(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
            unitEnergyConsumptionMonth.setD30(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
            unitEnergyConsumptionMonth.setD31(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        }else if (unitEnergyMonthList.size()==30){
            unitEnergyConsumptionMonth.setD29(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
            unitEnergyConsumptionMonth.setD30(Double.valueOf(String.valueOf(new BigDecimal(Double.valueOf(unitEnergyMonthList.get(i++).getEleQ())).setScale(1, RoundingMode.HALF_UP))));
        }
        return unitEnergyConsumptionMonth;
    }

    /**
     * 查出属于该行政区域的单位
     * @param treeMenuList
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @return
     */
    public List<Integer> isAgencyUnit(List<TreeMenu> treeMenuList,String provinceCode,String cityCode,String areaCode){
        List<Integer> unitList = new ArrayList<>();
        for (TreeMenu menu:treeMenuList ) {
            Integer unitId = Integer.valueOf(String.valueOf(menu.getNodeId()));
            Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
            if ("000000".equals(provinceCode)|| "".equals(provinceCode)){
                unitList.add(unitId);
            }else {
                if (("000000".equals(cityCode)|| "".equals(cityCode))&&provinceCode.equals(tblnprojectinfo.getProprovincecode())){
                    unitList.add(unitId);
                }else {
                    if (("000000".equals(areaCode)|| "".equals(areaCode))
                            &&(cityCode.equals(tblnprojectinfo.getProcitycode()))
                            &&(provinceCode.equals(tblnprojectinfo.getProprovincecode()))
                    ){
                        unitList.add(unitId);
                    }else {
                        if (areaCode.equals(tblnprojectinfo.getProareacode())
                                &&cityCode.equals(tblnprojectinfo.getProcitycode())
                                &&provinceCode.equals(tblnprojectinfo.getProprovincecode())
                        ){
                            unitList.add(unitId);
                        }else {
                            continue;
                        }
                    }
                }
            }
        }
        return unitList;
    }

    public Double sumMonthTotal(UnitEnergyConsumptionMonth unitEnergyConsumptionMonth,Integer dayNum){
        Double monthTotal = 0D;
        monthTotal = unitEnergyConsumptionMonth.getD1()+
                unitEnergyConsumptionMonth.getD2()+
                unitEnergyConsumptionMonth.getD3()+
                unitEnergyConsumptionMonth.getD4()+
                unitEnergyConsumptionMonth.getD5()+
                unitEnergyConsumptionMonth.getD6()+
                unitEnergyConsumptionMonth.getD7()+
                unitEnergyConsumptionMonth.getD8()+
                unitEnergyConsumptionMonth.getD9()+
                unitEnergyConsumptionMonth.getD10()+
                unitEnergyConsumptionMonth.getD11()+
                unitEnergyConsumptionMonth.getD12()+
                unitEnergyConsumptionMonth.getD13()+
                unitEnergyConsumptionMonth.getD14()+
                unitEnergyConsumptionMonth.getD15()+
                unitEnergyConsumptionMonth.getD16()+
                unitEnergyConsumptionMonth.getD17()+
                unitEnergyConsumptionMonth.getD18()+
                unitEnergyConsumptionMonth.getD19()+
                unitEnergyConsumptionMonth.getD20()+
                unitEnergyConsumptionMonth.getD21()+
                unitEnergyConsumptionMonth.getD22()+
                unitEnergyConsumptionMonth.getD23()+
                unitEnergyConsumptionMonth.getD24()+
                unitEnergyConsumptionMonth.getD25()+
                unitEnergyConsumptionMonth.getD26()+
                unitEnergyConsumptionMonth.getD27()+
                unitEnergyConsumptionMonth.getD28();
        if (dayNum==31){
            return monthTotal +unitEnergyConsumptionMonth.getD29()+unitEnergyConsumptionMonth.getD30()+unitEnergyConsumptionMonth.getD31();
        }else if (dayNum==30){
            return monthTotal +unitEnergyConsumptionMonth.getD29()+unitEnergyConsumptionMonth.getD30();
        }else if (dayNum==29){
            return monthTotal +unitEnergyConsumptionMonth.getD29();
        }else {
            return monthTotal;
        }

    }

    /**
     * 查出属于该行政区域的单位
     * @param treeMenuList
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @return
     */
    public List<Integer> isAgencyUnitNew(List<TreeMenu> treeMenuList,String provinceCode,String cityCode,String areaCode){
        List<Integer> unitList = new ArrayList<>();
        for (TreeMenu menu:treeMenuList ) {
            Integer unitId = Integer.valueOf(String.valueOf(menu.getNodeId()));
            Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
            if (provinceCode.equals(tblnprojectinfo.getProprovincecode())&&cityCode.equals(tblnprojectinfo.getProcitycode())&&areaCode.equals(tblnprojectinfo.getProareacode())){
                unitList.add(unitId);
            }else {
               continue;
            }
        }
        return unitList;
    }

}
