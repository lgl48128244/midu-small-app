package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.pojo.pagetopselecteneity.UnitRealDataInfo;
import com.leniao.huanbao.pojo.receive.UnitAnalysisData;
import com.leniao.huanbao.pojo.receive.UnitEnergyConsumption;
import com.leniao.huanbao.pojo.receive.UnitUseEleInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/24 19:36
 * @update
 * @description
 */
@Mapper
public interface TbprojectInfoPlusMapper extends BaseMapper<Tblnprojectinfo> {
    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proProvinceCode = #{provinceId}")
    List<Map<String,Object>> findDefaultProvinceUnit(Page<Map<String,Object>> page, String provinceId);

    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proCityCode = #{cityId}")
    List<Map<String,Object>> findDefaultCityUnit(Page<Map<String,Object>> page,String cityId);

    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proAreaCode = #{areaId}")
    List<Map<String,Object>> findDefaultAreaUnit(Page<Map<String,Object>> page,String areaId);

    @Select("${sql}")
    List<UnitRealDataInfo> findUnitStatusList(String sql);

    @Select("${sql}")
    UnitAnalysisData unitPollConDevCount(String sql);

    @Select("SELECT IFNULL((SELECT tblndeviceparainfo.paraValue FROM tblndevicenodeinfo,tblndeviceparainfo WHERE tblndevicenodeinfo.pkId = tblndeviceparainfo.devNodepk AND tblndevicenodeinfo.devNode1 = "+"\'"+"#{node}"+"\'"+"AND tblndevicenodeinfo.devTy =#{devTy} AND tblndeviceparainfo.devIdpk =#{devId}),0)")
    String devRealTimeData(Integer devId,Integer devTy,String node);

    @Select("SELECT tblndeviceinfo.installLocation AS devName,ushare_device_electricuse.dayTotalQ AS dayTotal,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19,h20,h21,h22,h23,h24 " +
            "FROM ushare_device_electricuse,tblndeviceinfo " +
            "WHERE " +
            "tblndeviceinfo.devIdpk = ushare_device_electricuse.devIdpk " +
            "AND ushare_device_electricuse.devIdpk = ${devId} " +
            "AND addtime = '${day}'")
    UnitEnergyConsumption findUsharEleByDateTimeUnitDevId(String day,Integer devId);

    @Select("${sql}")
    List<UnitUseEleInfo> findUseElectricityCompany(String sql);

    @Select("${sql}")
    UnitUseEleInfo findUseEleCompany(String sql);

}
