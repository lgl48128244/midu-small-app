package com.leniao.huanbao.dto.schedule;

import lombok.Data;

import java.util.Date;

/**
 * 修改过单位行业的数据DTO
 */
@Data
public class UnitIndustryDTO {

    private Integer unitId;
    private Integer industryId;
    private Date updateTime;

}
