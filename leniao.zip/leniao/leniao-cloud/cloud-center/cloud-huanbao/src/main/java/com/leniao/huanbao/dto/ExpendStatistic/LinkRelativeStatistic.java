package com.leniao.huanbao.dto.ExpendStatistic;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.leniao.huanbao.utils.DoubleSerialize;
import lombok.Data;
import lombok.Getter;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 环比统计
 * @author: jiangdy
 * @create: 2019-12-31 11:43
 **/
@Data
public class LinkRelativeStatistic extends ProjectDayCountInfo {

    /**
     * 趋势比 （百分比）
     */
    private String trend;

    /**
     * 趋势差值
     */
    private String differenceValue;

}
