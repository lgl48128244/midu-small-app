package com.leniao.huanbao.schedule.udpbean;

import java.util.Date;

/**
 * @program: leniaorestful
 * @description: 用电量
 * @author: lwl
 * @create: 2019-06-06 11:03
 **/
public class Ele_Consumption {

    private int devIdpk;
    private double totalQ;
    private int realTotalQ;
    private Date updateTime;

    public int getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(int devIdpk) {
        this.devIdpk = devIdpk;
    }

    public double getTotalQ() {
        return totalQ;
    }

    public void setTotalQ(double totalQ) {
        this.totalQ = totalQ;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public int getRealTotalQ() {
        return realTotalQ;
    }

    public void setRealTotalQ(int realTotalQ) {
        this.realTotalQ = realTotalQ;
    }
}
