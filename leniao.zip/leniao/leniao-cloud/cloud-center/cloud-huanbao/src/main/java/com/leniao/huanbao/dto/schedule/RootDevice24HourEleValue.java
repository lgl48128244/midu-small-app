package com.leniao.huanbao.dto.schedule;

import lombok.Data;

/**
 * hsw
 * 设备24小时电量使用类
 */
@Data
public class RootDevice24HourEleValue {
    private Integer devIdpk;
    private Double h1;
    private Double h2;
    private Double h3;
    private Double h4;
    private Double h5;
    private Double h6;
    private Double h7;
    private Double h8;
    private Double h9;
    private Double h10;
    private Double h11;
    private Double h12;
    private Double h13;
    private Double h14;
    private Double h15;
    private Double h16;
    private Double h17;
    private Double h18;
    private Double h19;
    private Double h20;
    private Double h21;
    private Double h22;
    private Double h23;
    private Double h24;
}
