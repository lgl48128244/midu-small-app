package com.leniao.huanbao.utils;

/**
 * @author liudongshuai
 * @date 2019/12/19 14:26
 */
public class APIConstant {

    /**
     * 登录账号下默认单位和行政区域
     */
    public static final String DEFAULTUNITANDAGENCY = "/defaultUnitAndAgency";

    /**
     * 省份信息
     * */
    public static final String PROVINCE = "/province";
    /**
     * 省级下面的单位
     */
    public static final String PROVINCEUNIT = "/provinceUnit";
    /**
     * 市级信息
     * */
    public static final String CITY = "/city";
    /**
     * 市级下面的单位
     */
    public static final String CITYUNIT = "/cityUnit";
    /**
     * 县级信息
     * */
    public static final String AREA = "/area";
    /**
     * 搜索框单位信息
     * */
    public static final String UNIT = "/unit";
    /**
     * 搜索框监测点信息
     * */
    public static final String LOOK_POINT = "/lookPoint";
    /**
     * 设备编号信息
     * */
    public static final String DEVSIGNINFO = "/devsigninfo";
    /**
     * 设备详情列表
     */
    public static final String DEVDEATILS = "/devDeatils";


    /**
     * 监测点信息列表
     */
    public static final String LOOKPOINTADMININFO = "/lookPointAdminInfo";
    /**
     * 监测点添加信息
     */
    public static final String ADDLOOKPOINT="/addLookPoint";
    /**
     * 分组信息
     */
    public static final String GROUPIDNAME = "/groupIdName";
    /**
     * 设备信息表
     */
    public static final String DEVSYSIDNAME = "/devsysIdName";
    /**
     * 通过分组显示的设备列表
     */
    public static final String GROUPDEVSIGN = "/groupDevSign";

    /**
     * 查看一个单位是否满足添加监测点的条件
     * 1, 有智慧用电设备分组
     * 2，有行业
     * 3，有行政区域环保局
     */
    public static final String ISADDINDUSTRYAGENCY = "/isAddIndustryAgency";

    /**
     * 删除监测点 逻辑删除
     */
    public static final String DELLOOKPOINT = "/delLookPoint";
    /**
     * 修改监测点信息
     */
    public static final String UPDATELOOKPOINT = "/updateLookPoint";
    /**
     * 修改监测点信息的时候监测点信息的详细展示
     */
    public static final String LOOKPOINTINFOVIEW = "/lookPointInfoView";
    /**
     * 监测点下产污治污设备展示
     */
    public static final String SENDPOLLCONDEVICE = "/sendPollConDevice";


    /**
     * 设备实时数据
     */
    public static final String DEVREALTIMEDATA = "/devRealTimeData";
    /**
     * 单位实时数据(手机端)
     */
    public static final String DEVREALDATAINFO = "/devRealDataInfo";
    /**
     * 单位设备运行日工况数据
     */
    public static final String UNITDAYREALDATA = "/unitDayRealData";
    /**
     * 单位默认设备运行工况
     */
    public static final String UNITDAYDEFAULTDATA = "/unitDayDefaultData";

    /**
     * 单位统计数据
     */
    public static final String UNITCOUNTINFO = "/unitCountInfo";

    /**
     * 首页单位地图瞄点信息
     */
    public static final String UNITINDEXMAPINFO = "/unitIndexMapInfo";

    /**
     * 单位数据展示
     */
    public static final String SENDUNITDATAINFO = "/sendUnitDataInfo";

    /**
     * 单位设施运行数据（产治污设备一对一）
     */
    public static final String UNITLOOKPOINTRUNDATA = "/unitLookpointRunData";

    /**
     * 单位下监测点设备信息(手机端)
     */
    public static final String UNITLOOKPOINTRUNDATACOUNTDEV = "/unitLookpointRunDataCountDev";

    /**
     * 单位监控首页单位信息
     */
    public static final String UNITINDEXINFO = "/unitIndexInfo";

    /**
     * 单位监控明细
     */
    public static final String UNITPOWERLOADINFO = "/unitPowerLoadInfo";

    /**
     * 首页统计单位设备信息
     */
    public static final String UNITDEVINFOTOTALCOUNT = "/unitDevInfoTotalCount";

    /**
     * 单位产治污设备统计
     */
    public static final String UNITPOLLCONDEVCOUNT = "/unitPollConDevCount";

    /**
     * 统计分析能耗统计
     */
    public static final String UNITENERGYCONSUMPTION = "/unitEnergyConsumption";

    /**
     * 企业用电总汇
     */
    public static final String UNITUSEELECTRICITYCOMPANY = "/unitUseElectricityCompany";

}
