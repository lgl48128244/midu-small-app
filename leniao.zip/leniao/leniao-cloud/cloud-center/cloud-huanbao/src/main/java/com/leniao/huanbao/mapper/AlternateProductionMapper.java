package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlanExample;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * 错峰生产mapper
 * Alternate 错开
 * Production 生产
 */
public interface AlternateProductionMapper extends BaseMapper<HbyReduceEmmissionPlan> {

//    List<ReduceEmmissionDto> selectReduceEmmissionDto(@Param("agencyId") long agencyId, @Param("example") HbyReduceEmmissionPlanExample example);

    int updateReduceEmmissionPlanState(@Param("userId") int userId, @Param("planId") long planId);

    List<ReduceEmmissionDto> selectReduceEmmissionDto(@Param("agencyId") Long agencyId, @Param("userGrade") Integer userGrade,
                                                      @Param("platformId") Integer platformId,
                                                      @Param("areaCode") AreaCodeJoinOther areaCode, @Param("agcyId") Integer agcyId,
                                                      @Param("warnLevel") Integer warnLevel, @Param("isUsing") Integer isUsing,
                                                      @Param("nowTime") Date nowTime, @Param("beginTime") Date beginTime, @Param("endTime") Date endTime);

    Integer selectBindCount(@Param("planId") Long planId);
}
