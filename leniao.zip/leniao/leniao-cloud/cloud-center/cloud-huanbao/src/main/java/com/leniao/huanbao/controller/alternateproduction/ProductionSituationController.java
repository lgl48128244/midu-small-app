package com.leniao.huanbao.controller.alternateproduction;

import cn.hutool.core.date.DateTime;
import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.constant.SystemConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 错峰生产执行情况
 * @author: jiangdy
 * @create: 2019-12-24 13:56
 **/
@RestController
@RequestMapping(ApiConstant.PRODUCTION_SITUATION)
public class ProductionSituationController extends BaseController {

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private TreeMenuService treeMenuService;

    @Autowired
    private HbyAgencyService hbyAgencyService;

    @Autowired
    private HbyReduceEmmissionService hbyReduceEmmissionService;

    @Autowired
    private ProductionSituationService productionSituationService;

    @Autowired
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;

    /**
     * 错峰生产执行情况查询
     * @param jsonObj beginTime 生效开始时间 非必须,
     *                endTime 生效结束时间 非必须,
     *                agencyId 机构id 非必须,
     *                projId 单位id 非必须,
     *                industryId 行业id 非必须,
     *                pageNum 分页页码 必须，
     *                pageSize 每页大小 必须
     * @return
     */
    @RequestMapping(value = ApiConstant.SELECT_PRODUCTION, method = RequestMethod.POST)
    public Object selectProduction(@RequestBody JSONObject jsonObj) {

        UserInfo userInfo = this.getUserInfo();

        Map<String, Object> params = new HashMap<>(6);
        params.put("industryId", jsonObj.get("industryId"));
        params.put("projId", jsonObj.get("projId"));
        Long agencyId = jsonObj.getLong("agencyId");
        params.put("agencyId", jsonObj.get("agencyId"));

        if (!StringUtils.isEmpty(jsonObj.getString("beginTime"))) {
            DateTime begin = DateTime.of(jsonObj.getString("beginTime"), "yyyy-MM-dd");
            params.put("begin", begin);
        }
        if (!StringUtils.isEmpty(jsonObj.getString("endTime"))) {
            DateTime end = DateTime.of(jsonObj.getString("endTime"), "yyyy-MM-dd");
            params.put("end", end);
        }

        AreaCodeJoinOther areaCode = null;
        Integer userGrade = null;
        List<TreeMenu> projectList;
//        if (agencyId != null && agencyId > 0) {
//            // 查询机构和单位
//            List<TreeMenu> agencyAndProjectByList = permissionService.selectCanShowAgencyAndProjectByUser(userInfo.getUserId(), params);
//            if (agencyAndProjectByList == null || agencyAndProjectByList.size() == 0) {
//                return renderResult();
//            }
//            List<TreeMenu> collect = agencyAndProjectByList.stream().filter(list -> list.getNodeId().equals(agencyId)).collect(Collectors.toList());
//            if (collect == null || collect.size() == 0) {
//                return renderResult();
//            }
//            projectList = collect.get(0).getChildTreeMenu();
//        } else {
            // 区域用户
            if (userInfo.getGroupType() == 2) {
                // 获取区域码
                areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
                if (areaCode == null) {
                    throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
                }
                // 判断区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
                userGrade = UserUtil.getUserGrade(areaCode);
            }

            // 查询用户可见的单位
            projectList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), areaCode != null, areaCode, userGrade, params);
//        }
        if (projectList == null || projectList.size() == 0) {
            return renderResult();
        }
        List<Long> list = projectList.stream().map(tm -> tm.getNodeId()).collect(Collectors.toList());
        HbyAgency agency;
        if (agencyId != null && agencyId > 0) {
            // 查询指定机构的子机构
            agency = hbyAgencyService.getById(agencyId);
            if (agency == null) {
                throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
            }
            userGrade = UserUtil.getAgencyGrade(agency);
            if (userGrade == 1) {
                list = projectList.stream().filter(tm -> tm.getProvinceCode().equals(agency.getProvinceCode()))
                        .map(tm -> tm.getNodeId()).collect(Collectors.toList());
            } else if (userGrade == 2) {
                list = projectList.stream().filter(tm -> tm.getCityCode().equals(agency.getCityCode()))
                        .map(tm -> tm.getNodeId()).collect(Collectors.toList());
            } else if (userGrade == 3) {
                list = projectList.stream().filter(tm -> tm.getAreaCode().equals(agency.getAreaCode()))
                        .map(tm -> tm.getNodeId()).collect(Collectors.toList());
            }
            areaCode.setProvinceCode(agency.getProvinceCode());
            areaCode.setCityCode(agency.getCityCode());
            areaCode.setAreaCode(agency.getAreaCode());
        }

        int pageNum = 1;
        int pageSize = SystemConstant.PAGE_SIZE;
        if (jsonObj.getInteger("pageNum") != null && jsonObj.getInteger("pageNum") > 0) {
            pageNum = jsonObj.getInteger("pageNum");
        }
        if (jsonObj.getInteger("pageSize") != null && jsonObj.getInteger("pageSize") > 0) {
            pageSize = jsonObj.getInteger("pageSize");
        }
        if (areaCode != null) {
            params.put("agencyId", "");
        }

        // 设置分页
        PageHelper.startPage(pageNum, pageSize);
        // 查询方案执行情况
        List<ReduceEmmissionDto> reduceEmmissionDtoList = productionSituationService.selectProductionSituationByNotAreaUser(
                list, areaCode, userGrade, params);
        if (areaCode != null && (userInfo.getGroupOnlyRead() == 0 || areaCode.getProvinceCode().equals("000000"))) {
            for (ReduceEmmissionDto dto : reduceEmmissionDtoList) {
                dto.setOnlyRead(userInfo.getGroupOnlyRead());
            }
        }
        return renderResult(new PageInfo<>(reduceEmmissionDtoList));
    }

    /**
     * 根据方案id查询单位
     * @param planId 方案id 必须
     * @param industryId 行业id 非必须,
     * @return
     */
    @RequestMapping(value = ApiConstant.SELECT_PROJECT)
    public Object selectProjectByPlanId(@RequestParam("planId") Long planId, @RequestParam(value = "industryId", required = false) Integer industryId) {

        if (planId == null || planId.equals(0)) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        UserInfo userInfo = this.getUserInfo();
        // 判断是否是区域用户
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (areaCode == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        // 查询方案(确保方案存在)
        HbyReduceEmmissionPlan plan = hbyReduceEmmissionService.selectByPrimaryKey(planId);
        if (plan == null) {
            throw new CloudException(CloudErrorCode.REDUCE_EMMISSION_EMPTY);
        }
        boolean onlyRead = UserUtil.isManagementArea(areaCode, plan);
        if (areaCode.getProvinceCode().equals("000000")) {
            if (userInfo.getGroupOnlyRead() == 1) {
                onlyRead = true;
            } else {
                onlyRead = false;
            }
        }

        // 查询机构信息
        HbyAgency agency = hbyAgencyService.getById(plan.getBelongAgency());
        Map<String, Object> params = new HashMap<>(4);
        params.put("industryId", industryId+"");
        // 查询机构下的所有单位
        List<TreeMenu> projList = treeMenuService.selectChildTreemenu(userInfo.getPlatformId(), onlyRead ? 1 : 0, agency.getId(), 1, null, null, params);

        // 查询单位绑定方案的信息
        Map<Integer, HbyReduceplanJoinProject> joinProjectMap = hbyReduceplanJoinProjectService.selectHbyReduceplanJoinProjectByPlanId(planId);

        for (TreeMenu projInfo : projList) {
            if (joinProjectMap != null && joinProjectMap.get(projInfo.getNodeId().intValue()) != null) {
                projInfo.setIsBind(1);
            } else {
                projInfo.setIsBind(0);
            }
        }

        TreeMenu treeMenu = new TreeMenu();
        treeMenu.setOnlyRead(onlyRead ? 1 : 0);
        treeMenu.setNodeId(agency.getId());
        treeMenu.setNodeName(agency.getAgcyName());
        treeMenu.setAreaCode(agency.getAreaCode());
        treeMenu.setCityCode(agency.getCityCode());
        treeMenu.setProvinceCode(agency.getProvinceCode());
        treeMenu.setNodeType(1);
        treeMenu.setChildTreeMenu(projList);

        return renderResult(treeMenu);
    }
}
