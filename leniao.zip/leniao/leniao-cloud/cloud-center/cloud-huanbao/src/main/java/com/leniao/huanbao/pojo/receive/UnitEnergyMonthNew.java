package com.leniao.huanbao.pojo.receive;

/**
 * @author liudongshuai
 * @version 1.0
 * @date 2020/3/13 9:58
 * @email liudongs@aliyun.com
 * @description
 */

public class UnitEnergyMonthNew {
    private Double dayTotalQ;
    private String addtime;
    private Integer devIdpk;

    public Double getDayTotalQ() {
        return dayTotalQ;
    }

    public void setDayTotalQ(Double dayTotalQ) {
        this.dayTotalQ = dayTotalQ;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        String strh = addtime.substring(addtime.length() -2,addtime.length());
        this.addtime = strh;
    }

    public Integer getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(Integer devIdpk) {
        this.devIdpk = devIdpk;
    }
}
