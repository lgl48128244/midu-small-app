package com.leniao.huanbao.controller;

import com.alibaba.fastjson.JSONObject;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.commons.util.HbaseUtil;
import com.leniao.commons.util.thrift.realValue1;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.ExpendStatistic.LinkRelativeStatistic;
import com.leniao.huanbao.dto.ExpendStatistic.UseEleRanking;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.service.TreeMenuService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.vo.UserInfo;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 企业日统计信息 峰值
 * @author: jiangdy
 * @create: 2019-12-31 10:13
 **/
@RestController
@RequestMapping(ApiConstant.PROJECT_DAY_COUNTINFO)
public class ProjectDayCountInfoController extends BaseController {

    @Autowired
    private HbyProjectDayCountinfoService hbyProjectDayCountinfoService;

    @Autowired
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private TreeMenuService treeMenuService;

    /**
     * 峰值统计
     * @param params projId 单位id
     * @return
     */
    @RequestMapping(value = ApiConstant.PEAK_VALUE)
    public Object selectPeakValue(@RequestBody JSONObject params) {

        if (params == null || params.getInteger("projId") == null || params.getInteger("projId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "单位id错误");
        }

        UserInfo userInfo = this.getUserInfo();
        Integer permission = permissionService.checkPermission(userInfo.getUserId(), params.getInteger("projId"));
        if (permission == -1) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        return renderResult(hbyProjectDayCountinfoService.selectPeakValue(params));
    }

    /**
     * 峰值统计 功率曲线图
     * @param params projId 单位id
     * @return
     */
    @RequestMapping(value = ApiConstant.CURVE_CHART, method = RequestMethod.POST)
    public Object selectCurveChart(@RequestBody JSONObject params) {
        if (params == null) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "单位id错误");
        }
        Integer projId = params.getInteger("projId");
        if (projId == null || projId == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "单位id错误");
        }

        // 权限检验
        UserInfo userInfo = this.getUserInfo();
        Integer permission = permissionService.checkPermission(userInfo.getUserId(), params.getInteger("projId"));
        if (permission == -1) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        Integer devIdpk = 0;
        if (params.getInteger("devIdpk") != null && params.getInteger("devIdpk") > 0) {
            devIdpk = params.getInteger("devIdpk");
        } else {
            // 默认查询总表
            List<DevDto> devices = commonSimpleBeanInfoService.findDevicesOfOverLookPointByUnitID(projId);
            // 过滤总表id
            List<Integer> collect = devices.stream().filter(dev -> dev.getDevProTy().equals(0)).map(dev -> dev.getDevIdpk()).collect(Collectors.toList());
            if (collect != null && collect.size() > 0) {
                devIdpk = collect.get(0);
            }
        }
        String nodeArray = "PA-PB-PC";
        int totalRows = 500;
        Date date = params.getDate("date");
        if (date == null) {
            date = new Date();
        }
        DateTime now = new DateTime(date);
        String beginTime = now.toString("yyyyMMdd000000");
        String endTime = now.toString("yyyyMMdd235959");
        List<realValueList1> todayRealValueList = hbyProjectDayCountinfoService.selectCurveChart(devIdpk, beginTime, endTime, nodeArray, totalRows);

        beginTime = now.minusDays(1).toString("yyyyMMdd000000");
        endTime = now.minusDays(1).toString("yyyyMMdd235959");
        List<realValueList1> yesterdayRealValueList = hbyProjectDayCountinfoService.selectCurveChart(devIdpk, beginTime, endTime, nodeArray, totalRows);

        List<realValue1> tpa = todayRealValueList.stream().filter(a -> a.keyname.equals("PA")).map(a -> a.rows).collect(Collectors.toList()).get(0);
        List<realValue1> tpb = todayRealValueList.stream().filter(a -> a.keyname.equals("PB")).map(a -> a.rows).collect(Collectors.toList()).get(0);
        List<realValue1> tpc = todayRealValueList.stream().filter(a -> a.keyname.equals("PC")).map(a -> a.rows).collect(Collectors.toList()).get(0);

        List<realValue1> ypa = yesterdayRealValueList.stream().filter(a -> a.keyname.equals("PA")).map(a -> a.rows).collect(Collectors.toList()).get(0);
        List<realValue1> ypb = yesterdayRealValueList.stream().filter(a -> a.keyname.equals("PB")).map(a -> a.rows).collect(Collectors.toList()).get(0);
        List<realValue1> ypc = yesterdayRealValueList.stream().filter(a -> a.keyname.equals("PC")).map(a -> a.rows).collect(Collectors.toList()).get(0);

        Double[] tval;
        Double[] yval;
        String[] ttime;
        String[] ytime;
        if (tpa != null && tpa.size() > 0) {
            tval = new Double[tpa.size()];
            ttime = new String[tpa.size()];
            for (int i = 0; i < tpa.size(); i++) {
                if (tpa != null && tpa.size() > i) {
                    tval[i] = Double.valueOf(tpa.get(i).val) + Double.valueOf(tpb.get(i).val) + Double.valueOf(tpc.get(i).val);
                    ttime[i] = tpa.get(i).addtime;
                }
            }
        } else {
            tval = new Double[]{};
            ttime = new String[]{};
        }

        if (ypa != null && ypa.size() > 0) {
            yval = new Double[ypa.size()];

            ytime = new String[ypa.size()];

            for (int i = 0; i < ypa.size(); i++) {
                if (tpa != null && tpa.size() > i) {
                    tval[i] = Double.valueOf(tpa.get(i).val) + Double.valueOf(tpb.get(i).val) + Double.valueOf(tpc.get(i).val);
                    ttime[i] = tpa.get(i).addtime;
                }
                if (ypa != null && ypa.size() > i) {
                    yval[i] = Double.valueOf(ypa.get(i).val) + Double.valueOf(ypb.get(i).val) + Double.valueOf(ypc.get(i).val);
                    ytime[i] = ypa.get(i).addtime;
                }
            }
        } else {
            yval = new Double[]{};
            ytime = new String[]{};
        }
        Map<String, Object> powerCurveChart = new HashMap<>(8);
        powerCurveChart.put("tval", tval);
        powerCurveChart.put("yval", yval);
        powerCurveChart.put("ttime", ttime);
        powerCurveChart.put("ytime", ytime);
        return renderResult(powerCurveChart);
    }

    /**
     * 单位电能环比
     * @param params projId 单位id
     * @return
     */
    @RequestMapping(value = ApiConstant.PROJECT_LINK_RELATIVE, method = RequestMethod.POST)
    public Object selectProjectEleLinkRelative(@RequestBody JSONObject params) {

        if (params == null || params.getInteger("projId") == null || params.getInteger("projId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "单位id错误");
        }

        UserInfo userInfo = this.getUserInfo();
        Integer permission = permissionService.checkPermission(userInfo.getUserId(), params.getInteger("projId"));
        if (permission == -1) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        List<Integer> projIdList = new ArrayList<>(4);
        projIdList.add(params.getInteger("projId"));
        List<LinkRelativeStatistic> statisticList = hbyProjectDayCountinfoService.selectEleLinkRelative(projIdList);
        statisticList.stream().forEach(statistic -> {
            statistic.setProjId(params.getInteger("projId"));
        });
        return renderResult(statisticList);
    }

    /**
     * 行业电能环比
     * @param params industryId 行业id
     * @return
     */
    @RequestMapping(value = ApiConstant.INDUSTRY_LINK_RELATIVE, method = RequestMethod.POST)
    public Object selectIndustryEleLinkRelative(@RequestBody JSONObject params) {

        List<TreeMenu> projList = getProjIdByIndustryId(params);

        List<Integer> projIdList = new ArrayList<>();
        projList.stream().map(a -> a.getNodeId()).forEach(a -> {
            projIdList.add(a.intValue());
        });
        List<LinkRelativeStatistic> statisticList = hbyProjectDayCountinfoService.selectEleLinkRelative(projIdList);
        statisticList.stream().forEach(statistic -> {
            statistic.setIndustryId(params.getLong("industryId"));
        });
        return renderResult(statisticList);
    }

    /**
     * 行政区域电能环比
     * @param params agencyId 机构id
     * @return
     */
    @RequestMapping(value = ApiConstant.AGENCY_LINK_RELATIVE, method = RequestMethod.POST)
    public Object selectAgencyEleLinkRelative(@RequestBody JSONObject params) {

        if (params == null || params.getLong("agencyId") == null || params.getLong("agencyId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "行政机构id错误");
        }

        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (code == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        List<TreeMenu> projList = treeMenuService.selectChildTreemenu(userInfo.getUserId(), userInfo.getGroupOnlyRead(), params.getLong("agencyId"), 1, null, null, null);

        List<Integer> projIdList = new ArrayList<>();
        projList.stream().map(a -> a.getNodeId()).forEach(a -> {
            projIdList.add(a.intValue());
        });
        List<LinkRelativeStatistic> statisticList = hbyProjectDayCountinfoService.selectEleLinkRelative(projIdList);
        statisticList.stream().forEach(statistic -> {
            statistic.setAgcyId(params.getLong("agencyId"));
        });
        return renderResult(statisticList);
    }

    /**
     * 单位下分组、设备用电量排名
     * @param params projId-单位id，label-标签 1-分组，2-设备
     * @return
     */
    @RequestMapping(value = ApiConstant.PROJECT_ELE_RANKING, method = RequestMethod.POST)
    public Object useEleRankingProj(@RequestBody JSONObject params) {

        if (params == null || params.getInteger("projId") == null || params.getInteger("projId") == 0
                || params.getInteger("label") == null || params.getInteger("label") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        UserInfo userInfo = this.getUserInfo();
        Integer permission = permissionService.checkPermission(userInfo.getUserId(), params.getInteger("projId"));
        if (permission == -1) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        return renderResult(hbyProjectDayCountinfoService.findUseEleRankingProj(params.getInteger("projId"), params.getInteger("label")));
    }

    /**
     * 行业下单位用电量排名
     * @param params industryId 行业id
     * @return
     */
    @RequestMapping(value = ApiConstant.INDUSTRY_ELE_RANKING, method = RequestMethod.POST)
    public Object useEleRankingIndustry(@RequestBody JSONObject params) {

        // TODO 当前是查询行业下的所有单位，可能需要改动 查询行业下绑定监测点的单位(环保云单位)
        List<TreeMenu> projList = getProjIdByIndustryId(params);
        if (projList == null || projList.size() == 0) {
            return renderResult(new ArrayList<>());
        }
        return renderResult(this.getRankingMap2(projList));
    }

    /**
     * 行政区域下单位用电量排名
     * @param params agencyId 区域id
     * @return
     */
    @RequestMapping(value = ApiConstant.AGENCY_ELE_RANKING, method = RequestMethod.POST)
    public Object useEleRankingAgency(@RequestBody JSONObject params) {

        if (params == null || params.getLong("agencyId") == null || params.getLong("agencyId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "行政机构id错误");
        }
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (code == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        // TODO 当前是行政机构下的所有单位，可能需要改动 查询行政机构下绑定监测点的单位(环保云单位)
        List<TreeMenu> projList = treeMenuService.selectChildTreemenu(userInfo.getUserId(), userInfo.getGroupOnlyRead(), params.getLong("agencyId"), 1, null, null, null);
        if (projList == null || projList.size() == 0) {
            return renderResult(new ArrayList<>());
        }
        return renderResult(this.getRankingMap2(projList));
    }

    /**
     * 单位-电能趋势 柱状图
     * @param params projId 单位id, label-标签（默认环比） 1-环比 2-同比，timeType（默认日） 1-日 2-月 3-年, date-时间
     * @return
     */
    @RequestMapping(value = ApiConstant.PROJECT_ELE_BARGRAPH, method = RequestMethod.POST)
    public Object eleTrendBarGraphProj(@RequestBody JSONObject params) {

        if (params == null || params.getInteger("projId") == null || params.getInteger("projId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        UserInfo userInfo = this.getUserInfo();
        Integer permission = permissionService.checkPermission(userInfo.getUserId(), params.getInteger("projId"));
        if (permission == -1) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        Integer label = params.getInteger("label");
        Integer timeType = params.getInteger("timeType");
        List<Integer> projIdList = new ArrayList<>(4);
        projIdList.add(params.getInteger("projId"));
        Date date = params.getDate("date");
        if (label == 2) {
            return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphYoY(projIdList, timeType, date));
        }
        return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphLinkRelative(projIdList, timeType, date));
    }

    /**
     * 行业-电能趋势 柱状图
     * @param params industryId 行业id, label-标签（默认环比） 1-环比 2-同比，timeType（默认日） 1-日 2-月 3-年
     * @return
     */
    @RequestMapping(value = ApiConstant.INDUSTRY_ELE_BARGRAPH, method = RequestMethod.POST)
    public Object eleTrendBarGraphIndustry(@RequestBody JSONObject params) {

        Integer label = params.getInteger("label");
        Integer timeType = params.getInteger("timeType");
        Date date = params.getDate("date");
        List<Integer> projIdList = new ArrayList<>();
        List<TreeMenu> projList = getProjIdByIndustryId(params);
        projList.stream().forEach(a -> {
            projIdList.add(a.getNodeId().intValue());
        });
        if (label == 2) {
            return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphYoY(projIdList, timeType, date));
        }
        return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphLinkRelative(projIdList, timeType, date));
    }

    /**
     * 区域-电能趋势 柱状图
     * @param params agencyId 区域id, label-标签（默认环比） 1-环比 2-同比，timeType（默认日） 1-日 2-月 3-年
     * @return
     */
    @RequestMapping(value = ApiConstant.AGENCY_ELE_BARGRAPH, method = RequestMethod.POST)
    public Object eleTrendBarGraphAgency(@RequestBody JSONObject params) {


        Integer label = params.getInteger("label");
        Integer timeType = params.getInteger("timeType");
        Date date = params.getDate("date");

        if (params == null || params.getLong("agencyId") == null || params.getLong("agencyId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "行政机构id错误");
        }
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (code == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        List<TreeMenu> projList = treeMenuService.selectChildTreemenu(userInfo.getUserId(), userInfo.getGroupOnlyRead(), params.getLong("agencyId"), 1, null, null, null);

        List<Integer> projIdList = new ArrayList<>();
        projList.stream().forEach(a -> {
            projIdList.add(a.getNodeId().intValue());
        });
        if (label == 2) {
            return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphYoY(projIdList, timeType, date));
        }
        return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphLinkRelative(projIdList, timeType, date));
    }

    /**
     * 首页柱状图
     * @param params {
     *   "projId": "986",
     *   "label": 1,
     *   "timeType": 1,
     *   "date": "2020-01-14"
     * }
     * @return
     */
    @RequestMapping(value = ApiConstant.HOME_ELE_BARGRAPH, method = RequestMethod.POST)
    public Object homeBarGraph(@RequestBody(required = false) JSONObject params) {
        Integer label = 2;
        Integer timeType = null;
        Date date = null;
        if (params != null) {
            label = params.getInteger("label");
            timeType = params.getInteger("timeType");
            date = params.getDate("date");
        }
        if (timeType == null || timeType.equals(0)) {
            timeType = 1;
        }
        List<Integer> projIdList = getThisUserCanShowProjectIdList();
        if (label != null && label == 1) {
            return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphLinkRelative(projIdList, timeType, date));
        }
        return renderResult(hbyProjectDayCountinfoService.selectEleBarGraphYoY(projIdList, timeType, date));
    }

    /**
     * 首页-停限产方案绑定情况
     * @return
     */
    @RequestMapping(value = ApiConstant.HOME_PLAN_BIND, method = RequestMethod.POST)
    public Object homePlanBind() {

        List<Integer> projIdList = getThisUserCanShowProjectIdList();
        return renderResult(hbyProjectDayCountinfoService.findHomePlanBind(projIdList));
    }

    /**
     * 获取当前用户可见的单位ids
     * @return
     */
    private List<Integer> getThisUserCanShowProjectIdList() {
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        List<TreeMenu> projList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), null);
        List<Integer> projIdList = new ArrayList<>();
        projList.stream().forEach(a -> {
            projIdList.add(a.getNodeId().intValue());
        });
        return projIdList;
    }

    /**
     * 单位总表用电量查询
     * @param projList
     * @return
     */
    private Object getRankingMap(List<TreeMenu> projList) {
        Map<Integer, Map<String, Object>> rankingMap = new HashMap<>();
        projList.stream().forEach(a -> {
            Map<String, Object> tem = new HashMap<>(4);
            tem.put("name", a.getNodeName());
            tem.put("value", "0.0");
            rankingMap.put(a.getNodeId().intValue(), tem);
        });
        DateTime now = DateTime.now();
        List<HbyProjectDayCountinfo> countInfoList = hbyProjectDayCountinfoService.selectHbyProjectDayCountinfoByProjIds(new ArrayList<>(rankingMap.keySet()),
                now.getYear(), now.getMonthOfYear(), now.getDayOfMonth());
        countInfoList.stream().forEach(a -> {
            rankingMap.get(a.getUnitId()).put("value", String.format("%.1f", Double.parseDouble(a.getTotalDevEleUse())));
        });

        return rankingMap.values();
    }

    /**
     * 单位总表用电量查询 -- 2020-03-30 修改
     * @param projList
     * @return
     */
    private Object getRankingMap2(List<TreeMenu> projList) {
        List<Integer> projIdList = projList.stream().map(pro -> pro.getNodeId().intValue()).collect(Collectors.toList());
        List<UseEleRanking> rankings = hbyProjectDayCountinfoService.selectHbyProjectDayCountinfoByProjIds2(projIdList);
        if (rankings.size() >= 10) {
            return rankings;
        }
        Map<Integer, Object> rankingMap = new HashMap<>();
        for (UseEleRanking ranking : rankings) {
            rankingMap.put(ranking.getId().intValue(), 1);
        }
        UseEleRanking use;
        for (TreeMenu menu : projList) {
            if (rankingMap.get(menu.getNodeId().intValue()) == null && rankings.size() < 10) {
                use = new UseEleRanking();
                use.setId(menu.getNodeId());
                use.setName(menu.getNodeName());
                use.setValue(0.0);
                rankings.add(use);
            }
        }
        return rankings;
    }

    /**
     * 行业id获取单位
     * @param params
     * @return
     */
    private List<TreeMenu> getProjIdByIndustryId(@RequestBody JSONObject params) {
        if (params == null || params.getLong("industryId") == null) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "行业id错误");
        }
        Map<String, Object> param = new HashMap<>(4);
        param.put("industryId", params.getLong("industryId"));
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer userGrade = UserUtil.getUserGrade(code);
        return permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), code != null, code, userGrade, param);
    }

    public static void main(String[] args) {
        Date date = new Date();
        DateTime minus = DateTime.now().minus(date.getTime());
        System.out.println(minus);
    }

    @RequestMapping("/test")
    public Object createTest(@RequestParam("projId") Integer projId) throws InterruptedException {
        // 查询总表
        List<DevDto> devices = commonSimpleBeanInfoService.findDevicesOfOverLookPointByUnitID(projId);
        // 过滤总表id
        Integer devIdpk = 0;
        List<Integer> collect = devices.stream().filter(dev -> dev.getDevProTy().equals(0)).map(dev -> dev.getDevIdpk()).collect(Collectors.toList());
        if (collect != null && collect.size() > 0) {
            devIdpk = collect.get(0);
        }
        double a1 = 10;
        double b = 20;
        double c = 30;
        HbaseUtil.AddRow(devIdpk+"", a1 + "|" + b+ "|" +c, "PA|PB|PC");
        Thread.sleep(1000);
        for (int i = 0; i < 100; i++) {
            a1 = a1 - i;
            b = b - i;
            c = c - i;
            HbaseUtil.AddRow(devIdpk+"", a1 + "|" + b+ "|" +c, "PA|PB|PC");
        }
        return renderResult();
    }

}
