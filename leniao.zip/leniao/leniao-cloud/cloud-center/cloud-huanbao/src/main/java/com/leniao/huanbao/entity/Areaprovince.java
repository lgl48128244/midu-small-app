package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;

import lombok.ToString;



@TableName("areaprovince")
@ToString
public class Areaprovince {
    private String provinceid;

    private String province;

    public String getProvinceid() {
        return provinceid;
    }

    public void setProvinceid(String provinceid) {
        this.provinceid = provinceid == null ? null : provinceid.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }
}