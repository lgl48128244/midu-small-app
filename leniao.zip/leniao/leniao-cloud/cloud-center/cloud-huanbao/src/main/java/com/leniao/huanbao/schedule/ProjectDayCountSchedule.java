package com.leniao.huanbao.schedule;

import cn.hutool.core.util.ArrayUtil;
import com.alibaba.fastjson.JSON;
import com.leniao.commons.util.SpringUtils;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.dto.schedule.OverLookPointWithDevlist;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import com.leniao.huanbao.service.HbyProjectstatusService;
import com.leniao.service.HbyAgencyService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: 统计单位日数据的定时任务
 * @Author: haosw
 * @CreateDate: 2020/1/2 15:04
 * @Version: 1.0
 */
@Slf4j
public class ProjectDayCountSchedule /*extends AbstractOperation*/ implements Runnable {

    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;
    private HbScheduledService hbScheduledService;
    private HbyProjectDayCountinfoService hbyProjectDayCountinfoService;
    private HbyProjectstatusService hbyProjectstatusService;
    private HbyAgencyService hbyAgencyService;
    private RedisTemplate<String, Object> redisTemplate;


    public ProjectDayCountSchedule() {
        ApplicationContext applicationContext = SpringUtils.getApplicationContext();
        this.commonSimpleBeanInfoService = SpringUtils.getBean(CommonSimpleBeanInfoService.class);
        this.hbScheduledService = SpringUtils.getBean(HbScheduledService.class);
        this.hbyProjectDayCountinfoService =  SpringUtils.getBean(HbyProjectDayCountinfoService.class);
        this.hbyProjectstatusService = SpringUtils.getBean(HbyProjectstatusService.class);
        this.hbyAgencyService = SpringUtils.getBean(HbyAgencyService.class);
        this.redisTemplate = (RedisTemplate<String, Object>) SpringUtils.getBean("redisTemplate");
    }

    @Override
    public void run() {
        System.out.println(DateTime.now().toString("yyyy-MM-dd HH:mm:ss") + ": 功率异常定时器运行完成，异步调用单位日数据统计");
        this.bgein();
    }

    protected void bgein() {
        log.error("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++单位日数据信息统计程序开始运行+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        Set<Integer> unitSet = new HashSet<>();
        Date now = DateTime.now().toDate();
        //获取所有监测点及设备数据
        List<OverLookPointWithDevlist> overLookPointsWithDevlist = this.hbScheduledService.findOverLookPointsWithDevlist();
        for (OverLookPointWithDevlist lookPoint : overLookPointsWithDevlist) {
            Integer unitId = lookPoint.getUnitId();
            if (unitSet.contains(unitId)) {
                continue;
            }
            unitSet.add(unitId);
            List<OverLookPointWithDevlist> unitPointList = overLookPointsWithDevlist.stream().filter(p -> p.getUnitId().equals(unitId)).collect(Collectors.toList());
            try {
                if (CollectionUtils.isNotEmpty(unitPointList)) {
                    this.dealWithOverLookPointData(now, unitId);
                }
            } catch (Exception e) {
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                log.error(e.getMessage(), e);
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }

        }
        System.out.println("单位日数据信息统计程序结束运行");
        log.error("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++单位日数据信息统计程序结束运行+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

    }

    /**
     * @description: 处理单位监测点的数据
     * @author: haosw
     * @param: unitPointList：监测点及设备数据，now：当前时间，unitId：单位ID
     * @return:
     * @date: 2020/1/3 10:44
     */
    private synchronized void dealWithOverLookPointData(Date now, Integer unitId) {
        DateTime nowTime = new DateTime(now);
        int year = nowTime.getYear();
        int monthOfYear = nowTime.getMonthOfYear();
        int dayOfMonth = nowTime.getDayOfMonth();
        //获取单位的当日数据
        List<HbyProjectDayCountinfo> dayInfos = this.hbyProjectDayCountinfoService.selectHbyProjectDayCountinfoByProjIds(unitId, year, monthOfYear, dayOfMonth);
        //获取单位实时统计数据
        HbyProjectDayCountinfo dayInfo = null;
        if (CollectionUtils.isEmpty(dayInfos)) {
            dayInfo = this.newOneDayCountInfoBean(nowTime, unitId);
        } else {
            dayInfo = dayInfos.get(0);
        }
        HbyProjectstatus unitStatus = this.hbyProjectstatusService.getById(unitId);
        if (unitStatus != null) {
            this.copyFromRealTimeBean(dayInfo, unitStatus);
            //获取单位的机构
            HbyAgency hbyAgency = this.hbyAgencyService.selectByAreaCode(unitStatus.getProvinceCode(), unitStatus.getCityCode(), unitStatus.getAreaCode(),unitStatus.getPlatformId());
            if (hbyAgency != null) {
                dayInfo.setAgcyId(hbyAgency.getId());
            }
        }
        //for (OverLookPointWithDevlist point : unitPointList) {
        //获取单位的产污设备和治污设备的用电量
        HashMap<String, Object> eleMap = this.hbScheduledService.getPollAndConDevEleQ(unitId, now);
        dayInfo.setPollDevEleUse(eleMap.get("pollEle").toString());
        dayInfo.setConDevEleUse(eleMap.get("conEle").toString());
        dayInfo.setTotalDevEleUse(eleMap.get("rootEle").toString());

        //获取单位的几大异常数
        HashMap<String, Object> errNumMap = this.commonSimpleBeanInfoService.findUnitEveryErrTypeNum(unitId, now);
        dayInfo.setPollDevErrNum((long) errNumMap.get("pollDevErrNum"));
        dayInfo.setConDevErrNum((long) errNumMap.get("conDevErrNum"));
        dayInfo.setStopOrLimitErrNum((long) errNumMap.get("stopProErrNum") + (long) errNumMap.get("limitProErrNum"));
        dayInfo.setEleErrNum((long) errNumMap.get("eleErrNum"));
        dayInfo.setPowerErrNum((long) errNumMap.get("powerErrNum"));
        dayInfo.setDevStopErrNum((long) errNumMap.get("stopDevErrNum"));

        //获取功率和电量的峰值数据 TODO 2020-03-16 注释
        /*HbyErrorDto.EleMaxDto eleExcute = redisTemplate.execute((RedisConnection redisConnection) -> {
            //byte[] bytes = redisConnection.hGet("DeviceMaxEle".getBytes(), point.getUnitId().toString().getBytes());
            byte[] bytes = redisConnection.hGet("DeviceMaxEle".getBytes(), unitId.toString().getBytes());
            if (ArrayUtil.isNotEmpty(bytes)) {
                return JSON.parseObject(new String(bytes), HbyErrorDto.EleMaxDto.class);
            }
            return null;
        });
        if (eleExcute != null) {
            dayInfo.setEleMax(eleExcute.getMaxEle().toString());
            dayInfo.setMaxEleTime(eleExcute.getAddtime());
        }*/
        //从电量表中获取该单位的最大电量
        HbyErrorDto.EleMaxDto eleExcute = this.hbScheduledService.findMaxEleUseOfUnitOneDay(unitId);
        if (eleExcute != null) {
            dayInfo.setEleMax(eleExcute.getMaxEle().toString());
            dayInfo.setMaxEleTime(eleExcute.getAddtime());
        }

        HbyErrorDto.PowerMaxDto powerExcute = redisTemplate.execute((RedisConnection redisConnection) -> {
            byte[] bytes = redisConnection.hGet("DeviceMaxPower".getBytes(), unitId.toString().getBytes());
            if (ArrayUtil.isNotEmpty(bytes)) {
                return JSON.parseObject(new String(bytes), HbyErrorDto.PowerMaxDto.class);
            }
            return null;
        });
        if (powerExcute != null) {
            Double maxPower = powerExcute.getMaxPower();
            dayInfo.setPowerMax(maxPower == null ? "0" : maxPower.toString());
            dayInfo.setMaxPowerTime(powerExcute.getAddtime());
        } else {
            dayInfo.setPowerMax("0");
        }

        //执行入库操作 TODO
        this.hbyProjectDayCountinfoService.saveOrUpdate(dayInfo);
    }

    /**
     * @description: 从单位实时数据对象中获取单位统计数据
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 15:07
     */
    private void copyFromRealTimeBean(HbyProjectDayCountinfo dayInfo, HbyProjectstatus unitStatus) {
        //生产状态
        if (dayInfo.getProducState() != 1) {
            dayInfo.setProducState(unitStatus.getProducState());
        }
        //停机数
        if (dayInfo.getStopDevNum() < unitStatus.getStopDevNum()) {
            dayInfo.setStopDevNum(unitStatus.getStopDevNum());
        }
        //失联数
        if (dayInfo.getLostDevNum() < unitStatus.getLostDevNum()) {
            dayInfo.setLostDevNum(unitStatus.getLostDevNum());
        }
        //运行数
        if (dayInfo.getRunDevNum() < unitStatus.getRunDevNum()) {
            dayInfo.setRunDevNum(unitStatus.getRunDevNum());
        }
        //产污设备数
        if (dayInfo.getPollDevNum() < unitStatus.getPollDevNum()) {
            dayInfo.setPollDevNum(unitStatus.getPollDevNum());
        }
        //治污设备数据
        if (dayInfo.getConDevNum() < unitStatus.getConDevNum()) {
            dayInfo.setConDevNum(unitStatus.getConDevNum());
        }
        dayInfo.setBothDevNum(unitStatus.getPollDevNum() + unitStatus.getConDevNum());
        dayInfo.setIndustryIdpk(unitStatus.getIndustryId());
    }

    /**
     * @description: new一个单位日数据对象并赋予初始值
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 15:06
     */
    private synchronized HbyProjectDayCountinfo newOneDayCountInfoBean(DateTime nowTime, Integer unitId) {
        HbyProjectDayCountinfo dayInfo = new HbyProjectDayCountinfo();
        //获取单位基本信息
        UnitBasicInfoDto unitBasicInfo = this.commonSimpleBeanInfoService.findUnitBasicInfoByID(unitId);
        BeanUtils.copyProperties(unitBasicInfo, dayInfo);
        dayInfo.setYear(nowTime.getYear());
        dayInfo.setMonth(nowTime.getMonthOfYear());
        dayInfo.setDay(nowTime.getDayOfMonth());
        HbyAgency agency = this.hbyAgencyService.selectByAreaCode(unitBasicInfo.getProvinceCode(), unitBasicInfo.getCityCode(), unitBasicInfo.getAreaCode(), unitBasicInfo.getPlatformId());
        if (agency != null) {
            dayInfo.setAgcyId(agency.getId());
        }
        dayInfo.setPollDevEleUse("0");
        dayInfo.setConDevEleUse("0");
        dayInfo.setTotalDevEleUse("0");
        dayInfo.setPollDevErrNum(0L);
        dayInfo.setConDevErrNum(0L);
        dayInfo.setStopOrLimitErrNum(0L);
        dayInfo.setEleErrNum(0L);
        dayInfo.setPowerErrNum(0L);
        dayInfo.setDevStopErrNum(0L);
        dayInfo.setBothDevNum(0);
        dayInfo.setPollDevNum(0);
        dayInfo.setConDevNum(0);
        dayInfo.setRunDevNum(0);
        dayInfo.setStopDevNum(0);
        dayInfo.setLostDevNum(0);
        dayInfo.setPowerMax("0");
        dayInfo.setEleMax("0");
        dayInfo.setMaxPowerTime(nowTime.toDate());
        dayInfo.setMaxEleTime(nowTime.toDate());
        //当天生产状态默认0   1:生产,2:停产,3:失联
        dayInfo.setProducState(0);
        return dayInfo;
    }

}
