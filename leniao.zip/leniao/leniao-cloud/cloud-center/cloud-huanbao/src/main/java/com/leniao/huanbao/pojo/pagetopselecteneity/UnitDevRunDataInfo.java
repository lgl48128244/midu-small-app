package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/30 18:50
 * @update
 * @description
 */
public class UnitDevRunDataInfo {

    //时间
    private String time;
    //行政区域
    private String area;
    //单位名称
    private String unitName;
    //分组名称
    private String groupName;
    //监测点名称
    private String lookPointName;
    //监测点Id
    private Long lookPointId;
    //产污设备
    //private Integer pollsNum = 0;
    //产污设备安装位置
    private String pollsNum;
    //产污设备阈值
    private Float pollsPower = 0.0f;
    //产污设备采集值
    private Float pollsReal = 0.0f;
    //治污设备
    //private Integer consNum = 0;
    //产污设备安装位置
    private String consNum;
    //治污设备阈值
    private Float consPower = 0.0f;
    //治污设备采集值
    private Float consReal = 0.0f;
    //停限计划
    private boolean reducePlan;

    @Override
    public String toString() {
        return "UnitDevRunDataInfo{" +
                ", time='" + time + '\'' +
                ", area='" + area + '\'' +
                ", unitName='" + unitName + '\'' +
                ", groupName='" + groupName + '\'' +
                ", lookPointName='" + lookPointName + '\'' +
                ", pollsNum=" + pollsNum +
                ", pollsPower=" + pollsPower +
                ", pollsReal=" + pollsReal +
                ", consNum=" + consNum +
                ", consPower=" + consPower +
                ", consReal=" + consReal +
                ", reducePlan=" + reducePlan +
                '}';
    }

    public Long getLookPointId() {
        return lookPointId;
    }

    public void setLookPointId(Long lookPointId) {
        this.lookPointId = lookPointId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getLookPointName() {
        return lookPointName;
    }

    public void setLookPointName(String lookPointName) {
        this.lookPointName = lookPointName;
    }

    public String getPollsNum() {
        return pollsNum;
    }

    public void setPollsNum(String pollsNum) {
        this.pollsNum = pollsNum;
    }

    public String getConsNum() {
        return consNum;
    }

    public void setConsNum(String consNum) {
        this.consNum = consNum;
    }

    public Float getPollsPower() {
        return pollsPower;
    }

    public void setPollsPower(Float pollsPower) {
        this.pollsPower = pollsPower;
    }

    public Float getPollsReal() {
        return pollsReal;
    }

    public void setPollsReal(Float pollsReal) {
        this.pollsReal = pollsReal;
    }



    public Float getConsPower() {
        return consPower;
    }

    public void setConsPower(Float consPower) {
        this.consPower = consPower;
    }

    public Float getConsReal() {
        return consReal;
    }

    public void setConsReal(Float consReal) {
        this.consReal = consReal;
    }

    public boolean isReducePlan() {
        return reducePlan;
    }

    public void setReducePlan(boolean reducePlan) {
        this.reducePlan = reducePlan;
    }
}
