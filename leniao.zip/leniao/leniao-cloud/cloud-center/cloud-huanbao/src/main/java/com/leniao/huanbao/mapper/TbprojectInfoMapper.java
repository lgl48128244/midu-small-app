package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/24 19:36
 * @update
 * @description
 */
public interface TbprojectInfoMapper {
    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proProvinceCode = #{provinceId}")
    List<Map<String,Object>> findDefaultProvinceUnit(Page<Map<String,Object>> page, String provinceId);

    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proCityCode = #{cityId}")
    List<Map<String,Object>> findDefaultCityUnit(Page<Map<String,Object>> page,String cityId);

    @Select("SELECT projId AS unitId,projName AS unitName,proArea AS area,proCity AS city,proProvince AS province FROM tblnprojectinfo WHERE proAreaCode = #{areaId}")
    List<Map<String,Object>> findDefaultAreaUnit(Page<Map<String,Object>> page,String areaId);
}
