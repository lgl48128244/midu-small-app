package com.leniao.huanbao.dto.statisticanalysis;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.utils.DoubleSerialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 统计分析
 * @author: jiangdy
 * @create: 2019-12-24 17:29
 **/
@Getter
@Setter
@ToString
public class StatisticAnalysisDto {

    /**
     * 排名
     */
    private Integer ranking;

    /**
     * 单位id
     */
    private Long projId;

    /**
     * 单位名称
     */
    private String projName;

    /**
     * 行政机构名称
     */
    private String agencyName;

    /**
     * 行业名称
     */
    private String industryName;

    /**
     * 生成状态
     */
    private Integer producState;

    /**
     * 是否污染日 1-污染日 0-非污染日
     */
    private Integer isPollution = 0;

    /**
     * 用电量
     */
    @JsonSerialize(using = DoubleSerialize.class)
    private Double totalQ;

    /**
     * 设备主键id
     */
    private Integer devIdpk;

    /**
     * 设备用户量
     */
    private UshareDeviceElectricuse deviceElectricuse;
}
