package com.leniao.huanbao.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlanExample;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public interface HbyReduceEmmissionService extends IService<HbyReduceEmmissionPlan> {

    long countByExample(HbyReduceEmmissionPlanExample example);

    int deleteByExample(HbyReduceEmmissionPlanExample example);

    int deleteByPrimaryKey(Long planId);

    int insert(HbyReduceEmmissionPlan record);

    int insertSelective(HbyReduceEmmissionPlan record);

    List<HbyReduceEmmissionPlan> selectByExampleWithBLOBs(HbyReduceEmmissionPlanExample example);

    List<HbyReduceEmmissionPlan> selectByExample(HbyReduceEmmissionPlanExample example);

    HbyReduceEmmissionPlan selectByPrimaryKey(Long planId);

    int updateByExampleSelective(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example);

    int updateByExampleWithBLOBs(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example);

    int updateByExample(HbyReduceEmmissionPlan record, HbyReduceEmmissionPlanExample example);

    int updateByPrimaryKeySelective(HbyReduceEmmissionPlan record);

    int updateByPrimaryKeyWithBLOBs(HbyReduceEmmissionPlan record);

    int updateByPrimaryKey(HbyReduceEmmissionPlan record);

    /**
     * 添加减产减排方案
     * @param userId 用户userID
     * @param reduceEmmissionDto 减产减排方案dto信息
     * @return 方案id
     */
    Long insertReduceEmmissionPlan(int userId, ReduceEmmissionDto reduceEmmissionDto);

    /**
     * 修改减产减排方案
     * @param userId 用户userID
     * @param reduceEmmissionDto 减产减排方案dto信息
     * @return 方案id
     */
    Long updateReduceEmmissionPlan(int userId, ReduceEmmissionDto reduceEmmissionDto);

    /**
     * 删除减产减排方案, 假删除
     * @param userId 用户userID
     * @param planId 方案id
     * @return 删除结果
     */
    boolean deleteReduceEmmissionPlan(int userId, Long planId);

    /**
     * 可变条件查询减排方案
     *
     * @param userGrade 区域用户等
     * @param areaCode  区域码
     * @param agcyId 机构id 非必须
     * @param beginTime 方案生效开始时间 非必须
     * @param endTime 方案生效结束时间 非必须
     * @param warnLevel 预警等级 非必须
     * @param isUsing 仅仅显示正在启用的方案 0-否， 1-是 非必须(默认0)
     * @return
     */
    List<ReduceEmmissionDto> selectReduceEmmissionPlan(Long agencyId, Integer userGrade, AreaCodeJoinOther areaCode,
                                                              Integer agcyId, Integer warnLevel, Integer isUsing, Date nowTime, Date beginTime, Date endTime);

    /**
     * 方案绑定
     * @param planId 方案id
     * @param projIdList 单位id集合
     * @return
     */
    boolean updateBindReduceEmmissionPlan(Long planId, List<Integer> projIdList);

    /**
     * 方案解除绑定
     * @param planId 方案id
     * @param projIdList 单位id集合
     * @return
     */
    boolean updateUnBindReduceEmmissionPlan(Long planId, ArrayList<Integer> projIdList);

    Integer selectBindCount(Long planId);

    List<HbyAgency> getAgencyInfo(AreaCodeJoinOther areaCode);
}
