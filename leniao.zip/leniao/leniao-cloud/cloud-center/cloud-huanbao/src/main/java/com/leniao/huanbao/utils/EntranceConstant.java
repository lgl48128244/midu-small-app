package com.leniao.huanbao.utils;

/**
 * @author liudongshuai
 * @date 2019/12/22 22:10
 * @update
 * @description
 */
public class EntranceConstant {

    /**
     * 基础数据管理，监测点管理接口入口
     */
    public static final String BASELOOKPOINT = "/baseLookPoint";

    /**
     * 设备状态列表入口
     * */
    public static final String REGION = "/region";

    /**
     * 设备实时数据入口
     */
    public static final String DEVDATAINFO = "/devDataInfo";

    /**
     * 单位数据信息入口
     */
    public static final String UNITDATAINFO = "/unitDataInfo";

    /**
     * 统计信息入口
     */
    public static final String COUNTANALYSIS = "/countAnalysis";
}
