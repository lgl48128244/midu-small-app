package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/19 17:31
 * @update
 */
public class DevDetailsInfo {
    //行政区域
    private String administrativeArea;
    //单位名称
    private String unitName;
    //分组名称
    private String groupName;
    //监测点名称
    private String overLookName;
    //设备类型
    private String devType;
    //设备编号
    private String devSignature;
    //设备状态
    private String devStatus;


    public String getAdministrativeArea() {
        return administrativeArea;
    }

    public void setAdministrativeArea(String administrativeArea) {
        this.administrativeArea = administrativeArea;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getOverLookName() {
        return overLookName;
    }

    public void setOverLookName(String overLookName) {
        this.overLookName = overLookName;
    }

    public String getDevType() {
        return devType;
    }

    public void setDevType(String devType) {
        this.devType = devType;
    }

    public String getDevSignature() {
        return devSignature;
    }

    public void setDevSignature(String devSignature) {
        this.devSignature = devSignature;
    }

    public String getDevStatus() {
        return devStatus;
    }

    public void setDevStatus(String devStatus) {
        this.devStatus = devStatus;
    }

    @Override
    public String toString() {
        return "DevDetailsInfo{" +
                "administrativeArea='" + administrativeArea + '\'' +
                ", unitName='" + unitName + '\'' +
                ", groupName='" + groupName + '\'' +
                ", overLookName='" + overLookName + '\'' +
                ", devType='" + devType + '\'' +
                ", devSignature='" + devSignature + '\'' +
                ", devStatus='" + devStatus + '\'' +
                '}';
    }
}
