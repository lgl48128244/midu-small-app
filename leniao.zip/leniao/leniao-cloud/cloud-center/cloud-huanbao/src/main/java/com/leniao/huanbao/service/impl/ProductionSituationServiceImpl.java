package com.leniao.huanbao.service.impl;

import com.leniao.commons.BaseService;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.mapper.ProductionSituationMapper;
import com.leniao.huanbao.service.ProductionSituationService;
import com.leniao.mapper.BussinessExMapper;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.model.vo.UserInfo;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 错峰生产方案执行情况
 * @author: jiangdy
 * @create: 2019-12-24 14:51
 **/
@Service
public class ProductionSituationServiceImpl extends BaseService implements ProductionSituationService {

    @Resource
    private ProductionSituationMapper productionSituationMapper;

    @Resource
    private BussinessExMapper bussinessExMapper;

    /**
     * 非区域用户查询错所见单位的错峰生产方案执行情况
     * @param projIds 单位id集合
     * @param params 查询参数 有效参数 机构id agencyId， 方案生效开始时间 begin， 方案生效结束时间 end
     * @return
     */
    @Override
    public List<ReduceEmmissionDto> selectProductionSituationByNotAreaUser(List<Long> projIds, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params) {
        String endTime = DateTime.now().toString("yyyy-MM-dd");
        UserInfo userInfo = GlobalConstant.getUserInfo();
        List<ReduceEmmissionDto> emmissionDtoList = productionSituationMapper.selectProductionSituationByNotAreaUser(projIds, userInfo.getPlatformId(), endTime, areaCode, userGrade, params);
        List<BaseBusinessExDTO.BusinessExCuoFengList> list;
        for (ReduceEmmissionDto dto : emmissionDtoList) {
            list = bussinessExMapper.selectErrorCuoFengList(dto.getProjId());
            if (list != null) {
                dto.setErrCount(list.size());
            } else {
                dto.setErrCount(0);
            }
        }
        return emmissionDtoList;
    }

    /**
     * 区域用户查询机构下所有单位的错峰生产方案执行情况
     * @param agencyIds 机构id集合
     * @param params 查询参数 有效参数 单位id projId，行业id industryId， 机构id agencyId， 方案生效开始时间 begin， 方案生效结束时间 end
     * @return
     */
    @Override
    public List<ReduceEmmissionDto> selectProductionSituationByAreaUser(List<Long> agencyIds, Map<String, Object> params) {
        UserInfo userInfo = GlobalConstant.getUserInfo();
        return productionSituationMapper.selectProductionSituationByAreaUser(agencyIds, userInfo.getPlatformId(), params);
    }
}
