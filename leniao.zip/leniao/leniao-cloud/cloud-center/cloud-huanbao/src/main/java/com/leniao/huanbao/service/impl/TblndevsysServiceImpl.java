package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.huanbao.entity.Tblndevsys;
import com.leniao.huanbao.mapper.TblndevsysMapper;
import com.leniao.huanbao.service.TblndevsysService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/23 15:35
 * @update
 * @description
 */
@Service
public class TblndevsysServiceImpl implements TblndevsysService {

    @Resource
    private TblndevsysMapper tblndevsysMapper;

    /**
     * 查出所有的设备系统，以及系统ID
     */
    @Override
    public List<Tblndevsys> findDevSysNameId() {
        //创建条件
        QueryWrapper<Tblndevsys> queryWrapper = new QueryWrapper<>();

        queryWrapper.select("devsysid","devsysname").lambda().eq(Tblndevsys::getIsdelete,0);

        return tblndevsysMapper.selectList(queryWrapper);
    }
}
