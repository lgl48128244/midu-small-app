package com.leniao.huanbao.service.impl;

import cn.hutool.core.util.ArrayUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.common.collect.Lists;
import com.leniao.commons.BaseService;
import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.commons.util.HbaseUtil;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.commons.util.thrift.realValue1;
import com.leniao.commons.util.thrift.realValueByNode1;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.entity.HbyProjectErrorInfoExample;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.dto.schedule.*;
import com.leniao.huanbao.entity.*;
import com.leniao.huanbao.mapper.HbyDevalTimeStatusMapper;
import com.leniao.huanbao.mapper.HbyProjectstatusMapper;
import com.leniao.huanbao.mapper.HbyReduceplanJoinProjectMapper;
import com.leniao.huanbao.mapper.ScheduledMapper;
import com.leniao.huanbao.utils.ScheduleNeedUtil;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyProjectstatusService;
import com.leniao.huanbao.service.HbyReduceplanJoinProjectService;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import com.leniao.model.constant.SpringCacheConstants;
import com.leniao.service.HbyOverLookDevJoinService;
import com.leniao.service.HbyProjectErrorInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.BeanUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import static com.leniao.model.constant.SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR;

/**
 * @Description: 定时任务使用的业务实现类
 * @Author: haosw
 * @CreateDate: 2019/12/27 16:52
 * @Version: 1.0
 */
@Service
@Slf4j
public class HbScheduledServiceImpl extends BaseService implements HbScheduledService {

    @Resource
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    @Resource
    private HbyProjectstatusService hbyProjectstatusService;
    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;
    @Resource
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;
    @Resource
    private ScheduledMapper scheduledMapper;
    @Resource
    private HbyDevalTimeStatusMapper hbyDevalTimeStatusMapper;
    @Resource
    private HbyProjectstatusMapper hbyProjectstatusMapper;
    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;
    @Resource
    private HbyReduceplanJoinProjectMapper hbyReduceplanJoinProjectMapper;


    @Override
//    @Cacheable(cacheNames = SpringCacheConstants.REDIS_CACHE_1MIN_NAME, keyGenerator = DEFAULT_CACHE_KEY_GENERATOR, unless = "#result == null")
    public List<OverLookPointWithDevlist> findOverLookPointsWithDevlist() {
        List<OverLookPointWithDevlist> overLookPointsWithDevlist = this.scheduledMapper.findOverLookPointsWithDevlist();
        return overLookPointsWithDevlist;
    }

    @Override
    public List<realValueList1> getDataPackagesOfTimeArea(DateTime sBeginTime, DateTime eEndTime, Integer devIdpk) {
        //获取HBase中该设备的
        return HbaseUtil.GetListArrayByFilter(devIdpk + "",
                sBeginTime.toString("yyyyMMddHHmmss"), eEndTime.toString("yyyyMMddHHmmss"),
                ScheduleConstant.HBY_DEV_POWER_NODE_ARRAY, "20");
    }

    @Override
    public List<realValueList1> getDataPackagesMuchOfTimeArea(DateTime sBeginTime, DateTime eEndTime, Integer devIdpk) {
        //获取HBase中该设备的
        return HbaseUtil.GetListArrayByFilter(devIdpk + "",
                sBeginTime.toString("yyyyMMddHHmmss"), eEndTime.toString("yyyyMMddHHmmss"),
                ScheduleConstant.HBY_DEV_POWER_NODE_ARRAY, "500");
    }

    @Override
    public double getAvgPower(List<realValueList1> dataPackages, Integer devIdpk) {
        double avgVal = 0;
        int size = 0;
        String addtime = "1200-01-01";
        for (realValueList1 dataPackage : dataPackages) {
            size = dataPackage.getRowsSize();
            Iterator<realValue1> rowsIterator = dataPackage.getRowsIterator();
            while (rowsIterator.hasNext()) {
                realValue1 next = rowsIterator.next();
                addtime = next.getAddtime();
                avgVal += Double.parseDouble(next.getVal());
            }
        }
        //size = dataPackages.get(0).getRowsSize();
        //缓存设备的功率值和时间
        //this.cachDevMaxPower(devIdpk, avgVal, addtime);
        //计算平均值
        if (size > 0) {
            avgVal = BigDecimalUtils.calculate(avgVal).div(size).getBigDecimal().doubleValue();
            avgVal = Double.parseDouble(new DecimalFormat("#.00").format(avgVal));
        }
        return avgVal;
    }

    @Override
    public int countJudgeDevWorkStatus(Integer devSillVal, double avgValue, Integer devPower) {
        //停机---平均功率 < 启停功率
        if (BigDecimalUtils.is(avgValue).lt(devSillVal)) {
            return 3;
        } else if (BigDecimalUtils.is(avgValue).lt(BigDecimalUtils.calculate(devPower).multiply("0.3").getBigDecimal().doubleValue())) {
            //低负荷---平均功率 < 额定功率的30%
            return 2;
        } else if (BigDecimalUtils.is(avgValue).gteq(devSillVal)) {
            //运行---平均功率 >= 启停功率阈值
            return 1;
        } else {
            return 4;
        }
    }

    @Override
    public synchronized void updateOrInsertWorkStatus(DateTime beforEndTime, DevDto dev, int state) {
        int hourOfDay = beforEndTime.getHourOfDay();
        int minuteOfHour = beforEndTime.getMinuteOfHour();
        //判断更新哪一个时区的数据
        String filed = "h" + hourOfDay + "_" + this.timeArea(minuteOfHour);
        //查询当天数据的时间条件
        String beginOfDay = new DateTime(beforEndTime.getYear(), beforEndTime.getMonthOfYear(), beforEndTime.getDayOfMonth(),
                0, 0, 0).toString("yyyy-MM-dd HH:mm:ss");
        String endOfDay = new DateTime(beforEndTime.getYear(), beforEndTime.getMonthOfYear(), beforEndTime.getDayOfMonth(),
                23, 59, 59).toString("yyyy-MM-dd HH:mm:ss");

        HbyDevalTimeStatus item = this.scheduledMapper.findDeviceWorkStatusToday(dev.getDevIdpk(), beginOfDay, endOfDay);
        if (item == null || item.getId() == null) {
            item = new HbyDevalTimeStatus();
            //item.setAddtime(DateTime.now().toDate());
            item.setAddtime(dev.getNow());
            item.setUpdateTime(DateTime.now().toDate());
            item.setId(new SnowflakeConfig().nextId());
            BeanUtils.copyProperties(dev, item);
            String sql = String.format(
                    "INSERT INTO  hby_deval_time_status (id, unitId, devIdpk, devProTy, platformId, updateTime, addtime, %s ) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s') ",
                    filed, item.getId(), item.getUnitId(), item.getDevIdpk(), item.getDevProTy(), item.getPlatformId(),
                    new DateTime(item.getUpdateTime()).toString("yyyy-MM-dd HH:mm:ss"),
                    new DateTime(item.getAddtime()).toString("yyyy-MM-dd HH:mm:ss"),
                    state
            );
            this.scheduledMapper.insertDevWorkStatus(sql);
        } else {
            item.setUpdateTime(DateTime.now().toDate());
            Class<? extends HbyDevalTimeStatus> aClass = item.getClass();
            try {
                Field declaredField = aClass.getDeclaredField(filed);
                declaredField.setAccessible(true);
                declaredField.set(item, state);
                hbyDevalTimeStatusMapper.updateByPrimaryKeySelective(item);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                log.error("通过反射获取字段:" + filed + " 出现异常:", e);
                log.error(e.getMessage(), e);
                throw new RuntimeException();
            }

        }
        //修改设备的状态
        QueryWrapper<HbyOverLookDevJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookDevJoin::getDevIdpk, dev.getDevIdpk());
        List<HbyOverLookDevJoin> hbyOverlookDevJoins = this.hbyOverLookDevJoinService.list(queryWrapper);
        for (HbyOverLookDevJoin devJoin : hbyOverlookDevJoins) {
            devJoin.setDevWorkState(state);
        }
        this.hbyOverLookDevJoinService.saveOrUpdateBatch(hbyOverlookDevJoins);
    }

    @Override
    public synchronized void updateOrInsertUnitInfo(List<UnitBasicInfoDto> unitBasicInfoDtoList) {
        if (CollectionUtils.isEmpty(unitBasicInfoDtoList)) {
            return;
        }
        List<HbyProjectstatus> list = this.shuntByDealType(unitBasicInfoDtoList);
        this.hbyProjectstatusService.saveOrUpdateBatch(list);
    }

    @Override
    public List<HbyProjectErrorInfo> findHasBeenNormalErrInfo() {
        return this.scheduledMapper.findHasBeenNormalErrInfo();
    }

    @Override
    public void updateHbyErrorDealStatus(List<HbyProjectErrorInfo> errorInfos) {
        String sql = "UPDATE hby_project_errorinfo SET deal_status = ? WHERE id = ?";
        List<Object[]> objects = Lists.newArrayListWithExpectedSize(errorInfos.size());
        for (HbyProjectErrorInfo errorInfo : errorInfos) {
            objects.add(new Object[]{errorInfo.getDealStatus(), errorInfo.getId()});
        }
        jdbcTemplate.batchUpdate(sql, objects);
    }

    @Override
    public void executeCatchLookPointDevEleErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto devDto) throws Exception {
        Integer devProTy = devDto.getDevProTy();
        Integer devEleSillVal = null;
        Integer devEleLiveTime = null;
        if (devProTy.equals(1)) {
            //电量阈值
            devEleSillVal = lookPoint.getPollDevEleSillVal();
            //电量门限时间
            devEleLiveTime = lookPoint.getPollDevEleLiveTime();
        } else {
            devEleSillVal = lookPoint.getConDevEleSillVal();
            devEleLiveTime = lookPoint.getConDevEleLiveTime();
        }
        if (devEleSillVal == null || devEleLiveTime == null) {
            log.debug("监测点的电量门限或电量阈值数据不全" + lookPoint.toString());
            return;
        }
        //开始判断
        //获取该设备的实时电量
        DateTime now = new DateTime(devDto.getNow());
        //门限时间的起点
        DateTime liveTimeBegin = now.minus(devEleLiveTime * 60 * 1000);
        //临时开始时间,用于得到门限时间起点时的电量
        DateTime start = liveTimeBegin.minus(devEleLiveTime * 60 * 1000);
        List<realValueByNode1> eleDataStartList = HbaseUtil.GetMaxSingleArrayByFilter(devDto.getDevIdpk().toString(), start.toString("yyyyMMddHHmmss"),
                liveTimeBegin.toString("yyyyMMddHHmmss"), ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY);
        List<realValueByNode1> eleDataEndList = HbaseUtil.GetMaxSingleArrayByFilter(devDto.getDevIdpk().toString(), liveTimeBegin.toString("yyyyMMddHHmmss"),
                now.toString("yyyyMMddHHmmss"), ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY);


        double eleStart = eleDataStartList.stream().mapToDouble(e -> Double.parseDouble(e.getVal())).summaryStatistics().getSum();
        double eleEnd = eleDataEndList.stream().mapToDouble(e -> Double.parseDouble(e.getVal())).summaryStatistics().getSum();
        double minu = Double.parseDouble(new DecimalFormat("#.00").format(eleEnd - eleStart));
        //TODO 为了测试效果eleEnd = 100;
        HbyReduceEmmissionPlan plan = this.findReduceEmmPlanByUnitId(devDto.getUnitId());
        //TODO 判断是否属于正常生产(调用停限产异常的判断方法)
        //当前时间不在方案限制的时间内则为正常生产
        boolean flag = ScheduleNeedUtil.isPlanInTimeArea(plan, devDto.getNow());
        StringBuffer sb = new StringBuffer();
        if (devProTy.equals(1)) {
            //治污设备,如果用电量超了电量阈值为异常
            if (minu > devEleSillVal) {
                //插入一条产污设备电量异常
                sb.append("安装在").append("[" + devDto.getInstallLocation() + "]")
                        .append("的生产设备")
                        .append("[" + devDto.getDevSignature() + "] <br>")
                        .append("电量阈值").append("[" + devEleSillVal + "]kWh <br>")
                        .append("电量门限时间为").append("[" + devEleLiveTime + "]分钟 <br>")
                        .append("设备从 ").append(liveTimeBegin.toString("yyyy-MM-dd HH:mm:ss"))
                        .append(" 到").append(now.toString("yyyy-MM-dd HH:mm:ss"));
                if (!flag) {
                    sb.append(" 属于正常生产状态 <br>");
                } else {
                    sb.append(" 属于违规生产状态 <br>");
                }
                sb.append(" 在这段时间里面用电量为").append("[" + minu + "]kWh <br>")
                        .append(" 已经超过了产污设备门限电量阈值,属于用电量异常");
                this.insertHbyDeviceErrorData(devDto, 5, sb.toString());
            }
        } else {
            if (minu < devEleSillVal) {
                //插入一条产污设备电量异常
                sb.append("安装在").append("[" + devDto.getInstallLocation() + "]")
                        .append("的治污设备")
                        .append("[" + devDto.getDevSignature() + "] <br>")
                        .append("电量阈值").append("[" + devEleSillVal + "]kWh <br>")
                        .append("电量门限时间为").append("[" + devEleLiveTime + "]分钟 <br>")
                        .append("设备从 ").append(liveTimeBegin.toString("yyyy-MM-dd HH:mm:ss"))
                        .append(" 到 ").append(now.toString("yyyy-MM-dd HH:mm:ss"));
                if (!flag) {
                    sb.append(" 属于正常生产状态 <br>");
                } else {
                    sb.append(" 属于违规生产状态 <br>");
                }
                sb.append(" 在这段时间里面用电量为").append("[" + minu + "]kWh <br>")
                        .append(" 没有达到治污设备门限电量阈值,属于用电量异常");
                this.insertHbyDeviceErrorData(devDto, 5, sb.toString());
            }
        }

    }


    /**
     * @description: 修改设备的最大功率到Redis
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/6 11:20
     */
    private void saveUnitMaxPower(Integer unitId, double power, String addtime) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        DateTime newTime = DateTime.parse(addtime, dateTimeFormatter);
        Boolean update = redisTemplate.execute((RedisConnection redisConnection) -> {
            byte[] bytes = redisConnection.hGet("DeviceMaxPower".getBytes(), unitId.toString().getBytes());
            HbyErrorDto.PowerMaxDto powerMaxDto = null;
            if (ArrayUtil.isNotEmpty(bytes)) {
                String json = new String(bytes);
                powerMaxDto = JSON.parseObject(json, HbyErrorDto.PowerMaxDto.class);
                DateTime oldTime = new DateTime(powerMaxDto.getAddtime());
                //数据是同一天的，并且新的电量大于原记录值
                Double maxPower = powerMaxDto.getMaxPower() == null ? 0 : powerMaxDto.getMaxPower();
                if ((newTime.getDayOfYear() == oldTime.getDayOfYear()) && maxPower < power) {
                    powerMaxDto.setMaxPower(power);
                    powerMaxDto.setAddtime(newTime.toDate());
                } else if (newTime.getDayOfYear() - oldTime.getDayOfYear() >= 1) {
                    //如果新数据是后一天或多天的
                    powerMaxDto.setMaxPower(power);
                    powerMaxDto.setAddtime(newTime.toDate());
                }
            } else {
                powerMaxDto = new HbyErrorDto.PowerMaxDto();
                powerMaxDto.setAddtime(newTime.toDate());
                powerMaxDto.setMaxPower(power);
            }
            return redisConnection.hSet("DeviceMaxPower".getBytes(), unitId.toString().getBytes(), JSON.toJSONBytes(powerMaxDto));
        });
        if (null == update || !update) {
            log.debug("设备最大功率记录失败,单位ID{},功率{},数据时间{},当前时间{}", unitId, power, addtime, DateTime.now());
        }


    }

    /**
     * @description: 修改设备的最大用电量到Redis
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/6 11:00
     */
    private void saveUnitMaxEle(Integer unitId, double ele, String addtime) {
        if (ele < 0) {
            return;
        }
        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        DateTime newTime = DateTime.parse(addtime, dateTimeFormatter);
        Boolean update = redisTemplate.execute((RedisConnection redisConnection) -> {
            byte[] bytes = redisConnection.hGet("DeviceMaxEle".getBytes(), unitId.toString().getBytes());
            HbyErrorDto.EleMaxDto eleMaxDto = null;
            if (ArrayUtil.isNotEmpty(bytes)) {
                String json = new String(bytes);
                eleMaxDto = JSON.parseObject(json, HbyErrorDto.EleMaxDto.class);
                DateTime oldTime = new DateTime(eleMaxDto.getAddtime());
                //数据是同一天的，并且新的电量大于原记录值
                if ((newTime.getDayOfYear() == oldTime.getDayOfYear()) && eleMaxDto.getMaxEle() < ele) {
                    eleMaxDto.setMaxEle(ele);
                    eleMaxDto.setAddtime(newTime.toDate());
                } else if (newTime.getDayOfYear() - oldTime.getDayOfYear() > 1) {
                    //如果新数据是后一天或多天的
                    eleMaxDto.setMaxEle(ele);
                    eleMaxDto.setAddtime(newTime.toDate());
                }
            } else {
                eleMaxDto = new HbyErrorDto.EleMaxDto();
                eleMaxDto.setAddtime(newTime.toDate());
                eleMaxDto.setMaxEle(ele);
            }
            return redisConnection.hSet("DeviceMaxEle".getBytes(), unitId.toString().getBytes(), JSON.toJSONBytes(eleMaxDto));
        });
        if (null == update || !update) {
            log.debug("设备最大电量记录失败, 单位ID{},电量{},数据时间{},当前时间{}", unitId, ele, addtime, DateTime.now());
        }
    }

    @Override
    public void executeCatchLookPointDevPowerErr(DateTime[] frontTimeArea, OverLookPointWithDevlist lookPoint, DevDto devDto, Integer devProTy, boolean isConRun) {
        //额定功率
        Integer devPowerVal = null;
        //功率阈值
        Integer devPowerSilVal = null;
        //功率门限
        Integer devPowerLiveTime = null;
        if (devProTy.equals(1)) {
            devPowerSilVal = lookPoint.getPollDevPowerSillVal();
            //功率门限时间
            devPowerLiveTime = lookPoint.getPollDevPowerLiveTime();
            devPowerVal = lookPoint.getPollDevPower();
        } else {
            devPowerSilVal = lookPoint.getConDevPowerSillVal();
            devPowerLiveTime = lookPoint.getConDevEleLiveTime();
            devPowerVal = lookPoint.getConDevPower();
        }
        if (devPowerVal == null || devPowerLiveTime == null) {
            log.debug("监测点的电量门限或电量阈值数据不全" + lookPoint.toString());
            return;
        }

        //开始判断
        //获取该设备的实时功率
        DateTime now = new DateTime(devDto.getNow());
        //门限时间的起点
        DateTime liveTimeBegin = now.minus(devPowerLiveTime * 60 * 1000);
        //获取此段时间内的所有功率实时数据
        List<realValueList1> dataPkgs = this.getDataPackagesOfTimeArea(liveTimeBegin, now, devDto.getDevIdpk());
        //获取平均功率
        double avgPower = this.getAvgPower(dataPkgs, devDto.getDevIdpk());

        //满足治污设备停机异常的  获取设备的状态 1:运行, 2:低负荷, 3:停机, 4:失联, 0:未知状态
        //TODO 2020-02-25 修改
        //int devState = ScheduleNeedUtil.getDevState(dataPkgs, devPowerSilVal, devPowerVal);
        int devState = devDto.getDevWorkState();
        if (devState == 0) {
            log.info("24小时设备工况判断条件异常: 设备:{}--额定功率:{}--启动功率阈值:{}--平均功率:{},结束运行",
                    devDto.getDevIdpk(), devPowerVal, devPowerSilVal, this.getAvgPower(dataPkgs, devDto.getDevIdpk()));
            return;
        }
        //设备的状态 1:运行, 2:低负荷, 3:停机, 4:失联, 0:未知状态
        //如果为治污设备且所有治污设备停机
        if (devProTy.equals(2) && !isConRun) {
            //执行治污设备停机异常的处理
            this.saveOrUpdateConDevStopErr(devDto, lookPoint, liveTimeBegin, 7);
        }
        //如果为产污设备
        if (devProTy.equals(1)) {
            if (avgPower > devPowerVal) {
                //功率异常
                this.saveOrUpdatePowerErr(devDto, lookPoint, liveTimeBegin, avgPower, 6);
            }
        } else {
            if (avgPower < devPowerVal) {
                //功率异常
                this.saveOrUpdatePowerErr(devDto, lookPoint, liveTimeBegin, avgPower, 6);
            }
        }


    }

    @Override
    public HbyReduceEmmissionPlan findReduceEmmPlanByUnitId(Integer unitId) {
        return this.scheduledMapper.findReduceEmmPlanByUnitId(unitId);
    }

    @Override
    public void saveOrUpdateStopProPlanErr(DevDto dev, HbyReduceEmmissionPlan plan, HbyErrorDto.StopProErrChargeDto stopProErrChargeDto) {
        //查询是否有当前的停产异常
        StringBuffer sb = new StringBuffer();
        sb.append("安装在").append("[" + dev.getInstallLocation() + "]")
                .append(" 的产污设备")
                .append(" [" + dev.getDevSignature() + "]")
                .append(" 违反了").append("[" + plan.getPlanName() + "]")
                .append(" 停产计划").append("设备在").append(stopProErrChargeDto.getStartTime().toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 到 ").append(stopProErrChargeDto.getEndTime().toString("yyyy-MM-dd HH:mm:ss"))
                .append("的这段时间段内处于生产状态,触发了停产异常");
        this.insertHbyDeviceErrorData(dev, 3, sb.toString());
    }

    @Override
    @Cacheable(cacheNames = SpringCacheConstants.REDIS_CACHE_1MIN_NAME, keyGenerator = DEFAULT_CACHE_KEY_GENERATOR, unless = "#result == null")
    public HbyReduceplanJoinProject findReducePlanJoinUnitByUnitId(Integer unitId) {
        QueryWrapper<HbyReduceplanJoinProject> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId, unitId);
        return this.hbyReduceplanJoinProjectMapper.selectOne(queryWrapper);
    }

    @Override
    public void saveOrUpdateLimitProPlanErr(DevDto dev, HbyReduceEmmissionPlan plan, double hourSum) {
        //查询是否有当前的停产异常
        StringBuffer sb = new StringBuffer();
        sb.append("安装在").append("[" + dev.getInstallLocation() + "]")
                .append(" 的产污设备")
                .append(" [" + dev.getDevSignature() + "] <br>")
                .append(" 违反了").append("[" + plan.getPlanName() + "]")
                .append(" 限产计划 <br>").append("截至到").append(DateTime.now().toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 已生产了").append("[" + hourSum + "]").append("小时,")
                .append(" 触发了限产异常");
        this.insertHbyDeviceErrorData(dev, 4, sb.toString());
    }

    @Override
    public HashMap<String, Object> getPollAndConDevEleQ(Integer unitId, Date now) {
        String addtime = new DateTime(now).toString("yyyy-MM-dd");
        List<HashMap<String, Object>> list = this.scheduledMapper.getPollAndConDevEleQ(unitId, addtime);
        Double rootEle = 0D;
        Double pollEle = 0D;
        Double conEle = 0D;
        for (HashMap<String, Object> map : list) {
            int devProTy = (int) map.get("devProTy");
            Double dayTotalQ = (Double) map.get("dayTotalQ");
            if (devProTy == 0) {
                rootEle += dayTotalQ;
            }
            if (devProTy == 1) {
                pollEle += dayTotalQ;
            }
            if (devProTy == 2) {
                conEle += dayTotalQ;
            }
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("pollEle", pollEle);
        map.put("conEle", conEle);
        map.put("rootEle", rootEle);
        return map;
    }

    @Override
    public void executeCachRootPointDevEleAndPower(DateTime[] frontTimeArea, DevDto devDto) throws Exception {
        DateTime dateTime1 = frontTimeArea[0];
        //将dateTime1置为 当前时间的整点  当前时间 19:09 则dateTime1为：18:00， 当前时间：19:45 则dateTime1为：19:00
        dateTime1 = dateTime1.withTime(0, 0, 0, 0);
        //dateTime2为当前时间的上一个区间的结束值 --> 改为当前时间，防止当前时间上传的数据值比上一个时间区间的值大，造成页面显示的不一致问题
        DateTime dateTime2 = DateTime.now();
        //获取一天前的时间节点
        //DateTime dateTime0 = dateTime1.minus(24 * 60 * 60 * 1000);

        //获取两个用电量节点 -->用电量
        // TODO 暂时不缓存 2020-03-16 注释掉的
       /* List<realValueByNode1> eleDataStartList = HbaseUtil.GetMaxSingleArrayByFilter(devDto.getDevIdpk().toString(),
                dateTime0.toString("yyyyMMddHHmmss"),
                dateTime1.toString("yyyyMMddHHmmss"), ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY);
        List<realValueByNode1> eleDataEndList = HbaseUtil.GetMaxSingleArrayByFilter(devDto.getDevIdpk().toString(),
                dateTime1.toString("yyyyMMddHHmmss"),
                dateTime2.toString("yyyyMMddHHmmss"), ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY);
        double eleStart = eleDataStartList.stream().mapToDouble(e -> Double.parseDouble(e.getVal())).summaryStatistics().getSum();
        double eleEnd = eleDataEndList.stream().mapToDouble(e -> Double.parseDouble(e.getVal())).summaryStatistics().getSum();
        //缓存用电量
        String addtime = eleDataEndList.get(0).getAddtime();
        if (!addtime.startsWith("1200-01-01")) {
            this.saveUnitMaxEle(devDto.getUnitId(), (eleEnd - eleStart), addtime);
        }*/
        //获取功率数据
        List<realValueList1> powerList = this.getDataPackagesMuchOfTimeArea(dateTime1, dateTime2, devDto.getDevIdpk());

        //缓存功率
        HbyErrorDto.PowerMaxDto maxPowerDto = this.getMaxPower(powerList);
        if (maxPowerDto.getMaxPower() >= 0) {
            //转为kw
            //double div1000 = ScheduleNeedUtil.valueDiv1000(maxPowerDto.getMaxPower());
            this.saveUnitMaxPower(devDto.getUnitId(), maxPowerDto.getMaxPower(), new DateTime(maxPowerDto.getAddtime()).toString("yyyy-MM-dd HH:mm:ss"));
        }

    }

    @Override
    public List<HashMap<String, Object>> findUnitCurrentMonthEleUse(int year, int monthOfYear) {
        return this.scheduledMapper.findUnitCurrentMonthEleUse(year, monthOfYear);
    }

    @Override
    public List<HashMap<String, Object>> findErrSimpInfoList(Integer unitId) {
        return this.scheduledMapper.findErrSimpInfoListToPush(unitId);
    }

    @Override
    public void updateErrInfoIsPush(List<Long> errIds) {
        String sql = "update hby_project_errorinfo set is_push = ? , push_time = ? where id = ? ";
        List<Object[]> objects = Lists.newArrayListWithExpectedSize(errIds.size());
        for (Long errId : errIds) {
            if (errId != null) {
                objects.add(new Object[]{1, DateTime.now().toDate(), errId});
            }
        }
        this.jdbcTemplate.batchUpdate(sql, objects);
    }

    @Override
    public HbyErrorDto.EleMaxDto findMaxEleUseOfUnitOneDay(Integer unitId) {
        RootDevice24HourEleValue electricuse = this.scheduledMapper.findDeveleUse(unitId);
        double max = 0;
        Date time = DateTime.now().toDate();
        HbyErrorDto.EleMaxDto exdto = new HbyErrorDto.EleMaxDto();
        if (electricuse == null) {
            exdto.setMaxEle(max);
            exdto.setAddtime(new Date());
            return exdto;
        }
        Class<? extends RootDevice24HourEleValue> aClass = electricuse.getClass();
        Field[] declaredFields = aClass.getDeclaredFields();

        try {
            for (Field field : declaredFields) {
                field.setAccessible(true);
                if (field.getName().startsWith("h")) {
                    Object o = field.get(electricuse);
                    if (o != null && (double) o >  max) {
                        max = (double) o;
                        Integer hour = Integer.valueOf(field.getName().substring(1));
                        DateTime now = DateTime.now().withTime(hour - 1, 0, 0, 0);
                        time = now.toDate();
                    }
                }
            }
        } catch (IllegalAccessException e) {
            log.error("====================判断设备最大用电量出错了=============================");
            log.error(e.getMessage(), e);
            log.error("=======================================================================");
        }

        DateTime beginTime = new DateTime(time);
        DateTime endTime;
        if (beginTime.getHourOfDay() == 23) {
            endTime = beginTime.withTime(beginTime.getHourOfDay(), 59, 59, 0);
        } else {
            endTime = beginTime.withTime(beginTime.getHourOfDay() + 1, 0, 0, 0);
        }
        List<realValueList1> realValueList1s = HbaseUtil.GetListArrayByFilter(electricuse.getDevIdpk().toString(), beginTime.toString("yyyyMMddHHmmss"),
                endTime.toString("yyyyMMddHHmmss"), ScheduleConstant.HBY_DEV_ELEMENT_NODE_ARRAY, "10");

        Date maxEleTime = ScheduleNeedUtil.getMaxEleTime(0, realValueList1s);
        exdto.setMaxEle(max);
        if (maxEleTime != null) {
            exdto.setAddtime(maxEleTime);
        } else {
            exdto.setAddtime(time);
        }
        return exdto;
    }

    /**
     * @description: 计算最大的功率值
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/6 14:10
     */
    @Override
    public HbyErrorDto.PowerMaxDto getMaxPower(List<realValueList1> powerList) {
        List<realValueList1> paList = powerList.stream().filter(r -> "PA".equalsIgnoreCase(r.getKeyname())).collect(Collectors.toList());
        List<realValueList1> pbList = powerList.stream().filter(r -> "PB".equalsIgnoreCase(r.getKeyname())).collect(Collectors.toList());
        List<realValueList1> pcList = powerList.stream().filter(r -> "PC".equalsIgnoreCase(r.getKeyname())).collect(Collectors.toList());
        double maxPower = 0;
        String addtime = "1200-01-01";
        if (!paList.isEmpty()) {
            List<realValue1> rowsA = paList.get(0).getRows();
            List<realValue1> rowsB = pbList.get(0).getRows();
            List<realValue1> rowsC = pcList.get(0).getRows();
            if (rowsA != null && rowsA.size() > 0) {
                for (int i = 0; i < rowsA.size(); i++) {
                    realValue1 ra = rowsA.get(i);
                    realValue1 rb = rowsB.get(i);
                    realValue1 rc = rowsC.get(i);
                    double v = BigDecimalUtils.calculate(ra.getVal()).add(rb.getVal()).add(rc.getVal()).getBigDecimal().doubleValue();
                    if (v >= maxPower) {
                        addtime = ra.getAddtime();
                        maxPower = v;
                    }
                }
            }
        }
        HbyErrorDto.PowerMaxDto powerMaxDto = new HbyErrorDto.PowerMaxDto();

        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        if (addtime.startsWith("1200-01-01")) {
            addtime = DateTime.now().toString(dateTimeFormatter);
        }
        DateTime parse = DateTime.parse(addtime, dateTimeFormatter);
        powerMaxDto.setMaxPower(maxPower);
        powerMaxDto.setAddtime(parse.toDate());
        return powerMaxDto;
    }


    /**
     * 治污设备停机异常的处理
     *
     * @param devDto
     * @param lookPoint
     * @param errType
     */
    private void saveOrUpdateConDevStopErr(DevDto devDto, OverLookPointWithDevlist lookPoint, DateTime liveTimeBegin, int errType) {
        StringBuffer sb = new StringBuffer();
        //除以1000 保留两位小数
        double devPower = ScheduleNeedUtil.valueDiv1000(lookPoint.getConDevPower());
        sb.append("安装在").append("[" + devDto.getInstallLocation() + "]")
                .append(" 的治污设备")
                .append("[" + devDto.getDevSignature() + "] <br>")
                .append(" 额定功率").append("[" + devPower + "]KW <br>")
                .append(" 功率门限时间为").append("[" + lookPoint.getConDevPowerLiveTime() + "]分钟 <br>")
                .append(" 设备从 ").append(liveTimeBegin.toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 到").append(new DateTime(devDto.getNow()).toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 产生了停机异常");
        this.insertHbyDeviceErrorData(devDto, errType, sb.toString());
    }

    private void saveOrUpdatePowerErr(DevDto devDto, OverLookPointWithDevlist lookPoint, DateTime liveTimeBegin, double avgPower, int errType) {
        StringBuffer sb = new StringBuffer();
        //除以1000 保留两位小数
        double devPower = ScheduleNeedUtil.valueDiv1000(lookPoint.getConDevPower());
        sb.append("安装在").append("[" + devDto.getInstallLocation() + "]");
        if (devDto.getDevProTy().equals(1)) {
            sb.append(" 的产污设备");
        } else {
            sb.append(" 的治污设备");
        }
        sb.append("[" + devDto.getDevSignature() + "] <br>")
                .append(" 额定功率").append("[" + devPower + "]KW <br>")
                .append(" 功率门限时间为").append("[" + lookPoint.getConDevPowerLiveTime() + "]分钟 <br>")
                .append(" 设备从 ").append(liveTimeBegin.toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 到").append(new DateTime(devDto.getNow()).toString("yyyy-MM-dd HH:mm:ss"))
                .append(" 的平均功率为").append("[" + (ScheduleNeedUtil.valueDiv1000(avgPower)) + "]KW")
                .append(" 产生了功率异常");
        this.insertHbyDeviceErrorData(devDto, errType, sb.toString());
    }

    /**
     * 插入设备异常数据
     *
     * @param devDto
     * @param errType
     * @param errDesc
     */
    private synchronized void insertHbyDeviceErrorData(DevDto devDto, int errType, String errDesc) {
        //先根据条件查询是否有该异常,如果有,则更新异常时间
        HbyProjectErrorInfo projectErrorInfo = this.scheduledMapper.findSoftwareErrBy(devDto, errType);
        boolean saveOrUpdate = false;
        if (projectErrorInfo == null) {
            saveOrUpdate = true;
            projectErrorInfo = new HbyProjectErrorInfo();
            UnitBasicInfoDto unitBasicInfo = this.commonSimpleBeanInfoService.findUnitBasicInfoByID(devDto.getUnitId());
            BeanUtils.copyProperties(unitBasicInfo, projectErrorInfo);
            BeanUtils.copyProperties(devDto, projectErrorInfo);
        }

        projectErrorInfo.setType(errType);
        projectErrorInfo.setPollOrCon(devDto.getDevProTy());
        projectErrorInfo.setErrorTime(devDto.getNow());
        projectErrorInfo.setDealStatus(0);
        projectErrorInfo.setErrorDesc(errDesc);
        if (errType <= 2 && errType >= 0) {
            projectErrorInfo.setCheckResult(2);
        } else {
            projectErrorInfo.setCheckResult(1);
        }

        //获取当前单位关联的减产减排方案
        QueryWrapper<HbyReduceplanJoinProject> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId, devDto.getUnitId());
        HbyReduceplanJoinProject joinProject = this.hbyReduceplanJoinProjectMapper.selectOne(queryWrapper);
        if (joinProject != null) {
            projectErrorInfo.setPlanId(joinProject.getPlanId());
            joinProject.setIsViolat(1);
            joinProject.setIsMark(1);
            joinProject.setErrorId(projectErrorInfo.getId());
        }

        switch (errType) {
            case 3:
                projectErrorInfo.setErrorEventType(190);
                break;
            case 4:
                projectErrorInfo.setErrorEventType(191);
                break;
            case 5:
                projectErrorInfo.setErrorEventType(192);
                break;
            case 6:
                projectErrorInfo.setErrorEventType(193);
                break;
            case 7:
                projectErrorInfo.setErrorEventType(194);
                break;
            default:
                break;
        }

        //boolean save = this.hbyProjectErrorInfoService.saveOrUpdate(projectErrorInfo);
        // 为了返回自增主键改变后的方法
        boolean save = false;
        if (saveOrUpdate) {
            int inst = this.scheduledMapper.insertProjectErrorInfo(projectErrorInfo);
            if (inst > 0) {
                save = true;
                if (joinProject != null) {
                    projectErrorInfo.setPlanId(joinProject.getPlanId());
                    joinProject.setIsMark(1);
                    joinProject.setIsViolat(1);
                    joinProject.setErrorId(projectErrorInfo.getId());
                }
            }
        } else {
            save = this.hbyProjectErrorInfoService.updateById(projectErrorInfo);
        }
        if (save) {
            log.info("设备软件异常判断入库成功:" + projectErrorInfo.toString());
        } else {
            log.info("设备软件异常判断入库失败:" + projectErrorInfo.toString());
        }
        //修改方案和单位的绑定数据
        this.hbyReduceplanJoinProjectService.saveOrUpdate(joinProject);
    }


    /**
     * 处理所有建立监测点的单位的实时数据信息,并返回需要插入和需要更新的数据,insert,update
     *
     * @param unitBasicInfoDtoList
     * @return
     */
    private synchronized List<HbyProjectstatus> shuntByDealType(List<UnitBasicInfoDto> unitBasicInfoDtoList) {
        List<HbyProjectstatus> list = new ArrayList<>();
        for (UnitBasicInfoDto unitBasicInfoDto : unitBasicInfoDtoList) {
            Integer unitId = unitBasicInfoDto.getUnitId();
            //获取单位下监测点关联的设备基本信息,产，治，总表设备
            List<DevDto> devDtoList = this.commonSimpleBeanInfoService.findDevicesOfOverLookPointByUnitID(unitId);
            //获取单位的实时数据信息
            HbyProjectstatus projectstatus = this.hbyProjectstatusMapper.selectByPrimaryKey(unitId);
            //单位数据是否存在的标志,默认true, 存在
            //boolean isExist = true;
            if (projectstatus == null) {
                projectstatus = new HbyProjectstatus();
                //设置基础信息
                projectstatus.setAddtime(DateTime.now().toDate());
                BeanUtils.copyProperties(unitBasicInfoDto, projectstatus);
                //isExist = false;
            } else {
                BeanUtils.copyProperties(unitBasicInfoDto, projectstatus);
                projectstatus.setAddtime(DateTime.now().toDate());
            }
            this.dealWithProjectStatusData(unitId, projectstatus, devDtoList);
            list.add(projectstatus);
        }
        return list;
    }

    /**
     * 根据设备的数据,处理单位实时状态的相关值(统计单位实时状态表所需要的数据)
     *
     * @param unitId
     * @param projectstatus
     * @param devDtoList
     */
    private void dealWithProjectStatusData(Integer unitId, HbyProjectstatus projectstatus, List<DevDto> devDtoList) {
        //总表监测点设备数 和 没有指定设备类型的设备数之和
        int adminDevNum = (int) devDtoList.stream().filter(devDto -> devDto.getDevProTy() <= 0).count();
        //设置统计信息
        projectstatus.setAllDeviceNum(devDtoList.size() - adminDevNum);
        //产污设备数
        int pollDevNum = (int) devDtoList.stream().filter(devDto -> devDto.getDevProTy().equals(1)).count();
        //治污设备数
        int conDevNum = (int) devDtoList.stream().filter(devDto -> devDto.getDevProTy().equals(2)).count();

        //设备状态 1:运行 2：低负荷 3：停机 4：失联
        int runDevSize = (int) devDtoList.stream().filter(devDto -> devDto.getDevWorkState().equals(1)).count();
        int lowPowerDevSize = (int) devDtoList.stream().filter(devDto -> devDto.getDevWorkState().equals(2)).count();
        int stopDevSize = (int) devDtoList.stream().filter(devDto -> devDto.getDevWorkState().equals(3)).count();
        int lostDevSize = (int) devDtoList.stream().filter(devDto -> devDto.getDevWorkState().equals(4)).count();
        projectstatus.setStopDevNum(stopDevSize);
        projectstatus.setLostDevNum(lostDevSize);
        //低负荷和运行的都算作生产状态设备
        projectstatus.setRunDevNum(runDevSize + lowPowerDevSize);
        projectstatus.setPollDevNum(pollDevNum);
        projectstatus.setConDevNum(conDevNum);
        //运行的产污设备数
        long runPollDevNum = (int) devDtoList.stream().filter(devDto -> devDto.getDevProTy().equals(1)
                && (devDto.getDevWorkState().equals(1) || devDto.getDevWorkState().equals(2))).count();
        long losePollDevNum = (int) devDtoList.stream().filter(devDto -> devDto.getDevWorkState().equals(4)).count();

        //单位状态 1:生产,  2:停产, 3:失联
        if (runPollDevNum > 0) {
            projectstatus.setProducState(1);
        } else if (losePollDevNum >= (devDtoList.size() - adminDevNum)) {
            //如果所有设备失联了,则单位为失联状态
            projectstatus.setProducState(3);
        } else {
            projectstatus.setProducState(2);
        }

        //判断单位是否有异常
        //0:未处理,1:已处理无需申报(除产污设备的停限产异常外), 2: 已处理待申报,3:已申报待审核,4:审核通过, 5:审核失败待重申报
        HbyProjectErrorInfoExample example = new HbyProjectErrorInfoExample();
        HbyProjectErrorInfoExample.Criteria criteria = example.createCriteria();
        criteria.andUnitIdEqualTo(unitId).andDealStatusIn(Arrays.asList(0, 5));
        //example.or().andDealStatusEqualTo(0).andDealStatusEqualTo(5);
        List<HbyProjectErrorInfo> errorInfos = this.hbyProjectErrorInfoMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(errorInfos)) {
            projectstatus.setIsErrState(0);
        } else {
            projectstatus.setIsErrState(1);
        }

    }

    /**
     * 从Redis中获取单位关联的环保设备信息
     *
     * @param unitId: 单位ID
     * @return
     */
    private List<DevDto> getDevicesOfUnit(Integer unitId) {
        Object o = this.hashOperations.get(ScheduleConstant.HBY_SCHEDULE_PREFIX + ScheduleConstant.DEVICE_OF_OVERLOOK_POINT, unitId.toString());
        return o == null ? null : (List<DevDto>) o;
    }

    /**
     * 判断时间区间的方法
     *
     * @param minuteOfHour:当前时间所在小时的分钟值
     * @author haosw
     */
    private String timeArea(int minuteOfHour) {
        if (minuteOfHour >= ScheduleConstant.TIME_AREA_0 && minuteOfHour < ScheduleConstant.TIME_AREA_20) {
            return "1";
        } else if (minuteOfHour >= ScheduleConstant.TIME_AREA_20 && minuteOfHour < ScheduleConstant.TIME_AREA_40) {
            return "2";
        } else {
            return "3";
        }
    }


}