package com.leniao.huanbao.utils;

/**
 * @author liudongshuai
 * @date 2019/12/21 10:36
 * @update
 * @description
 */
public class PageConstant {
    /**
     * 设备状态列表每页显示行数
     */
    public static final Integer DEVSTATUSLIST = 10;

    /**
     * 基础数据管理，监测点管理，每页显示行数
     */
    public static final Integer BASELOOKPOINTADMIN = 10;

    /**
     * 默认实时数据查询开始时间
     */
    public static final String BEGINDATETIME = "20190701000000";

    /**
     * 设备日数据默认数
     */
    public static final String ROWS = "200";

    /**
     * 企业电力明细实时数据对应节点字符串
     */
    public static final String NODESTR = "Va-Vb-Vc-Ia-Ib-Ic-PA-PB-PC-RPA-RPB-RPC-QA-QB-QC-DA-DB-DC";

    /**
     * 单位实时数据 开始时间
     */
    public static  final  String BEGINTIME = "20200101000000";
}
