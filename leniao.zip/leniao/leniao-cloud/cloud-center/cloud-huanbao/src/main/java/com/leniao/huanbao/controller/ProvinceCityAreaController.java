package com.leniao.huanbao.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.entity.Areaarea;
import com.leniao.huanbao.entity.Areacity;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.pojo.pagetopselecteneity.*;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.APIConstant;
import com.leniao.huanbao.utils.DevUtils;
import com.leniao.huanbao.utils.EntranceConstant;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import com.leniao.mapper.TblndeviceinfoMapper;
import com.leniao.model.devlist.DevStatusListInfo;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author liudongshuai
 * @date 2019/12/19 10:10
 */

@RestController
@RequestMapping(EntranceConstant.REGION)
public class ProvinceCityAreaController extends BaseController {

    /**
     * 省信息
     */
    @Resource
    private AreaprovinceService areaprovinceService;
    /**
     * 市信息
     */
    @Resource
    private AreacityService areacityService;
    /**
     * 县信息
     */
    @Resource
    private AreaareaService areaareaService;
    /**
     * 单位信息表
     * */
    @Resource
    private TblnprojectinfoService tblnprojectinfoService;
    /**
     * 监测点信息表
     * */
    @Resource
    private HbyOverLookpointService hbyOverlookpointService;
    /**
     * 设备信息表
     * */
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    @Resource
    private TblndeviceinfoMapper tblndeviceinfoMapper;
    /**
     * 设备监测点关联表
     */
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    /**
     * 账号用户处理
     */
    @Resource
    private PermissionService permissionService;
    /**
     * 账号树形关系
     */
    @Resource
    private TreeMenuService treeMenuService;
    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;
    /**
     * 单位环保局设备数量表
     */
    private HbyProjectstatusService hbyProjectstatusService;

    /**
     * 环保局表
     */
    @Resource
    private HbyAgencyService hbyAgencyService;

    @RequestMapping(value = APIConstant.PROVINCE,method = RequestMethod.POST)
    public Object sendProvince(){
        return renderResult(areaprovinceService.findAllProvince());
    }

    @RequestMapping(value = APIConstant.PROVINCEUNIT,method = RequestMethod.POST)
    public Object sendProvinceUnit(@RequestParam("provinceId") String provinceId){
        List<Tblnprojectinfo> tblnprojectinfoList = tblnprojectinfoService.findProvinceUnit(provinceId);
        List<UnitSelectInfo> unitSelectInfoList = new ArrayList<>();
        if (tblnprojectinfoList.size()>0) {
            for (Tblnprojectinfo unitInfo: tblnprojectinfoList ) {
                UnitSelectInfo unitSelectInfo = new UnitSelectInfo();
                unitSelectInfo.setUnitId(unitInfo.getProjid());
                unitSelectInfo.setUnitName(unitInfo.getProjname());
                unitSelectInfoList.add(unitSelectInfo);

            }
        }

        return  renderResult(unitSelectInfoList);
    }

    @RequestMapping(value = APIConstant.CITY,method = RequestMethod.POST)
    public Object sendCity(@RequestParam("provinceId") String provinceId){
        List<SendCityInfo> sendCityInfoList = new LinkedList<>();

        List<Areacity> areacityList = areacityService.findAllCity(provinceId);
        for (Areacity city:areacityList ) {
            SendCityInfo sendCityInfo = new SendCityInfo();
            sendCityInfo.setCityId(city.getCityid());
            sendCityInfo.setCity(city.getCity());
            sendCityInfoList.add(sendCityInfo);
        }
        return renderResult(sendCityInfoList);
    }

    @RequestMapping(value = APIConstant.CITYUNIT,method = RequestMethod.POST)
    public Object sendCityUnit(@RequestParam("cityId") String cityId){
        List<Tblnprojectinfo> tblnprojectinfoList = tblnprojectinfoService.findCityUnit(cityId);
        List<UnitSelectInfo> unitSelectInfoList = new ArrayList<>();
        if (tblnprojectinfoList.size()>0) {
            for (Tblnprojectinfo unitInfo: tblnprojectinfoList ) {
                UnitSelectInfo unitSelectInfo = new UnitSelectInfo();
                unitSelectInfo.setUnitId(unitInfo.getProjid());
                unitSelectInfo.setUnitName(unitInfo.getProjname());
                unitSelectInfoList.add(unitSelectInfo);
            }
        }
        return  renderResult(unitSelectInfoList);
    }

    @RequestMapping(value = APIConstant.AREA,method = RequestMethod.POST)
    public Object sendArea(@RequestParam("cityId") String cityId){
        List<Areaarea> areaareaList = areaareaService.findAllArea(cityId);
        List<SendAreaInfo> sendAreaInfoList = new LinkedList<>();
        for (Areaarea area:areaareaList ) {
            SendAreaInfo sendAreaInfo = new SendAreaInfo();
            sendAreaInfo.setAreaId(area.getAreaid());
            sendAreaInfo.setArea(area.getArea());
            sendAreaInfoList.add(sendAreaInfo);
        }
        return renderResult(sendAreaInfoList);
    }

    @RequestMapping(value = APIConstant.UNIT,method = RequestMethod.POST)
    public Object sendUnitInfo(@RequestParam("areaId") Integer areaId){
        List<Tblnprojectinfo> tblnprojectinfoList = tblnprojectinfoService.findUnitInfo(areaId);
        List<UnitSelectInfo> unitSelectInfoList = new ArrayList<>();
        if (tblnprojectinfoList.size()>0) {
            for (Tblnprojectinfo unitInfo: tblnprojectinfoList ) {
                UnitSelectInfo unitSelectInfo = new UnitSelectInfo();
                unitSelectInfo.setUnitId(unitInfo.getProjid());
                unitSelectInfo.setUnitName(unitInfo.getProjname());
                unitSelectInfoList.add(unitSelectInfo);

            }
        }

        return  renderResult(unitSelectInfoList);

    }

    @RequestMapping(value = APIConstant.LOOK_POINT,method = RequestMethod.POST)
    public Object sendLookPointInfo(@RequestParam("unitId") Integer unitId){
        List<HbyOverLookPoint> hbyOverlookpointList = hbyOverlookpointService.findLookPointInfo(unitId);
        List<LookPointSelectInfo> lookPointSelectInfoList = new ArrayList<>();
        if (hbyOverlookpointList.size()>0){
            for (HbyOverLookPoint lookPointInfo:hbyOverlookpointList ) {
                LookPointSelectInfo lookPointSelectInfo = new LookPointSelectInfo();
                lookPointSelectInfo.setLookPointId(lookPointInfo.getId());
                lookPointSelectInfo.setLookPointunitName(lookPointInfo.getOverLookName());
                lookPointSelectInfoList.add(lookPointSelectInfo);
            }
        }
        return  renderResult(lookPointSelectInfoList);
    }

    @RequestMapping(value = APIConstant.DEVSIGNINFO,method = RequestMethod.POST)
    public Object sendDevSign(@RequestParam("lookPointId") String lookPointId){
        List<HbyOverLookDevJoin> hbyOverlookDevJoinList = hbyOverLookDevJoinService.findAlldeviceByLookPointId(Long.parseLong(lookPointId));

        List<DevInfos> devSignList = new ArrayList<>();
        for (HbyOverLookDevJoin hbyOverlookDevJoin:hbyOverlookDevJoinList ) {
            DevInfos devInfos = new DevInfos();
            devInfos.setDevlocation(tblndeviceinfoService.findLocation(hbyOverlookDevJoin.getDevIdpk()));
            devInfos.setDevsignature(tblndeviceinfoService.findDevSignById(hbyOverlookDevJoin.getDevIdpk()));
            devSignList.add(devInfos);
        }
        return renderResult(devSignList);
    }

    @RequestMapping(value = APIConstant.DEFAULTUNITANDAGENCY,method = RequestMethod.POST)
    public Object defaultUnitAndAgency(@RequestParam("userId") Integer userId){
        UserInfo userInfo = this.getUserInfo();
        Map<String,Object> resultMap = new HashMap<>();
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        List<TreeMenu> menuList= permissionService.selectCanShowProjectByUserId2(userId,
                areaCodeJoinOther != null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null, params,this.getUserInfo().getPlatformId());
        if (menuList.size()==0){
            return renderResult(false,-1,"该账号下暂无绑定监测点的单位");
        }else {
            for (TreeMenu menu:menuList) {
                QueryWrapper<HbyProjectErrorInfo> queryWrapper = new QueryWrapper<>();
                queryWrapper.select().lambda().eq(HbyProjectErrorInfo::getUnitId,menu.getNodeId());
                List<HbyProjectErrorInfo> hbyProjectErrorInfoList = hbyProjectErrorInfoMapper.selectList(queryWrapper);
                if (hbyProjectErrorInfoList.size()>0){
                    Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(Integer.valueOf(String.valueOf(menu.getNodeId())));
                    resultMap.put("unitId",menu.getNodeId());
                    resultMap.put("unitName",tblnprojectinfo.getProjname());
                    HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(), userInfo.getPlatformId());
                    if (hbyAgency==null){
                        resultMap.put("agencyId",0);
                        resultMap.put("agencyName","暂无环保局");
                    }else {
                        resultMap.put("agencyId",hbyAgency.getId());
                        resultMap.put("agencyName",hbyAgency.getAgcyName());
                    }
                    break;
                }
            }
            if (resultMap.get("unitId")==null){
                Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(Integer.valueOf(String.valueOf(menuList.get(0).getNodeId())));
                resultMap.put("unitId",menuList.get(0).getNodeId());
                resultMap.put("unitName",tblnprojectinfo.getProjname());
                HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(), userInfo.getPlatformId());
                if (hbyAgency==null){
                    resultMap.put("agencyId",0);
                    resultMap.put("agencyName","暂无环保局");
                }else {
                    resultMap.put("agencyId",hbyAgency.getId());
                    resultMap.put("agencyName",hbyAgency.getAgcyName());
                }
            }

            return renderResult(resultMap);
        }

    }

    @RequestMapping(value = APIConstant.DEVDEATILS,method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object sendDevDeatils(@RequestBody HashMap<String, Object> receiveMap){
        Integer userId = this.getUserInfo().getUserId();
        String provinceCode = String.valueOf(receiveMap.get("provinceCode"));
        String cityCode = String.valueOf(receiveMap.get("cityCode"));
        String araeCode = String.valueOf(receiveMap.get("areaCode"));
        AreaCodeJoinOther areaCodeJoinOther = permissionService.selectAreaCodeByUserId(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        List<TreeMenu> menuList = permissionService.selectCanShowProjectByUserId2(userId, areaCodeJoinOther!=null, areaCodeJoinOther, UserUtil.getUserGrade(areaCodeJoinOther),null, params,this.getUserInfo().getPlatformId());

        List<Integer> unitList = isAgencyUnit(menuList,provinceCode,cityCode,araeCode);
        if(unitList.size()==0){
            return renderResult(false,-1,"无更多数据");
        }else {
            String sql = "SELECT DISTINCT " +
                    "tblnprojectinfo.projId AS unitId," +
                    "tblnprojectinfo.projName AS unitName," +
                    "groupName," +
                    "hby_overlookpoint.over_look_name AS lookPointName," +
                    "hby_overlook_dev_join.dev_pro_ty AS devTy," +
                    "tblndeviceinfo.devSignature AS devSignature," +
                    "hby_overlook_dev_join.dev_work_state AS devWorkStatus," +
                    "tblndeviceinfo.installLocation AS devLocation, " +
                    "hby_agency.agcy_name AS area " +
                    "FROM " +
                    "tblndeviceinfo," +
                    "tblnprojectinfo," +
                    "tblngroup," +
                    "hby_overlook_dev_join," +
                    "hby_overlookpoint," +
                    "hby_agency" +
                    " WHERE " +
                    " tblndeviceinfo.projId = tblnprojectinfo.projId " +
                    "AND tblndeviceinfo.isDelete = 0 " +
                    "AND tblndeviceinfo.devgroupId = tblngroup.groupId " +
                    "AND tblndeviceinfo.devIdpk = hby_overlook_dev_join.dev_idpk " +
                    "AND hby_overlook_dev_join.look_id = hby_overlookpoint.id " +
                    "AND tblnprojectinfo.proProvinceCode = hby_agency.province_code " +
                    "AND tblnprojectinfo.proCityCode = hby_agency.city_code " +
                    "AND tblnprojectinfo.proAreaCode = hby_agency.area_code";

            if (!"".equals(String.valueOf(receiveMap.get("unitId")))){
                sql = sql + " AND tblndeviceinfo.projId = "+Integer.parseInt(String.valueOf(receiveMap.get("unitId")));
            }
            if (!"".equals(String.valueOf(receiveMap.get("lookId")))){
                sql = sql + " AND hby_overlookpoint.id = " +Long.parseLong(String.valueOf(receiveMap.get("lookId")));
            }
            if (!"".equals(String.valueOf(receiveMap.get("groupId")))){
                sql = sql + " AND tblndeviceinfo.devgroupId = "+ Integer.parseInt(String.valueOf(receiveMap.get("groupId")));
            }
            if (!"".equals(String.valueOf(receiveMap.get("devSignature")))){
                sql = sql + " AND tblndeviceinfo.devSignature = " + "\'"+String.valueOf(receiveMap.get("devSignature"))+"\'";
            }
            if (!"".equals(String.valueOf(receiveMap.get("devStatus")))){
                sql = sql + " AND hby_overlook_dev_join.dev_work_state =" +Integer.parseInt(String.valueOf(receiveMap.get("devStatus")));
            }
            sql = sql + " AND  tblnprojectinfo.projId IN ( 0";
            for (Integer unit:unitList ) {
                sql = sql + ","+unit ;
            }
            sql = sql +" ) ";

            PageHelper.startPage(Integer.parseInt(String.valueOf(receiveMap.get("page"))), Integer.parseInt(String.valueOf(receiveMap.get("size"))));
            PageInfo<DevStatusListInfo> pageInfo = new PageInfo<>(tblndeviceinfoMapper.findDevStatusList(sql));

            for (DevStatusListInfo devStatusListInfo:pageInfo.getList()) {
                devStatusListInfo.setDevLocation(tblndeviceinfoService.findLocation(devStatusListInfo.getDevSignature()));
                if (devStatusListInfo.getDevTy()==1){
                    Long lookId  = hbyOverLookDevJoinService.findLookPointInfoByDevId(tblndeviceinfoService.findDevIdPk(devStatusListInfo.getDevSignature())).get(0).getLookId();
                    HbyOverLookPoint hbyOverLookPoint = hbyOverlookpointService.findOverLookPoint(lookId);
                    devStatusListInfo.setDevPower(hbyOverLookPoint.getPollDevPower());
                    devStatusListInfo.setDevPowerSillVal(hbyOverLookPoint.getPollDevPowerSillVal());
                    devStatusListInfo.setDevPowerLiveTime(hbyOverLookPoint.getPollDevPowerLiveTime());
                    devStatusListInfo.setDevEleSillVal(hbyOverLookPoint.getPollDevEleSillVal());
                    continue;
                }else if(devStatusListInfo.getDevTy()==2){
                    Long lookId  = hbyOverLookDevJoinService.findLookPointInfoByDevId(tblndeviceinfoService.findDevIdPk(devStatusListInfo.getDevSignature())).get(0).getLookId();
                    HbyOverLookPoint hbyOverLookPoint = hbyOverlookpointService.findOverLookPoint(lookId);
                    devStatusListInfo.setDevPower(hbyOverLookPoint.getConDevPower());
                    devStatusListInfo.setDevPowerSillVal(hbyOverLookPoint.getConDevPowerSillVal());
                    devStatusListInfo.setDevPowerLiveTime(hbyOverLookPoint.getConDevPowerLiveTime());
                    devStatusListInfo.setDevEleSillVal(hbyOverLookPoint.getConDevEleSillVal());
                    continue;
                }else {
                    continue;
                }
            }
            return renderResult(pageInfo);
        }
    }

    /**
     * 查出属于该行政区域的单位
     * @param treeMenuList
     * @param provinceCode
     * @param cityCode
     * @param areaCode
     * @return
     */
    public List<Integer> isAgencyUnit(List<TreeMenu> treeMenuList,String provinceCode,String cityCode,String areaCode){
        List<Integer> unitList = new ArrayList<>();
        for (TreeMenu menu:treeMenuList ) {
            Integer unitId = Integer.valueOf(String.valueOf(menu.getNodeId()));
            Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
            if ("000000".equals(provinceCode)|| "".equals(provinceCode)){
                unitList.add(unitId);
            }else {
                if (("000000".equals(cityCode)|| "".equals(cityCode))&&provinceCode.equals(tblnprojectinfo.getProprovincecode())){
                    unitList.add(unitId);
                }else {
                    if (("000000".equals(areaCode)|| "".equals(areaCode))
                            &&(cityCode.equals(tblnprojectinfo.getProcitycode()))
                            &&(provinceCode.equals(tblnprojectinfo.getProprovincecode()))
                    ){
                        unitList.add(unitId);
                    }else {
                        if (areaCode.equals(tblnprojectinfo.getProareacode())
                                &&cityCode.equals(tblnprojectinfo.getProcitycode())
                                &&provinceCode.equals(tblnprojectinfo.getProprovincecode())
                        ){
                            unitList.add(unitId);
                        }else {
                            continue;
                        }
                    }
                }
            }
        }
        return unitList;
    }
}
