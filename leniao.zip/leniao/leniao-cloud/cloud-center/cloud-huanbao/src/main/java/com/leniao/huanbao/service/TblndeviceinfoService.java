package com.leniao.huanbao.service;



import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.entity.Tblndeviceinfo;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/19 16:12
 */
public interface TblndeviceinfoService {

    /**
     * 通过设备编号查出设备信息
     */
    Tblndeviceinfo findGroupIdProTyStatus(String devSign);

    /**
     * 通过单位id查出设备相应的信息
     */
    List<Tblndeviceinfo> findGroupIdLookPointStatus(Integer unitId,Integer pageCount,Integer pageSize);

    /**
     * 通过分组ID 查出对应分组下的所有的设备编号
     */
    List<Tblndeviceinfo> findDevSign(Integer groupId);

    /**
     * 通过设备编号，找出对应的设备安装位置
     */
    String findLocation(String devSign);
    /**
     * 通过设备Id，找出安装位置
     */
    String findLocation(Integer devId);

    /**
     * 通过设备编号找到对应的设备ID
     */
    Integer findDevIdPk(String devSign);

    /**
     * 通过设备id 找出设备编号
     */
    String findDevSignById(Integer devIdpk);

    /**
     * 通过单位Id 找出相应的设备信息
     */
    List<Tblndeviceinfo>  findDevInfoByUnitId(Integer unitId,String date,Integer groupId,Integer page,Integer size);

    /**
     * 通过设备编号查设备
     * @param devSignature
     * @return
     */
    Tblndeviceinfo findDevBydDevSig(String devSignature);
}
