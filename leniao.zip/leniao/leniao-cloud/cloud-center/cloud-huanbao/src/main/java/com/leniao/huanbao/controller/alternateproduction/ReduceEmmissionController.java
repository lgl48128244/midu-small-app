package com.leniao.huanbao.controller.alternateproduction;

import cn.hutool.core.date.DateTime;
import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.alternateproduction.ReduceEmmissionDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.service.HbyReduceEmmissionService;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.vo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减产减排接口 情况
 * @author: j
 * @create: 2019-12-20 16:53
 **/
@RestController
@RequestMapping(ApiConstant.REDUCE_EMMISSION)
public class ReduceEmmissionController extends BaseController {

    @Autowired
    private HbyReduceEmmissionService hbyReduceEmmissionService;

    @Autowired
    private PermissionService permissionService;

    /**
     * 添加减排方案
     * @return
     */
    @RequestMapping(value = ApiConstant.ADD_PLAN,method = RequestMethod.POST)
    public Object insertPlan(@RequestBody @Validated ReduceEmmissionDto reduceEmmissionDto) {

        // 1. 通过用户token获取用户信息
        // 2. 通过用户信息校验用户权限
        // 3. 查用户相关的其他信息

        // 获取用户id （token校验通过后获取）
        UserInfo userInfo = this.getUserInfo();
        if (userInfo.getGroupOnlyRead() == 0 || userInfo.getGroupType() != 2) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        if (reduceEmmissionDto.getPlanType() == 1) {
            if (reduceEmmissionDto.getStopProducTimeList() == null || reduceEmmissionDto.getStopProducTimeList().size() == 0) {
                throw new CloudException(CloudErrorCode.PARAM_INVALID);
            }
        } else {
            if (reduceEmmissionDto.getLimitProducTimeCount() == null || reduceEmmissionDto.getLimitProducTimeCount() < 1) {
                throw new CloudException(CloudErrorCode.PARAM_INVALID);
            }
        }
        reduceEmmissionDto.setPlatformId(userInfo.getPlatformId());
        // 添加方案
        Long planId = hbyReduceEmmissionService.insertReduceEmmissionPlan(userInfo.getUserId(), reduceEmmissionDto);
        if (planId == null || planId == 0) {
            logger.error("添加减排方案失败" + JSON.toJSONString(reduceEmmissionDto));
            throw new CloudException(CloudErrorCode.SYS_FAIL_ADD);
        }

        return renderResult();
    }


    /**
     * 修改减排方案
     * @return
     */
    @RequestMapping(value = ApiConstant.MODIFY_PLAN, method = RequestMethod.POST)
    public Object updatePlan(@RequestBody @Validated ReduceEmmissionDto reduceEmmissionDto) {

        // 1. 通过用户token获取用户信息
        // 2. 通过用户信息校验用户权限
        // 3. 查用户相关的其他信息
        if (reduceEmmissionDto.getPlanType() == 1) {
            if (reduceEmmissionDto.getStopProducTimeList() == null || reduceEmmissionDto.getStopProducTimeList().size() == 0) {
                throw new CloudException(CloudErrorCode.PARAM_INVALID, "停产方案需要设置停产时间段");
            }
        } else {
            if (reduceEmmissionDto.getLimitProducTimeCount() == null || reduceEmmissionDto.getLimitProducTimeCount() < 1) {
                throw new CloudException(CloudErrorCode.PARAM_INVALID, "限产方案限产小时数不能小于1");
            }
        }
        UserInfo userInfo = this.getUserInfo();
        if (userInfo.getGroupOnlyRead() == 0 || userInfo.getGroupType() != 2) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        if (reduceEmmissionDto.getPlanId() == null || reduceEmmissionDto.getPlanId().equals(0)) {
            throw new CloudException(CloudErrorCode.PRIMARY_KEY_EMPTY);
        }

        // 判断是否有权限
        if (this.hasPermissionOperatePlan(userInfo.getUserId(), reduceEmmissionDto.getPlanId(), true)) {
            // 修改方案
            Long planId = hbyReduceEmmissionService.updateReduceEmmissionPlan(userInfo.getUserId(), reduceEmmissionDto);
            if (planId == null || planId == 0) {
                logger.error("减产减排方案修改异常" + JSON.toJSONString(reduceEmmissionDto));
                throw new CloudException(CloudErrorCode.SYS_FAIL_MODIFY);
            }

        } else {
            logger.error("减产减排方案修改异常" + JSON.toJSONString(reduceEmmissionDto));
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        return renderResult();
    }


    /**
     * 删除减排方案
     * @return
     */
    @RequestMapping(value = ApiConstant.DELETE_PLAN,method = RequestMethod.GET)
    public Object deletePlan(@RequestParam("planId") Long planId) {

        // 1. 通过用户token获取用户信息
        // 2. 通过用户信息校验用户权限
        // 3. 查用户相关的其他信息

        if (planId == null || planId.equals(0)) {
            throw new CloudException(CloudErrorCode.PRIMARY_KEY_EMPTY);
        }

        // 获取用户id
        UserInfo userInfo = this.getUserInfo();
        if (userInfo.getGroupOnlyRead() == 0 || userInfo.getGroupType() != 2) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        // 判断是否有权限
        if (this.hasPermissionOperatePlan(userInfo.getUserId(), planId, true)) {
            // 删除方案
            boolean delete = hbyReduceEmmissionService.deleteReduceEmmissionPlan(userInfo.getUserId(), planId);
            if (!delete) {
                logger.error("删除方案失败planId[{}]" + planId);
                throw new CloudException(CloudErrorCode.SYS_FAIL_DELETE);
            }
        } else {
            logger.error("删除方案失败planId[{}]" + planId);
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        return renderResult();
    }

    /**
     * 条件查询减产减排方案
     * @param params agcyId 机构id 非必须
     *               beginTime 方案生效开始时间 非必须
     *               endTime 方案生效结束时间 非必须
     *               warnLevel 预警等级 非必须
     *               onlyShowIsUsing 仅仅显示正在启用的方案 0-否， 1-是 非必须(默认0)
     *               pageNum 分页页码 必须
     *               pageSize 每页大小 必须
     * @return
     */
    @RequestMapping(ApiConstant.SELECT_PLAN)
    public Object selectPlan(@RequestBody JSONObject params) {

        // 1. 通过用户token获取用户信息
        // 2. 通过用户信息校验用户权限
        // 3. 查用户相关的其他信息
        List<ReduceEmmissionDto> reduceList = null;
        // 获取用户id （token校验通过后获取）
        UserInfo userInfo = this.getUserInfo();

        Integer onlyShowIsUsing = params.getInteger("onlyShowIsUsing");
        Integer agcyId = params.getInteger("agcyId");
        Integer warnLevel = params.getInteger("warnLevel");
        String startTime = params.getString("beginTime");
        String endTime = params.getString("endTime");

        Date beginTime = null;
        Date endTimes = null;
        Date nowTime = null;
        Integer isUsing = null;
        try {
            if (!StringUtils.isEmpty(startTime)) {
                beginTime = DateTime.of(startTime, "yyyy-MM-dd");
            }
            if (!StringUtils.isEmpty(endTime)) {
                endTimes = DateTime.of(endTime, "yyyy-MM-dd");
            }
        } catch (Exception e) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "时间格式不正确");
        }

        // 判断是否是只显示启用状态的方案
        if (onlyShowIsUsing != null && onlyShowIsUsing == 1) {
            // value = 1,只显示启用状态的方案
            isUsing = 1;
            nowTime = DateTime.of(DateTime.now().toDateStr(), "yyyy-MM-dd");
        }

        // 判断是否是区域用户
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (areaCode == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        Long agencyId = 0L;
        boolean isChange = false;
//        List<HbyAgency> agencyList = hbyReduceEmmissionService.getAgencyInfo(areaCode);
        Map<String, Object> param = new HashMap<>();
        param.put("showAll", 1);
        // 查询用户可见的所有机构
        List<TreeMenu> agencyList = permissionService.selectCanShowAgencyByUserId(userInfo.getUserId(),
                areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), param);
        if (agencyList != null && agencyList.size() > 0) {
            if (agcyId != null && agcyId > 0) {
                for (TreeMenu agency : agencyList) {
                    if (agency.getNodeId().equals(agcyId.longValue())) {
                        areaCode.setProvinceCode(agency.getProvinceCode());
                        areaCode.setCityCode(agency.getCityCode());
                        areaCode.setAreaCode(agency.getAreaCode());
                        isChange = true;
                    }
                }
                if (!isChange) {
                    throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
                }
            }
        }

        // 判断区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
        int userGrade = UserUtil.getUserGrade(areaCode);
        if (params.getInteger("pageNum") != null && params.getInteger("pageNum") != 0
                && params.getInteger("pageSize") != null && params.getInteger("pageSize") != 0) {
            PageHelper.startPage(params.getInteger("pageNum"), params.getInteger("pageSize"));
        }
        // 查询方案
        reduceList = hbyReduceEmmissionService.selectReduceEmmissionPlan(agencyId, userGrade, areaCode, agcyId, warnLevel, isUsing, nowTime, beginTime, endTimes);
        if (params.getInteger("pageNum") != null && params.getInteger("pageNum") > 0) {
            return renderResult(new PageInfo<>(reduceList));
        }
        return renderResult(reduceList);
    }

    /**
     * 方案绑定
     * @param jsonObject
     * @return
     */
    @RequestMapping(value = ApiConstant.BIND_PLAN, method = RequestMethod.POST)
    public Object bindPlan(@RequestBody JSONObject jsonObject) {

        Long planId = jsonObject.getLong("planId");
        List<Integer> inputProjIdList = JSON.parseObject(JSON.toJSONString(jsonObject.get("projIdList")), List.class);
        if (planId == null || inputProjIdList ==  null || inputProjIdList.size() == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        Map<Integer, Object> projMap = new HashMap<>();
        for (Integer projId : inputProjIdList) {
            projMap.put(projId, 1);
        }
        List<Integer> projIdList = new ArrayList<>(projMap.keySet());
        // 获取用户id （token校验通过后获取）
        UserInfo userInfo = this.getUserInfo();
        if (userInfo.getGroupOnlyRead() == 0 || userInfo.getGroupType() != 2) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        // 判断是否有权限
        if (this.hasPermissionOperatePlan(userInfo.getUserId(), planId, false)) {
            // 绑定方案
            boolean result = hbyReduceEmmissionService.updateBindReduceEmmissionPlan(planId, projIdList);
            if (!result) {
                logger.error("绑定方案失败planId[{}]，单位集合[{}]", planId, projIdList.toString());
                throw new CloudException(CloudErrorCode.BIZ_EXCEPTION);
            }
        } else {
            logger.error("绑定方案失败planId[{}]，单位集合[{}]", planId, projIdList.toString());
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        return renderResult();
    }

    /**
     * 方案解除绑定
     * @param jsonObject
     * @return
     */
    @RequestMapping(value = ApiConstant.UNBIND_PLAN, method = RequestMethod.POST)
    public Object unBindPlan(@RequestBody JSONObject jsonObject) {

        Long planId = jsonObject.getLong("planId");
        ArrayList<Integer> projIdList = JSON.parseObject(JSON.toJSONString(jsonObject.get("projIdList")), ArrayList.class);
        if (planId == null || projIdList ==  null || projIdList.size() == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }

        // 获取用户id （token校验通过后获取）
        UserInfo userInfo = this.getUserInfo();
        if (userInfo.getGroupOnlyRead() == 0 || userInfo.getGroupType() != 2) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }
        // 判断是否有权限
        if (this.hasPermissionOperatePlan(userInfo.getUserId(), planId, false)) {
            // 绑定方案
            boolean result = hbyReduceEmmissionService.updateUnBindReduceEmmissionPlan(planId, projIdList);
            if (!result) {
                logger.error("解除方案绑定失败planId[{}]，单位集合[{}]" + planId, projIdList.toString());
                throw new CloudException(CloudErrorCode.BIZ_EXCEPTION);
            }
        } else {
            logger.error("解除方案绑定失败planId[{}]，单位集合[{}]" + planId, projIdList.toString());
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        return renderResult();
    }


    /**
     * 判断当前用户是否具有操作该方案的权限
     * 1. 用户是否是区域用户
     * 2. 方案是否存在
     * 3. isChange=true, 方案当前绑定的单位数是不是0，不是则不可操作
     * 4. 该区域用户是否是该方案所在机构的用户
     * @param userId 用户id
     * @param planId 方案id
     * @param isChange 是否是修改、删除方案操作 true-修改、删除操作
     * @return
     */
    private boolean hasPermissionOperatePlan (int userId, Long planId, boolean isChange) {
        // 获取区域码 (判断是否是区域用户)
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userId);
        if (areaCode == null) {
            throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
        }

        // 查询方案
        HbyReduceEmmissionPlan plan = hbyReduceEmmissionService.selectByPrimaryKey(planId);
        if (plan == null) {
            throw new CloudException(CloudErrorCode.REDUCE_EMMISSION_EMPTY);
        }

        // 涉及到方案变动的操作，需要确认方案是否与单位有绑定，有绑定则不可操作
        Integer count = hbyReduceEmmissionService.selectBindCount(planId);
        if (isChange && count != null && count > 0) {
            throw new CloudException(CloudErrorCode.PLAN_JION_PROJECT);
        }

        return UserUtil.isManagementArea(areaCode, plan);
    }

}
