package com.leniao.huanbao.controller;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.statisticanalysis.StatisticAnalysisDto;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.entity.UshareDeviceElectricuseExample;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.service.ReduceEmAnalyzeService;
import com.leniao.huanbao.service.UshareDeviceElectricuseService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减产减排分析
 * @author: jiangdy
 * @create: 2019-12-27 14:49
 **/
@RestController
@RequestMapping(value = ApiConstant.REDUCE_EM_ANALYZE)
public class ReduceEmAnalyzeController extends BaseController {

    @Autowired
    private ReduceEmAnalyzeService reduceEmAnalyzeService;
    @Autowired
    private PermissionService permissionService;
    @Autowired
    private UshareDeviceElectricuseService ushareDeviceElectricuseService;
    @Autowired
    private HbyAgencyService hbyAgencyService;
    /**
     * 减产减排分析 查询
     * @param params
     * @return
     */
    @RequestMapping(value = ApiConstant.REDUCE_EM_ANALYZE_LIST, method = RequestMethod.POST)
    public Object list(@RequestBody JSONObject params) {

        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer grade = UserUtil.getUserGrade(code);
        params.put("industryId", params.get("industryId")+"");
        // 用户可见单位
        List<TreeMenu> projList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), code != null, code, grade, params);
        if (projList == null || projList.size() == 0) {
            return renderResult();
        }
        List<Long> projIds = projList.stream().map(proj -> proj.getNodeId()).collect(Collectors.toList());
//        List<Long> projIds = projList.stream().filter(proj2 -> proj2.getNodeId().equals(986L)).map(proj -> proj.getNodeId()).collect(Collectors.toList());

        if (params.getDate("addTime") == null) {
            params.put("addTime", DateTime.now().toString("yyyy-MM-dd"));
        }

        if (code != null && (params.get("agencyId") != null && !"".equals(params.get("agencyId")))) {
            // 查询指定机构的子机构
            HbyAgency agency = hbyAgencyService.getById(Integer.parseInt((String) params.get("agencyId")));
            code.setProvinceCode(agency.getProvinceCode());
            code.setCityCode(agency.getCityCode());
            code.setAreaCode(agency.getAreaCode());
            grade = UserUtil.getUserGrade(code);
            params.put("agencyId", "");
        }

        PageHelper.startPage(params.getInteger("pageNum"), params.getInteger("pageSize"));
        // 查询减排分析数据
        List<StatisticAnalysisDto> resultList = reduceEmAnalyzeService.selectStatisticAnalysisList2(projIds, code, grade, params);

        // 查询机构、单位、行业等名称信息
//        List<StatisticAnalysisDto> resultProjectList = reduceEmAnalyzeService.selectStatisticAnalysisProjectList(projIds, params);
        if (resultList == null || resultList.size() == 0) {
            return renderResult(new PageInfo<>());
        }

        // 查询单位主表设备
        Map<Integer, StatisticAnalysisDto> mainDeviceMap = reduceEmAnalyzeService.selectMainDevice(projIds);

//        List<Integer> devIdpks = mainDeviceMap.values().stream().map(device -> device.getDevIdpk()).collect(Collectors.toList());
//
//        // 查询主表用电量排名
//        Map<Integer, StatisticAnalysisDto> rankingMap = reduceEmAnalyzeService.selectRanking(devIdpks, (String) params.get("addTime"));
        StatisticAnalysisDto info;
//        int ranking = 0;
        for (StatisticAnalysisDto dto : resultList) {
            dto.setRanking((params.getInteger("pageNum") - 1) * params.getInteger("pageSize") + dto.getRanking());
            info = mainDeviceMap.get(dto.getProjId());
            if (info != null) {
                dto.setDevIdpk(info.getDevIdpk());
            } else {
                dto.setDevIdpk(0);
            }
        }

        // 查询排名第一的单位的总表24小时用电数据
        UshareDeviceElectricuseExample example = new UshareDeviceElectricuseExample();
        UshareDeviceElectricuseExample.Criteria criteria = example.createCriteria();
        if (params != null && params.getDate("addTime") != null) {
            criteria.andAddtimeEqualTo(params.getDate("addTime"));
        } else {
            criteria.andAddtimeEqualTo(DateTime.of(DateTime.now().toDateStr(), "yyyy-MM-dd"));
        }
        criteria.andDevidpkEqualTo(resultList.get(0).getDevIdpk());

        // devIdpk 和 addTime 条件查询设备24小时用电量
        List<UshareDeviceElectricuse> select = ushareDeviceElectricuseService.selectByExample(example);
        if (select != null && select.size() > 0) {
            resultList.get(0).setDeviceElectricuse(select.get(0));
        }

        return renderResult(new PageInfo<>(resultList));
    }

    /**
     * 减产减排分析 用电量曲线
     * @param params
     * @return
     */
    @RequestMapping(value = ApiConstant.REDUCE_EM_ANALYZE_ELECTRIC, method = RequestMethod.POST)
    public Object electric(@RequestBody JSONObject params) {

        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer grade = UserUtil.getUserGrade(code);
        long projId;
        int devIdpk;
        try {
            projId = params.getLongValue("projId");
            devIdpk = params.getInteger("devIdpk");
        } catch (Exception e) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }

        // 用户可见单位
        List<TreeMenu> projList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), code != null, code, grade, null);
        List<Long> projIds = projList.stream().filter(proj2 -> proj2.getNodeId().equals(projId)).map(proj -> proj.getNodeId()).collect(Collectors.toList());
        if (projIds == null || projIds.size() == 0) {
            return renderResult();
        }

        // 查询总表24小时用电数据
        UshareDeviceElectricuseExample example = new UshareDeviceElectricuseExample();
        UshareDeviceElectricuseExample.Criteria criteria = example.createCriteria();
        if (params != null && params.getDate("addTime") != null) {
            criteria.andAddtimeEqualTo(params.getDate("addTime"));
        } else {
            criteria.andAddtimeEqualTo(DateTime.of(DateTime.now().toDateStr(), "yyyy-MM-dd"));
        }
        criteria.andDevidpkEqualTo(devIdpk);
        StatisticAnalysisDto statisticAnalysisDto = new StatisticAnalysisDto();
        statisticAnalysisDto.setProjId(projId);
        // devIdpk 和 addTime 条件查询设备24小时用电量
        List<UshareDeviceElectricuse> select = ushareDeviceElectricuseService.selectByExample(example);
        if (select != null && select.size() > 0) {
            statisticAnalysisDto.setDeviceElectricuse(select.get(0));
        }
        return renderResult(statisticAnalysisDto);
    }

}
