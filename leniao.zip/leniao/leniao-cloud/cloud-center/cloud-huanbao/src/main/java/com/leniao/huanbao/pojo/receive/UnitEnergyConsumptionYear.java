package com.leniao.huanbao.pojo.receive;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author liudongshuai
 * @date 2020/1/15 17:25
 * @update
 */
public class UnitEnergyConsumptionYear implements Comparable<UnitEnergyConsumptionYear> {
    private String devName;
    private Double M1;
    private Double M2;
    private Double M3;
    private Double M4;
    private Double M5;
    private Double M6;
    private Double M7;
    private Double M8;
    private Double M9;
    private Double M10;
    private Double M11;
    private Double M12;
    private Double yearTotal;

    @Override
    public int compareTo(UnitEnergyConsumptionYear o) {
        return this.yearTotal.compareTo(o.getYearTotal());
    }

    public Double getYearTotal() {
        return yearTotal;
    }

    public void setYearTotal(Double yearTotal) {
        this.yearTotal = Double.valueOf(String.valueOf(new BigDecimal(yearTotal).setScale(1, RoundingMode.DOWN)));
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public Double getM1() {
        return M1;
    }

    public void setM1(Double m1) {
        M1 = m1;
    }

    public Double getM2() {
        return M2;
    }

    public void setM2(Double m2) {
        M2 = m2;
    }

    public Double getM3() {
        return M3;
    }

    public void setM3(Double m3) {
        M3 = m3;
    }

    public Double getM4() {
        return M4;
    }

    public void setM4(Double m4) {
        M4 = m4;
    }

    public Double getM5() {
        return M5;
    }

    public void setM5(Double m5) {
        M5 = m5;
    }

    public Double getM6() {
        return M6;
    }

    public void setM6(Double m6) {
        M6 = m6;
    }

    public Double getM7() {
        return M7;
    }

    public void setM7(Double m7) {
        M7 = m7;
    }

    public Double getM8() {
        return M8;
    }

    public void setM8(Double m8) {
        M8 = m8;
    }

    public Double getM9() {
        return M9;
    }

    public void setM9(Double m9) {
        M9 = m9;
    }

    public Double getM10() {
        return M10;
    }

    public void setM10(Double m10) {
        M10 = m10;
    }

    public Double getM11() {
        return M11;
    }

    public void setM11(Double m11) {
        M11 = m11;
    }

    public Double getM12() {
        return M12;
    }

    public void setM12(Double m12) {
        M12 = m12;
    }
}
