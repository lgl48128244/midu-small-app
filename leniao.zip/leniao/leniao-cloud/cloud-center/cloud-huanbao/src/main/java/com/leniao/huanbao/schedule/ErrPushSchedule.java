package com.leniao.huanbao.schedule;


import com.alibaba.fastjson.JSON;
import com.leniao.commons.AbstractOperation;
import com.leniao.huanbao.dto.schedule.ErrPushDto;
import com.leniao.huanbao.service.HbScheduledService;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@Slf4j
@Component
//@Profile({"DEV"})
@RestController
public class ErrPushSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;

    @Scheduled(cron = "0/3 * * * * ?")
    @RequestMapping("push123")
    private void pushErrMsgToRedis() {
        List<Long> errIds = new ArrayList<>();
        //、获取所有未处理的 3,4,5,6,7异常
        List<HashMap<String, Object>> errInfoList = this.hbScheduledService.findErrSimpInfoList(986);
        Long fgTimeStaple = (DateTime.now().getMillis()) / 1000;
        for (HashMap<String, Object> item : errInfoList) {
            try {
                ErrPushDto.PushMsgV2 pushMsgV2 = new ErrPushDto.PushMsgV2();
                ErrPushDto.Err err = new ErrPushDto.Err();
                List<ErrPushDto.ErrIfon> errList = new ArrayList<>();
                err.setDevId((Integer)item.get("DevId"));
                err.setDevIdpk((Integer) item.get("DevIdpk"));
                err.setFaultCount(1);
                err.setIsDele(0);
                err.setIsMaskNet(0);
                err.setLevel(0);
                err.setOperationCount(0);
                err.setProject(0);
                err.setR_Id("0000000000000000000000000000000");
                err.setRoad(0);
                err.setSig(item.get("Sig")+ "");
                err.setTroubleCount(0);
                err.setType((Integer) item.get("type"));
                ErrPushDto.ErrIfon errIfon = new ErrPushDto.ErrIfon();
                errIfon.setErrIsFg(Integer.valueOf(item.get("ErrIsFg")+""));
                errIfon.setErrType(Integer.valueOf(item.get("ErrType")+""));
                errIfon.setErrVal(item.get("ErrVal")+"");
                errIfon.setIsSave(Integer.valueOf(item.get("IsSave")+""));
                errIfon.setNode(item.get("Node")+ "");
                errIfon.setSaveType(Integer.valueOf(item.get("SaveType") + ""));
                errIfon.setTime(item.get("Time")+"");
                errIfon.setValUin(item.get("ValUin")+"");
                errIfon.setXh(1);

                errList.add(errIfon);
                err.setErrList(errList);

                pushMsgV2.setErr(err);
                pushMsgV2.setFgTimeStaple(fgTimeStaple);
                System.out.println(JSON.toJSONString(pushMsgV2));
                //存入Redis
                Boolean execute = this.redisTemplate.execute((RedisConnection redisConnection) -> {
                    Boolean aBoolean = redisConnection.zAdd("PushMsgV2".getBytes(), fgTimeStaple, JSON.toJSONBytes(pushMsgV2));
                    return aBoolean;
                });
                if (execute) {
                    errIds.add((Long) item.get("id"));
                }
            } catch (NumberFormatException e) {
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~异常推送程序解析数据异常~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                log.error(e.getMessage(), e);
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
        }
        if (errIds.size() > 0) {
            try {
                //批量处理，修改is_push = 1
                this.hbScheduledService.updateErrInfoIsPush(errIds);
            } catch (Exception e) {
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~批量更新异常是否推送字段异常~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                log.error(e.getMessage(), e);
                log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
        }
    }
}
