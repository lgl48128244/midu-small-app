package com.leniao.huanbao.mapper;

import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.huanbao.dto.DeviceDayCountInfo;
import com.leniao.huanbao.dto.ExpendStatistic.ExecuteState;
import com.leniao.huanbao.dto.ExpendStatistic.LinkRelativeStatistic;
import com.leniao.huanbao.dto.ExpendStatistic.UseEleRanking;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;

import java.util.*;

public interface ProjectDayCountinfoMapper {

    List<UseEleRanking> selectDeviceUseEle(@Param("devIdpks") Set<Integer> devIdpks, @Param("label") Integer label, @Param("addTime") String addTime);

    List<UseEleRanking> selectDeviceUseEle2(@Param("devIdpks") Set<Integer> devIdpks, @Param("label") Integer label);

    List<UseEleRanking> selectDeviceUseEle3(@Param("projIdList") List<Integer>  projIdList);

    UshareDeviceElectricuse selectTotalDeviceH24UseEleByProjIds(@Param("projIdList") List<Integer> projIdList, @Param("addTime") Date addTime);

    List<Integer> selectTotalDeviceIdpk(@Param("projIds") List<Integer> projIds, @Param("platformId") Integer platformId);

    @MapKey("key")
    Map<String, ExecuteState> homePlanBind(@Param("projIdList") List<Integer> projIdList, @Param("lastDate") Date lastDate);

    List<DeviceDayCountInfo> selectTotalDeviceDayCountInfo(@Param("devIdpks") List<Integer> devIdpks, @Param("year") Integer year, @Param("month") Integer month);

    List<DeviceDayCountInfo> selectTotalDeviceMonthCountInfo(@Param("devIdpks") List<Integer> devIdpks, @Param("year") Integer year);

//    List<HbyProjectDayCountinfo> selectHbyProjectDayCountinfoByProjIds(@Param("projIdList") List<Integer> projIdList, @Param("year") int year,
//                                                                       @Param("month") int month, @Param("day") int day, @Param("platformId") Integer platformId);
}
