package com.leniao.huanbao.service;


import com.leniao.huanbao.entity.Areaarea;

import java.util.List;

public interface AreaareaService {

    /**
     * 根据市级id 找出相对应的县级信息
     */
    List<Areaarea> findAllArea(String cityId);
}
