package com.leniao.huanbao.schedule;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONUtil;
import com.leniao.commons.AbstractOperation;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.dto.schedule.UnitIndustryDTO;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import com.leniao.huanbao.service.HbyProjectstatusService;
import com.leniao.service.HbyProjectErrorInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 定时修改经过修改过的单位行业
 * @author haosw
 */
@Slf4j
@Component
//@Profile({"DEV"})
public class UpdateIndustryOfUnitSchedule extends AbstractOperation {

    /**
     * 散列操作
     */
    @Resource
    private RedisTemplate<String, Object> redisTemplate;
    @Resource
    private HbyProjectDayCountinfoService hbyProjectDayCountinfoService;
    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;
    @Resource
    private HbyProjectstatusService hbyProjectstatusService;

    @Scheduled(cron = "0 0/3 * * * ?")
    private void begin() {
        //获取Redis中的数据
        UnitIndustryDTO industryIdDTO = redisTemplate.execute((RedisConnection connection) -> {
            byte[] bytes = connection.lPop(ScheduleConstant.UNIT_INDUSTRY_UPDATE_INFO.getBytes());
            if (!ArrayUtil.isEmpty(bytes)) {
                String str = new String(bytes);
                UnitIndustryDTO unitIndustryDTO = JSONUtil.toBean(str, UnitIndustryDTO.class);
                return unitIndustryDTO;
            }
            return null;
        });
        if (industryIdDTO != null) {
            Integer unitId = industryIdDTO.getUnitId();
            Integer industryId = industryIdDTO.getIndustryId();
            //更新三张含有单位行业的表 hby_project_day_countinfo ， hby_project_errorinfo ， hby_projectstatus
            if (unitId != null && industryId != null) {
                this.hbyProjectDayCountinfoService.updateIndustryOfUnit(unitId, industryId);
                this.hbyProjectErrorInfoService.updateIndustryOfUnit(unitId, industryId);
                this.hbyProjectstatusService.updateIndustryOfUnit(unitId, industryId);
            }
        }
    }


}
