package com.leniao.huanbao.mapper;

import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface TreeMenuMapper {

    TreeMenu selectAgencyInfoByAreaCode(@Param("provinceCode") String provinceCode, @Param("cityCode") String cityCode, @Param("areaCode") String areaCode, @Param("platformId") int platformId);

    @MapKey(value = "nodeId")
    Map<Long,TreeMenu> selectAgencyInfoByUserAreaCode(@Param("agencyId") Long agencyId, @Param("platformId") int platformId, @Param("areaCode") AreaCodeJoinOther areaCode, @Param("userGrade") int userGrade);

    List<TreeMenu> selectProjectInfoByAgencyTreeMenu(@Param("agencyInfo") TreeMenu agencyInfo, @Param("platformId") int platformId, @Param("onlyRead") int onlyRead, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowProjectByAgency(@Param("agencyInfo") HbyAgency agencyInfo, @Param("platformId") int platformId, @Param("userId") int userId, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectDeviceGroupByProjId(@Param("parentNodeId") Long parentNodeId, @Param("parentNodeType") Integer parentNodeType, @Param("onlyRead") Integer onlyRead);

    List<TreeMenu> selectOverLookPointByGroupId(@Param("parentNodeId") Long parentNodeId, @Param("parentNodeType") Integer parentNodeType, @Param("onlyRead") Integer onlyRead);

    List<TreeMenu> selectDeviceInfoByOverLookPointId(@Param("parentNodeId") Long parentNodeId, @Param("parentNodeType") Integer parentNodeType, @Param("onlyRead") Integer onlyRead, @Param("lookId") Long lookId);
}
