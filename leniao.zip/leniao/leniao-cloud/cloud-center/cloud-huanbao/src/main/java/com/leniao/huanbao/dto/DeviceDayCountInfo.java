package com.leniao.huanbao.dto;

/**
 * @program: leniao-hbcloudV1.0
 * @description:
 * @author: jiangdy
 * @create: 2020-03-20 18:30
 **/
public class DeviceDayCountInfo {

    private Double value;
    private String addTime;

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
}
