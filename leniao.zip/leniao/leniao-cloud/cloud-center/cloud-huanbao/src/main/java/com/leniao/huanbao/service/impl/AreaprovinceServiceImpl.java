package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.huanbao.entity.Areaprovince;
import com.leniao.huanbao.mapper.AreaprovinceMapper;
import com.leniao.huanbao.service.AreaprovinceService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 9:47
 */
@Service
public class AreaprovinceServiceImpl implements AreaprovinceService {

    @Resource
    private AreaprovinceMapper areaprovinceMapper;

    /**
     * 显示出所有省份
     */
    @Override
    public List<Areaprovince> findAllProvince() {
        //创建条件对象
        QueryWrapper<Areaprovince> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("provinceid","province");

        List<Areaprovince> areaprovinceList = areaprovinceMapper.selectList(queryWrapper);

        return areaprovinceList;
    }
}
