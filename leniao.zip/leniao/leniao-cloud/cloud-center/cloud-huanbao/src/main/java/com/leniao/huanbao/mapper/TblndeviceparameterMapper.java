package com.leniao.huanbao.mapper;

import com.leniao.huanbao.schedule.udpbean.*;

import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public  interface TblndeviceparameterMapper {
    int countByExample(TblndeviceparameterExample example);

    int deleteByExample(TblndeviceparameterExample example);

    int deleteByPrimaryKey(String pid);

    int insert(Tblndeviceparameter record);

    int insertSelective(Tblndeviceparameter record);

    List<Tblndeviceparameter> selectByExample(TblndeviceparameterExample example);

    Tblndeviceparameter selectByPrimaryKey(String pid);

    int updateByExampleSelective(@Param("record") Tblndeviceparameter record, @Param("example") TblndeviceparameterExample example);

    int updateByExample(@Param("record") Tblndeviceparameter record, @Param("example") TblndeviceparameterExample example);

    int updateByPrimaryKeySelective(Tblndeviceparameter record);

    int updateByPrimaryKey(Tblndeviceparameter record);

    UshareDeviceElectricuse findUshareDeviceElectricuse(@Param("devIdpk") int devIdpk, @Param("time") String time);

    Ele_Consumption findEle_Consumption(@Param("devIdpk") int devIdpk);

    int updateUshareDeviceElectricuse(@Param("lastData") UshareDeviceElectricuse lastData);

    Double findUnitPrice(@Param("startTime") Integer startTime, @Param("endTime") Integer endTime, @Param("unitId") int unitId);

    List<UshareCharge> findUshareCharges(@Param("unitId") int unitId);

    int addUshareDeviceElectricuse(UshareDeviceElectricuse todayData);

    void resetError_Lv2(@Param("devidpk") int devidpk, @Param("lv") int lv);

    int resetPower(@Param("devidpk") int devidpk);

    UshareDeviceElectricuse findUshareDeviceElectricuseByDevIdpk(@Param("devIdpk") int devIdpk);

    Double summationHistoryPower(@Param("devIdpk") int devIdpk, @Param("addtime") Date addtime);

    Double summationHistoryFee(@Param("devIdpk") int devIdpk, @Param("addtime") Date addtime);
}