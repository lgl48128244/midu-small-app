package com.leniao.huanbao.dto.ExpendStatistic;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.leniao.huanbao.utils.DoubleSerialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 企业日统计数据 能耗统计
 * @author: jiangdy
 * @create: 2019-12-31 11:17
 **/
@Getter
@Setter
@ToString
public class ProjectDayCountInfo {

    /**
     * 单位id
     */
    private Integer projId;

    /**
     * 机构id
     */
    private Long agcyId;

    /**
     * 行业id
     */
    private Long industryId;

    /**
     * 当前最大值
     *
     * 根据类型分电量和功率
     * 根据时间 timeType 分 日、月、年
     */
    @JsonSerialize(using = DoubleSerialize.class)
    private Double maxValue;

    /**
     * 上一条最大值
     *
     * 根据类型分电量和功率
     * 根据时间 timeType 分 日、月、年
     */
    @JsonSerialize(using = DoubleSerialize.class)
    private Double lastMaxValue;

    /**
     *  1-日 2-月 3-年
     */
    private int timeType;

}
