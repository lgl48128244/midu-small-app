package com.leniao.huanbao.service;

import com.leniao.entity.Tblndevicenodeinfo;

import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/26 8:57
 * @update
 * @description
 */

public interface TblndevicenodeinfoService {

    /**
     * 通过设备节点ID,找出所有的节点，并拼接成字符串
     */
    String findDevNode(Integer devTyId);

    /**
     * 通过设备节点id查询出节点的集合
     */
    List<Tblndevicenodeinfo> findNodeStr(Integer devTyId);

    /**
     * 找出nodeId
     */
    Integer findNodeIdPk(Integer devTy,String node);

}
