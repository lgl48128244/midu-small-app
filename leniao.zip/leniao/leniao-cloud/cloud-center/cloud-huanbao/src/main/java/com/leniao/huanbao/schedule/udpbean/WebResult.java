package com.leniao.huanbao.schedule.udpbean;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: leniaorestful
 * @description: 统一的查询返回实体
 * @author: lwl
 * @create: 2019-05-17 11:02
 **/
public class WebResult {
    /**
     * 命令编码 1 成功 0 失败
     */
    private int backCode;

    /**
     *  消息ID
     */
    private String id;

    /**
     * 结果数据（轮循结果描述）
     */
    private Object data;

    /**
     * 轮循专用结果数据返回
     */
    private Object resultData;


    public Integer getBackCode() {
    return backCode;
    }

    public void setBackCode(Integer backCode) {
    this.backCode = backCode;
    }

    public String getId() {
    return id;
    }

    public void setId(String id) {
    this.id = id;
    }

    public Object getData() {
        return data;
    }

    public Object getResultData() {
        return resultData;
    }

    public void setResultData(Object resultData) {
        this.resultData = resultData;
    }

    public void setData(Object data) {
        if (data != null || !"".equals(data)) {
            backCode = 1;
            id = "请求成功";
        }
        this.data = data;
    }

    public WebResult() {
        backCode=0;
        id="请求失败";
        data = "";
        resultData = "";
    }

    public WebResult(int code, String message, Object data, Object resultData) {
        this.backCode = code;
        this.id = message;
        this.data = data;
        this.resultData = resultData;
    }

    public static WebResult failure (String message) {
        return new WebResult(0, message, new HashMap<String, Object>(), new HashMap<String, Object>());
    }

    public static WebResult success (String message) {
        return new WebResult(1, message, new HashMap<String, Object>(), new HashMap<String, Object>());
    }

    public static WebResult success (Object data, Object resultData) {
        if (data == null) {
            data = new HashMap<>();
        }
        if (resultData == null) {
            resultData = new HashMap<>();
        }
        return new WebResult(1, "请求成功", data, resultData);
    }

    @Override
    public String toString() {
        return "{" +
                "backCode=" + backCode +
                ", id='" + id + '\'' +
                ", data=" + data +
                ", resultData=" + resultData +
                '}';
    }
}
