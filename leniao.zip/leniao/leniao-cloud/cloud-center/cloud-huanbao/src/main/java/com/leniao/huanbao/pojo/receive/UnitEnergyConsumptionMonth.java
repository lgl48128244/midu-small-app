package com.leniao.huanbao.pojo.receive;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author liudongshuai
 * @date 2020/1/14 17:47
 * @update
 */
public class UnitEnergyConsumptionMonth implements Serializable,Comparable<UnitEnergyConsumptionMonth>{

    private String devName;
    private Double D1 = 0D;
    private Double D2 = 0D;
    private Double D3 = 0D;
    private Double D4 = 0D;
    private Double D5 = 0D;
    private Double D6 = 0D;
    private Double D7 = 0D;
    private Double D8 = 0D;
    private Double D9 = 0D;
    private Double D10 = 0D;
    private Double D11 = 0D;
    private Double D12 = 0D;
    private Double D13 = 0D;
    private Double D14 = 0D;
    private Double D15 = 0D;
    private Double D16 = 0D;
    private Double D17 = 0D;
    private Double D18 = 0D;
    private Double D19 = 0D;
    private Double D20 = 0D;
    private Double D21 = 0D;
    private Double D22 = 0D;
    private Double D23 = 0D;
    private Double D24 = 0D;
    private Double D25 = 0D;
    private Double D26 = 0D;
    private Double D27 = 0D;
    private Double D28 = 0D;
    private Double D29 = 0D;
    private Double D30 = 0D;
    private Double D31 = 0D;
    private Double monthTotal;

    @Override
    public int compareTo(UnitEnergyConsumptionMonth o) {
        return this.monthTotal.compareTo(o.getMonthTotal());
    }

    public Double getMonthTotal() {
        return monthTotal;
    }

    public void setMonthTotal(Double monthTotal) {
        this.monthTotal = Double.valueOf(String.valueOf(new BigDecimal(monthTotal).setScale(1, RoundingMode.DOWN)));
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public Double getD1() {
        return D1;
    }

    public void setD1(Double d1) {
        D1 = d1;
    }

    public Double getD2() {
        return D2;
    }

    public void setD2(Double d2) {
        D2 = d2;
    }

    public Double getD3() {
        return D3;
    }

    public void setD3(Double d3) {
        D3 = d3;
    }

    public Double getD4() {
        return D4;
    }

    public void setD4(Double d4) {
        D4 = d4;
    }

    public Double getD5() {
        return D5;
    }

    public void setD5(Double d5) {
        D5 = d5;
    }

    public Double getD6() {
        return D6;
    }

    public void setD6(Double d6) {
        D6 = d6;
    }

    public Double getD7() {
        return D7;
    }

    public void setD7(Double d7) {
        D7 = d7;
    }

    public Double getD8() {
        return D8;
    }

    public void setD8(Double d8) {
        D8 = d8;
    }

    public Double getD9() {
        return D9;
    }

    public void setD9(Double d9) {
        D9 = d9;
    }

    public Double getD10() {
        return D10;
    }

    public void setD10(Double d10) {
        D10 = d10;
    }

    public Double getD11() {
        return D11;
    }

    public void setD11(Double d11) {
        D11 = d11;
    }

    public Double getD12() {
        return D12;
    }

    public void setD12(Double d12) {
        D12 = d12;
    }

    public Double getD13() {
        return D13;
    }

    public void setD13(Double d13) {
        D13 = d13;
    }

    public Double getD14() {
        return D14;
    }

    public void setD14(Double d14) {
        D14 = d14;
    }

    public Double getD15() {
        return D15;
    }

    public void setD15(Double d15) {
        D15 = d15;
    }

    public Double getD16() {
        return D16;
    }

    public void setD16(Double d16) {
        D16 = d16;
    }

    public Double getD17() {
        return D17;
    }

    public void setD17(Double d17) {
        D17 = d17;
    }

    public Double getD18() {
        return D18;
    }

    public void setD18(Double d18) {
        D18 = d18;
    }

    public Double getD19() {
        return D19;
    }

    public void setD19(Double d19) {
        D19 = d19;
    }

    public Double getD20() {
        return D20;
    }

    public void setD20(Double d20) {
        D20 = d20;
    }

    public Double getD21() {
        return D21;
    }

    public void setD21(Double d21) {
        D21 = d21;
    }

    public Double getD22() {
        return D22;
    }

    public void setD22(Double d22) {
        D22 = d22;
    }

    public Double getD23() {
        return D23;
    }

    public void setD23(Double d23) {
        D23 = d23;
    }

    public Double getD24() {
        return D24;
    }

    public void setD24(Double d24) {
        D24 = d24;
    }

    public Double getD25() {
        return D25;
    }

    public void setD25(Double d25) {
        D25 = d25;
    }

    public Double getD26() {
        return D26;
    }

    public void setD26(Double d26) {
        D26 = d26;
    }

    public Double getD27() {
        return D27;
    }

    public void setD27(Double d27) {
        D27 = d27;
    }

    public Double getD28() {
        return D28;
    }

    public void setD28(Double d28) {
        D28 = d28;
    }

    public Double getD29() {
        return D29;
    }

    public void setD29(Double d29) {
        D29 = d29;
    }

    public Double getD30() {
        return D30;
    }

    public void setD30(Double d30) {
        D30 = d30;
    }

    public Double getD31() {
        return D31;
    }

    public void setD31(Double d31) {
        D31 = d31;
    }
}
