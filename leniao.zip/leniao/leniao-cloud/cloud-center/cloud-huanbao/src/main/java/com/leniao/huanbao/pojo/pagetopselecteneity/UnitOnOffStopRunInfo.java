package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/27 16:33
 * @update
 * @description
 */
public class UnitOnOffStopRunInfo {
    //在线单位
    private Integer onlineUnit;
    //失联单位
    private Integer outlineUnit;
    //在线设备
    private Integer onlineDev;
    //失联设备
    private Integer outlineDev;
    //停机设备
    private Integer stopDev;

    @Override
    public String
    toString() {
        return "UnitOnOffStopRunInfo{" +
                "onlineUnit=" + onlineUnit +
                ", outlineUnit=" + outlineUnit +
                ", onlineDev=" + onlineDev +
                ", outlineDev=" + outlineDev +
                ", stopDev=" + stopDev +
                '}';
    }

    public Integer getOnlineUnit() {
        return onlineUnit;
    }

    public void setOnlineUnit(Integer onlineUnit) {
        this.onlineUnit = onlineUnit;
    }

    public Integer getOutlineUnit() {
        return outlineUnit;
    }

    public void setOutlineUnit(Integer outlineUnit) {
        this.outlineUnit = outlineUnit;
    }

    public Integer getOnlineDev() {
        return onlineDev;
    }

    public void setOnlineDev(Integer onlineDev) {
        this.onlineDev = onlineDev;
    }

    public Integer getOutlineDev() {
        return outlineDev;
    }

    public void setOutlineDev(Integer outlineDev) {
        this.outlineDev = outlineDev;
    }

    public Integer getStopDev() {
        return stopDev;
    }

    public void setStopDev(Integer stopDev) {
        this.stopDev = stopDev;
    }
}
