package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;
@ToString
@TableName("hby_deval_time_status")
public class HbyDevalTimeStatus {
    private Long id;

    @TableField("unitId")
    private Integer unitId;

    @TableField("devIdpk")
    private Integer devIdpk;

    @TableField("devProTy")
    private Integer devProTy;

    @TableField("platformId")
    private Integer platformId;

    @TableField("updateTime")
    private Date updateTime;

    @TableField("addTime")
    private Date addtime;

    @TableField("H0_1")
    private Integer h0_1;

    private Integer h0_2;

    private Integer h0_3;

    private Integer h1_1;

    private Integer h1_2;

    private Integer h1_3;

    private Integer h2_1;

    private Integer h2_2;

    private Integer h2_3;

    private Integer h3_1;

    private Integer h3_2;

    private Integer h3_3;

    private Integer h4_1;

    private Integer h4_2;

    private Integer h4_3;

    private Integer h5_1;

    private Integer h5_2;

    private Integer h5_3;

    private Integer h6_1;

    private Integer h6_2;

    private Integer h6_3;

    private Integer h7_1;

    private Integer h7_2;

    private Integer h7_3;

    private Integer h8_1;

    private Integer h8_2;

    private Integer h8_3;

    private Integer h9_1;

    private Integer h9_2;

    private Integer h9_3;

    private Integer h10_1;

    private Integer h10_2;

    private Integer h10_3;

    private Integer h11_1;

    private Integer h11_2;

    private Integer h11_3;

    private Integer h12_1;

    private Integer h12_2;

    private Integer h12_3;

    private Integer h13_1;

    private Integer h13_2;

    private Integer h13_3;

    private Integer h14_1;

    private Integer h14_2;

    private Integer h14_3;

    private Integer h15_1;

    private Integer h15_2;

    private Integer h15_3;

    private Integer h16_1;

    private Integer h16_2;

    private Integer h16_3;

    private Integer h17_1;

    private Integer h17_2;

    private Integer h17_3;

    private Integer h18_1;

    private Integer h18_2;

    private Integer h18_3;

    private Integer h19_1;

    private Integer h19_2;

    private Integer h19_3;

    private Integer h20_1;

    private Integer h20_2;

    private Integer h20_3;

    private Integer h21_1;

    private Integer h21_2;

    private Integer h21_3;

    private Integer h22_1;

    private Integer h22_2;

    private Integer h22_3;

    private Integer h23_1;

    private Integer h23_2;

    private Integer h23_3;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Integer getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(Integer devIdpk) {
        this.devIdpk = devIdpk;
    }

    public Integer getDevProTy() {
        return devProTy;
    }

    public void setDevProTy(Integer devProTy) {
        this.devProTy = devProTy;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public Integer getH0_1() {
        return h0_1;
    }

    public void setH0_1(Integer h0_1) {
        this.h0_1 = h0_1;
    }

    public Integer getH0_2() {
        return h0_2;
    }

    public void setH0_2(Integer h0_2) {
        this.h0_2 = h0_2;
    }

    public Integer getH0_3() {
        return h0_3;
    }

    public void setH0_3(Integer h0_3) {
        this.h0_3 = h0_3;
    }

    public Integer getH1_1() {
        return h1_1;
    }

    public void setH1_1(Integer h1_1) {
        this.h1_1 = h1_1;
    }

    public Integer getH1_2() {
        return h1_2;
    }

    public void setH1_2(Integer h1_2) {
        this.h1_2 = h1_2;
    }

    public Integer getH1_3() {
        return h1_3;
    }

    public void setH1_3(Integer h1_3) {
        this.h1_3 = h1_3;
    }

    public Integer getH2_1() {
        return h2_1;
    }

    public void setH2_1(Integer h2_1) {
        this.h2_1 = h2_1;
    }

    public Integer getH2_2() {
        return h2_2;
    }

    public void setH2_2(Integer h2_2) {
        this.h2_2 = h2_2;
    }

    public Integer getH2_3() {
        return h2_3;
    }

    public void setH2_3(Integer h2_3) {
        this.h2_3 = h2_3;
    }

    public Integer getH3_1() {
        return h3_1;
    }

    public void setH3_1(Integer h3_1) {
        this.h3_1 = h3_1;
    }

    public Integer getH3_2() {
        return h3_2;
    }

    public void setH3_2(Integer h3_2) {
        this.h3_2 = h3_2;
    }

    public Integer getH3_3() {
        return h3_3;
    }

    public void setH3_3(Integer h3_3) {
        this.h3_3 = h3_3;
    }

    public Integer getH4_1() {
        return h4_1;
    }

    public void setH4_1(Integer h4_1) {
        this.h4_1 = h4_1;
    }

    public Integer getH4_2() {
        return h4_2;
    }

    public void setH4_2(Integer h4_2) {
        this.h4_2 = h4_2;
    }

    public Integer getH4_3() {
        return h4_3;
    }

    public void setH4_3(Integer h4_3) {
        this.h4_3 = h4_3;
    }

    public Integer getH5_1() {
        return h5_1;
    }

    public void setH5_1(Integer h5_1) {
        this.h5_1 = h5_1;
    }

    public Integer getH5_2() {
        return h5_2;
    }

    public void setH5_2(Integer h5_2) {
        this.h5_2 = h5_2;
    }

    public Integer getH5_3() {
        return h5_3;
    }

    public void setH5_3(Integer h5_3) {
        this.h5_3 = h5_3;
    }

    public Integer getH6_1() {
        return h6_1;
    }

    public void setH6_1(Integer h6_1) {
        this.h6_1 = h6_1;
    }

    public Integer getH6_2() {
        return h6_2;
    }

    public void setH6_2(Integer h6_2) {
        this.h6_2 = h6_2;
    }

    public Integer getH6_3() {
        return h6_3;
    }

    public void setH6_3(Integer h6_3) {
        this.h6_3 = h6_3;
    }

    public Integer getH7_1() {
        return h7_1;
    }

    public void setH7_1(Integer h7_1) {
        this.h7_1 = h7_1;
    }

    public Integer getH7_2() {
        return h7_2;
    }

    public void setH7_2(Integer h7_2) {
        this.h7_2 = h7_2;
    }

    public Integer getH7_3() {
        return h7_3;
    }

    public void setH7_3(Integer h7_3) {
        this.h7_3 = h7_3;
    }

    public Integer getH8_1() {
        return h8_1;
    }

    public void setH8_1(Integer h8_1) {
        this.h8_1 = h8_1;
    }

    public Integer getH8_2() {
        return h8_2;
    }

    public void setH8_2(Integer h8_2) {
        this.h8_2 = h8_2;
    }

    public Integer getH8_3() {
        return h8_3;
    }

    public void setH8_3(Integer h8_3) {
        this.h8_3 = h8_3;
    }

    public Integer getH9_1() {
        return h9_1;
    }

    public void setH9_1(Integer h9_1) {
        this.h9_1 = h9_1;
    }

    public Integer getH9_2() {
        return h9_2;
    }

    public void setH9_2(Integer h9_2) {
        this.h9_2 = h9_2;
    }

    public Integer getH9_3() {
        return h9_3;
    }

    public void setH9_3(Integer h9_3) {
        this.h9_3 = h9_3;
    }

    public Integer getH10_1() {
        return h10_1;
    }

    public void setH10_1(Integer h10_1) {
        this.h10_1 = h10_1;
    }

    public Integer getH10_2() {
        return h10_2;
    }

    public void setH10_2(Integer h10_2) {
        this.h10_2 = h10_2;
    }

    public Integer getH10_3() {
        return h10_3;
    }

    public void setH10_3(Integer h10_3) {
        this.h10_3 = h10_3;
    }

    public Integer getH11_1() {
        return h11_1;
    }

    public void setH11_1(Integer h11_1) {
        this.h11_1 = h11_1;
    }

    public Integer getH11_2() {
        return h11_2;
    }

    public void setH11_2(Integer h11_2) {
        this.h11_2 = h11_2;
    }

    public Integer getH11_3() {
        return h11_3;
    }

    public void setH11_3(Integer h11_3) {
        this.h11_3 = h11_3;
    }

    public Integer getH12_1() {
        return h12_1;
    }

    public void setH12_1(Integer h12_1) {
        this.h12_1 = h12_1;
    }

    public Integer getH12_2() {
        return h12_2;
    }

    public void setH12_2(Integer h12_2) {
        this.h12_2 = h12_2;
    }

    public Integer getH12_3() {
        return h12_3;
    }

    public void setH12_3(Integer h12_3) {
        this.h12_3 = h12_3;
    }

    public Integer getH13_1() {
        return h13_1;
    }

    public void setH13_1(Integer h13_1) {
        this.h13_1 = h13_1;
    }

    public Integer getH13_2() {
        return h13_2;
    }

    public void setH13_2(Integer h13_2) {
        this.h13_2 = h13_2;
    }

    public Integer getH13_3() {
        return h13_3;
    }

    public void setH13_3(Integer h13_3) {
        this.h13_3 = h13_3;
    }

    public Integer getH14_1() {
        return h14_1;
    }

    public void setH14_1(Integer h14_1) {
        this.h14_1 = h14_1;
    }

    public Integer getH14_2() {
        return h14_2;
    }

    public void setH14_2(Integer h14_2) {
        this.h14_2 = h14_2;
    }

    public Integer getH14_3() {
        return h14_3;
    }

    public void setH14_3(Integer h14_3) {
        this.h14_3 = h14_3;
    }

    public Integer getH15_1() {
        return h15_1;
    }

    public void setH15_1(Integer h15_1) {
        this.h15_1 = h15_1;
    }

    public Integer getH15_2() {
        return h15_2;
    }

    public void setH15_2(Integer h15_2) {
        this.h15_2 = h15_2;
    }

    public Integer getH15_3() {
        return h15_3;
    }

    public void setH15_3(Integer h15_3) {
        this.h15_3 = h15_3;
    }

    public Integer getH16_1() {
        return h16_1;
    }

    public void setH16_1(Integer h16_1) {
        this.h16_1 = h16_1;
    }

    public Integer getH16_2() {
        return h16_2;
    }

    public void setH16_2(Integer h16_2) {
        this.h16_2 = h16_2;
    }

    public Integer getH16_3() {
        return h16_3;
    }

    public void setH16_3(Integer h16_3) {
        this.h16_3 = h16_3;
    }

    public Integer getH17_1() {
        return h17_1;
    }

    public void setH17_1(Integer h17_1) {
        this.h17_1 = h17_1;
    }

    public Integer getH17_2() {
        return h17_2;
    }

    public void setH17_2(Integer h17_2) {
        this.h17_2 = h17_2;
    }

    public Integer getH17_3() {
        return h17_3;
    }

    public void setH17_3(Integer h17_3) {
        this.h17_3 = h17_3;
    }

    public Integer getH18_1() {
        return h18_1;
    }

    public void setH18_1(Integer h18_1) {
        this.h18_1 = h18_1;
    }

    public Integer getH18_2() {
        return h18_2;
    }

    public void setH18_2(Integer h18_2) {
        this.h18_2 = h18_2;
    }

    public Integer getH18_3() {
        return h18_3;
    }

    public void setH18_3(Integer h18_3) {
        this.h18_3 = h18_3;
    }

    public Integer getH19_1() {
        return h19_1;
    }

    public void setH19_1(Integer h19_1) {
        this.h19_1 = h19_1;
    }

    public Integer getH19_2() {
        return h19_2;
    }

    public void setH19_2(Integer h19_2) {
        this.h19_2 = h19_2;
    }

    public Integer getH19_3() {
        return h19_3;
    }

    public void setH19_3(Integer h19_3) {
        this.h19_3 = h19_3;
    }

    public Integer getH20_1() {
        return h20_1;
    }

    public void setH20_1(Integer h20_1) {
        this.h20_1 = h20_1;
    }

    public Integer getH20_2() {
        return h20_2;
    }

    public void setH20_2(Integer h20_2) {
        this.h20_2 = h20_2;
    }

    public Integer getH20_3() {
        return h20_3;
    }

    public void setH20_3(Integer h20_3) {
        this.h20_3 = h20_3;
    }

    public Integer getH21_1() {
        return h21_1;
    }

    public void setH21_1(Integer h21_1) {
        this.h21_1 = h21_1;
    }

    public Integer getH21_2() {
        return h21_2;
    }

    public void setH21_2(Integer h21_2) {
        this.h21_2 = h21_2;
    }

    public Integer getH21_3() {
        return h21_3;
    }

    public void setH21_3(Integer h21_3) {
        this.h21_3 = h21_3;
    }

    public Integer getH22_1() {
        return h22_1;
    }

    public void setH22_1(Integer h22_1) {
        this.h22_1 = h22_1;
    }

    public Integer getH22_2() {
        return h22_2;
    }

    public void setH22_2(Integer h22_2) {
        this.h22_2 = h22_2;
    }

    public Integer getH22_3() {
        return h22_3;
    }

    public void setH22_3(Integer h22_3) {
        this.h22_3 = h22_3;
    }

    public Integer getH23_1() {
        return h23_1;
    }

    public void setH23_1(Integer h23_1) {
        this.h23_1 = h23_1;
    }

    public Integer getH23_2() {
        return h23_2;
    }

    public void setH23_2(Integer h23_2) {
        this.h23_2 = h23_2;
    }

    public Integer getH23_3() {
        return h23_3;
    }

    public void setH23_3(Integer h23_3) {
        this.h23_3 = h23_3;
    }
}