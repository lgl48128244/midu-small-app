package com.leniao.huanbao.schedule.udpbean;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

public  class DateUtil {

    private final static Log logger = LogFactory.getLog(DateUtil.class);

   /**
    * 获取当前时间对象
    * @return
    */
    public  static Date GetDate() {
       return new Date();
   }

   /**
    * 获取GUID函数
    * @return
    */
    public  static  String GetUUID(){
       return UUID.randomUUID().toString().replaceAll("\\-", "").toUpperCase();
   }


    /**
     * 日期转换成字符串  yyyy-MM-dd hh:mm:ss
     * @param date
     * @return
     */
   public static String dateToLongStr (Date date) {

       SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

       return df.format(date);
   }

    /**
     * 日期转换成字符串  yyyy-MM-dd
     * @param date
     * @return
     */
    public static String dateToShortStr (Date date) {

        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");

        return df.format(date);
    }

    /**
     * 日期转换成字符串  yyyy-MM-dd hh:mm:ss
     * @param dateStr
     * @return
     */
    public static Date strToLongDate (String dateStr) {

        try {
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return  df.parse(dateStr);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    /**
     * 日期转换成字符串  yyyy-MM-dd
     * @param dateStr
     * @return
     */
    public static Date strToShortDate (String dateStr) {

        try {
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
            return  df.parse(dateStr);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    /**
     * 获取当天0点0分0秒的时间 wee hours
     * @param date
     * @return
     */
    public static Date getWeehours (Date date) {

        try {
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");

            return  df.parse(df.format(date));

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    /**
     * 给变当前时间，增加或较少
     * @param date 需要改变的时间
     * @param increment 改变的量 负数为减少
     * @param unit 单位
     * @return 改变后的时间
     */
    public static Date changeDate (Date date, int increment, int unit) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(unit, increment);
        return  cal.getTime();
    }

    public static Date changeDate (String strDate, int increment, int unit) {

        return changeDate(DateUtil.strToLongDate(strDate), increment, unit);
    }

    /**
    * @Description:    根据当前时间(Date类型)获取分钟的long值
    * @Author:         haosw
    * @CreateDate:     2019/10/15 16:58
    * @UpdateUser:     haosw
    * @UpdateDate:     2019/10/15 16:58
    * @UpdateRemark:   修改内容
    * @Version:        1.2
    */
    public static long getLongSecondOfDate(Date date){
        if (date == null) {
            return 0L;
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String strDate = format.format(date);
        try {
            return format.parse(strDate).getTime()/1000;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0L;

    }

    /**
     * @Description:    根据当前时间(Date类型)获取分钟的long值
     * @Author:         haosw
     * @CreateDate:     2019/10/15 16:58
     * @UpdateUser:     haosw
     * @UpdateDate:     2019/10/15 16:58
     * @UpdateRemark:   修改内容
     * @Version:        1.2
     */
    public static long getLongSecondOfStringDate(String date){
        if (StringUtils.isBlank(date)) {
            return 0L;
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return format.parse(date).getTime()/1000;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0L;

    }

    /**
    * 获取时间所处时段的00分00秒 和 59分59秒 的时间
    * @author      Haosw
    * @param date
    * @return
    * @exception
    * @date        2019/10/16 10:22
    */
    public static Date[] getHourStartAndEndDate(Date date){
        Date[] dates = new Date[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.HOUR_OF_DAY), 0, 0);
        dates[0] = calendar.getTime();
        //calendar.add(Calendar.HOUR_OF_DAY,1);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.HOUR_OF_DAY), 59, 59);
        dates[1] = calendar.getTime();
        return dates;
    }


    /**
     * 日期转换成字符串  yyyy-MM-dd
     * @param date
     * @return
     */
    public static String dateToStr_yyyyMMddHHmmss (Date date) {

        SimpleDateFormat df=new SimpleDateFormat("yyyyMMddHHmmss");

        return df.format(date);
    }

    /**
     * 日期转换成字符串  yyyy-MM-dd
     * @param date
     * @return
     */
    public static String dateToStr_yyyyMMdd (Date date) {

        SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd");

        return df.format(date);
    }

    public static void main(String[] args) {
        String s = dateToStr_yyyyMMddHHmmss(new Date());
        System.out.println(s);
    }

    /**
     * 日期转换成字符串  yyyyMMdd 中文
     * @param date
     * @return
     */
    public static String dateToStr_Chinese (Date date) {

        SimpleDateFormat df=new SimpleDateFormat("yyyy年MM月dd日HH点mm分ss秒");

        return df.format(date);
    }

}
