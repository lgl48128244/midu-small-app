package com.leniao.huanbao.schedule;

import com.leniao.commons.AbstractOperation;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.OverLookPointWithDevlist;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyReduceplanJoinProjectService;
import com.leniao.huanbao.utils.ScheduleNeedUtil;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Description: 监测环保设备24小时运行工况的定时器
 * @Author: haosw
 * @CreateDate: 2019/12/19 14:35
 * @UpdateUser: haosw
 * @UpdateDate: 2019/12/19 14:35
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@Component
@Slf4j
//@Profile({"DEV"})
public class Device24hWorkDetailSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;
    @Resource
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;

    @Scheduled(cron = "0 0,20,40 * * * ?")
    @Async
    protected void begin() {
        log.error("==========================================24小时工况监控定时器运行了=========================================");
        Date now = new Date();
        //执行异步任务
        //this.taskScheduler.schedule(new DeviceWorkStatusRunnable(now), now);
        this.run(now);
    }

    /*private class DeviceWorkStatusRunnable implements Runnable {
        private volatile Date now;
        protected DeviceWorkStatusRunnable(Date now) {
            this.now = now;
        }
    @Override*/
    public void run(Date now) {
        //临时容器,存放已经增加了过生产时间的单位ID,防止时间多次增加
        Set<Integer> unitSet = new HashSet<>();
        long start = System.currentTimeMillis();
        //查询所有监测点以及监测点关联的设备信息
        List<OverLookPointWithDevlist> overLookPointWithDevlistList = hbScheduledService.findOverLookPointsWithDevlist();
        //判断当前时间c  -> 获取上一个时区的开始时间---s1和结束时间---e1,
        System.out.println("24时工况运行，当前时间：" + new DateTime(now).toString());
        log.error("24时工况运行，当前时间：" + new DateTime(now).toString());
        DateTime[] frontTimeArea = ScheduleNeedUtil.getFrontTimeArea(now);
        //遍历每一个设备,(如果设备量大的话可以考虑分批次遍历) 获取当前设备的功率阈值---y和功率门限---m
        for (OverLookPointWithDevlist lookPoint : overLookPointWithDevlistList) {
            List<DevDto> pointDevs = lookPoint.getPointDevs();
            pointDevs.forEach(devDto -> {
                devDto.setNow(now);
            });
            for (DevDto dev : pointDevs) {
                try {
                    Integer devProTy = dev.getDevProTy();
                    //如果为总监测点设备
                    if (devProTy <= 0) {
                        continue;
                    }
                    //设备功率门限时间
                    Integer devPowerLiveTime = null;
                    //设备启停功率阈值
                    Integer devPowerSillVal = null;
                    //设备额定功率
                    Integer devPower = null;

                    //产污设备
                    if (devProTy.equals(1)) {
                        devPowerLiveTime = lookPoint.getPollDevPowerLiveTime();
                        devPowerSillVal = lookPoint.getPollDevPowerSillVal();
                        devPower = lookPoint.getPollDevPower();
                    } else if (devProTy.equals(2)) {
                        //治污设备
                        devPowerLiveTime = lookPoint.getConDevPowerLiveTime();
                        devPowerSillVal = lookPoint.getConDevPowerSillVal();
                        devPower = lookPoint.getConDevPower();
                    } else {
                        log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        log.error("设备:" + dev.toString() + "产治污类型异常,devProTy:" + devProTy);
                        log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        continue;
                    }
                    //计算设备上传数据包数的开始时间
                    DateTime sBeginTime = frontTimeArea[0];
                    DateTime eEndTime = frontTimeArea[1];
                    if (devPowerLiveTime >= 20) {
                        sBeginTime = frontTimeArea[1].minus(devPowerLiveTime * 60 * 1000);
                    }
                    //获取HBase数据--指定时间内的每个节点最多10条数据
                    List<realValueList1> dataPackages = hbScheduledService.getDataPackagesOfTimeArea(sBeginTime, eEndTime, dev.getDevIdpk());

                    //默认当前设备失联状态 4
                    int state = 4;
                    //此处只判断了第一个节点"PA" 的实时值
                    if (dataPackages.get(0).getRows().size() > 0) {
                        //获取平均功率
                        double avgPower = hbScheduledService.getAvgPower(dataPackages, dev.getDevIdpk());
                        //判断设备状态
                        state = hbScheduledService.countJudgeDevWorkStatus(devPowerSillVal, avgPower, devPower);
                        //如果设备处于运行状态,修改单位生产时间 +20分钟,只修改一次
                        if (state == 1 || state == 2) {
                            //如果当前单位没有累加过生产时间，并且当前设备为产污设备则给当前单位的累加生产时间+20分钟
                            if (!unitSet.contains(dev.getUnitId()) && devProTy.equals(1)) {
                                //获取单位和减产减排方案的关联数据(10分钟缓存)
                                HbyReduceplanJoinProject reducePlanJoin = hbScheduledService.findReducePlanJoinUnitByUnitId(dev.getUnitId());
                                if (reducePlanJoin != null) {
                                    long sumTime = reducePlanJoin.getSumProTime() == null ? 0 : reducePlanJoin.getSumProTime();
                                    reducePlanJoin.setSumProTime(sumTime + 20);
                                    hbyReduceplanJoinProjectService.updateById(reducePlanJoin);
                                    unitSet.add(dev.getUnitId());
                                }
                            }
                        }
                    }
                    //将结果存入到数据库,当前时间点为当前时间的上一个区间的结束时间
                    hbScheduledService.updateOrInsertWorkStatus(eEndTime, dev, state);
                    log.error("saveOrUpdate设备工况完成，时间：{}，设备：{}，状态：{}", eEndTime.toString(), dev.toString(), state);
                    long end = System.currentTimeMillis();
                    log.error("==============================================本次设备24小时工况监控程序耗时: "
                            + (BigDecimalUtils.calculate(end - start).div(1000).div(60).getBigDecimal().doubleValue()) + "分钟!================================================");
                } catch (Exception e) {
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~24小时工况程序异常，报错信息为~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    log.error(e.getMessage(), e);
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    continue;
                }

            }

        }

    }
    //}

}
