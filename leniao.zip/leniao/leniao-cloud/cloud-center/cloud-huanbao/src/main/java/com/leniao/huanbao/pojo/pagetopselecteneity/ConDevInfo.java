package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/23 17:17
 * @update
 * @description
 */
public class ConDevInfo {
    //治污设备额定功率
    private String conDevPower;
    //治污设备功率启停阈值
    private String conDevPowerSillVal;
    //治污设备功率门限时间
    private String conDevPowerLiveTime;
    //治污设备电量阈值
    private String conDevEleSillVal;
    //治污设备电量门限时间
    private String conDevEleLiveTime;
    //治污设备分类
    private String conDevType;

    public String getConDevPower() {
        return conDevPower;
    }

    public void setConDevPower(String conDevPower) {
        this.conDevPower = conDevPower;
    }

    public String getConDevPowerSillVal() {
        return conDevPowerSillVal;
    }

    public void setConDevPowerSillVal(String conDevPowerSillVal) {
        this.conDevPowerSillVal = conDevPowerSillVal;
    }

    public String getConDevPowerLiveTime() {
        return conDevPowerLiveTime;
    }

    public void setConDevPowerLiveTime(String conDevPowerLiveTime) {
        this.conDevPowerLiveTime = conDevPowerLiveTime;
    }

    public String getConDevEleSillVal() {
        return conDevEleSillVal;
    }

    public void setConDevEleSillVal(String conDevEleSillVal) {
        this.conDevEleSillVal = conDevEleSillVal;
    }

    public String getConDevEleLiveTime() {
        return conDevEleLiveTime;
    }

    public void setConDevEleLiveTime(String conDevEleLiveTime) {
        this.conDevEleLiveTime = conDevEleLiveTime;
    }

    public String getConDevType() {
        return conDevType;
    }

    public void setConDevType(String conDevType) {
        this.conDevType = conDevType;
    }
}
