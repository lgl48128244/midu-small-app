package com.leniao.huanbao.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.entity.HbyOverlookJoin;
import com.leniao.huanbao.entity.Tblndevsys;
import com.leniao.huanbao.entity.Tblnprojectinfo;
import com.leniao.huanbao.mapper.HbyOverlookpointPlusMapper;
import com.leniao.huanbao.mapper.TbdeviceInfoPlusMapper;
import com.leniao.huanbao.mapper.TblngroupMapper;
import com.leniao.huanbao.pojo.pagetopselecteneity.*;
import com.leniao.huanbao.pojo.receive.ManyDelLookPoint;
import com.leniao.huanbao.service.*;
import com.leniao.huanbao.utils.APIConstant;
import com.leniao.huanbao.utils.DevUtils;
import com.leniao.huanbao.utils.EntranceConstant;
import com.leniao.mapper.HbyOverLookPointMapper;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.leniao.commons.exception.CloudErrorCode.SYS_EMPTY;
import static com.leniao.huanbao.utils.DevUtils.removeDuplicate;


/**
 * @author liudongshuai
 * @date 2019/12/22 22:03
 * @update
 * @description
 */
@CrossOrigin
@RestController
@RequestMapping(EntranceConstant.BASELOOKPOINT)
public class BaselookPointAdminController extends BaseController {
    /**
     * 监测点信息表
     */
    @Resource
    private HbyOverLookpointService hbyOverlookpointService;
    /**
     * 分组信息表
     */
    @Resource
    private TblngroupService tblngroupService;
    /**
     * 设备系统信息表
     */
    @Resource
    private TblndevsysService tblndevsysService;
    /**
     * 设备信息表
     */
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    /**
     * 监测点产污治污设备关联表
     */
    @Resource
    private HbyOverlookJoinService hbyOverlookJoinService;
    /**
     * 环保局信息表
     */
    @Resource
    private HbyAgencyService hbyAgencyService;
    @Resource
    private HbyOverLookPointMapper hbyOverLookPointMapper;
    /**
     * 设备监测点关联表
     */
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    @Resource
    private HbyOverlookpointPlusMapper hbyOverlookpointPlusMapper;
    @Resource
    private TbdeviceInfoPlusMapper tbdeviceInfoPlusMapper;
    @Resource
    private TblngroupMapper tblngroupMapper;
    @Resource
    private TblnprojectinfoService tblnprojectinfoService;
    @Resource
    private HbyProjectstatusService hbyProjectstatusService;
    @Resource
    private HbScheduledService hbScheduledService;

    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @RequestMapping(APIConstant.LOOKPOINTADMININFO)
    public Object defaultLookPointView(@RequestBody HashMap<String, String> receiveMap) {
        PageHelper.startPage(Integer.parseInt(receiveMap.get("page")), Integer.parseInt(receiveMap.get("size")));
        PageInfo<LookPointAdminInfo> pageInfo = new PageInfo<>(hbyOverlookpointPlusMapper.lookPointInfo(Integer.valueOf(String.valueOf(receiveMap.get("unitId")))));
        List<LookPointAdminInfo> lookPointAdminInfoList = pageInfo.getList();
        for (LookPointAdminInfo lookPointAdminInfo:lookPointAdminInfoList) {
            lookPointAdminInfo.setPollNum(hbyOverLookDevJoinService.findPollsNumByLookPointId(Long.valueOf(lookPointAdminInfo.getLookId())).size());
            lookPointAdminInfo.setConNum(hbyOverLookDevJoinService.findConsNumByLookPointId(Long.valueOf(lookPointAdminInfo.getLookId())).size());
            try {
                lookPointAdminInfo.setAddTime(simpleDateFormat.format(simpleDateFormat.parse(lookPointAdminInfo.getAddTime())));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return renderResult(pageInfo);
    }

    @RequestMapping(value = APIConstant.ADDLOOKPOINT, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object addLookPoint(@RequestBody AddlookPointInfo addlookPointInfo) {
        Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(Integer.valueOf(addlookPointInfo.getUnitId()));
        UserInfo userInfo = this.getUserInfo();
        HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(),userInfo.getPlatformId());
        if ((hbyAgency==null)||(tblnprojectinfo.getIndustryid()==null)){
            return renderResult(false,-1,"该单位区域无环保局，请返回添加后再尝试添加");
        }else {
            Map<String, Object> resultMap = new HashMap<>();
            if (addlookPointInfo.getCheckId().equals("1")) {

                HbyOverLookPoint hbyOverlookpoint = new HbyOverLookPoint();
                Long aLong = new SnowflakeConfig().nextId();
                hbyOverlookpoint.setId(aLong);
                hbyOverlookpoint.setUnitId(Integer.parseInt(addlookPointInfo.getUnitId()));
                hbyOverlookpoint.setUpdateUser(addlookPointInfo.getUserId());
                Date date = new Date();
                hbyOverlookpoint.setUpdateTime(date);
                hbyOverlookpoint.setCreateTime(date);
                hbyOverlookpoint.setDeleted(0);

                hbyOverlookpoint.setUnitId(Integer.parseInt(addlookPointInfo.getUnitId()));
                hbyOverlookpoint.setUpdateTime(date);
                hbyOverlookpoint.setOverLookName(addlookPointInfo.getLookPointName());
                hbyOverlookpoint.setDevGroupId(Integer.valueOf(addlookPointInfo.getGroupId()));
                hbyOverlookpoint.setIsDemoBox(Integer.valueOf(addlookPointInfo.getIsDemoBox()));
                hbyOverlookpoint.setDevUsing(addlookPointInfo.getDevUsing());
                hbyOverlookpoint.setRemark(addlookPointInfo.getRemark());
                hbyOverlookpoint.setPointType(Integer.valueOf(addlookPointInfo.getPointType()));
                hbyOverlookpoint.setPlatformId(this.getUserInfo().getPlatformId());

                if (addlookPointInfo.getPointType()==0 ) {
                    if (isTotalDev(Integer.parseInt(addlookPointInfo.getUnitId()))){
                        if (isOnlyTotalLookPoint(tblndeviceinfoService.findDevIdPk(addlookPointInfo.getDevSign()))) {
                            hbyOverlookpointService.addLookPointTotal2(hbyOverlookpoint,addlookPointInfo.getDevSign());
                            return renderResult();
                        } else {
                            return renderResult(false,-1,"监测点设备不符合要求，请检查该设备是否已被添加");
                        }
                    }else {
                        return renderResult(false,-1,"该单位下总监测点已经存在");
                    }
                } else if (addlookPointInfo.getPointType()==1) {

                    //产污监测信息
                    hbyOverlookpoint.setPollDevPower(Integer.valueOf(addlookPointInfo.getPollDevPower()));
                    hbyOverlookpoint.setPollDevPowerSillVal(Integer.valueOf(addlookPointInfo.getPollDevPowerSillVal()));
                    hbyOverlookpoint.setPollDevPowerLiveTime(Integer.valueOf(addlookPointInfo.getPollDevPowerLiveTime()));
                    hbyOverlookpoint.setPollDevEleSillVal(Integer.valueOf(addlookPointInfo.getPollDevEleSillVal()));
                    hbyOverlookpoint.setPollDevEleLiveTime(Integer.valueOf(addlookPointInfo.getPollDevEleLiveTime()));
                    hbyOverlookpoint.setPollDevType(Integer.valueOf(addlookPointInfo.getPollDevType()));
                    //治污监测信息
                    hbyOverlookpoint.setConDevPower(Integer.valueOf(addlookPointInfo.getConDevPower()));
                    hbyOverlookpoint.setConDevPowerSillVal(Integer.valueOf(addlookPointInfo.getConDevPowerSillVal()));
                    hbyOverlookpoint.setConDevEleSillVal(Integer.valueOf(addlookPointInfo.getConDevEleSillVal()));
                    hbyOverlookpoint.setConDevPowerLiveTime(Integer.valueOf(addlookPointInfo.getConDevPowerLiveTime()));
                    hbyOverlookpoint.setConDevEleLiveTime(Integer.valueOf(addlookPointInfo.getConDevEleLiveTime()));
                    hbyOverlookpoint.setConDevType(Integer.valueOf(addlookPointInfo.getConDevType()));

                    addlookPointInfo.setCons(removeDuplicate(addlookPointInfo.getCons()));
                    addlookPointInfo.setPolls(removeDuplicate(addlookPointInfo.getPolls()));
                    //一重校验 检验选择的产治污设备是否有重合
                    if (DevUtils.getRepetition(addlookPointInfo.getPolls(), addlookPointInfo.getCons())) {
                        Integer count = 0;
                        //二重校验 检验选择的产治污设备是否至少都有一个
                        if ((addlookPointInfo.getCons().size() > 0 )&&( addlookPointInfo.getPolls().size() > 0)) {
                            //三重校验 校验选择的产污设备是否已经被添加过
                            if (isAddPollDevInfo(addlookPointInfo.getPolls())){
                                hbyOverlookpointService.addLookPoint2(hbyOverlookpoint,addlookPointInfo.getPolls(),addlookPointInfo.getCons());
                                List<UnitBasicInfoDto> unitBasicInfoDtoList = new ArrayList<>();
                                UnitBasicInfoDto unitBasicInfoDto = new UnitBasicInfoDto();
                                unitBasicInfoDto.setUnitId(tblnprojectinfo.getProjid());
                                unitBasicInfoDto.setUnitName(tblnprojectinfo.getProjname());
                                unitBasicInfoDto.setProvinceCode(tblnprojectinfo.getProprovincecode());
                                unitBasicInfoDto.setCityCode(tblnprojectinfo.getProcitycode());
                                unitBasicInfoDto.setAreaCode(tblnprojectinfo.getProareacode());
                                unitBasicInfoDto.setIndustryId(tblnprojectinfo.getIndustryid());
                                unitBasicInfoDto.setPlatformId(tblnprojectinfo.getPlatformid());
                                unitBasicInfoDtoList.add(unitBasicInfoDto);
                                hbScheduledService.updateOrInsertUnitInfo(unitBasicInfoDtoList);
                                return renderResult();
                            }else {
                                return renderResult(false,-1,"该产污设备已经被添加，请重新选择");
                            }
                        } else {
                            return renderResult(false,-1,"请选择至少一个产治污设备");
                        }
                    } else {
                        return renderResult(false,-1,"设备选择冲突");
                    }
                } else {
                    return renderResult(false,-1,"参数错误，检查参数");
                }
            } else {
                return renderResult(false,-1,"参数错误，检查参数");
            }
        }
    }

    @RequestMapping(value = APIConstant.DELLOOKPOINT, method = RequestMethod.POST)
    public Object deleteLookPoint(@RequestBody ManyDelLookPoint lookPointId) {
        /*Map<String, Object> resultMap = new HashMap<>();
        int count = 0;
        for (Long id : lookPointId.getLookPointId()) {
            if (delLookPointDevByLookPointId(id)) {
                resultMap.put("监测点" + hbyOverlookpointService.findOverLookPoint(id).getOverLookName() + "关联产治设备解除关系",hbyOverlookpointService.deleteLookPoint(id));
                count++;
            }
            hbyOverlookpointService.deleteLookPoint(id);
        }
        resultMap.put("影响行数", count);
        return renderResult(resultMap);*/

        hbyOverlookpointService.removeLookPoint(lookPointId.getLookPointId());
        return renderResult();
    }

    @RequestMapping(value = APIConstant.UPDATELOOKPOINT, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object updateLookPoint(@RequestBody AddlookPointInfo addlookPointInfo) {
        List<Long> lookPointList = new ArrayList<>();
        if (addlookPointInfo.getCheckId().equals("2")) {
            HbyOverLookPoint hbyOverlookpoint = hbyOverlookpointService.findOverLookPoint(Long.parseLong(addlookPointInfo.getUpdateId()));
            hbyOverlookpoint.setUnitId(Integer.parseInt(addlookPointInfo.getUnitId()));
            hbyOverlookpoint.setUpdateUser(addlookPointInfo.getUserId());
            Date date = new Date();
            hbyOverlookpoint.setUnitId(Integer.parseInt(addlookPointInfo.getUnitId()));
            hbyOverlookpoint.setUpdateTime(date);
            hbyOverlookpoint.setOverLookName(addlookPointInfo.getLookPointName());
            hbyOverlookpoint.setDevGroupId(Integer.valueOf(addlookPointInfo.getGroupId()));
            hbyOverlookpoint.setIsDemoBox(Integer.valueOf(addlookPointInfo.getIsDemoBox()));
            hbyOverlookpoint.setDevUsing(addlookPointInfo.getDevUsing());
            hbyOverlookpoint.setRemark(addlookPointInfo.getRemark());
            hbyOverlookpoint.setPointType(Integer.valueOf(addlookPointInfo.getPointType()));
            hbyOverlookpoint.setPlatformId(this.getUserInfo().getPlatformId());
            if (addlookPointInfo.getPointType()==0) {
                Integer devIdpk = tblndeviceinfoService.findDevIdPk(addlookPointInfo.getDevSign());
                Integer devIdpkOld = hbyOverLookDevJoinService.findDevIdPkByLookPointId(Long.valueOf(addlookPointInfo.getUpdateId()));
                //1,先判断是否还是原设备，如果还是原设备就不需要对中间表进行写操作
                if (devIdpk.equals(devIdpkOld)){
                    //resultMap.put("总监测点修改", );
                    if (hbyOverlookpointService.updateLookPoint(hbyOverlookpoint)){
                        return renderResult("修改成功");
                    }else {
                        return renderResult(false,-1,"修改失败，请检查输入数据，再次尝试！");
                    }
                }else {
                    //如果不是原来的设备，删除总检测点的时候，若添加成功，才删除原有的中间表
                    //若删除失败，返回添加失败的信息
                    if (hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),devIdpk,
                            addlookPointInfo.getPointType())){
                        //删除原有的关联信息
                        hbyOverLookDevJoinService.removeLookDevJoin(Long.valueOf(addlookPointInfo.getUpdateId()),devIdpkOld);
                        return renderResult("修改成功");
                    }else {
                        return renderResult(false,-1,"修改失败，请检查输入数据，再次尝试！");
                    }
                }

            } else if (addlookPointInfo.getPointType()==1) {
                //产污监测信息
                hbyOverlookpoint.setPollDevPower(Integer.valueOf(addlookPointInfo.getPollDevPower()));
                hbyOverlookpoint.setPollDevPowerSillVal(Integer.valueOf(addlookPointInfo.getPollDevPowerSillVal()));
                hbyOverlookpoint.setPollDevPowerLiveTime(Integer.valueOf(addlookPointInfo.getPollDevPowerLiveTime()));
                hbyOverlookpoint.setPollDevEleSillVal(Integer.valueOf(addlookPointInfo.getPollDevEleSillVal()));
                hbyOverlookpoint.setPollDevEleLiveTime(Integer.valueOf(addlookPointInfo.getPollDevEleLiveTime()));
                hbyOverlookpoint.setPollDevType(Integer.valueOf(addlookPointInfo.getPollDevType()));
                //治污监测信息
                hbyOverlookpoint.setConDevPower(addlookPointInfo.getConDevPower());
                hbyOverlookpoint.setConDevPowerSillVal(addlookPointInfo.getConDevPowerSillVal());
                hbyOverlookpoint.setConDevEleSillVal(addlookPointInfo.getConDevEleSillVal());
                hbyOverlookpoint.setConDevPowerLiveTime(addlookPointInfo.getConDevPowerLiveTime());
                hbyOverlookpoint.setConDevEleLiveTime(addlookPointInfo.getConDevEleLiveTime());
                hbyOverlookpoint.setConDevType(addlookPointInfo.getConDevType());
                addlookPointInfo.setCons(removeDuplicate(addlookPointInfo.getCons()));
                addlookPointInfo.setPolls(removeDuplicate(addlookPointInfo.getPolls()));
                //一重校验 检验选择的产治污设备是否有重合
                if (DevUtils.getRepetition(addlookPointInfo.getPolls(), addlookPointInfo.getCons())) {
                    //二重校验 检验选择的产治污设备是否至少都有一个
                    if (addlookPointInfo.getCons().size() > 0 && addlookPointInfo.getPolls().size() > 0) {
                        lookPointList.add(Long.valueOf(addlookPointInfo.getUpdateId()));
                        hbyOverlookpointService.updateLookPoint2(lookPointList,hbyOverlookpoint,addlookPointInfo.getPolls(),addlookPointInfo.getCons());
                        Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(Integer.valueOf(addlookPointInfo.getUnitId()));
                        List<UnitBasicInfoDto> unitBasicInfoDtoList = new ArrayList<>();
                        UnitBasicInfoDto unitBasicInfoDto = new UnitBasicInfoDto();
                        unitBasicInfoDto.setUnitId(tblnprojectinfo.getProjid());
                        unitBasicInfoDto.setUnitName(tblnprojectinfo.getProjname());
                        unitBasicInfoDto.setProvinceCode(tblnprojectinfo.getProprovincecode());
                        unitBasicInfoDto.setCityCode(tblnprojectinfo.getProcitycode());
                        unitBasicInfoDto.setAreaCode(tblnprojectinfo.getProareacode());
                        unitBasicInfoDto.setIndustryId(tblnprojectinfo.getIndustryid());
                        unitBasicInfoDto.setPlatformId(tblnprojectinfo.getPlatformid());
                        unitBasicInfoDtoList.add(unitBasicInfoDto);
                        hbScheduledService.updateOrInsertUnitInfo(unitBasicInfoDtoList);
                        return renderResult();
                    } else {
                        return renderResult(false,-1,"请选择至少一个产治污设备");
                    }
                } else {
                    return renderResult(false,-1,"设备选择冲突");
                }
            } else {
                return renderResult(false,-1,"参数错误，检查参数");
            }
        } else {
            return renderResult(false,-1,"参数错误，检查参数");
        }

    }

    @RequestMapping(value = APIConstant.LOOKPOINTINFOVIEW, method = RequestMethod.POST)
    public Object lookPointInfoView(@RequestParam("lookPointId") String lookPointId) {
        HbyOverLookPoint hbyOverlookpoint = hbyOverlookpointService.findOverLookPoint(Long.valueOf(lookPointId));
        AddlookPointInfo addlookPointInfo = new AddlookPointInfo();
        addlookPointInfo.setUnitId(String.valueOf(hbyOverlookpoint.getUnitId()));
        addlookPointInfo.setUserId(String.valueOf(hbyOverlookpoint.getUpdateUser()));
        addlookPointInfo.setLookPointName(hbyOverlookpoint.getOverLookName());
        addlookPointInfo.setGroupId(String.valueOf(hbyOverlookpoint.getDevGroupId()));
        addlookPointInfo.setGroup(tblngroupService.findGroupName(hbyOverlookpoint.getDevGroupId()));
        addlookPointInfo.setIsDemoBox(hbyOverlookpoint.getIsDemoBox());
        addlookPointInfo.setDevUsing(hbyOverlookpoint.getDevUsing());
        addlookPointInfo.setRemark(hbyOverlookpoint.getRemark());
        addlookPointInfo.setCheckId("2");
        addlookPointInfo.setUpdateId(lookPointId);
        if (hbyOverlookpoint.getPointType() == 0) {
            //总监测点
            addlookPointInfo.setPointType(hbyOverlookpoint.getPointType());
            List<String> cons = new ArrayList<>();
            List<String> polls = new ArrayList<>();
            addlookPointInfo.setCons(cons);
            addlookPointInfo.setPolls(polls);
            Integer devId = hbyOverLookDevJoinService.findDevIdPkByLookPointId(Long.valueOf(lookPointId));

            addlookPointInfo.setDevSign(tblndeviceinfoService.findLocation(devId)+"+"+tblndeviceinfoService.findDevSignById(devId));
            return renderResult(addlookPointInfo);
        } else if ((hbyOverlookpoint.getPointType() == 1) || (hbyOverlookpoint.getPointType() == 2)) {
            //产污监测点
            addlookPointInfo.setPointType(hbyOverlookpoint.getPointType());

            addlookPointInfo.setPointType(hbyOverlookpoint.getPointType());
            addlookPointInfo.setPollDevPower(hbyOverlookpoint.getPollDevPower());
            addlookPointInfo.setPollDevPowerSillVal(hbyOverlookpoint.getPollDevPowerSillVal());
            addlookPointInfo.setPollDevPowerLiveTime(hbyOverlookpoint.getPollDevPowerLiveTime());
            addlookPointInfo.setPollDevEleSillVal(hbyOverlookpoint.getPollDevEleSillVal());
            addlookPointInfo.setPollDevEleLiveTime(hbyOverlookpoint.getPollDevEleLiveTime());
            addlookPointInfo.setPollDevType(hbyOverlookpoint.getPollDevType());
            addlookPointInfo.setConDevPower(hbyOverlookpoint.getConDevPower());
            addlookPointInfo.setConDevPowerSillVal(hbyOverlookpoint.getConDevPowerSillVal());
            addlookPointInfo.setConDevPowerLiveTime(hbyOverlookpoint.getConDevPowerLiveTime());
            addlookPointInfo.setConDevEleSillVal(hbyOverlookpoint.getConDevEleSillVal());
            addlookPointInfo.setConDevEleLiveTime(hbyOverlookpoint.getConDevEleLiveTime());
            addlookPointInfo.setConDevType(hbyOverlookpoint.getConDevType());
            //List<HbyOverlookJoin> hbyOverlookJoinList = hbyOverlookJoinService.finddevIdinfo(Long.valueOf(lookPointId));
            List<HbyOverLookDevJoin> hbyOverLookDevJoinConList = hbyOverLookDevJoinService.findConsNumByLookPointId(Long.valueOf(lookPointId));
            List<HbyOverLookDevJoin> hbyOverLookDevJoinPollList = hbyOverLookDevJoinService.findPollsNumByLookPointId(Long.valueOf(lookPointId));
            List<String> polls = new LinkedList<>();
            List<String> cons = new LinkedList<>();

//            for (HbyOverlookJoin hbyOverlookJoin : hbyOverlookJoinList) {
//                polls.add(tblndeviceinfoService.findLocation(hbyOverlookJoin.getPollDevId())+"+"+tblndeviceinfoService.findDevSignById(hbyOverlookJoin.getPollDevId()));
//                cons.add(tblndeviceinfoService.findLocation(hbyOverlookJoin.getPollDevId())+"+"+tblndeviceinfoService.findDevSignById(hbyOverlookJoin.getConDevId()));
//            }
            for (HbyOverLookDevJoin hbyCon:hbyOverLookDevJoinConList ) {
                cons.add(tblndeviceinfoService.findLocation(hbyCon.getDevIdpk())+"+"+tblndeviceinfoService.findDevSignById(hbyCon.getDevIdpk()));
            }
            for (HbyOverLookDevJoin hbyPoll:hbyOverLookDevJoinPollList ) {
                polls.add(tblndeviceinfoService.findLocation(hbyPoll.getDevIdpk())+"+"+tblndeviceinfoService.findDevSignById(hbyPoll.getDevIdpk()));
            }
            addlookPointInfo.setPolls(removeDuplicate(polls));
            addlookPointInfo.setCons(removeDuplicate(cons));

            return renderResult(addlookPointInfo);

        } else {
            return SYS_EMPTY;
        }
    }

    @RequestMapping(value = APIConstant.GROUPDEVSIGN, method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object sendGroupDevSign(@RequestBody HashMap<String, Object> receiveMap) {
        List<AddLookPointDevSignInfo> addLookPointDevSignInfoList = new ArrayList<>();
        //List<Tblndeviceinfo> tblndeviceinfoList = tblndeviceinfoService.findDevSign();
        List<AddLookPointDevSignInfo> addLookPointDevSignInfos = tbdeviceInfoPlusMapper.findDevSignInfoByGroupId(Integer.valueOf(String.valueOf(receiveMap.get("groupId"))));
        //总监测点设备列表展示
        if (String.valueOf(receiveMap.get("type")).equals("0")) {
            for (AddLookPointDevSignInfo addLookPointInfo : addLookPointDevSignInfos) {
                if (isOnlyTotalLookPoint(tblndeviceinfoService.findDevIdPk(addLookPointInfo.getSignature()))) {
                    addLookPointDevSignInfoList.add(addLookPointInfo);
                }
            }

        } else if (String.valueOf(receiveMap.get("type")).equals("1")) {
            //产污设备
            for (AddLookPointDevSignInfo addLookPointInfo : addLookPointDevSignInfos) {
                if (isAddPollConDevLookPoint(tblndeviceinfoService.findDevIdPk(addLookPointInfo.getSignature()),1)) {
                    addLookPointDevSignInfoList.add(addLookPointInfo);
                }
            }

        } else if (String.valueOf(receiveMap.get("type")).equals("2")) {
            //治污设备
            for (AddLookPointDevSignInfo addLookPointInfo : addLookPointDevSignInfos) {
                if (isAddPollConDevLookPoint(tblndeviceinfoService.findDevIdPk(addLookPointInfo.getSignature()),2)) {
                    addLookPointDevSignInfoList.add(addLookPointInfo);
                }
            }
        }

        return renderResult(addLookPointDevSignInfoList);
    }

    @RequestMapping(value = APIConstant.ISADDINDUSTRYAGENCY, method = RequestMethod.POST)
    public Object isAddIndustryAgency(@RequestParam("unitId") Integer unitId){
        Tblnprojectinfo tblnprojectinfo = tblnprojectinfoService.findUnitAreaNameInfo(unitId);
        if (tblnprojectinfo==null){
            return renderResult(false,-1,"异常单位，请选择其他单位");
        }
        /*if ((tblnprojectinfo.getIndustryid()==0)||(tblnprojectinfo.getIndustryid()==null)){
            return renderResult(false,-1,"该单位未绑定行业，请返回添加后再尝试添加");
        }*/
        UserInfo userInfo = this.getUserInfo();
        HbyAgency hbyAgency = hbyAgencyService.selectByAreaCode(tblnprojectinfo.getProprovincecode(),tblnprojectinfo.getProcitycode(),tblnprojectinfo.getProareacode(), userInfo.getPlatformId());
        if (hbyAgency==null){
            return renderResult(false,-1,"该单位未绑定环保局，请返回添加后再尝试添加");
        }
        List<GroupIdNameInfo> groupIdNameInfoList = tbdeviceInfoPlusMapper.findGroupNameIdByUnitId(unitId);
        if (groupIdNameInfoList.size()==0){
            return renderResult(false,-1,"该单位没有智慧用电设备，请添加后再试！");
        }

        return renderResult();
    }

    /**
     * 添加总监测点时判断该设备是否能添加为总监测点设备
     *
     * @param devIdpk
     * @return
     */
    public boolean isOnlyTotalLookPoint(Integer devIdpk) {
        List<HbyOverLookDevJoin> hbyOverlookDevJoinList = hbyOverLookDevJoinService.findLookPointInfoByDevId(devIdpk);
        if ((hbyOverlookDevJoinList == null) || (hbyOverlookDevJoinList.size() == 0)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断该设备是否已经关联了产污
     * @param devIdpk
     * @param type
     * @return
     */
    public boolean isAddPollConDevLookPoint(Integer devIdpk,Integer type) {
        List<HbyOverLookDevJoin> hbyOverlookDevJoinList = hbyOverLookDevJoinService.findLookPointInfoByDevId(devIdpk);
        if (type==1){//产污设备
            if ((hbyOverlookDevJoinList.size() == 0)) {
                return true;
            } else {
                return false;
            }
        }else {//治污设备
            if (((hbyOverlookDevJoinList.size()==0)||hbyOverlookDevJoinList.get(0).getDevProTy() == 2)) {
                return true;
            } else {
                return false;
            }
        }

    }

    /**
     * 删除监测点关联的原中间表关系
     *
     * @param lookPointId
     * @return
     */
    public boolean delLookPointDevByLookPointId(Long lookPointId) {
        return hbyOverLookDevJoinService.removeLookDevJoin(lookPointId) && hbyOverlookJoinService.removeLookJoin(lookPointId);
    }

    /**
     * 判断一个单位的分组下是否只有一个总监测点
     * @param unitId
     * @param groupId
     * @return
     */
    public boolean isOnlyTotalOnGroup(Integer unitId,Integer groupId){
        QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        queryWrapper.select().lambda().eq(HbyOverLookPoint::getUnitId,unitId).eq(HbyOverLookPoint::getDevGroupId,groupId).eq(HbyOverLookPoint::getDeleted,0);
        List<HbyOverLookPoint> hbyOverLookPointList = hbyOverLookPointMapper.selectList(queryWrapper);
        return hbyOverLookPointList.size()==0;
    }

    /**
     * 判断一个单位是否只有一个总表设备
     * @param unitId
     * @return
     */
    public boolean isTotalDev(Integer unitId){
        QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        queryWrapper.select().lambda().eq(HbyOverLookPoint::getUnitId,unitId).eq(HbyOverLookPoint::getPointType,0).eq(HbyOverLookPoint::getDeleted,0);
        List<HbyOverLookPoint> hbyOverLookPointList = hbyOverLookPointMapper.selectList(queryWrapper);
        return hbyOverLookPointList.size()==0;
    }

    public  boolean isAddPollDevInfo(List<String> polls){
        Integer count = 0;
        for (String devSign:polls ) {
            if (hbyOverLookDevJoinService.findLookPointInfoByDevId(tblndeviceinfoService.findDevIdPk(devSign)).size()>0){
                count++;
            }
        }
        if (count==0){
            return true;
        }else {
            return false;
        }
    }

    @RequestMapping(value = APIConstant.GROUPIDNAME, method = RequestMethod.POST)
    public Object sendGroupIdNameInfo(@RequestParam("unitId") String unitId) {
        return renderResult(tbdeviceInfoPlusMapper.findGroupNameIdByUnitId(Integer.valueOf(unitId)));
    }

    @RequestMapping(value = APIConstant.DEVSYSIDNAME, method = RequestMethod.POST)
    public Object sendDevSysNameId() {
        List<DevSysNameIdInfo> devSysNameIdInfoList = new LinkedList<>();
        List<Tblndevsys> tblndevsysList = tblndevsysService.findDevSysNameId();
        for (Tblndevsys devsys : tblndevsysList) {
            DevSysNameIdInfo devSysNameIdInfo = new DevSysNameIdInfo();
            devSysNameIdInfo.setDevsysId(String.valueOf(devsys.getDevsysid()));
            devSysNameIdInfo.setDevsysName(devsys.getDevsysname());
            devSysNameIdInfoList.add(devSysNameIdInfo);
        }
        return renderResult(devSysNameIdInfoList);
    }

}
