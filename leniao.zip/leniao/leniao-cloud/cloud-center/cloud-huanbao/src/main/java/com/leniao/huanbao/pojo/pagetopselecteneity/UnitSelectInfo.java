package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author songtm
 * @date 2019/12/19 15:08
 */
public class UnitSelectInfo {
    /**
     * 单位ID
     * */
    private Integer unitId;
    /**
     * 单位名称
     * */
    private String unitName;

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    @Override
    public String toString() {
        return "UnitSelectInfo{" +
                "unitId=" + unitId +
                ", unitName='" + unitName + '\'' +
                '}';
    }
}
