package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlanExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyReduceEmmissionPlanMapper extends BaseMapper<HbyReduceEmmissionPlan> {
    long countByExample(HbyReduceEmmissionPlanExample example);

    int deleteByExample(HbyReduceEmmissionPlanExample example);

    int deleteByPrimaryKey(Long planId);

    int insert(HbyReduceEmmissionPlan record);

    int insertSelective(HbyReduceEmmissionPlan record);

    List<HbyReduceEmmissionPlan> selectByExampleWithBLOBs(HbyReduceEmmissionPlanExample example);

    List<HbyReduceEmmissionPlan> selectByExample(HbyReduceEmmissionPlanExample example);

    HbyReduceEmmissionPlan selectByPrimaryKey(Long planId);

    int updateByExampleSelective(@Param("record") HbyReduceEmmissionPlan record, @Param("example") HbyReduceEmmissionPlanExample example);

    int updateByExampleWithBLOBs(@Param("record") HbyReduceEmmissionPlan record, @Param("example") HbyReduceEmmissionPlanExample example);

    int updateByExample(@Param("record") HbyReduceEmmissionPlan record, @Param("example") HbyReduceEmmissionPlanExample example);

    int updateByPrimaryKeySelective(HbyReduceEmmissionPlan record);

    int updateByPrimaryKeyWithBLOBs(HbyReduceEmmissionPlan record);

    int updateByPrimaryKey(HbyReduceEmmissionPlan record);
}