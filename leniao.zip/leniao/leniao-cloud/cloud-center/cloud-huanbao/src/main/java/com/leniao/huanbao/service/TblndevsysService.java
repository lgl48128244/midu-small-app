package com.leniao.huanbao.service;

import com.leniao.huanbao.entity.Tblndevsys;

import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/23 15:33
 * @update
 * @description
 */

public interface TblndevsysService {

    /**
     * 查出所有的设备系统，以及系统ID
     */
    List<Tblndevsys> findDevSysNameId();
}
