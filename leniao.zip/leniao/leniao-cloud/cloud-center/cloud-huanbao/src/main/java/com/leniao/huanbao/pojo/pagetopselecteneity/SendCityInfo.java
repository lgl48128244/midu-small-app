package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/20 16:53
 * @update
 * @description
 */
public class SendCityInfo {

    private String cityId;
    private String city;

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "SendCityInfo{" +
                "cityId='" + cityId + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
