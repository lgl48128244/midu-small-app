package com.leniao.huanbao.dto.schedule;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @Description:    封装单位简单基本信息的Dto
 * @Author:         haosw
 * @CreateDate:     2019/12/23 11:12
 * @Version:        1.0
 */
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UnitBasicInfoDto implements Serializable {

    private Integer unitId;
    private Long industryId;
    private String unitName;
    private String provinceCode;
    private String cityCode;
    private String areaCode;
    private Integer platformId;


}
