package com.leniao.huanbao.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.Areaarea;

public interface AreaareaMapper extends BaseMapper<Areaarea> {

}
