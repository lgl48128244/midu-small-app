package com.leniao.huanbao.schedule.udpbean;

import java.util.Date;

/**
 * @program: leniaorestful
 * @description:
 * @author: lwl
 * @create: 2019-06-06 13:23
 **/
public class UshareDeviceElectricuse {
    private Integer idPk; //
    private int devIdpk; // 设备表的主键
    private int unitId; // 单位表(老项目表)主键

    private double h1; // 第1小时用电平均值
    private double h2; // 第1小时用电平均值
    private double h3; // 第1小时用电平均值
    private double h4; // 第1小时用电平均值
    private double h5; // 第1小时用电平均值
    private double h6; // 第1小时用电平均值
    private double h7; // 第1小时用电平均值
    private double h8; // 第1小时用电平均值
    private double h9; // 第1小时用电平均值
    private double h10; // 第1小时用电平均值
    private double h11; // 第1小时用电平均值
    private double h12; // 第1小时用电平均值
    private double h13; // 第1小时用电平均值
    private double h14; // 第1小时用电平均值
    private double h15; // 第1小时用电平均值
    private double h16; // 第1小时用电平均值
    private double h17; // 第1小时用电平均值
    private double h18; // 第1小时用电平均值
    private double h19; // 第1小时用电平均值
    private double h20; // 第1小时用电平均值
    private double h21; // 第1小时用电平均值
    private double h22; // 第1小时用电平均值
    private double h23; // 第1小时用电平均值
    private double h24; // 第1小时用电平均值

    private Date addtime; // 添加时间
    private int elYear; // 年
    private int elMonth; // 月
    private int elWeek; // 周
    private double dayTotalQ; // 当天总用电量
    private double dayTotalFee; // 当天总电费
    private double dayCharge; // 当天电费单价
    private double devTotalQ; // 设备用电总量（2019-10-29开始弃用）
    private Date updateTime; // 最近上报数据时间
    // ----------2019-10-29 新加--------
    private double beforeTodayTotalQ; // 设备今天以前总用电量（安装开始到昨天的总用电量）
    private double beforeTodayTotalFee; // 设备今天以前总电费（安装开始到昨天的总电费）
    private int devRealTotalQ; // 设备实时总用电量

    public double getDevTotalQ() {
        return devTotalQ;
    }

    public void setDevTotalQ(double devTotalQ) {
        this.devTotalQ = devTotalQ;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIdPk() {
        return idPk;
    }

    public void setIdPk(Integer idPk) {
        this.idPk = idPk;
    }

    public int getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(int devIdpk) {
        this.devIdpk = devIdpk;
    }

    public int getUnitId() {
        return unitId;
    }

    public void setUnitId(int unitId) {
        this.unitId = unitId;
    }

    public double getH1() {
        return h1;
    }

    public void setH1(double h1) {
        this.h1 = h1;
    }

    public double getH2() {
        return h2;
    }

    public void setH2(double h2) {
        this.h2 = h2;
    }

    public double getH3() {
        return h3;
    }

    public void setH3(double h3) {
        this.h3 = h3;
    }

    public double getH4() {
        return h4;
    }

    public void setH4(double h4) {
        this.h4 = h4;
    }

    public double getH5() {
        return h5;
    }

    public void setH5(double h5) {
        this.h5 = h5;
    }

    public double getH6() {
        return h6;
    }

    public void setH6(double h6) {
        this.h6 = h6;
    }

    public double getH7() {
        return h7;
    }

    public void setH7(double h7) {
        this.h7 = h7;
    }

    public double getH8() {
        return h8;
    }

    public void setH8(double h8) {
        this.h8 = h8;
    }

    public double getH9() {
        return h9;
    }

    public void setH9(double h9) {
        this.h9 = h9;
    }

    public double getH10() {
        return h10;
    }

    public void setH10(double h10) {
        this.h10 = h10;
    }

    public double getH11() {
        return h11;
    }

    public void setH11(double h11) {
        this.h11 = h11;
    }

    public double getH12() {
        return h12;
    }

    public void setH12(double h12) {
        this.h12 = h12;
    }

    public double getH13() {
        return h13;
    }

    public void setH13(double h13) {
        this.h13 = h13;
    }

    public double getH14() {
        return h14;
    }

    public void setH14(double h14) {
        this.h14 = h14;
    }

    public double getH15() {
        return h15;
    }

    public void setH15(double h15) {
        this.h15 = h15;
    }

    public double getH16() {
        return h16;
    }

    public void setH16(double h16) {
        this.h16 = h16;
    }

    public double getH17() {
        return h17;
    }

    public void setH17(double h17) {
        this.h17 = h17;
    }

    public double getH18() {
        return h18;
    }

    public void setH18(double h18) {
        this.h18 = h18;
    }

    public double getH19() {
        return h19;
    }

    public void setH19(double h19) {
        this.h19 = h19;
    }

    public double getH20() {
        return h20;
    }

    public void setH20(double h20) {
        this.h20 = h20;
    }

    public double getH21() {
        return h21;
    }

    public void setH21(double h21) {
        this.h21 = h21;
    }

    public double getH22() {
        return h22;
    }

    public void setH22(double h22) {
        this.h22 = h22;
    }

    public double getH23() {
        return h23;
    }

    public void setH23(double h23) {
        this.h23 = h23;
    }

    public double getH24() {
        return h24;
    }

    public void setH24(double h24) {
        this.h24 = h24;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public int getElYear() {
        return elYear;
    }

    public void setElYear(int elYear) {
        this.elYear = elYear;
    }

    public int getElMonth() {
        return elMonth;
    }

    public void setElMonth(int elMonth) {
        this.elMonth = elMonth;
    }

    public int getElWeek() {
        return elWeek;
    }

    public void setElWeek(int elWeek) {
        this.elWeek = elWeek;
    }

    public double getDayTotalQ() {
        return dayTotalQ;
    }

    public void setDayTotalQ(double dayTotalQ) {
        this.dayTotalQ = dayTotalQ;
    }

    public double getDayTotalFee() {
        return dayTotalFee;
    }

    public void setDayTotalFee(double dayTotalFee) {
        this.dayTotalFee = dayTotalFee;
    }

    public double getDayCharge() {
        return dayCharge;
    }

    public void setDayCharge(double dayCharge) {
        this.dayCharge = dayCharge;
    }

    public double getBeforeTodayTotalQ() {
        return beforeTodayTotalQ;
    }

    public void setBeforeTodayTotalQ(double beforeTodayTotalQ) {
        this.beforeTodayTotalQ = beforeTodayTotalQ;
    }

    public double getBeforeTodayTotalFee() {
        return beforeTodayTotalFee;
    }

    public void setBeforeTodayTotalFee(double beforeTodayTotalFee) {
        this.beforeTodayTotalFee = beforeTodayTotalFee;
    }

    public int getDevRealTotalQ() {
        return devRealTotalQ;
    }

    public void setDevRealTotalQ(int devRealTotalQ) {
        this.devRealTotalQ = devRealTotalQ;
    }
}
