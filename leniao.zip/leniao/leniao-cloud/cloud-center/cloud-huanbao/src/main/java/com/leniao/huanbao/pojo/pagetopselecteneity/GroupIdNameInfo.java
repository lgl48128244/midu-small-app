package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/23 15:11
 * @update
 * @description
 */
public class GroupIdNameInfo {

    //分组名称
    private String groupName;
    //分组id
    private String groupId;

    public String getGroup() {
        return groupName;
    }

    public void setGroup(String group) {
        this.groupName = group;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String toString() {
        return "GroupIdNameInfo{" +
                "group='" + groupName + '\'' +
                ", groupId='" + groupId + '\'' +
                '}';
    }
}
