package com.leniao.huanbao.schedule.udpbean;

import java.util.Date;

/**
 * @program: leniaorestful_springboot
 * @description: 单位峰谷电价
 * @author: j
 * @create: 2019-12-14 13:19
 **/
public class UshareCharge {

    private int id;
    private int userId;
    private int unitId;
    private double chargeVal;
    private Integer startTime;
    private Integer stopTime;
    private int chargeType;
    private int isDele;
    private Date addTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUnitId() {
        return unitId;
    }

    public void setUnitId(int unitId) {
        this.unitId = unitId;
    }

    public double getChargeVal() {
        return chargeVal;
    }

    public void setChargeVal(double chargeVal) {
        this.chargeVal = chargeVal;
    }

    public Integer getStartTime() {
        return startTime;
    }

    public void setStartTime(Integer startTime) {
        this.startTime = startTime;
    }

    public Integer getStopTime() {
        return stopTime;
    }

    public void setStopTime(Integer stopTime) {
        this.stopTime = stopTime;
    }

    public int getChargeType() {
        return chargeType;
    }

    public void setChargeType(int chargeType) {
        this.chargeType = chargeType;
    }

    public int getIsDele() {
        return isDele;
    }

    public void setIsDele(int isDele) {
        this.isDele = isDele;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }
}
