package com.leniao.huanbao.mapper;

import com.leniao.huanbao.pojo.pagetopselecteneity.LookPointAdminInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author liudongshuai
 * @date 2020/1/2 14:00
 * @update
 * @description
 */
@Mapper
public interface HbyOverlookpointPlusMapper {


    @Select("SELECT id AS lookId,over_look_name AS lookPointName,deleted AS isDelete,create_time AS addTime,point_type AS lookPointType,remark,groupName FROM hby_overlookpoint,tblngroup WHERE groupId = dev_group_id AND deleted = 0 AND unit_id =#{unitId} ORDER BY create_time DESC")
    List<LookPointAdminInfo> lookPointInfo(Integer unitId);

    @Select("SELECT " +
            " hby_overlook_dev_join.dev_idpk " +
            "FROM " +
            " hby_overlookpoint, " +
            " hby_overlook_dev_join " +
            "WHERE " +
            " hby_overlookpoint.id = hby_overlook_dev_join.look_id " +
            "AND hby_overlookpoint.deleted = 0 " +
            "AND hby_overlookpoint.unit_id = #{unitId} ")
    List<Integer> findDevIdByUnitId(Integer unitId);

    @Select("SELECT hby_overlook_dev_join.dev_idpk\n" +
            "FROM hby_overlookpoint,hby_overlook_dev_join\n" +
            "WHERE hby_overlookpoint.id = hby_overlook_dev_join.look_id\n" +
            "AND hby_overlookpoint.deleted = 0\n" +
            "AND hby_overlookpoint.point_type = 0\n" +
            "AND hby_overlookpoint.unit_id = #{unitId};")
    List<Integer> findTotalDevIdByUnitId(Integer unitId);

    @Select("${sql}")
    List<Integer> findDevIdByUnitId(String sql);

    @Select("${sql}")
    List<String> findDevIdByUnitId2(String sql);

    @Select("${sql}")
    Double findDevTotalQByUnitId(String sql);

}
