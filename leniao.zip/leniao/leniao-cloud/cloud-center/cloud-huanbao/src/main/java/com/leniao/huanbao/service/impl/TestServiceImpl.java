package com.leniao.huanbao.service.impl;

import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.service.TestServiceI;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import org.joda.time.DateTime;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

import static com.leniao.model.constant.SpringCacheConstants.DEFAULT_CACHE_KEY_GENERATOR;
import static com.leniao.model.constant.SpringCacheConstants.DEFAULT_CACHE_NAME;
import static com.leniao.model.constant.SpringCacheConstants.REDIS_CACHE_10MIN_NAME;
import static com.leniao.model.constant.SpringCacheConstants.REDIS_CACHE_1MIN_NAME;
import static com.leniao.model.constant.SpringCacheConstants.REDIS_CACHE_30MIN_NAME;
import static com.leniao.model.constant.SpringCacheConstants.REDIS_CACHE_60MIN_NAME;

/**
 * redis缓存测试
 *
 * @author 乐鸟研发
 */
@Service
public class TestServiceImpl implements TestServiceI {

    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;

    @Override
    @Cacheable(cacheNames = DEFAULT_CACHE_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public HbyProjectErrorInfo defaultCache(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    /**
     * TODO key: 自定义生成规则 keyGenerator: 系统默认生成规则
     * TODO key keyGenerator 不能同时存在
     */
    @Override
    @Cacheable(cacheNames = REDIS_CACHE_1MIN_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public HbyProjectErrorInfo redisCache1min(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    @Override
    @Cacheable(cacheNames = REDIS_CACHE_10MIN_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public HbyProjectErrorInfo redisCache10min(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    @Override
    @Cacheable(cacheNames = REDIS_CACHE_30MIN_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public HbyProjectErrorInfo redisCache30min(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    @Override
    @Cacheable(cacheNames = REDIS_CACHE_60MIN_NAME, /*key = "#param",*/ keyGenerator = DEFAULT_CACHE_KEY_GENERATOR)
    public HbyProjectErrorInfo redisCache60min(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    @Async("taskExecutor")
    @Override
    public void testAsync() {
        System.out.println("测试异步时间前：" + new DateTime().toString("yyyy-MM-dd HH:mm:ss"));
        try {
            Thread.sleep(2000);
        } catch (Exception ignored) {

        }
        System.out.println("测试异步时间后：" + new DateTime().toString("yyyy-MM-dd HH:mm:ss"));
    }

    @Override
    public void insertTx() {
        HbyProjectErrorInfo recode = new HbyProjectErrorInfo();
        hbyProjectErrorInfoMapper.insert(recode);
    }

    @Override
    public void deleteTx(Long id) {
        hbyProjectErrorInfoMapper.deleteByPrimaryKey(id);
        int i = 1 / 0;
    }

    @Override
    public HbyProjectErrorInfo getById(Long param) {
        return hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
    }

    @Override
    public int updateById(Long param) {
        final HbyProjectErrorInfo hbyProjectErrorInfo = hbyProjectErrorInfoMapper.selectByPrimaryKey(param);
        hbyProjectErrorInfo.setUpdateTime(new Date());
        return hbyProjectErrorInfoMapper.updateByPrimaryKey(hbyProjectErrorInfo);
    }
}