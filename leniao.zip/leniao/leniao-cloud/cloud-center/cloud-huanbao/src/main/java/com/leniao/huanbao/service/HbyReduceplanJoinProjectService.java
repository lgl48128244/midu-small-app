package com.leniao.huanbao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;

import java.util.List;
import java.util.Map;

public interface HbyReduceplanJoinProjectService extends IService<HbyReduceplanJoinProject> {

    long countByExample(HbyReduceplanJoinProjectExample example);

    int deleteByExample(HbyReduceplanJoinProjectExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyReduceplanJoinProject record);

    int insertSelective(HbyReduceplanJoinProject record);

    List<HbyReduceplanJoinProject> selectByExample(HbyReduceplanJoinProjectExample example);

    HbyReduceplanJoinProject selectByPrimaryKey(Long id);

    int updateByExampleSelective(HbyReduceplanJoinProject record, HbyReduceplanJoinProjectExample example);

    int updateByExample(HbyReduceplanJoinProject record, HbyReduceplanJoinProjectExample example);

    int updateByPrimaryKeySelective(HbyReduceplanJoinProject record);

    int updateByPrimaryKey(HbyReduceplanJoinProject record);

    /**
     * 查询单位绑定方案信息
     * @param planId 方案id
     * @return Map<Integer, HbyReduceplanJoinProject> key: 单位id， value：HbyReduceplanJoinProject
     */
    Map<Integer, HbyReduceplanJoinProject> selectHbyReduceplanJoinProjectByPlanId(Long planId);

    /**
     * 查询一个单位是否绑定了停限产方案
     */
    Boolean checkReducePlan(Integer unitId);

    /**
     * 更新绑定数量
     * @param planId
     * @param count
     * @return
     */
    boolean updateBindUnitCount(Long planId, int count);

    /**
     * 通过单位找出对应的停限产计划的Id
     * @param unitId
     * @return
     */
    Long selectPlanIdByUnitId(Integer unitId);
}
