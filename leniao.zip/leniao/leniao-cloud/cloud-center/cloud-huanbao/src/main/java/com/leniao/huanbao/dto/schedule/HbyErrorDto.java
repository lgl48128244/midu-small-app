package com.leniao.huanbao.dto.schedule;


import com.leniao.entity.HbyProjectErrorInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.DateTime;

import java.util.Date;

public abstract class HbyErrorDto {

    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class ForwardSyncErrorDto extends HbyProjectErrorInfo {
        private String nodeDesc;
        private String installLocation;
    }

    @Data
    public static class StopProErrChargeDto {
        private boolean isInTimeArea;
        private DateTime startTime;
        private DateTime endTime;
    }

    @Data
    public static class EleMaxDto {
        private Double maxEle;
        private Date addtime;
    }

    @Data
    public static class PowerMaxDto {
        private Double maxPower;
        private Date addtime;
    }

}
