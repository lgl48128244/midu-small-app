package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import com.leniao.huanbao.entity.Areacity;
import com.leniao.huanbao.mapper.AreacityMapper;
import com.leniao.huanbao.service.AreacityService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 9:54
 */
@Service
public class AreacityServiceImpl implements AreacityService {

    @Resource
    private AreacityMapper areacityMapper;

    /**
     * 根据省份ID查出，相应省份下的所有的市级信息
     */
    @Override
    public List<Areacity> findAllCity(String provinceId) {

        //创建条件对象
        QueryWrapper<Areacity> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("cityid","city").lambda().eq(Areacity::getFather,provinceId);

        List<Areacity> areacityList = areacityMapper.selectList(queryWrapper);


        return areacityList;
    }
}
