package com.leniao.huanbao.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 区域码与其他关联表 查询实体
 * @author: jiangdy
 * @create: 2019-12-21 09:49
 **/
@Getter
@Setter
@ToString
public class AreaCodeJoinOther {

    public AreaCodeJoinOther(){}
    public AreaCodeJoinOther(String provinceCode, String cityCode, String areaCode){
        this.provinceCode = provinceCode;
        this.cityCode = cityCode;
        this.areaCode = areaCode;
    }

    /**
     * 其他关联表id 方案表，单位表等
     */
    private Long otherId;

    /**
     * 省份六位码
     */
    private String provinceCode;

    /**
     * 市区六位码
     */
    private String cityCode;

    /**
     * 县区六位码
     */
    private String areaCode;

}
