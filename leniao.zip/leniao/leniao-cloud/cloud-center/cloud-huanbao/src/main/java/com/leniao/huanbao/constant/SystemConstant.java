package com.leniao.huanbao.constant;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 系统常用常量定义
 * @author: jiangdy
 * @create: 2019-12-24 13:56
 */
public class SystemConstant {

    /**
     * 默认分页大小
     */
    public static final int PAGE_SIZE = 10;

}
