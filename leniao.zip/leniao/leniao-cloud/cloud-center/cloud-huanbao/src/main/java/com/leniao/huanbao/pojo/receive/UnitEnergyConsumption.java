package com.leniao.huanbao.pojo.receive;

import com.leniao.huanbao.pojo.pagetopselecteneity.UnitElePowerDetailInfo;
import com.leniao.model.devlist.CountUnitAnalysisInfo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author liudongshuai
 * @date 2020/1/14 17:01
 * @update
 */
public class UnitEnergyConsumption implements Serializable,Comparable<UnitEnergyConsumption>{

    private String devName;
    private Double h1 = 0D;
    private Double h2 = 0D;
    private Double h3 = 0D;
    private Double h4 = 0D;
    private Double h5 = 0D;
    private Double h6 = 0D;
    private Double h7 = 0D;
    private Double h8 = 0D;
    private Double h9 = 0D;
    private Double h10 = 0D;
    private Double h11 = 0D;
    private Double h12 = 0D;
    private Double h13 = 0D;
    private Double h14 = 0D;
    private Double h15 = 0D;
    private Double h16 = 0D;
    private Double h17 = 0D;
    private Double h18 = 0D;
    private Double h19 = 0D;
    private Double h20 = 0D;
    private Double h21 = 0D;
    private Double h22 = 0D;
    private Double h23 = 0D;
    private Double h24 = 0D;
    private Double dayTotal = 0D;

    @Override
    public int compareTo(UnitEnergyConsumption o) {
        return this.dayTotal.compareTo(o.getDayTotal());
    }

    public Double getDayTotal() {
        return dayTotal;
    }

    public void setDayTotal(Double dayTotal) {
        this.dayTotal = Double.valueOf(String.valueOf(new BigDecimal(dayTotal).setScale(1, RoundingMode.DOWN)));
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public Double getH1() {
        return h1;
    }

    public void setH1(Double h1) {
        this.h1 = Double.valueOf(String.valueOf(new BigDecimal(h1).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH2() {
        return h2;
    }

    public void setH2(Double h2) {
        this.h2 = Double.valueOf(String.valueOf(new BigDecimal(h2).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH3() {
        return h3;
    }

    public void setH3(Double h3) {
        this.h3 = Double.valueOf(String.valueOf(new BigDecimal(h3).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH4() {
        return h4;
    }

    public void setH4(Double h4) {
        this.h4 = Double.valueOf(String.valueOf(new BigDecimal(h4).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH5() {
        return h5;
    }

    public void setH5(Double h5) {
        this.h5 = Double.valueOf(String.valueOf(new BigDecimal(h5).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH6() {
        return h6;
    }

    public void setH6(Double h6) {
        this.h6 = Double.valueOf(String.valueOf(new BigDecimal(h6).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH7() {
        return h7;
    }

    public void setH7(Double h7) {
        this.h7 = Double.valueOf(String.valueOf(new BigDecimal(h7).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH8() {
        return h8;
    }

    public void setH8(Double h8) {
        this.h8 = Double.valueOf(String.valueOf(new BigDecimal(h8).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH9() {
        return h9;
    }

    public void setH9(Double h9) {
        this.h9 = Double.valueOf(String.valueOf(new BigDecimal(h9).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH10() {
        return h10;
    }

    public void setH10(Double h10) {
        this.h10 = Double.valueOf(String.valueOf(new BigDecimal(h10).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH11() {
        return h11;
    }

    public void setH11(Double h11) {
        this.h11 = Double.valueOf(String.valueOf(new BigDecimal(h11).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH12() {
        return h12;
    }

    public void setH12(Double h12) {
        this.h12 = Double.valueOf(String.valueOf(new BigDecimal(h12).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH13() {
        return h13;
    }

    public void setH13(Double h13) {
        this.h13 = Double.valueOf(String.valueOf(new BigDecimal(h13).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH14() {
        return h14;
    }

    public void setH14(Double h14) {
        this.h14 = Double.valueOf(String.valueOf(new BigDecimal(h14).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH15() {
        return h15;
    }

    public void setH15(Double h15) {
        this.h15 = Double.valueOf(String.valueOf(new BigDecimal(h15).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH16() {
        return h16;
    }

    public void setH16(Double h16) {
        this.h16 = Double.valueOf(String.valueOf(new BigDecimal(h16).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH17() {
        return h17;
    }

    public void setH17(Double h17) {
        this.h17 = Double.valueOf(String.valueOf(new BigDecimal(h17).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH18() {
        return h18;
    }

    public void setH18(Double h18) {
        this.h18 = Double.valueOf(String.valueOf(new BigDecimal(h18).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH19() {
        return h19;
    }

    public void setH19(Double h19) {
        this.h19 = Double.valueOf(String.valueOf(new BigDecimal(h19).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH20() {
        return h20;
    }

    public void setH20(Double h20) {
        this.h20 = Double.valueOf(String.valueOf(new BigDecimal(h20).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH21() {
        return h21;
    }

    public void setH21(Double h21) {
        this.h21 = Double.valueOf(String.valueOf(new BigDecimal(h21).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH22() {
        return h22;
    }

    public void setH22(Double h22) {
        this.h22 = Double.valueOf(String.valueOf(new BigDecimal(h22).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH23() {
        return h23;
    }

    public void setH23(Double h23) {
        this.h23 = Double.valueOf(String.valueOf(new BigDecimal(h23).setScale(1, RoundingMode.DOWN)));
    }

    public Double getH24() {
        return h24;
    }

    public void setH24(Double h24) {
        this.h24 = Double.valueOf(String.valueOf(new BigDecimal(h24).setScale(1, RoundingMode.DOWN)));
    }
}
