package com.leniao.huanbao.pojo.receive;

/**
 * @author liudongshuai
 * @date 2020/1/16 10:04
 * @update
 */
public class UnitEnergyMonth {

    private String Day;
    private Double eleQ;

    public String getDay() {
        return Day;
    }

    public void setDay(String day) {
        Day = day;
    }

    public Double getEleQ() {
        return eleQ;
    }

    public void setEleQ(Double eleQ) {
        this.eleQ = eleQ;
    }
}
