package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import com.leniao.huanbao.entity.UshareDeviceElectricuseExample;
import com.leniao.huanbao.mapper.UshareDeviceElectricuseMapper;
import com.leniao.huanbao.service.UshareDeviceElectricuseService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 设备用电量
 * @author: jiangdy
 * @create: 2019-12-27 18:07
 **/
@Service
public class UshareDeviceElectricuseServiceImpl extends ServiceImpl<UshareDeviceElectricuseMapper, UshareDeviceElectricuse> implements UshareDeviceElectricuseService {

    @Resource
    private UshareDeviceElectricuseMapper ushareDeviceElectricuseMapper;

    @Override
    public int countByExample(UshareDeviceElectricuseExample example) {
        return ushareDeviceElectricuseMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(UshareDeviceElectricuseExample example) {
        return ushareDeviceElectricuseMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer idpk) {
        return ushareDeviceElectricuseMapper.deleteByPrimaryKey(idpk);
    }

    @Override
    public int insert(UshareDeviceElectricuse record) {
        return ushareDeviceElectricuseMapper.insert(record);
    }

    @Override
    public int insertSelective(UshareDeviceElectricuse record) {
        return ushareDeviceElectricuseMapper.insertSelective(record);
    }

    @Override
    public List<UshareDeviceElectricuse> selectByExample(UshareDeviceElectricuseExample example) {
        return ushareDeviceElectricuseMapper.selectByExample(example);
    }

    @Override
    public UshareDeviceElectricuse selectByPrimaryKey(Integer idpk) {
        return ushareDeviceElectricuseMapper.selectByPrimaryKey(idpk);
    }

    @Override
    public int updateByExampleSelective(UshareDeviceElectricuse record, UshareDeviceElectricuseExample example) {
        return ushareDeviceElectricuseMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExample(UshareDeviceElectricuse record, UshareDeviceElectricuseExample example) {
        return ushareDeviceElectricuseMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(UshareDeviceElectricuse record) {
        return ushareDeviceElectricuseMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(UshareDeviceElectricuse record) {
        return ushareDeviceElectricuseMapper.updateByPrimaryKey(record);
    }

    /**
     * 设备日电量数据信息
     * @param date
     * @param unitId
     * @param devId
     * @return
     */
    @Override
    public Double findUsharEleByDateTimeUnitDevId(String date, Integer unitId, Integer devId) {
        QueryWrapper<UshareDeviceElectricuse> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("dayTotalQ").lambda().eq(UshareDeviceElectricuse::getDevidpk,devId).eq(UshareDeviceElectricuse::getUnitid,unitId).eq(UshareDeviceElectricuse::getAddtime,date);
        UshareDeviceElectricuse ushareDeviceElectricuse = ushareDeviceElectricuseMapper.selectOne(queryWrapper);
        if (ushareDeviceElectricuse==null){
            return 0D;
        }else {
            return ushareDeviceElectricuse.getDaytotalq();
        }
    }
}
