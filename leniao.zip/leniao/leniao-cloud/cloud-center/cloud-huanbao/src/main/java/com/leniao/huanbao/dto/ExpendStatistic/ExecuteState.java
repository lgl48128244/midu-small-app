package com.leniao.huanbao.dto.ExpendStatistic;

import lombok.Data;

/**
 * @program: leniao-hbcloudV1.0
 * @description:
 * @author: jiangdy
 * @create: 2020-01-09 18:56
 **/
@Data
public class ExecuteState {
    private String key;
    private Integer tdExecute;
    private Integer tdUnexecute;
    private Integer ydExecute;
    private Integer ydUnexecute;
}
