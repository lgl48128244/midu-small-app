package com.leniao.huanbao.pojo.receive;

import java.io.Serializable;

/**
 * @author liudongshuai
 * @date 2020/1/10 10:56
 * @update
 */
public class UnitAnalysisData implements Serializable {
    //行业名称
    private String industryName = "";
    //单位Id
    private Integer unitId;
    //运行状态
    private Integer runStatus = 2;
    //产污设备数
    private Integer pollNum = 0;
    //治污设备数
    private Integer conNum = 0;
    //运行设备数
    private Integer runNum = 0;
    //停机设备数
    private Integer stopNum = 0;
    //失联设备数
    private Integer lostNum = 0;

    @Override
    public String toString() {
        return "UnitAnalysisData{" +
                "unitId=" + unitId +
                ", runStatus=" + runStatus +
                ", pollNum=" + pollNum +
                ", conNum=" + conNum +
                ", runNum=" + runNum +
                ", stopNum=" + stopNum +
                ", lostNum=" + lostNum +
                '}';
    }

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Integer getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(Integer runStatus) {
        this.runStatus = runStatus;
    }

    public Integer getPollNum() {
        return pollNum;
    }

    public void setPollNum(Integer pollNum) {
        this.pollNum = pollNum;
    }

    public Integer getConNum() {
        return conNum;
    }

    public void setConNum(Integer conNum) {
        this.conNum = conNum;
    }

    public Integer getRunNum() {
        return runNum;
    }

    public void setRunNum(Integer runNum) {
        this.runNum = runNum;
    }

    public Integer getStopNum() {
        return stopNum;
    }

    public void setStopNum(Integer stopNum) {
        this.stopNum = stopNum;
    }

    public Integer getLostNum() {
        return lostNum;
    }

    public void setLostNum(Integer lostNum) {
        this.lostNum = lostNum;
    }
}
