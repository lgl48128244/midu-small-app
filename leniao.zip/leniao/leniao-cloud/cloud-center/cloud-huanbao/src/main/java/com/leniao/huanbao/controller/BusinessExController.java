package com.leniao.huanbao.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.commons.util.EnumUtils;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.service.TblndeviceinfoService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.constant.RangeConstant;
import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.model.vo.Page;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyProjectErrorInfoService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author guoliang.li
 * @date 2019/12/25 16:30
 * @description TODO 企业异常信息接口
 */
@RestController
@RequestMapping(ApiConstant.BUSINESS_EX_PREF)
public class BusinessExController extends BaseController {

    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;
    @Resource
    private PermissionService permissionService;
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    @Resource
    private HbScheduledService hbScheduledService;

    /**
     * 获取当前用户的单位IDs
     * showAll 0:查看创建了监测点的单位， 1：查看所有可见单位
     * @return
     */
    private List<Long> getProjIdsAboutUser(int showAll) {
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther code = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer grade = UserUtil.getUserGrade(code);
        // 用户可见单位
        //List<TreeMenu> projList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), code != null, code, grade, null);
        Map<String, Object> params = null;
        if (showAll == 1) {
            params = new HashMap<>();
            params.put("showAll", 1);
        }
        List<TreeMenu> projList = permissionService.selectCanShowProjectByUserId2(userInfo.getUserId(), code != null, code, grade, null, params, userInfo.getPlatformId());
        return projList.stream().map(proj -> proj.getNodeId()).collect(Collectors.toList());
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_SEARCH_LIST)
    public Object list(@RequestBody BaseBusinessExDTO.BusinessExSearchReq req) {
        super.checkArgs(req);
        List<Long> projIds = this.getProjIdsAboutUser(0);
        if (projIds == null || projIds.size() == 0) {
            throw new CloudException(CloudErrorCode.SYS_EMPTY);
        }
        req.setUnitIds(projIds);
        UserInfo userInfo = this.getUserInfo();
        req.setPlatformId(userInfo.getPlatformId());
        return renderResult(new PageInfo<>(hbyProjectErrorInfoService.selectErrorSearchList(req)));
    }

    /**
     * 污处异常的列表接口--分页
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_SEARCH_POLL_LIST)
    public Object pollErrList(@RequestBody BaseBusinessExDTO.BusinessExSearchReq req){
        super.checkArgs(req);
        String devSignature = req.getDevSignature();
        if (StringUtils.isBlank(devSignature)) {
            return renderResult(null, 200, "设备编号不能为空");
        }
        //获取单位id
        Tblndeviceinfo tblndeviceinfo = this.tblndeviceinfoService.findDevBydDevSig(devSignature);
        if (tblndeviceinfo == null) {
            return renderResult(null, 200, "该设备不存在");
        }
        req.setDevSignature(devSignature);
        return this.list(req);
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_SEARCH)
    public Object search(@RequestBody BaseBusinessExDTO.BusinessExSearch req) {
        super.checkArgs(req);
        this.execute(req);
        return renderResult();
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_SEARCH_DETAIL)
    public Object searchDetail(@RequestBody JSONObject jsonObject) {
        Long id = jsonObject.getLong("id");
        if (id == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(hbyProjectErrorInfoService.selectErrorSearchDetail(id));
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_HANDLE)
    public Object handler(@RequestBody BaseBusinessExDTO.BusinessExHandler handler) {
        super.checkArgs(handler);
        handler.setDealStatus(EnumUtils.ExStatus.STATUS2.getCode());
        handler.setCheckTime(new Date());
        handler.setCheckUser(super.getUserInfo().getUserId());
        handler.setCheckUserName(super.getUserInfo().getUsername());
        this.execute(handler);
        return renderResult();
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_HANDLE_DETAIL)
    public Object handlerDetail(@RequestBody JSONObject jsonObject) {
        Long id = jsonObject.getLong("id");
        if (id == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(hbyProjectErrorInfoService.selectErrorHandlerDetail(id));
    }

    /**
     * 批量处理--修改处理人
     * @param ids
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_HANDLE_BATCH)
    public Object handlerBatch(@RequestBody List<Long> ids) {
        hbyProjectErrorInfoService.updateErrorHandlerBatch(ids, EnumUtils.ExStatus.STATUS2.getCode());
        return renderResult();
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_DECLARE)
    public Object declare(@RequestBody BaseBusinessExDTO.BusinessExHandler handler) {
        super.checkArgs(handler);
        handler.setDealStatus(EnumUtils.ExStatus.STATUS3.getCode());
        handler.setCheckTime(new Date());
        handler.setCheckUser(super.getUserInfo().getUserId());
        handler.setCheckUserName(super.getUserInfo().getUsername());
        this.execute(handler);
        return renderResult();
    }

    private void execute(Object obj) {
        Class<?> aClass = obj.getClass();
        try {
            Field field = aClass.getDeclaredField("id");
            field.setAccessible(true);
            Object id = field.get(obj);
            HbyProjectErrorInfo hbyProjectErrorInfo = hbyProjectErrorInfoService.getById((Serializable) id);
            if (hbyProjectErrorInfo == null) {
                throw new CloudException(CloudErrorCode.OBJ_NULL);
            }
            BeanUtils.copyProperties(obj, hbyProjectErrorInfo);
            hbyProjectErrorInfoService.updateById(hbyProjectErrorInfo);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_DECLARE_DETAIL)
    public Object declareDetail(@RequestBody JSONObject jsonObject) {
        return this.handlerDetail(jsonObject);
    }

    /**
     * 批量申报
     * @param ids
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_DECLARE_BATCH)
    public Object declareBatch(@RequestBody List<Long> ids) {
        hbyProjectErrorInfoService.updateErrorHandlerBatch(ids, EnumUtils.ExStatus.STATUS3.getCode());
        return renderResult();
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_EXAMINE)
    public Object examine(@RequestBody BaseBusinessExDTO.BusinessExExamine examine) {
        super.checkArgs(examine);
        //如果前端选择通过，则处理状态改为审核通过（完成）
        if (examine.getVerifyResult().equals(1)) {
            examine.setDealStatus(EnumUtils.ExStatus.STATUS4.getCode());
        } else {
            //如果前端选择不通过，则处理状态改为审核失败待重新申报
            examine.setDealStatus(EnumUtils.ExStatus.STATUS5.getCode());
        }
        examine.setVerifyTime(new Date());
        examine.setVerifyUser(this.getUserInfo().getUserId());
        examine.setVerifyUserName(this.getUserInfo().getUsername());
        this.execute(examine);
        return renderResult();
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_EXAMINE_DETAIL)
    public Object examineDetail(@RequestBody JSONObject jsonObject) {
        Long id = jsonObject.getLong("id");
        if (id == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        return renderResult(hbyProjectErrorInfoService.selectErrorExamineDetail(id));
    }

    /**
     * 批量审核通过--审核人
     * @param ids
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_EXAMINE_BATCH_PASS)
    public Object examineBatchPass(@RequestBody List<Long> ids) {
        hbyProjectErrorInfoService.updateErrorHandlerBatch(ids, EnumUtils.ExStatus.STATUS4.getCode());
        return renderResult();
    }

    /**
     * 批量审核不通过--审核人
     * @param ids
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_EXAMINE_BATCH_NOT_PASS)
    public Object examineBatchNotPass(@RequestBody List<Long> ids) {
        hbyProjectErrorInfoService.updateErrorHandlerBatch(ids, EnumUtils.ExStatus.STATUS5.getCode());
        return renderResult();
    }

    /**
     * 异常统计接口
     *
     * @param req
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_STATISTICS)
    public Object statistics(@RequestBody BaseBusinessExDTO.BusinessExStatisticsReq req) {
        super.checkArgs(req);
        //此处添加权限判断
        req.setProjIds(this.getProjIdsAboutUser(0));
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer userGrade = UserUtil.getUserGrade(areaCode);
        req.setPlatformId(userInfo.getPlatformId());
        return renderResult(new PageInfo<>(hbyProjectErrorInfoService.selectErrorStatisticsList(req, userGrade)));
    }

    /**
     * 首页异常柱状图
     * @param page
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_STATISTICS_AGENCY_LIST)
    public Object statisticsAgencyList(@RequestBody Page page) {
        super.checkArgs(page);
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer userGrade = UserUtil.getUserGrade(areaCode);
        if (userGrade == null) {
            //return this.personnalUserCount(page, areaCode, userInfo);
            return this.personnalUserCount2(page, userInfo);
        } else {
            List<Long> projIdsAboutUser = this.getProjIdsAboutUser(1);
            return this.areaUserCount(userGrade, areaCode, userInfo, projIdsAboutUser);
        }
    }

    /**
     * 区域用户各区域统计统计
     * @param areaCode
     * @param userInfo
     * @return
     */
    private Object areaUserCount(Integer userGrade, AreaCodeJoinOther areaCode, UserInfo userInfo, List<Long> projIdsAboutUser) {
        //查询所有对应机构
        List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> agencyLists =
                this.hbyProjectErrorInfoService.findAgencyByAreaCode(userGrade, userInfo,areaCode.getProvinceCode(), areaCode.getCityCode(), areaCode.getAreaCode(),projIdsAboutUser);
        Collections.sort(agencyLists, Comparator.comparing(BaseBusinessExDTO.BusinessExStatisticsAgencyList::getTotal).reversed() );
        if (userGrade == 3 && agencyLists.size() > RangeConstant.INDEX_PAGE_ERR_COUNT_LIST_SIZE) {
            return renderResult(agencyLists.subList(0, RangeConstant.INDEX_PAGE_ERR_COUNT_LIST_SIZE-1));
        }
        return renderResult(agencyLists);
    }

    /**
     * 个人用户各区域统计统计
     * @param page
     * @param areaCode
     * @param userInfo
     * @return
     */
    private Object personnalUserCount(Page page, AreaCodeJoinOther areaCode, UserInfo userInfo) {
        Map<String, Object> params = new HashMap<>();
        //showAll 0：只查询有监测点的机构   1：查询所有可见机构
        params.put("showAll", 0);
        // 查询用户可见的所有机构
        List<TreeMenu> allMenuList = permissionService.selectCanShowAgencyByUserId(userInfo.getUserId(),
                areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), params);
        if (CollectionUtils.isEmpty(allMenuList)) {
            return renderResult(Collections.emptyList());
        }
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        page.setProjIds(projIdsAboutUser);
        page.setPlatformId(userInfo.getPlatformId());
        List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> businessExStatisticsAgencyLists = hbyProjectErrorInfoService.selectErrorStatisticsAgencyList(page);


        List<String> collect = allMenuList.stream().map(agc -> agc.getNodeName()).collect(Collectors.toList());
        //最终的返回结果
        List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> resultList = new ArrayList<>();
        collect.forEach(agencName -> {
            BaseBusinessExDTO.BusinessExStatisticsAgencyList item = new BaseBusinessExDTO.BusinessExStatisticsAgencyList();
            item.setAgcyName(agencName);
            item.setTotal(0);
            resultList.add(item);
        });
        resultList.forEach(agenc -> {
            businessExStatisticsAgencyLists.forEach(item -> {
                if (agenc.getAgcyName().equals(item.getAgcyName())) {
                    agenc.setTotal(item.getTotal());
                }
            });
        });
        //resultList.sort((r1,r2) -> r1.getTotal().compareTo(r2.getTotal()));
        Collections.sort(resultList, Comparator.comparing(BaseBusinessExDTO.BusinessExStatisticsAgencyList::getTotal).reversed());
        return renderResult(resultList);
    }

    private Object personnalUserCount2(Page page, UserInfo userInfo) {
        Map<String, Object> params = new HashMap<>();
        //showAll 0：只查询有监测点的机构   1：查询所有可见机构
        params.put("showAll", 0);
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        page.setProjIds(projIdsAboutUser);
        page.setPlatformId(userInfo.getPlatformId());
        List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> resultList = hbyProjectErrorInfoService.selectErrorStatisticsProjectList(page);
        return renderResult(resultList);
    }

    /**
     * app端首页各行业异常占比
     * @param page
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_STATISTICS_INDUSTRY_LIST)
    public Object statisticsIndustryList(@RequestBody Page page) {
        super.checkArgs(page);
        UserInfo userInfo = this.getUserInfo();
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Integer userGrade = UserUtil.getUserGrade(areaCode);
        if (userGrade == null) {
            List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
            page.setProjIds(projIdsAboutUser);
            page.setPlatformId(userInfo.getPlatformId());
            return renderResult(new PageInfo<>(hbyProjectErrorInfoService.selectErrorStatisticsIndustryList(page)));
        } else {
            page.setPlatformId(userInfo.getPlatformId());
            return renderResult(new PageInfo<>(hbyProjectErrorInfoService.selectErrorStatisticsIndustryList(areaCode.getProvinceCode(),
                    areaCode.getCityCode(), areaCode.getAreaCode(), userGrade, page)));
        }
    }

    /**
     * 普通用户首页异常滚动列表
     *
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_ROLLING_NORMAL)
    public Object rolling() {
        Integer userId = GlobalConstant.getUserInfo().getUserId();
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        return renderResult(hbyProjectErrorInfoService.selectErrorHomeRollingListByNormalUser((userId == null ? 0 : userId), projIdsAboutUser));
    }

    /**
     * 区域用户首页异常信息滚动列表
     *
     * @param req
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_ROLLING_SPECIFY)
    public Object rolling(@RequestBody BaseBusinessExDTO.BusinessExRollingReq req) {
        super.checkArgs(req);
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        req.setProjIds(projIdsAboutUser);
        return renderResult(hbyProjectErrorInfoService.selectErrorHomeRollingListBySpecifyUser(req));
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_CUOFENG_LIST)
    public Object cuofeng(@RequestBody BaseBusinessExDTO.BusinessExCuoFengReq req) {
        super.checkArgs(req);
        PageHelper.startPage(req.getPage(), req.getRows());
        return renderResult(new PageInfo<>(hbyProjectErrorInfoService.selectErrorCuoFengList(req.getUnitId())));
    }

    /**
     * 全屏首页统计治污设施情况
     *
     * @return
     */
    @RequestMapping(ApiConstant.BUSINESS_EX_STATISTICS_DEVICE_INFO)
    public Object deviceInfo() {
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        Map<String, Object> map = new HashMap<>(2);
        map.put("today", new BaseBusinessExDTO.BusinessExDeviceInfo(
                hbyProjectErrorInfoService.selectTodayUnitCount(projIdsAboutUser),
                hbyProjectErrorInfoService.selectTodayDeviceCount(projIdsAboutUser),
                hbyProjectErrorInfoService.selectTodayDeclareCount(projIdsAboutUser)
        ));
        map.put("yestoday", new BaseBusinessExDTO.BusinessExDeviceInfo(
                hbyProjectErrorInfoService.selectYesTodayUnitCount(projIdsAboutUser),
                hbyProjectErrorInfoService.selectYesTodayDeviceCount(projIdsAboutUser),
                hbyProjectErrorInfoService.selectYesTodayDeclareCount(projIdsAboutUser)
        ));
        return renderResult(map);
    }

    @RequestMapping(ApiConstant.BUSINESS_EX_STATISTICS_MAX_POWER)
    public Object getRealTimeMaxPower(@RequestBody JSONObject jsonObject){
        Integer unitId = jsonObject.getInteger("projId");
        if (unitId == null) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("maxValue", "0.0");
        map.put("maxValueTime", "00:00:00");
        List<Long> projIdsAboutUser = this.getProjIdsAboutUser(0);
        if (CollectionUtils.isEmpty(projIdsAboutUser) ||! projIdsAboutUser.contains(unitId.longValue())) {
            return renderResult(map);
        }
        //获取总监测点设备
        Integer devIdpk = this.hbyProjectErrorInfoService.findRootPointDevIdpkOfUnit(unitId);
        if (devIdpk == null) {
            return renderResult(map);
        }
        DateTime endTime = DateTime.now();
        DateTime beginTime = endTime.withTime(0, 0, 0, 0);
        List<realValueList1> dataPackagesMuchOfTimeArea = this.hbScheduledService.getDataPackagesMuchOfTimeArea(beginTime, endTime, devIdpk);

        HbyErrorDto.PowerMaxDto maxPower = this.hbScheduledService.getMaxPower(dataPackagesMuchOfTimeArea);
        Double power = maxPower.getMaxPower();
        Date addtime = maxPower.getAddtime();
        //map.put("maxValue", new DecimalFormat("#.0").format(power));
        map.put("maxValue",power);
        map.put("maxValueTime", new DateTime(addtime).toString("HH:mm:ss"));
        return renderResult(map);

    }
}