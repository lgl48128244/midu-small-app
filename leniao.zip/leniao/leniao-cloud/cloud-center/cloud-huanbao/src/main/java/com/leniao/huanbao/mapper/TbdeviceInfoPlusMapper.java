package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.huanbao.dto.schedule.ErrPushDto;
import com.leniao.huanbao.pojo.pagetopselecteneity.AddLookPointDevSignInfo;
import com.leniao.huanbao.pojo.pagetopselecteneity.GroupIdNameInfo;
import com.leniao.huanbao.pojo.receive.UnitEnergyMonth;
import com.leniao.huanbao.pojo.receive.UnitEnergyMonthNew;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/24 19:41
 * @update
 * @description
 */
public interface TbdeviceInfoPlusMapper {
    @Select("SELECT devgroupId AS groupId,devSignature AS devSign,overlookId AS overlookId,devProTy AS devTy,devWorkState AS devStatus  FROM tblndeviceinfo WHERE projId=#{unitId}")
    List<Map<String,Object>> findGroupIdLookPointStatus(Page<Map<String, Object>> page, Integer unitId);

    @Select("SELECT devIdpk,devSignature,devProductTime,projId,devgroupId,devTyId FROM tblndeviceinfo WHERE projId=#{unitId} AND devProductTime>#{date} LIMIT #{pageCount},#{size}")
    List<Tblndeviceinfo>  findDevInfoByUnitId(Integer unitId, String date, Integer pageCount, Integer size);

    @Select("SELECT devIdpk,devSignature,devProductTime,projId,devgroupId,devTyId FROM tblndeviceinfo WHERE projId=#{unitId} AND devgroupId=#{groupId} AND devProductTime>#{date} LIMIT #{pageCount},#{size}")
    List<Tblndeviceinfo>  findDevInfoByUnitIdGroupId(Integer unitId, Integer groupId, String date, Integer pageCount, Integer size);

    @Select("select totalgrade from tblngrid_gradehistory WHERE unitId=#{unitId} order by id desc limit 1")
    Float findUnitGrade(Integer unitId);

    @Select("SELECT DISTINCT\n" +
            "\ttblngroup.groupId AS groupId,\n" +
            "\ttblngroup.groupName AS groupName\n" +
            "FROM\n" +
            "\ttblndeviceinfo,\n" +
            "\ttblngroup,\n" +
            "\ttblndevty\n" +
            "WHERE\n" +
            " tblndeviceinfo.devgroupId = tblngroup.groupId\n" +
            "AND tblndeviceinfo.devTyId = tblndevty.devTyId\n" +
            "AND tblndeviceinfo.isDelete = 0\n" +
            "AND tblndeviceinfo.projId = ${unitId}\n" +
            "AND tblndevty.BType IN (1,2,30,45)")
    List<GroupIdNameInfo> findGroupNameIdByUnitId(Integer unitId);

    @Select("SELECT " +
            " t2. DAY, " +
            " t3.devIdpk, " +
            " IFNULL(t3.eleQ, 0) eleQ " +
            "FROM " +
            " ( " +
            "  SELECT " +
            "   * " +
            "  FROM " +
            "   ( " +
            "    SELECT " +
            "     @cdate := DATE_ADD(@cdate, INTERVAL + 1 DAY) DAY " +
            "    FROM " +
            "     ( " +
            "      SELECT " +
            "       @cdate := DATE_ADD( " +
            "        '${monthDate}', " +
            "        INTERVAL - DAY ('${monthDate}') DAY " +
            "       ) " +
            "    FROM " +
            "      ushare_device_electricuse " +
            "    ) t0 " +
            "   ) t1 " +
            "  WHERE " +
            "   date_format(DAY, '%Y%m') = date_format('${monthDate}', '%Y%m') " +
            " ) t2 " +
            "LEFT JOIN ( " +
            " SELECT " +
            "  a.devIdpk, " +
            "  a.gateName, " +
            "  a.cupName, " +
            "  dev.installLocation, " +
            "  dev.devSignature, " +
            "  ty.devTy, " +
            "  IFNULL(ROUND(b.dayTotalQ, 2), 0) eleQ, " +
            "  b.addtime " +
            " FROM " +
            "  ele_mon_gateinfo a " +
            " JOIN tblndeviceinfo dev ON a.devIdpk = dev.devIdpk " +
            " LEFT JOIN ( " +
            "  SELECT " +
            "   devIdpk, " +
            "   dayTotalQ, " +
            "   addtime " +
            "  FROM " +
            "   ushare_device_electricuse " +
            "  WHERE " +
            "   unitId = ${unitId} " +
            "  AND isReset = 0 " +
            " ) b ON a.devIdpk = b.devIdpk " +
            " JOIN tblndevty ty ON dev.devTyId = ty.devTyId " +
            " WHERE " +
            " a.unitId = ${unitId} AND a.devIdpk = ${devIdpk} " +
            " GROUP BY " +
            " addtime " +
            ") t3 ON t2. DAY = t3.addtime")
    List<UnitEnergyMonth> findUnitMonthData(Integer unitId, Integer devIdpk, String monthDate);

    @Select("SELECT\n" +
            "\tdayTotalQ,\n" +
            "\taddtime,\n" +
            "\tdevIdpk\n" +
            "FROM\n" +
            "\tushare_device_electricuse\n" +
            "WHERE\n" +
            " elYear = ${year}\n" +
            "AND elMonth = ${month}\n" +
            "AND devIdpk IN (${devStr})")
    List<UnitEnergyMonthNew> findUnitMonthNewData(String devStr, Integer month,Integer year);

    @Select("SELECT DISTINCT\n" +
            "\ttblndeviceinfo.devSignature AS signature,\n" +
            "\ttblndeviceinfo.installLocation AS devLocation\n" +
            "FROM\n" +
            "\ttblndevty,\n" +
            "\ttblndeviceinfo,\n" +
            "\ttblngroup\n" +
            "WHERE\n" +
            "  tblndeviceinfo.devTyId = tblndevty.devTyId\n" +
            "AND tblndeviceinfo.devgroupId = tblngroup.groupId\n" +
            "AND tblndeviceinfo.isDelete = 0\n" +
            "AND tblndeviceinfo.devgroupId = ${groupId}\n" +
            "AND tblndevty.BType IN (1,2,30,45)")
    List<AddLookPointDevSignInfo> findDevSignInfoByGroupId(Integer groupId);

}
