package com.leniao.huanbao.health;

import com.leniao.commons.AppServerParams;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author guoliang.li
 * @date 2019/12/25 11:54
 * @description TODO 验证服务是否正常
 */
@RestController
public class HealthController {

    @Resource
    private AppServerParams appServerParams;

    @RequestMapping("/server/health")
    public String health() {
        return "I am ok!!!\t" + appServerParams.getAppName();
    }
}