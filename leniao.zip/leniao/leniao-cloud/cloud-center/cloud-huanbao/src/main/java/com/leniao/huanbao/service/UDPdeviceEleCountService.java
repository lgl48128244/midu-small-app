package com.leniao.huanbao.service;

import com.leniao.huanbao.schedule.udpbean.WebResult;

import java.util.List;

public interface UDPdeviceEleCountService {

    /**
     * 获取建立了监测点单位的所有UDP设备ID
     * @return
     */
    List<Integer> findAllUdpDeviceInOverLookPoint();

    WebResult saveDevicePower_v20191214(int devIdpk, int realPower, String time, int multiple);


}
