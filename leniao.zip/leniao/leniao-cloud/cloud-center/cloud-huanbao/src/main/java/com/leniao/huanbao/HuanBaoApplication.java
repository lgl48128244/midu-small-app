package com.leniao.huanbao;

import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * @author guoliang.li
 * @date 2019/12/17 16:21
 * @description TODO
 */
@ServletComponentScan
@ConfigurationPropertiesScan
@SpringBootApplication(scanBasePackages = "com.leniao", exclude = DruidDataSourceAutoConfigure.class)
public class HuanBaoApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(HuanBaoApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(HuanBaoApplication.class);
    }
}