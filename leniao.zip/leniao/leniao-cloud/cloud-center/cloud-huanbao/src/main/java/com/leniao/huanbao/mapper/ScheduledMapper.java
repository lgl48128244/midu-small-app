package com.leniao.huanbao.mapper;

import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.OverLookPointWithDevlist;
import com.leniao.huanbao.dto.schedule.RootDevice24HourEleValue;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.entity.HbyDevalTimeStatus;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.UshareDeviceElectricuse;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 定时任务相关的mapper
 * @Author: haosw
 * @CreateDate: 2019/12/21 15:39
 * @Version: 1.0
 */
public interface ScheduledMapper {
    /**
     * @description: 方法的作用描述
     * @author: haosw
     * @param:
     * @return: 查询所有监测点以及关联的设备简单信息
     * @date: 2019/12/21 15:40
     */
    List<OverLookPointWithDevlist> findOverLookPointsWithDevlist();

    /**
     * @description: 方法的作用描述
     * @author: haosw
     * @param: sql:执行24小时工况表插入的sql语句
     * @return:
     * @date: 2019/12/24 15:34
     */
    void insertDevWorkStatus(@Param("sql") String sql);

    /**
     * @description: 方法的作用描述
     * @author: haosw
     * @param: devIdpk
     * @return: HbyDevalTimeStatus 设备工况
     * @date: 2019/12/24 9:32
     */
    HbyDevalTimeStatus findDeviceWorkStatusToday(@Param("devIdpk") Integer devIdpk, @Param("beginOfDay") String beginOfDay, @Param("endOfDay") String endOfDay);

    /**
     * @description: 查询环保云异常表中已在原119异常表中不存在异常数据
     * @author: haosw
     * @param:
     * @return: 已经自动恢复正常的异常数据
     * @date: 2019/12/26 14:08
     */
    List<HbyProjectErrorInfo> findHasBeenNormalErrInfo();

    /**
     * 根据条件查询设备的异常数据
     *
     * @param devDto
     * @param errType
     * @return
     */
    HbyProjectErrorInfo findSoftwareErrBy(@Param("dto") DevDto devDto, @Param("type") int errType);

    /**
     * 获取单位关联的为启用状态的减产减排方案(缓存)
     *
     * @param unitId
     * @return
     */
    HbyReduceEmmissionPlan findReduceEmmPlanByUnitId(Integer unitId);

    /**
     * @description: 根据单位ID查询单位的减产方案
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/2 13:44
     */
    HbyReduceEmmissionPlan findReducePlanJoinUnitByUnitId(Integer unitId);

    /**
     * @description: 新增一条异常数据, 返回自增主键
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/2 11:19
     */
    int insertProjectErrorInfo(HbyProjectErrorInfo projectErrorInfo);

    /**
     * @description: 获取单位检查点设备的用电量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/3 16:52
     */
    List<HashMap<String, Object>> getPollAndConDevEleQ(@Param("unitId") Integer unitId, @Param("addtime") String addtime);

    /**
     * @description: 获取所有建立了检测点单位的总表设备用电量
     * @author: haosw
     * @param:
     * @return:
     * @date: 2020/1/8 17:26
     */
    List<HashMap<String, Object>> findUnitCurrentMonthEleUse(@Param("year") int year, @Param("month") int monthOfYear);

    /**
     * 获取有需要推送的异常
     * @param unitId
     * @return
     */
    List<HashMap<String, Object>> findErrSimpInfoListToPush(Integer unitId);

    RootDevice24HourEleValue findDeveleUse(Integer unitId);
}
