package com.leniao.huanbao.pojo.receive;

public class UnitRealTimeData {

    //单位名称
    private String unitName;
    //单位状态
    private Integer unitStatus;
    //A相电压
    private Float voltA = 0f;
    //B相电压
    private Float voltB = 0f;
    //C相电压
    private Float voltC = 0f;
    //A相电流
    private Float currentA =  0f;
    //B相电流
    private Float currentB =  0f;
    //C相电流
    private Float currentC =  0f;

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public Integer getUnitStatus() {
        return unitStatus;
    }

    public void setUnitStatus(Integer unitStatus) {
        this.unitStatus = unitStatus;
    }

    public Float getVoltA() {
        return voltA;
    }

    public void setVoltA(Float voltA) {
        this.voltA = voltA;
    }

    public Float getVoltB() {
        return voltB;
    }

    public void setVoltB(Float voltB) {
        this.voltB = voltB;
    }

    public Float getVoltC() {
        return voltC;
    }

    public void setVoltC(Float voltC) {
        this.voltC = voltC;
    }

    public Float getCurrentA() {
        return currentA;
    }

    public void setCurrentA(Float currentA) {
        this.currentA = currentA;
    }

    public Float getCurrentB() {
        return currentB;
    }

    public void setCurrentB(Float currentB) {
        this.currentB = currentB;
    }

    public Float getCurrentC() {
        return currentC;
    }

    public void setCurrentC(Float currentC) {
        this.currentC = currentC;
    }
}
