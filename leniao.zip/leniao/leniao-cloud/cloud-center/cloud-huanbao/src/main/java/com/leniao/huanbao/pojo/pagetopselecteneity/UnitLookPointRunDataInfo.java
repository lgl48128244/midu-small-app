package com.leniao.huanbao.pojo.pagetopselecteneity;

public class UnitLookPointRunDataInfo {
    //分组名称
    private String groupName;
    //监测点名称
    private String lookPointName;
    //监测点Id
    private Long lookPointId;
    //产污设备
    private Integer pollsNum = 0;
    //治污设备
    private Integer consNum = 0;
    //监测点类别 0 总监测点 1普通监测点
    private Integer lookPointType;

    public Integer getLookPointType() {
        return lookPointType;
    }

    public void setLookPointType(Integer lookPointType) {
        this.lookPointType = lookPointType;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getLookPointName() {
        return lookPointName;
    }

    public void setLookPointName(String lookPointName) {
        this.lookPointName = lookPointName;
    }

    public Long getLookPointId() {
        return lookPointId;
    }

    public void setLookPointId(Long lookPointId) {
        this.lookPointId = lookPointId;
    }

    public Integer getPollsNum() {
        return pollsNum;
    }

    public void setPollsNum(Integer pollsNum) {
        this.pollsNum = pollsNum;
    }

    public Integer getConsNum() {
        return consNum;
    }

    public void setConsNum(Integer consNum) {
        this.consNum = consNum;
    }
}
