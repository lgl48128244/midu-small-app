package com.leniao.huanbao.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.Areaprovince;

public interface AreaprovinceMapper extends BaseMapper<Areaprovince> {
}
