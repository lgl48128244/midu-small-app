package com.leniao.huanbao.dto.schedule;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Description:    设备用电量封装类
 * @Author:         haosw
 * @CreateDate:     2020/1/15 13:17
 * @Version:        1.0
 */
@Data
public class DeviceEleUseDto {
    private Integer devIdpk;
    private Integer unitId;
    private BigDecimal totalQ;
}
