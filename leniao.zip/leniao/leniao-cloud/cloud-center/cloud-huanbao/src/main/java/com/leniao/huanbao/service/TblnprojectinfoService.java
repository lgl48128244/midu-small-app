package com.leniao.huanbao.service;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.huanbao.entity.Tblnprojectinfo;

import java.util.List;
import java.util.Map;

public interface TblnprojectinfoService {

    /**
     *  通过县级编号，找出所有单位
     * */
    List<Tblnprojectinfo> findUnitInfo(Integer areaId);

    /**
     * 通过单位Id查出单位对应的信息
     * */
    Tblnprojectinfo findUnitAreaNameInfo(Integer unitId);

    /**
     * 通过省级编号查询出默认的单位id 单位名称 单位行政区域
     */
    Page<Map<String,Object>> findDefaultProvinceUnit(String provinceId);

    /**
     * 通过市级编号查询出默认单位id 单位名称 单位行政区域
     */
    Page<Map<String,Object>> findDefaultCityUnit(String cityId);

    /**
     * 通过县级编号查询出默认的单位id 单位名称 单位行政区域
     */
    Page<Map<String,Object>> findDefaultAreaUnit(String areaId);

    /**
     * 直接找出省级下的单位
     */
    List<Tblnprojectinfo> findProvinceUnit(String provinceId);

    /**
     * 直接找出市级下的单位
     */
    List<Tblnprojectinfo> findCityUnit(String cityId);

}
