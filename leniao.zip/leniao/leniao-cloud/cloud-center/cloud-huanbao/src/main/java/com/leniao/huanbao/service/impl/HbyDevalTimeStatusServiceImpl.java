package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.entity.HbyDevalTimeStatus;
import com.leniao.huanbao.entity.HbyDevalTimeStatusExample;
import com.leniao.huanbao.mapper.HbyDevalTimeStatusMapper;
import com.leniao.huanbao.mapper.HbyOverlookpointPlusMapper;
import com.leniao.huanbao.service.HbyDevalTimeStatusService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


/**
 * @author liudongshuai
 * @date 2019/12/26 14:04
 * @update
 * @description
 */
@Service
public class HbyDevalTimeStatusServiceImpl extends ServiceImpl<HbyDevalTimeStatusMapper,HbyDevalTimeStatus> implements HbyDevalTimeStatusService {

    @Resource
    private HbyDevalTimeStatusMapper hbyDevalTimeStatusMapper;

    @Resource
    private HbyOverlookpointPlusMapper hbyOverlookpointPlusMapper;



    /**
     * 返回一个企业的日运行数据
     */
    @Override
    public List<HbyDevalTimeStatus> findHbyDevalTimeStatus(Integer unitId, Integer devIdpk) {
        //创建条件
        QueryWrapper<HbyDevalTimeStatus> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyDevalTimeStatus::getUnitId,unitId).eq(HbyDevalTimeStatus::getDevIdpk,devIdpk);

        return hbyDevalTimeStatusMapper.selectList(queryWrapper);
    }

    /**
     * 返回一个企业的日运行数据
     */
    @Override
    public List<HbyDevalTimeStatus> findHbyDevalTimeStatus(Integer devIdpk) {
        //创建条件
        QueryWrapper<HbyDevalTimeStatus> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyDevalTimeStatus::getDevIdpk,devIdpk);

        return hbyDevalTimeStatusMapper.selectList(queryWrapper);
    }

    /**
     * 通过一个企业日数据的Id找出企业的日数据
     */
    @Override
    public HbyDevalTimeStatus findHbyDevalTimeStatus(Long id) {

        HbyDevalTimeStatusExample example = new HbyDevalTimeStatusExample();
        example.createCriteria().andIdEqualTo(id);
        HbyDevalTimeStatus hbyDevalTimeStatus = hbyDevalTimeStatusMapper.selectByExample(example).get(0);

        return hbyDevalTimeStatus;
    }

    /**
     * 返回一个企业的日运行数据
     */
    @Override
    public List<HbyDevalTimeStatus> findHbyDevalTimeStatus2( Integer devIdpk,Integer platformId) {

        //创建条件
        QueryWrapper<HbyDevalTimeStatus> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyDevalTimeStatus::getDevIdpk,devIdpk).eq(HbyDevalTimeStatus::getPlatformId,platformId);

        return hbyDevalTimeStatusMapper.selectList(queryWrapper);
    }


}
