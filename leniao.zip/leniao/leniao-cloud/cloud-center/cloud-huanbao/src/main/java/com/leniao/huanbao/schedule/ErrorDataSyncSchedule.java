package com.leniao.huanbao.schedule;

import com.alibaba.fastjson.JSON;
import com.leniao.commons.AbstractOperation;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.huanbao.constant.ScheduleConstant;
import com.leniao.huanbao.dto.schedule.DevDto;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.dto.schedule.OverLookPointWithDevlist;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyReduceplanJoinProjectService;
import com.leniao.huanbao.utils.ScheduleNeedUtil;
import com.leniao.service.HbyProjectErrorInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: 定时监测单位实时状态的任务程序
 * @Author: haosw
 * @CreateDate: 2019/12/23 10:53
 * @Version: 1.0
 */
@Slf4j
@Component
//@Profile({"DEV"})
@RestController
public class ErrorDataSyncSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;
    @Resource
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;
    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;
    @Resource
    private HbyReduceplanJoinProjectService hbyReduceplanJoinProjectService;


    /**
     * 异常数据的正向同步: 将原报警表中的相关数据同步到环保云异常管理表中
     * 相关数据:监测点下的设备的报警信息
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    private void begin() {
        log.info("=========================================================" + Thread.currentThread().getId() + "异常正向同步程序开始运行===================================================");
        /*
            执行业务层代码
         */
        //获取缓存的最大报警ID
        int maxWranId = 0;
        ValueOperations valueOperations = redisTemplate.opsForValue();
        Object o = valueOperations.get(ScheduleConstant.HBY_SCHEDULE_PREFIX + ScheduleConstant.MAX_RAW_WARN_ID);
        if (o != null) {
            maxWranId = (int) o;
        }
        //查询当前所有监测点中的设备的故障信息
        List<HbyProjectErrorInfo> devErrList = this.commonSimpleBeanInfoService.findAllOverlookDevErrs(maxWranId);
        //将最大报警ID存入缓存
        if (CollectionUtils.isNotEmpty(devErrList)) {
            IntSummaryStatistics longSummaryStatistics = devErrList.stream().mapToInt(e -> e.getRawErrid()).summaryStatistics();
            maxWranId = longSummaryStatistics.getMax();
            valueOperations.set(ScheduleConstant.HBY_SCHEDULE_PREFIX + ScheduleConstant.MAX_RAW_WARN_ID, maxWranId);

            //将异常数据插入数据库
            this.hbyProjectErrorInfoService.saveOrUpdateBatch(devErrList);
        }

        log.info("==========================================================" + Thread.currentThread().getId() + "异常正向同步程序结束运行==================================================");
    }


    /**
     * 异常数据的反向同步:将119异常表中已处理过的异常在环保云平台的异常表中修改其状态
     */
    @Scheduled(cron = "0 0/3 * * * ?")
    private void start() {
        log.info("=========================================================" + Thread.currentThread().getId() + "异常反向同步程序开始运行==================================================");
        //获取所有产污设备和治污设备未处理的异常
        List<HbyProjectErrorInfo> errorInfos = this.hbScheduledService.findHasBeenNormalErrInfo();
        errorInfos.stream().forEach(err -> {
            if (err.getPollOrCon().equals(1)) {
                //已处理无需申报
                err.setDealStatus(1);
            }
            if (err.getPollOrCon().equals(2)) {
                //已处理待申报
                err.setDealStatus(2);
            }
        });
        //批量修改异常的状态
        this.hbScheduledService.updateHbyErrorDealStatus(errorInfos);
        log.info("=========================================================" + Thread.currentThread().getId() + "异常反向同步程序结束运行==================================================");
    }


    /**
     * 电量异常，功率异常，治污设备停机异常
     */
    @Scheduled(cron = "0 0/15 * * * ?")
    @PostMapping("err")
    private void go() {
        log.info("=========================================================" + Thread.currentThread().getId() + "电量,功率,治污设备停机异常程序开始运行=====================================");
        Date now = DateTime.now().toDate();
        this.taskScheduler.schedule(new ErrorDataSyncSchedule.SoftChargedErrorRunnable(now), now);

    }

    /**
     * 停限产异常
     */
    @Scheduled(cron = "0 0/20 * * * ?")
    private void load() {
        log.info("=======================================================" + Thread.currentThread().getId() + "停限产异常程序开始运行======================================================");
        Date now = DateTime.now().toDate();
        //处理设备停限产异常
        this.dealWithDevReducePlanError(now);

    }

    private void dealWithDevReducePlanError(Date now) {
        Set<Integer> unitSet = new HashSet<>();
        //获取所有监测点及设备数据
        List<OverLookPointWithDevlist> overLookPointsWithDevlist = this.hbScheduledService.findOverLookPointsWithDevlist();
        for (OverLookPointWithDevlist lookPoint : overLookPointsWithDevlist) {
            Integer unitId = lookPoint.getUnitId();
            if (unitSet.contains(unitId)) {
                continue;
            }
            List<OverLookPointWithDevlist> unitPointList = overLookPointsWithDevlist.stream().filter(p -> p.getUnitId().equals(unitId)).collect(Collectors.toList());
            unitSet.add(unitId);
            this.dealWithOverLookPointData(unitPointList, now, unitId);
        }
        log.info("=========================================================" + Thread.currentThread().getId() + "停限产异常程序结束运行=====================================================");
    }

    private void dealWithOverLookPointData(List<OverLookPointWithDevlist> unitPointList, Date now, Integer unitId) {
        DateTime[] frontTimeArea = ScheduleNeedUtil.getFrontTimeArea(now);
        //获取单位关联的减产减排方案
        HbyReduceEmmissionPlan plan = this.hbScheduledService.findReduceEmmPlanByUnitId(unitId);
        for (OverLookPointWithDevlist lookPoint : unitPointList) {
            /**
             * 判断当前方案是否过期
             * 注意：此判断与下面的判断有所区别，此判断为当前方案是否过期，下面的ScheduleNeedUtil.isPlanInTimeArea(plan, now)判断
             * 是在判断当前时间是否在方案的运行时间区间内，两者无法通用
             */
            if (ScheduleNeedUtil.isPlanOutOfTime(plan)) {
                try {
                    if (plan != null) {
                        HbyReduceplanJoinProjectExample example = new HbyReduceplanJoinProjectExample();
                        example.createCriteria().andPlanIdEqualTo(plan.getPlanId());
                        int i = this.hbyReduceplanJoinProjectService.deleteByExample(example);
                        if (i > 0) {
                            log.info("=============================================删除方案关联成功=======================================================");
                        }else {
                            log.info("=============================================删除方案关联失败=======================================================");
                        }
                    }
                } catch (Exception e) {
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~判断方案是否过期异常~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    log.error(e.getMessage(), e);
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                }

            }
            //如果方案过期 或 当前时间不在方案限定的时间区间内,则停止当前判断
            if (!ScheduleNeedUtil.isPlanInTimeArea(plan, now)) {
                return;
            }
            List<DevDto> pointDevs = lookPoint.getPointDevs();
            for (DevDto devDto : pointDevs) {
                devDto.setNow(now);
                Integer devProTy = devDto.getDevProTy();
                //如果不是产污设备,直接跳过
                if (devProTy != 1) {
                    continue;
                }

                //设备功率门限时间
                Integer devPowerLiveTime = lookPoint.getPollDevPowerLiveTime();
                //设备启停功率阈值
                Integer devPowerSillVal = lookPoint.getPollDevPowerSillVal();
                //设备额定功率
                Integer devPower = lookPoint.getPollDevPower();
                //计算设备上传数据包数的开始时间
                DateTime sBeginTime = frontTimeArea[0];
                DateTime eEndTime = frontTimeArea[1];
                if (devPowerLiveTime >= 20) {
                    sBeginTime = frontTimeArea[1].minus(devPowerLiveTime * 60 * 1000);
                }
                //获取HBase数据--指定时间内的每个节点最多20条数据
                List<realValueList1> dataPackages = hbScheduledService.getDataPackagesOfTimeArea(sBeginTime, eEndTime, devDto.getDevIdpk());
                int devState = ScheduleNeedUtil.getDevState(dataPackages, devPowerSillVal, devPower);
                // TODO 为了测试效果devState = 1;
                if (devState == 1) {
                    //判断
                    if (plan.getPlanType().equals(1)) {
                        Date beginTime = plan.getBeginTime();
                        Date endTime = plan.getEndTime();
                        String stopProducTimeList = plan.getStopProducTimeList();
                        List<String> strings = JSON.parseArray(stopProducTimeList, String.class);
                        HbyErrorDto.StopProErrChargeDto stopProErrChargeDto = ScheduleNeedUtil.chargeTimeIsInTimeArea(beginTime, endTime, strings, now);
                        if (stopProErrChargeDto.isInTimeArea()) {
                            //新增或修改一条停产异常
                            this.hbScheduledService.saveOrUpdateStopProPlanErr(devDto, plan, stopProErrChargeDto);
                        }
                    } else if (plan.getPlanType().equals(2)) {
                        //判断生产小时数是否超标
                        HbyReduceplanJoinProject reducePlanJoin = this.hbScheduledService.findReducePlanJoinUnitByUnitId(unitId);
                        if (reducePlanJoin != null) {
                            Long sumTime = reducePlanJoin.getSumProTime() == null ? 0 : reducePlanJoin.getSumProTime();
                            double hourSum = BigDecimalUtils.calculate(sumTime).div(60).getBigDecimal().doubleValue();
                            // TODO 为了测试效果hourSum = 120;
                            if (BigDecimalUtils.is(hourSum).gt(plan.getLimitProducTimeCount())) {
                                //新增或修改一个限产异常
                                this.hbScheduledService.saveOrUpdateLimitProPlanErr(devDto, plan, hourSum);
                            }
                        }

                    } else {
                        log.debug("未知的减产减排计划类型" + plan.toString());
                    }
                }


            }
        }

    }


    /**
     * @Description: 判断监测点设备的软件异常程序
     * @Author: haosw
     * @CreateDate: 2019/12/26 19:01
     * @Version: 1.0
     */
    private class SoftChargedErrorRunnable implements Runnable {

        private volatile Date now;

        public SoftChargedErrorRunnable(Date now) {
            this.now = now;
        }

        @Override
        public void run() {
            Set<Integer> unitSet = new HashSet<>();
            List<OverLookPointWithDevlist> overLookPointsWithDevlist = hbScheduledService.findOverLookPointsWithDevlist();
            if (overLookPointsWithDevlist != null && overLookPointsWithDevlist.size() > 0) {
                overLookPointsWithDevlist.stream().forEach(point -> {
                    List<DevDto> pointDevs = point.getPointDevs();
                    for (DevDto devDto : pointDevs) {
                        devDto.setNow(now);
                    }
                });
                //以企业为基本单位,把监测点进行分类,获取所有的监测点
                for (OverLookPointWithDevlist lookPoint : overLookPointsWithDevlist) {
                    Integer unitId = lookPoint.getUnitId();
                    if (unitSet.contains(unitId)) {
                        continue;
                    }
                    unitSet.add(unitId);
                    List<OverLookPointWithDevlist> unitOverLookWithDevList = overLookPointsWithDevlist.stream().filter(overlook -> overlook.getUnitId().equals(unitId)).collect(Collectors.toList());
                    //处理这个单位的监测点数据
                    dealWithOverLookPointData(unitOverLookWithDevList, now);
                }
            }
            log.info(Thread.currentThread().getId() + "电量,功率,治污设备停机异常程序结束运行");
            log.info("异步调用单位日数据统计");
            new ProjectDayCountSchedule().run();
        }
    }


    /**
     * @description: 方法的作用描述
     * @author: haosw
     * @param: OverLookPointWithDevlist: 单位监测点带设备的集合
     * @return:
     * @date: 2019/12/27 14:24
     */
    private void dealWithOverLookPointData(List<OverLookPointWithDevlist> unitOverLookWithDevList, Date now) {
        DateTime[] frontTimeArea = ScheduleNeedUtil.getFrontTimeArea(now);
        for (OverLookPointWithDevlist lookPoint : unitOverLookWithDevList) {
            List<DevDto> pointDevs = lookPoint.getPointDevs();
            //updateTime: 2020-01-08 11:24
            //将当前检测点下的治污和产污设备分开
            //总检测点设备
            List<DevDto> rootDevs = pointDevs.stream().filter(devDto -> devDto.getDevProTy().equals(0)).collect(Collectors.toList());
            //产污设备
            List<DevDto> pollDevs = pointDevs.stream().filter(devDto -> devDto.getDevProTy().equals(1)).collect(Collectors.toList());
            //治污设备
            List<DevDto> conDevs = pointDevs.stream().filter(devDto -> devDto.getDevProTy().equals(2)).collect(Collectors.toList());
            //遍历产污设备判断结果 默认产污设备无运行
            boolean isPollRun = false;
            for (DevDto pollDev : pollDevs) {
                //直接去处理产污设备数据，返回设备运行状态，如果有运行的设备则治污设备也必须要运行
                //TODO 此处必须保证 devWorkState 有值，且有效
                // com.leniao.huanbao.service.impl.HbScheduledServiceImpl.updateOrInsertWorkStatus-182Line修改设备状态
                if (pollDev.getDevWorkState().equals(1) || pollDev.getDevWorkState().equals(2)) {
                    isPollRun = true;
                }
                //判断并处理电量异常
                try {
                    this.hbScheduledService.executeCatchLookPointDevEleErr(frontTimeArea, lookPoint, pollDev);
                } catch (Exception e) {
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~处理产污设备电量异常出错了~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    log.error(e.getMessage(), e);
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                }
                try {
                    this.hbScheduledService.executeCatchLookPointDevPowerErr(frontTimeArea, lookPoint, pollDev, pollDev.getDevProTy(),false);
                } catch (Exception e) {
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~处理产污设备功率和停机异常出错了~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    log.error(e.getMessage(), e);
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                }
            }

            //默认治污设备无运行
            boolean isConRun = false;
            for (DevDto conDev : conDevs) {
                if (conDev.getDevWorkState().equals(1) || conDev.getDevWorkState().equals(2)) {
                    isConRun = true;
                }
            }
            //如果有产污设备运行：可能治污设备停机异常，可能治污设备功率异常，可能治污设备电量异常
            if (isPollRun) {
                for (DevDto conDev : conDevs) {
                    try {
                        this.hbScheduledService.executeCatchLookPointDevPowerErr(frontTimeArea, lookPoint, conDev, conDev.getDevProTy(), isConRun);
                    } catch (Exception e) {
                        log.error("处理治污设备功率和停机异常出错了：" + e);
                    }
                    //电量异常
                    try {
                        this.hbScheduledService.executeCatchLookPointDevEleErr(frontTimeArea, lookPoint, conDev);
                    } catch (Exception e) {
                        log.error("处理治污设备电量异常出错了：" + e);
                    }
                }
            }
            //缓存总检测点设备的功率
            for (DevDto rootDev : rootDevs) {
                //总监测点设备---处理总检测点设备的数据，缓存最大用电量，最大功率和时间
                try {
                    this.hbScheduledService.executeCachRootPointDevEleAndPower(frontTimeArea, rootDev);
                } catch (Exception e) {
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~缓存总监测点设备电量异常了~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    log.error(e.getMessage(), e);
                    log.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                }
            }
        }
    }


}
