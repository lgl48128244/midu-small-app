package com.leniao.huanbao.pojo.pagetopselecteneity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/23 17:05
 * @update
 * @description
 */
@Data
public class AddlookPointInfo implements Serializable {

    //单位Id
    private String unitId;
    //账号Id
    private String userId;
    //监测点名称
    private String lookPointName;
    //所属分组
    private String group;
    //分组Id
    private String groupId;
    //是否演示箱
    private Integer isDemoBox;
    //设备用途
    private String devUsing;
    //监测点备注
    private String remark;
    //监测点类别
    private Integer pointType;
    //监测点创建时间
    private String addTime;
    //设备名称 == 设备地址+设备编号
    private String devSign;
    //产污设备额定功率
    private Integer pollDevPower;
    //产污设备功率启停阈值
    private Integer pollDevPowerSillVal;
    //产污设备功率门限时间
    private Integer pollDevPowerLiveTime;
    //产污设备电量阈值
    private Integer pollDevEleSillVal;
    //产污设备电量门限时间
    private Integer pollDevEleLiveTime;
    //产污设备分类
    private Integer pollDevType;
    //治污设备额定功率
    private Integer conDevPower;
    //治污设备功率启停阈值
    private Integer conDevPowerSillVal;
    //治污设备功率门限时间
    private Integer conDevPowerLiveTime;
    //治污设备电量阈值
    private Integer conDevEleSillVal;
    //治污设备电量门限时间
    private Integer conDevEleLiveTime;
    //治污设备分类
    private Integer conDevType;
    //治污设备集合
    private List<String> cons;
    //产污设备集合
    private List<String> polls;
    //操作 1,添加 添加时，监测点id可以为空 2，修改时，监测点ID（updateId）不能为空
    private String checkId;

    private String updateId;

    public String getCheckId() {
        return checkId;
    }

    public void setCheckId(String checkId) {
        this.checkId = checkId;
    }

    public String getUpdateId() {
        return updateId;
    }

    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLookPointName() {
        return lookPointName;
    }

    public void setLookPointName(String lookPointName) {
        this.lookPointName = lookPointName;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getDevUsing() {
        return devUsing;
    }

    public void setDevUsing(String devUsing) {
        this.devUsing = devUsing;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getDevSign() {
        return devSign;
    }

    public void setDevSign(String devSign) {
        this.devSign = devSign;
    }

    public List<String> getCons() {
        return cons;
    }

    public void setCons(List<String> cons) {
        this.cons = cons;
    }

    public List<String> getPolls() {
        return polls;
    }

    public void setPolls(List<String> polls) {
        this.polls = polls;
    }
}
