package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/20 16:54
 * @update
 * @description
 */
public class SendAreaInfo {
    private String areaId;
    private String area;

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "SendAreaInfo{" +
                "areaId='" + areaId + '\'' +
                ", area='" + area + '\'' +
                '}';
    }
}
