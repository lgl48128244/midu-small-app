package com.leniao.huanbao.listener;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpServletRequest;

/**
 * @author guoliang.li
 * @date 2019/12/19 13:15
 * @description TODO
 */
//@WebListener("这是一个测试监听器")
public class TestListener implements ServletRequestListener {

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {

    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        System.out.println("==========监听器生效==============");
        ServletRequest servletRequest = sre.getServletRequest();
        int serverPort = servletRequest.getServerPort();
        System.out.println("服务端口：" + serverPort);
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        StringBuffer requestUrl = request.getRequestURL();
        System.out.println("请求地址：" + requestUrl);
    }
}