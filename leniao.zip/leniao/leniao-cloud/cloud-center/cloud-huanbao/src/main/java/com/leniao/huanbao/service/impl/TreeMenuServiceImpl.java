package com.leniao.huanbao.service.impl;

import com.github.pagehelper.PageHelper;
import com.leniao.commons.BaseService;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.HbyOverLookPointExample;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.mapper.TreeMenuMapper;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.service.TreeMenuService;
import com.leniao.mapper.HbyAgencyMapper;
import com.leniao.mapper.HbyOverLookPointMapper;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.swing.text.GapContent;
import java.util.*;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 树形结构菜单
 * @author: jiangdy
 * @create: 2019-12-23 11:23
 **/
@Service
public class TreeMenuServiceImpl extends BaseService implements TreeMenuService {

    @Autowired
    private PermissionService permissionService;

    @Resource
    private TreeMenuMapper treeMenuMapper;

    @Resource
    private HbyAgencyMapper hbyAgencyMapper;

    @Resource
    private HbyOverLookPointMapper hbyOverLookPointMapper;

    /**
     * 根据单位区域码查询机构
     * @param provinceCode 省级区域码
     * @param cityCode 市区级区域码
     * @param areaCode 县区级区域码
     * @return 该区域的机构信息（仅一个）
     */
    @Override
    public TreeMenu selectAgencyInfoByAreaCode(String provinceCode, String cityCode, String areaCode, int platformId) {
        return treeMenuMapper.selectAgencyInfoByAreaCode(provinceCode, cityCode, areaCode, platformId);
    }

    /**
     * 区域用户查询区域下的所有机构
     * @param agencyId 机构id 查找指定机构的信息
     * @param platformId 平台id
     * @param areaCode 用户所在区域的区域码
     * @param userGrade 区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
     * @return Map<Integer, TreeMenu> Map<key:区域id, TreeMenu>
     */
    @Override
    public Map<Long, TreeMenu> selectAgencyInfoByUserAreaCode(Long agencyId, int platformId, AreaCodeJoinOther areaCode, int userGrade) {
        return treeMenuMapper.selectAgencyInfoByUserAreaCode(agencyId, platformId, areaCode, userGrade);
    }

    /**
     * 通过机构菜单查询单位
     * @param agencyInfo 机构菜单信息
     * @param onlyRead 只否只读
     * @return
     */
    @Override
    public List<TreeMenu> selectProjectInfoByAgencyTreeMenu(TreeMenu agencyInfo, int onlyRead, Map<String, Object> params) {
        UserInfo userInfo = GlobalConstant.getUserInfo();
        return treeMenuMapper.selectProjectInfoByAgencyTreeMenu(agencyInfo, userInfo.getPlatformId(), onlyRead, params);
    }

    @Override
    public List<TreeMenu> selectCanShowProjectByAgency(Integer userId, Long agencyId, Integer parentNodeType, Integer pageNum, Integer pageSize, Map<String, Object> params) {
        // 查询机构下的所有单位.
        HbyAgency hbyAgency = hbyAgencyMapper.selectByPrimaryKey(agencyId);
        if (hbyAgency == null) {
            throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        List<TreeMenu> treeMenuList = treeMenuMapper.selectCanShowProjectByAgency(hbyAgency, userInfo.getPlatformId(), userId, params);
//        treeMenuList.stream().forEach(tree -> {
//            if (tree.getOnlyRead() == 0) {
//                tree.setNodeName(tree.getNodeName() + "-分-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 1) {
//                tree.setNodeName(tree.getNodeName() + "-下-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 2) {
//                tree.setNodeName(tree.getNodeName() + "-权-有权");
//                tree.setOnlyRead(1);
//            } else if (tree.getOnlyRead() == 3) {
//                tree.setNodeName(tree.getNodeName() + "-创-有权");
//                tree.setOnlyRead(1);
//            }
//        });
        return treeMenuList;
    }

    @Override
    public List<TreeMenu> selectChildTreemenu(Integer platformId, Integer onlyRead, Long parentNodeId, Integer parentNodeType, Integer pageNum, Integer pageSize, Map<String, Object> params) {
        List<TreeMenu> treeMenuList = null;
        switch (parentNodeType) {
            case 1:
                // 查询机构下的所有单位.
                HbyAgency hbyAgency = hbyAgencyMapper.selectByPrimaryKey(parentNodeId);
                if (hbyAgency == null) {
                    throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
                }
                TreeMenu agencyInfo = new TreeMenu();
                agencyInfo.setAreaCode(hbyAgency.getAreaCode());
                agencyInfo.setCityCode(hbyAgency.getCityCode());
                agencyInfo.setProvinceCode(hbyAgency.getProvinceCode());
                agencyInfo.setNodeId(hbyAgency.getId());
                agencyInfo.setNodeType(parentNodeType);
                agencyInfo.setOnlyRead(onlyRead);
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                if (params == null) {
                    params = new HashMap<>();
                }
                if (params.get("showAll") == null) {
                    params.put("showAll", 0);
                }
                treeMenuList = this.selectProjectInfoByAgencyTreeMenu(agencyInfo, onlyRead, params);
                break;
            case 2:
                // 查询单位下的所有分组
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                treeMenuList = treeMenuMapper.selectDeviceGroupByProjId(parentNodeId.longValue(), parentNodeType, onlyRead);
                List<TreeMenu> childTreeMenu = null;
                TreeMenu treeMenu = null;
                ListIterator<TreeMenu> iter = treeMenuList.listIterator();
                while (iter.hasNext()) {
                    treeMenu = iter.next();
                    childTreeMenu = treeMenuMapper.selectOverLookPointByGroupId(treeMenu.getNodeId().longValue(), treeMenu.getNodeType(), onlyRead);
                    if (childTreeMenu == null || childTreeMenu.size() == 0) {
                        iter.remove();
                    }
                }
//                for (TreeMenu treeMenu : treeMenuList) {
//                    childTreeMenu = treeMenuMapper.selectOverLookPointByGroupId(treeMenu.getNodeId().longValue(), treeMenu.getNodeType(), onlyRead);
//                    if (childTreeMenu == null || childTreeMenu.size() == 0) {
//                        treeMenuList.remove(treeMenu);
//                    }
//                }
                break;
            case 3:
                // 查询分组下的所有监测点
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                treeMenuList = treeMenuMapper.selectOverLookPointByGroupId(parentNodeId.longValue(), parentNodeType, onlyRead);
                break;
            case 4:
                // 查询监测点下的所有总表/产/治污设备
                List<TreeMenu> deviceTreeMenuList = null;
                // 总监测点
                TreeMenu lookPoint0 = createLookPoint(parentNodeId, parentNodeType, onlyRead, 0L, "总表设备");
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                deviceTreeMenuList = treeMenuMapper.selectDeviceInfoByOverLookPointId(lookPoint0.getNodeId(), lookPoint0.getNodeType(), onlyRead, parentNodeId);
                lookPoint0.setChildTreeMenu(deviceTreeMenuList);
                // 产污监测点
                TreeMenu lookPoint1 = createLookPoint(parentNodeId, parentNodeType, onlyRead, 1L, "产污设备");
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                deviceTreeMenuList = treeMenuMapper.selectDeviceInfoByOverLookPointId(lookPoint1.getNodeId(), lookPoint1.getNodeType(), onlyRead, parentNodeId);
                lookPoint1.setChildTreeMenu(deviceTreeMenuList);
                // 治污监测点
                TreeMenu lookPoint2 = createLookPoint(parentNodeId, parentNodeType, onlyRead, 2L, "治污设备");
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                deviceTreeMenuList = treeMenuMapper.selectDeviceInfoByOverLookPointId(lookPoint2.getNodeId(), lookPoint2.getNodeType(), onlyRead, parentNodeId);
                lookPoint2.setChildTreeMenu(deviceTreeMenuList);

                treeMenuList = new ArrayList<>();
                if (lookPoint0 != null && lookPoint0.getChildTreeMenu().size() > 0) {
                    treeMenuList.add(lookPoint0);
                } else {
                    treeMenuList.add(lookPoint1);
                    treeMenuList.add(lookPoint2);
                }
                break;
            case 5:
                // 查询总表/产/治污设备下的所有设备列表
                if (pageNum != null && pageNum > 0) {
                    PageHelper.startPage(pageNum, pageSize);
                }
                treeMenuList = treeMenuMapper.selectDeviceInfoByOverLookPointId(parentNodeId.longValue(), parentNodeType, onlyRead, parentNodeId);
                break;
            default:
                throw new CloudException(CloudErrorCode.PARAM_INVALID);
        }
        return treeMenuList;
    }

    /**
     * 根据单位id查询监测点
     * @param projId
     * @return
     */
    @Override
    public List<HbyOverLookPoint> selectOverLookPointByProjId(Integer projId) {
        HbyOverLookPointExample example = new HbyOverLookPointExample();
        example.createCriteria().andUnitIdEqualTo(projId);;
        return hbyOverLookPointMapper.selectByExample(example);
    }


    /**
     * 非区域用户查询树形菜单
     * @param userId 用户id
     * @param platformId 平台id
     * @param params 条件参数 当前支持 行业类型id industryId, 单位id projId, 区域id agencyId 查询,key值严格要求相同
     * @return 菜单（机构信息以及机构下的单位信息）
     */
    @Override
    public List<TreeMenu> createTreeMenuByNotAreaUser(int userId, int platformId, Map<String, Object> params) {

        Map<Long, TreeMenu> agcyMap = new HashMap<>();
        // 查询用户可见的单位信息
        List<TreeMenu> projectList = permissionService.selectCanShowProjectByUserId(userId, false,null, null,  params);
        if (projectList == null || projectList.size() == 0) {
            throw new CloudException(CloudErrorCode.SYS_EMPTY);
        }

        TreeMenu agencyInfo = null;
        List<TreeMenu> childTreeMenu = null;

        // 遍历单位，找到单位所在的机构，并将单位加到该机构底下
        for (TreeMenu projectInfo : projectList) {
            // 根据单位区域码查询机构
            agencyInfo = this.selectAgencyInfoByAreaCode(projectInfo.getProvinceCode(), projectInfo.getCityCode(), projectInfo.getAreaCode(), platformId);
            if (agencyInfo != null) {

                if (params != null && params.get("agencyId") != null) {
                    // 条件查询制定区域id下的信息
                    if (!agencyInfo.getNodeId().equals(params.get("agencyId"))) {
                        continue;
                    }
                }
                if (agcyMap.get(agencyInfo.getNodeId()) == null) {
                    agcyMap.put(agencyInfo.getNodeId(), agencyInfo);
                }
                childTreeMenu = agcyMap.get(agencyInfo.getNodeId()).getChildTreeMenu();
                if (childTreeMenu == null) {
                    childTreeMenu = new ArrayList<>();
                }
                projectInfo.setParentNodeId(agencyInfo.getNodeId());
                projectInfo.setParentNodeType(agencyInfo.getNodeType());
                childTreeMenu.add(projectInfo);

            }
        }

        return new ArrayList<>(agcyMap.values());
    }

    /**
     * 区域用户查询树形菜单
     * @param onlyRead 用户id
     * @param platformId 平台id
     * @param params 条件参数 当前支持 行业类型id industryId, 单位id projId, 区域id agencyId 查询,key值严格要求相同
     * @param areaCode 区域用户区域码
     * @param userGrade 区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
     * @return 菜单（机构信息）
     */
    @Override
    public List<TreeMenu> createTreeMenuByAreaUser(int onlyRead, int platformId, Map<String, Object> params, AreaCodeJoinOther areaCode, int userGrade) {

        Long agencyId = null;
        if (params != null && params.get("agencyId") != null) {
            agencyId = Long.valueOf((String) params.get("agencyId"));
        }

        // 查询区域内的所有机构， 如果指定agencyId机构id，则查询指定机构
        Map<Long, TreeMenu> agencyMap = this.selectAgencyInfoByUserAreaCode(agencyId, platformId, areaCode, userGrade);

        // 所有条件查询都必须先指定机构
        if (agencyId != null && agencyMap != null && agencyMap.size() > 0) {
            TreeMenu agencyInfo = agencyMap.get(agencyId);
            List<TreeMenu> projTreeMenuList = this.selectProjectInfoByAgencyTreeMenu(agencyInfo, onlyRead, params);
            agencyInfo.setChildTreeMenu(projTreeMenuList);
        }

        return new ArrayList<>(agencyMap.values());
    }

    private TreeMenu createLookPoint(Long parentNodeId, Integer parentNodeType, Integer onlyRead, Long lookPointId, String lookPointName) {
        TreeMenu lookPoint = new TreeMenu();
        lookPoint.setOnlyRead(onlyRead);
        lookPoint.setParentNodeId(parentNodeId.longValue());
        lookPoint.setParentNodeType(parentNodeType);
        lookPoint.setNodeId(lookPointId);
        lookPoint.setNodeName(lookPointName);
        lookPoint.setNodeType(5);
        return lookPoint;
    }
}
