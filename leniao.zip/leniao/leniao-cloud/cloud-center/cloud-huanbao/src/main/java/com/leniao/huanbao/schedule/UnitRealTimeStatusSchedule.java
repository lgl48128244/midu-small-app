package com.leniao.huanbao.schedule;

import com.leniao.commons.AbstractOperation;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description:    定时监测单位实时状态的任务程序
 * @Author:         haosw
 * @CreateDate:     2019/12/23 10:53
 * @Version:        1.0
 */
@Slf4j
@Component
//@Profile({"DEV"})
public class UnitRealTimeStatusSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;
    @Resource
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;



    @Scheduled(cron = "5 * * * * ?")
    private void begin() {
        log.info("========================+++++++++++++++++++++++==========================单位实时状态监测程序开始运行============================++++++++++++++++++++++++===================");
        //执行业务层代码
        //1.查询监测点的单位基本信息
        List<UnitBasicInfoDto> unitBasicInfoDtoList = this.commonSimpleBeanInfoService.findAllUnitBasicInfo();
        //将基本信息处理后存入数据库
        this.hbScheduledService.updateOrInsertUnitInfo(unitBasicInfoDtoList);
    }



}
