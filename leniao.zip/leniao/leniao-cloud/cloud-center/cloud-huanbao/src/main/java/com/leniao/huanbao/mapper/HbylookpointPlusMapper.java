package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leniao.entity.HbyOverLookPoint;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/25 14:47
 * @update
 * @description
 */
public interface HbylookpointPlusMapper {

    @Select("SELECT look_id AS lookPointId FROM hby_overlookpoint WHERE unit_id=#{unitId};")
    List<Map<String,Object>> findLookPointId(Page<Map<String,Object>> page, Integer unitId);

    @Select("SELECT * FROM hby_overlookpoint WHERE update_time > #{date} AND unit_id =#{unitId} AND deleted = 0")
    List<HbyOverLookPoint> findLookPointInfo(Integer unitId, String date);

    @Select("SELECT * FROM hby_overlookpoint WHERE update_time > #{date} AND unit_id =#{unitId} AND dev_group_id=#{groupId}  AND deleted = 0")
    List<HbyOverLookPoint> findLookPointInfoByGroupId(Integer unitId,String date,Integer groupId);

}
