package com.leniao.huanbao.pojo.receive;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author liudongshuai
 * @date 2020/1/15 10:27
 * @update
 */
public class UnitUseEleInfo implements Comparable<UnitUseEleInfo>{

    private String unitName;
    private Double conDevEleUse;
    private Double pollDevEleUse;
    private Double totalDevEleUse;
    private Double conPollProportion;
    private Double conTotalProportion;

    @Override
    public int compareTo(UnitUseEleInfo o) {
        return this.totalDevEleUse.compareTo(o.getTotalDevEleUse());
    }

    public Double getConPollProportion() {
        return conPollProportion;
    }

    public Double getConTotalProportion() {
        return conTotalProportion;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public Double getConDevEleUse() {
        return conDevEleUse;
    }

    public void setConDevEleUse(Double conDevEleUse) {
        this.conDevEleUse = Double.valueOf(String.valueOf(new BigDecimal(conDevEleUse).setScale(1, RoundingMode.HALF_UP)));
    }

    public Double getPollDevEleUse() {
        return pollDevEleUse;
    }

    public void setPollDevEleUse(Double pollDevEleUse) {
        this.pollDevEleUse = Double.valueOf(String.valueOf(new BigDecimal(pollDevEleUse).setScale(1, RoundingMode.DOWN)));
    }

    public Double getTotalDevEleUse() {
        return totalDevEleUse;
    }

    public void setTotalDevEleUse(Double totalDevEleUse) {
        this.totalDevEleUse = Double.valueOf(String.valueOf(new BigDecimal(totalDevEleUse).setScale(1, RoundingMode.DOWN)));
    }

    public void setConPollProportion(Double conPollProportion) {
        this.conPollProportion = Double.valueOf(String.valueOf(new BigDecimal(conPollProportion).setScale(1, RoundingMode.DOWN)));
    }

    public void setConTotalProportion(Double conTotalProportion) {
        this.conTotalProportion = Double.valueOf(String.valueOf(new BigDecimal(conTotalProportion).setScale(1, RoundingMode.DOWN)));
    }
}
