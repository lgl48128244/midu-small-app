package com.leniao.huanbao.service;




import com.leniao.huanbao.entity.Areacity;

import java.util.List;

public interface AreacityService {
    /**
     * 根据省份ID查出，相应省份下的所有的市级信息
     */

    List<Areacity> findAllCity(String provinceId);
}
