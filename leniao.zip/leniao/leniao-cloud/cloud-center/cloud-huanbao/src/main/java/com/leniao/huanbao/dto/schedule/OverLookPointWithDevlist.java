package com.leniao.huanbao.dto.schedule;

import com.leniao.entity.HbyOverLookPoint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
/**
 * @Description:    查询监测点以及监测点关联的设备集合
 * @Author:         haosw
 * @CreateDate:     2019/12/20 15:44
 * @Version:        1.0
 */
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OverLookPointWithDevlist extends HbyOverLookPoint implements Serializable {
    /**
     * 监测点中的设备
     */
    private List<DevDto> pointDevs;

}
