package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.huanbao.mapper.TbdeviceInfoPlusMapper;

import com.leniao.huanbao.service.TblndeviceinfoService;

import com.leniao.mapper.TblndeviceinfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * @author liudongshuai
 * @date 2019/12/19 16:17
 */
@Service
public class TblndeviceinfoServiceImpl extends ServiceImpl<TblndeviceinfoMapper, Tblndeviceinfo> implements TblndeviceinfoService {

    @Resource
    private TblndeviceinfoMapper tblndeviceinfoMapper;

    @Resource
    private TbdeviceInfoPlusMapper tbdeviceInfoPlusMapper;

    /**
     * 通过设备编号查出设备信息
     */
    @Override
    public Tblndeviceinfo findGroupIdProTyStatus(String devSign) {
        //创建条件对象
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Tblndeviceinfo::getDevsignature,devSign).eq(Tblndeviceinfo::getIsdelete,0);

        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoMapper.selectOne(queryWrapper);

        return tblndeviceinfo;

    }

    /**
     * 通过单位id查出设备相应的信息
     * devgroupId AS groupId,
     * devSignature AS devSign,
     * overlookId AS overlookId,
     * devProTy AS devTy,
     * devWorkState AS devStatus
     */
    @Override
    public List<Tblndeviceinfo> findGroupIdLookPointStatus(Integer unitId, Integer pageCount, Integer pageSize) {
        //创建条件对象
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.lambda().eq(Tblndeviceinfo::getProjid,unitId).eq(Tblndeviceinfo::getIsdelete,0);

        //不返回总记录数 设置false
        Page<Tblndeviceinfo> page = new Page<>(pageCount, pageSize, false);
        IPage<Tblndeviceinfo> iPage = baseMapper.selectPage(page, queryWrapper);

        return iPage.getRecords();

    }

    /**
     * 通过分组ID 查出对应分组下的所有的设备编号
     */
    @Override
    public List<Tblndeviceinfo> findDevSign(Integer groupId) {

        //创建条件
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("devsignature","installlocation","devidpk").lambda().eq(Tblndeviceinfo::getDevgroupid,groupId).eq(Tblndeviceinfo::getIsdelete,0);

        return tblndeviceinfoMapper.selectList(queryWrapper);
    }

    /**
     * 通过设备编号，找出对应的设备安装位置
     */
    @Override
    public String findLocation(String devSign) {
        //创建条件
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("installLocation").lambda().eq(Tblndeviceinfo::getDevsignature,devSign).eq(Tblndeviceinfo::getIsdelete,0);
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoMapper.selectOne(queryWrapper);

        if (tblndeviceinfo==null){
            return "";
        }else {
            return tblndeviceinfo.getInstalllocation();
        }

    }

    /**
     * 通过设备Id，找出安装位置
     */
    @Override
    public String findLocation(Integer devId) {
        //创建条件
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("installLocation").lambda().eq(Tblndeviceinfo::getDevidpk,devId).eq(Tblndeviceinfo::getIsdelete,0);
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoMapper.selectOne(queryWrapper);

        if (tblndeviceinfo==null){
            return "";
        }else {
            return tblndeviceinfo.getInstalllocation();
        }
    }

    /**
     * 通过设备编号找到对应的设备ID
     */
    @Override
    public Integer findDevIdPk(String devSign) {
        //创建条件
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("devidpk").lambda().eq(Tblndeviceinfo::getDevsignature,devSign).eq(Tblndeviceinfo::getIsdelete,0);
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoMapper.selectOne(queryWrapper);
        if (tblndeviceinfo==null){
            return null;
        }else {
            return tblndeviceinfo.getDevidpk();
        }

    }

    /**
     * 通过设备id 找出设备编号
     */
    @Override
    public String findDevSignById(Integer devIdpk) {
        //创建条件
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("devsignature").lambda().eq(Tblndeviceinfo::getDevidpk,devIdpk).eq(Tblndeviceinfo::getIsdelete,0);
        Tblndeviceinfo tblndeviceinfo = tblndeviceinfoMapper.selectOne(queryWrapper);
        if (tblndeviceinfo==null){
            return "";
        }else {
            return tblndeviceinfo.getDevsignature();
        }

    }

    @Override
    public Tblndeviceinfo findDevBydDevSig(String devSignature) {
        QueryWrapper<Tblndeviceinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Tblndeviceinfo::getDevsignature, devSignature).eq(Tblndeviceinfo::getIsdelete,0);
        return this.tblndeviceinfoMapper.selectOne(queryWrapper);
    }

    /**
     * 通过单位Id 找出相应的设备信息
     */
    @Override
    public List<Tblndeviceinfo> findDevInfoByUnitId(Integer unitId,String date,Integer groupId,Integer pageCount,Integer size) {

        if (groupId==0){
            return tbdeviceInfoPlusMapper.findDevInfoByUnitId(unitId,date,pageCount,size);
        }else{
            return tbdeviceInfoPlusMapper.findDevInfoByUnitIdGroupId(unitId,groupId,date,pageCount,size);
        }

    }

}
