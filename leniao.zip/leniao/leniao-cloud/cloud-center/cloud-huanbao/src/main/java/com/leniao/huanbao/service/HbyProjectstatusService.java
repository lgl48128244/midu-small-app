package com.leniao.huanbao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.entity.HbyProjectstatusExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyProjectstatusService extends IService<HbyProjectstatus> {

    /**
     * 通过单位id查出单位运行的全部状态数据
     */
    HbyProjectstatus findAllByUnitId(Integer unitId,Integer runStatus);

    /**
     * 更新单位实时状态表中的单位的行业字段（批量更新）
     * @param unitId
     * @param industryId
     */
    void updateIndustryOfUnit(Integer unitId, Integer industryId);
}
