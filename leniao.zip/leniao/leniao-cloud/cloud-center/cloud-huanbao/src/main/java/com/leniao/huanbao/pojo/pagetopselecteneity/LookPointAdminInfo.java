package com.leniao.huanbao.pojo.pagetopselecteneity;


import java.io.Serializable;

/**
 * @author liudongshuai
 * @date 2019/12/23 9:43
 * @update
 * @description
 */
public class LookPointAdminInfo implements Serializable {

    //监测点Id
    private String lookId;
    //监测点名称
    private String lookPointName;
    //监测点分组名称
    private String groupName;
    //监测点备注
    private String remark;
    //监测点添加时间
    private String addTime;
    //监测点状态
    private Integer isDelete;
    //监测点类型 0 总监测点 1 普通监测点
    private Integer lookPointType;
    //产污设备数
    private Integer pollNum;
    //治污设备数
    private Integer conNum;

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Integer getLookPointType() {
        return lookPointType;
    }

    public void setLookPointType(Integer lookPointType) {
        this.lookPointType = lookPointType;
    }

    public Integer getPollNum() {
        return pollNum;
    }

    public void setPollNum(Integer pollNum) {
        this.pollNum = pollNum;
    }

    public Integer getConNum() {
        return conNum;
    }

    public void setConNum(Integer conNum) {
        this.conNum = conNum;
    }

    @Override
    public String toString() {
        return "LookPointAdminInfo{" +
                "lookId='" + lookId + '\'' +
                ", lookPointName='" + lookPointName + '\'' +
                ", remark='" + remark + '\'' +
                ", addTime='" + addTime + '\'' +
                '}';
    }


    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getLookId() {
        return lookId;
    }

    public void setLookId(String lookId) {
        this.lookId = lookId;
    }

    public String getLookPointName() {
        return lookPointName;
    }

    public void setLookPointName(String lookPointName) {
        this.lookPointName = lookPointName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
}
