package com.leniao.huanbao.utils;


import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.text.DecimalFormat;

/**
 * @program: leniao-hbcloudV1.0
 * @description:
 * @author: jiangdy
 * @create: 2020-03-05 17:16
 **/
public class DoubleSerialize extends JsonSerializer<Double> {

    @Override
    public void serialize(Double value, JsonGenerator gen, SerializerProvider serializers)
        throws IOException, JsonProcessingException {
        if(value != null && value.doubleValue() > 0) {
//            gen.writeString(df.format(value));
            gen.writeString(String.format("%.1f", value));
        } else {
            gen.writeString("0.0");
        }
    }
}
