package com.leniao.huanbao.dto.schedule;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description: 监测点Dto中包含的设备包装类
 * @Author: haosw
 * @CreateDate: 2019/12/20 9:55
 * @Version: 1.0
 */
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DevDto implements Serializable {
    private Integer devIdpk;
    private String devSignature;
    private String installLocation;
    private Integer devProTy;
    /**
     * 1:运行(生产),   2:低负荷,  3:停机,    4:失联
     */
    private Integer devWorkState;
    private Integer unitId;
    private Integer platformId;
    private Long industryId;
    /**
     * 当前时间,用于记录当前设备的运行时刻
     */
    private Date now;
}
