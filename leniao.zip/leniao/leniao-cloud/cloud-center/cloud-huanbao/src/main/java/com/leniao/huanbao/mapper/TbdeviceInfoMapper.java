package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/24 19:41
 * @update
 * @description
 */

public interface TbdeviceInfoMapper {
    @Select("SELECT devgroupId AS groupId,devSignature AS devSign,overlookId AS overlookId,devProTy AS devTy,devWorkState AS devStatus  FROM tblndeviceinfo WHERE projId=#{unitId}")
    List<Map<String,Object>> findGroupIdLookPointStatus(Page<Map<String,Object>> page, Integer unitId);
}
