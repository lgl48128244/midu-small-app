package com.leniao.huanbao.mapper;

import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface PermissionMapper {

    List<TreeMenu> selectCanShowProjectByNotAreaUser(@Param("userId") Integer userId, @Param("platformId") Integer platformId, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowProjectByNotAreaUser2(@Param("userId") Integer userId, @Param("platformId") Integer platformId, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowProjectByAreaUser(@Param("userId") Integer userId, @Param("platformId") Integer platformId, @Param("areaCode") AreaCodeJoinOther areaCode,
                                                  @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowProjectByAreaUser2(@Param("userId") Integer userId, @Param("platformId") Integer platformId, @Param("areaCode") AreaCodeJoinOther areaCode,
                                                   @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params);

    /**
     * 用户下监测点Id
     * @param userId
     * @param areaCode
     * @param userGrade
     * @param params
     * @return
     */
    List<TreeMenu> selectCanShowProjectByAreaUser3(@Param("userId") Integer userId, @Param("areaCode") AreaCodeJoinOther areaCode,
                                                   @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params,@Param("platformId") Integer platformId);

    AreaCodeJoinOther selectAreaCodeByUserId(@Param("userId") Integer userId);

    List<TreeMenu> selectCanShowAgencyByUserId(@Param("platformId") Integer platformId, @Param("areaCodeList") List<AreaCodeJoinOther> areaCodeList);

    List<TreeMenu> selectCanShowAgencyByAreaUser(@Param("platformId") Integer platformId, @Param("areaCode") AreaCodeJoinOther areaCode, @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowAgencyByAreaUser3(@Param("platformId") Integer platformId, @Param("areaCode") AreaCodeJoinOther areaCode, @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowAgencyByAreaUser2(@Param("platformId") Integer platformId, @Param("areaCode") AreaCodeJoinOther areaCode, @Param("userGrade") Integer userGrade, @Param("params") Map<String, Object> params);

    List<TreeMenu> selectCanShowAgencyByProjIdList(@Param("platformId") Integer platformId, @Param("projIdList") List<Long> projIdList, @Param("params") Map<String, Object> params);
}
