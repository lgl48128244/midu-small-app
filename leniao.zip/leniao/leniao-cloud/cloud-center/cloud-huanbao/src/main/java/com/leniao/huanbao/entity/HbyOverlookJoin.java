package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;


@TableName("hby_overlook_join")
@ToString
public class HbyOverlookJoin {
    private Long id;

    private String lookId;

    private Integer pollDevId;

    private Integer conDevId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLookId() {
        return lookId;
    }

    public void setLookId(String lookId) {
        this.lookId = lookId == null ? null : lookId.trim();
    }

    public Integer getPollDevId() {
        return pollDevId;
    }

    public void setPollDevId(Integer pollDevId) {
        this.pollDevId = pollDevId;
    }

    public Integer getConDevId() {
        return conDevId;
    }

    public void setConDevId(Integer conDevId) {
        this.conDevId = conDevId;
    }
}