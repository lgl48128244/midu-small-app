package com.leniao.huanbao.service;


import com.leniao.huanbao.entity.HbyDevalTimeStatus;

import java.util.Date;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/26 14:01
 * @update
 * @description
 */

public interface HbyDevalTimeStatusService {

    /**
     * 返回一个企业的日运行数据
     */
    List<HbyDevalTimeStatus> findHbyDevalTimeStatus(Integer unitId, Integer devIdpk);

    /**
     * 返回一个企业的日运行数据
     */
    List<HbyDevalTimeStatus> findHbyDevalTimeStatus(Integer devIdpk);

    /**
     * 通过一个企业日数据的Id找出企业的日数据
     */
    HbyDevalTimeStatus findHbyDevalTimeStatus(Long id);

    /**
     * 返回一个企业的日运行数据
     */
    List<HbyDevalTimeStatus> findHbyDevalTimeStatus2( Integer devIdpk,Integer platformId);

}
