package com.leniao.huanbao.service;

import com.leniao.entity.HbyOverLookPoint;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;

import java.util.List;
import java.util.Map;

public interface TreeMenuService {
    /**
     * 非区域用户查询树形菜单
     * @param userId 用户id
     * @param platformId 平台id
     * @param params 条件参数 当前支持 行业类型id industryId, 单位id projId, 区域id agencyId 查询,key值严格要求相同
     * @return 菜单（机构信息以及机构下的单位信息）
     */
    List<TreeMenu> createTreeMenuByNotAreaUser(int userId, int platformId, Map<String, Object> params);

    /**
     * 区域用户查询树形菜单
     * @param onlyRead 用户id
     * @param platformId 平台id
     * @param params 条件参数 当前支持 行业类型id industryId, 单位id projId, 区域id agencyId 查询,key值严格要求相同
     * @param areaCode 区域用户区域码
     * @param userGrade 区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
     * @return 菜单（机构信息）
     */
    List<TreeMenu> createTreeMenuByAreaUser(int onlyRead, int platformId, Map<String, Object> params, AreaCodeJoinOther areaCode, int userGrade);

    /**
     * 根据单位区域码查询机构
     * @param provinceCode 省级区域码
     * @param cityCode 市区级区域码
     * @param areaCode 县区级区域码
     * @param platformId 平台id
     * @return 该区域的机构信息（仅一个）
     */
    TreeMenu selectAgencyInfoByAreaCode(String provinceCode, String cityCode, String areaCode, int platformId);

    /**
     * 区域用户查询区域下的所有机构
     * @param agencyId 机构id 查找指定机构的信息 查询条件，可为null
     * @param platformId 平台id
     * @param areaCode 用户所在区域的区域码
     * @param userGrade 区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
     * @return Map<Integer, TreeMenu> Map<key:机构id, TreeMenu>
     */
    Map<Long,TreeMenu> selectAgencyInfoByUserAreaCode(Long agencyId, int platformId, AreaCodeJoinOther areaCode, int userGrade);

    /**
     * 通过机构菜单查询单位
     * @param agencyInfo 机构菜单信息
     * @param onlyRead 只否只读
     * @param params 所有条件查询都必须先指定机构, 当前支持 行业类型id industryId, 单位id projId查询,key值严格要求相同
     * @return 单位菜单
     */
    List<TreeMenu> selectProjectInfoByAgencyTreeMenu(TreeMenu agencyInfo, int onlyRead, Map<String, Object> params);

    /**
     * 普通账号和个人账号 查询机构底下的单位
     * @param userId
     * @param agencyId
     * @param parentNodeType
     * @param pageNum
     * @param pageSize
     * @param params
     * @return
     */
    List<TreeMenu> selectCanShowProjectByAgency(Integer userId, Long agencyId, Integer parentNodeType, Integer pageNum, Integer pageSize, Map<String, Object> params);
    /**
     * 查询子节点
     * @param platformId 平台id
     * @param onlyRead 是否只读 0-只读 1-可操作
     * @param parentNodeId 父节点id
     * @param parentNodeType 父节点类型
     * @return
     */
    List<TreeMenu> selectChildTreemenu(Integer platformId, Integer onlyRead, Long parentNodeId, Integer parentNodeType, Integer pageNum, Integer pageSize, Map<String, Object> params);

    /**
     * 根据单位id查询监测点
     * @param projId
     * @return
     */
    List<HbyOverLookPoint> selectOverLookPointByProjId(Integer projId);

}
