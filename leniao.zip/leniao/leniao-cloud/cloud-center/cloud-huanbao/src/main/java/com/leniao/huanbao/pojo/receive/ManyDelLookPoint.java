package com.leniao.huanbao.pojo.receive;

import java.io.Serializable;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2020/1/3 12:00
 * @update
 * @description
 */
public class ManyDelLookPoint implements Serializable {
    private List<Long> lookPointId;

    public List<Long> getLookPointId() {
        return lookPointId;
    }

    public void setLookPointId(List<Long> lookPointId) {
        this.lookPointId = lookPointId;
    }
}
