package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.huanbao.entity.HbyOverlookJoin;
import com.leniao.huanbao.mapper.HbyOverlookpointPlusMapper;
import com.leniao.huanbao.mapper.HbylookpointPlusMapper;

import com.leniao.huanbao.service.HbyOverLookpointService;
import com.leniao.huanbao.service.HbyOverlookJoinService;
import com.leniao.huanbao.service.TblndeviceinfoService;
import com.leniao.huanbao.utils.DevUtils;
import com.leniao.huanbao.utils.PageConstant;
import com.leniao.mapper.HbyOverLookPointMapper;
import com.leniao.service.HbyOverLookDevJoinService;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liudongshuai
 * @date 2019/12/19 15:17
 */
@Service
public class HbyOverLookpointServiceImpl extends ServiceImpl<HbyOverLookPointMapper, HbyOverLookPoint> implements HbyOverLookpointService {

    @Resource
    private HbyOverLookPointMapper hbyOverLookPointMapper;
    @Resource
    private HbylookpointPlusMapper hbylookpointPlusMapper;
    @Resource
    private HbyOverlookJoinService hbyOverlookJoinService;
    @Resource
    private HbyOverLookDevJoinService hbyOverLookDevJoinService;
    @Resource
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Resource
    private TblndeviceinfoService tblndeviceinfoService;
    @Resource
    private HbyOverlookpointPlusMapper hbyOverlookpointPlusMapper;

    /**
     * 通过单位id，找出对应的监测点信息
     */
    @Override
    public List<HbyOverLookPoint> findLookPointInfo(Integer unitId) {

        //创建条件对象
        QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        //储存条件
        queryWrapper.select("id", "over_look_name", "point_type").lambda().eq(HbyOverLookPoint::getUnitId, unitId).eq(HbyOverLookPoint::getDeleted, 0);

        List<HbyOverLookPoint> hbyOverlookpointList = hbyOverLookPointMapper.selectList(queryWrapper);

        if (hbyOverlookpointList == null) {
            List<HbyOverLookPoint> hbyOverlookpoint = new ArrayList<>();
            return hbyOverlookpoint;
        } else {
            return hbyOverlookpointList;
        }

    }


    /**
     * 通过监测点id，找出监测点名称
     */
    @Override
    public List<HbyOverLookPoint> findLookPointInfo(Integer unitId, Integer pageCount, Integer pageSize, String date, Integer groupId) {

        if (groupId == 0) {
            return hbylookpointPlusMapper.findLookPointInfo(unitId, date);
        } else {
            return hbylookpointPlusMapper.findLookPointInfoByGroupId(unitId, date, groupId);
        }


    }

    /**
     * 通过单位id，找出对应的监测点id
     * 默认第一个
     */
    @Override
    public Long findLookPointId(Integer unitId) {
        // 新建分页
        Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, PageConstant.DEVSTATUSLIST);

        // 返回分页结果
        Map<String, Object> map = page.setRecords(this.hbylookpointPlusMapper.findLookPointId(page, unitId)).getRecords().get(0);

        return Long.parseLong(String.valueOf(map.get("lookPointId")));

    }

    /**
     * 通过监测点id找出单位id
     */
    @Override
    public Integer findUnitId(Integer lookPointId) {

        //创建条件
        QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("unitId").lambda().eq(HbyOverLookPoint::getId, lookPointId).eq(HbyOverLookPoint::getDeleted, 0);

        HbyOverLookPoint hbyOverlookpoint = hbyOverLookPointMapper.selectOne(queryWrapper);
        if (hbyOverlookpoint == null) {
            return 0;
        } else {
            return hbyOverlookpoint.getUnitId();
        }

    }

    /**
     * 添加监测点信息
     */
    @Override
    public boolean addLookPoint(HbyOverLookPoint hbyOverlookpoint) {

        //创建条件
        //QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        return save(hbyOverlookpoint);
    }

    /**
     * 删除监测点信息 逻辑删除
     */
    @Override
    public void removeLookPoint(List<Long> lookPointIds) {
        for (Long lookPointId: lookPointIds) {
            //第一步：逻辑删除监测点
            UpdateWrapper<HbyOverLookPoint> updateWrapper = new UpdateWrapper<>();
            updateWrapper.set("deleted",1).lambda().eq(HbyOverLookPoint::getId,lookPointId);
            update(updateWrapper);
            //第二步：物理删除关联关系表1
            hbyOverlookJoinService.removeLookJoin(lookPointId);
            //第三步：物理删除关联关系表2
            hbyOverLookDevJoinService.removeLookDevJoin(lookPointId);
        }
        /*//第一步：逻辑删除监测点
        super.removeByIds(lookPointIds);
        //第二步：物理删除关联关系表1
        Map<String, Object> params = new HashMap<>(2);
        params.put("ids", lookPointIds);
        String sql = "delete from hby_overlook_join where look_id in (select id from hby_overlookpoint where id in (:ids))";
        namedParameterJdbcTemplate.update(sql, params);
        //第三步：物理删除关联关系表2
        sql = "delete from hby_overlook_dev_join where look_id in (select id from hby_overlookpoint where id in (:ids))";
        namedParameterJdbcTemplate.update(sql, params);*/
    }

    /**
     * 删除监测点信息 逻辑删除
     */
    @Override
    public void updateLookPoint2(List<Long> lookPointIds,HbyOverLookPoint hbyOverlookpoint,List<String> pollList,List<String> conList) {
        for (Long lookPointId: lookPointIds) {
            //第一步：物理删除关联关系表1
            hbyOverlookJoinService.removeLookJoin(lookPointId);
            //第二步：物理删除关联关系表2
            hbyOverLookDevJoinService.removeLookDevJoin(lookPointId);
        }
        //第三步：修改监测点信息
        hbyOverLookPointMapper.updateByPrimaryKey(hbyOverlookpoint);

        //第四步：添加中间表关联关系(三乘三的表)
        for (Integer i = 0; i < conList.size(); i++) {
            for (Integer j = 0; j < pollList.size(); j++) {
                HbyOverlookJoin hbyOverlookJoin = new HbyOverlookJoin();
                hbyOverlookJoin.setLookId(String.valueOf(hbyOverlookpoint.getId()));
                hbyOverlookJoin.setConDevId(tblndeviceinfoService.findDevIdPk(conList.get(i)));
                hbyOverlookJoin.setPollDevId(tblndeviceinfoService.findDevIdPk(pollList.get(j)));
                hbyOverlookJoinService.addLookJoin(hbyOverlookJoin);
            } }
        //第五步：添加中间表，监测点和设备
        for (String polls:pollList) {
            hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),
                    tblndeviceinfoService.findDevIdPk(polls),
                    1);
        }
        for (String cons:conList) {
            hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),
                    tblndeviceinfoService.findDevIdPk(cons),
                    2);
        }

    }

    /**
     * 添加普通监测点信息
     */
    @Override
    public void addLookPoint2(HbyOverLookPoint hbyOverlookpoint,List<String> pollList,List<String> conList) {
        //第一步：保存监测点信息
        save(hbyOverlookpoint);
        //第二步：保存中间表信息
        HbyOverlookJoin hbyOverlookJoin = new HbyOverlookJoin();
        for (Integer i = 0; i < conList.size(); i++) {
            for (Integer j = 0; j < pollList.size(); j++) {
                hbyOverlookJoin.setLookId(String.valueOf(hbyOverlookpoint.getId()));
                hbyOverlookJoin.setConDevId(tblndeviceinfoService.findDevIdPk(conList.get(i)));
                hbyOverlookJoin.setPollDevId(tblndeviceinfoService.findDevIdPk(pollList.get(j)));
                hbyOverlookJoinService.addLookJoin(hbyOverlookJoin);
            }
        }
        for (String polls:pollList) {
            hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),
                    tblndeviceinfoService.findDevIdPk(polls),
                    1);
        }
        for (String cons:conList) {
            hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),
                    tblndeviceinfoService.findDevIdPk(cons),
                    2);
        }
    }


    /**
     * 添加总监测点
     */
    @Override
    public void addLookPointTotal2(HbyOverLookPoint hbyOverlookpoint, String devSign) {
        //第一步：保存监测点信息
        save(hbyOverlookpoint);
        //第二步：保存中间表信息
        hbyOverLookDevJoinService.addLookPointDevJoin(hbyOverlookpoint.getId(),
                tblndeviceinfoService.findDevIdPk(devSign),
                        0);
    }

    /**
     * 修改监测点信息
     */
    @Override
    public boolean updateLookPoint(HbyOverLookPoint hbyOverlookpoint) {
        hbyOverLookPointMapper.updateByPrimaryKey(hbyOverlookpoint);

        return true;
    }

    /**
     * 通过监测点Id查出监测点所有的信息
     */
    @Override
    public HbyOverLookPoint findOverLookPoint(Long lookPointId) {
        //创建查询条件
        QueryWrapper<HbyOverLookPoint> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyOverLookPoint::getId, lookPointId).eq(HbyOverLookPoint::getDeleted, 0);
        return hbyOverLookPointMapper.selectOne(queryWrapper);
    }

    @Override
    public String findPollDevStrByUnit(Integer unitId) {
        String sql = "SELECT hby_overlook_dev_join.dev_idpk\n" +
                "FROM hby_overlookpoint INNER JOIN hby_overlook_dev_join\n" +
                "WHERE hby_overlookpoint.id = hby_overlook_dev_join.look_id\n" +
                "AND hby_overlook_dev_join.dev_pro_ty = 1\n" +
                "AND hby_overlookpoint.deleted = 0\n" +
                "AND hby_overlookpoint.unit_id = "+unitId;
        List<String> devIdList = hbyOverlookpointPlusMapper.findDevIdByUnitId2(sql);
        if (devIdList.size()==0){
            return "(0)";
        }else {
            List<String> devStrList = DevUtils.removeDuplicate(devIdList);
            String str = "(0";
            for (String devId:devStrList) {
                str = str+","+Integer.parseInt(devId);
            }
            str = str+")";
            return str;
        }
    }

    @Override
    public String findConDevStrByUnit(Integer unitId) {
        String sql = "SELECT hby_overlook_dev_join.dev_idpk\n" +
                "FROM hby_overlookpoint INNER JOIN hby_overlook_dev_join\n" +
                "WHERE hby_overlookpoint.id = hby_overlook_dev_join.look_id\n" +
                "AND hby_overlook_dev_join.dev_pro_ty = 2\n" +
                "AND hby_overlookpoint.deleted = 0\n" +
                "AND hby_overlookpoint.unit_id = "+unitId;

        List<String> devIdList = hbyOverlookpointPlusMapper.findDevIdByUnitId2(sql);
        if (devIdList.size()==0){
            return "(0)";
        }else {
            List<String> devStrList = DevUtils.removeDuplicate(devIdList);
            String str = "(0";
            for (String devId:devStrList) {
                str = str+","+Integer.parseInt(devId);
            }
            str = str+")";
            return str;
        }
    }

    @Override
    public String findTotalDevStrByUnit(Integer unitId) {
        String sql = "SELECT hby_overlook_dev_join.dev_idpk\n" +
                "FROM hby_overlookpoint INNER JOIN hby_overlook_dev_join\n" +
                "WHERE hby_overlookpoint.id = hby_overlook_dev_join.look_id\n" +
                "AND hby_overlook_dev_join.dev_pro_ty = 0\n" +
                "AND hby_overlookpoint.deleted = 0\n" +
                "AND hby_overlookpoint.unit_id = "+unitId;
        List<String> devIdList = hbyOverlookpointPlusMapper.findDevIdByUnitId2(sql);
        if (devIdList.size()==0){
            return "(0)";
        }else {
            List<String> devStrList = DevUtils.removeDuplicate(devIdList);
            String str = "(0";
            for (String devId:devStrList) {
                str = str+","+Integer.parseInt(devId);
            }
            str = str+")";
            return str;
        }
    }


}
