package com.leniao.huanbao.pojo.pagetopselecteneity;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

/**
 * @author songtm
 * @date 2019/12/19 15:35
 */
public class LookPointSelectInfo {
    /**
     * 监测点ID
     * */
    @JsonSerialize(using= ToStringSerializer.class)
    private Long lookPointId;
    /**
     * 监测点名称
     * */
    private String lookPointunitName;

    public Long getLookPointId() {
        return lookPointId;
    }

    public void setLookPointId(Long lookPointId) {
        this.lookPointId = lookPointId;
    }

    public String getLookPointunitName() {
        return lookPointunitName;
    }

    public void setLookPointunitName(String lookPointunitName) {
        this.lookPointunitName = lookPointunitName;
    }

    @Override
    public String toString() {
        return "LookPointSelectInfo{" +
                "lookPointId=" + lookPointId +
                ", lookPointunitName='" + lookPointunitName + '\'' +
                '}';
    }
}
