package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.entity.HbyProjectstatusExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyProjectstatusMapper extends BaseMapper<HbyProjectstatus> {
    long countByExample(HbyProjectstatusExample example);

    int deleteByExample(HbyProjectstatusExample example);

    int deleteByPrimaryKey(Integer unitId);

    int insert(HbyProjectstatus record);

    int insertSelective(HbyProjectstatus record);

    List<HbyProjectstatus> selectByExample(HbyProjectstatusExample example);

    HbyProjectstatus selectByPrimaryKey(Integer unitId);

    int updateByExampleSelective(@Param("record") HbyProjectstatus record, @Param("example") HbyProjectstatusExample example);

    int updateByExample(@Param("record") HbyProjectstatus record, @Param("example") HbyProjectstatusExample example);

    int updateByPrimaryKeySelective(HbyProjectstatus record);

    int updateByPrimaryKey(HbyProjectstatus record);
}