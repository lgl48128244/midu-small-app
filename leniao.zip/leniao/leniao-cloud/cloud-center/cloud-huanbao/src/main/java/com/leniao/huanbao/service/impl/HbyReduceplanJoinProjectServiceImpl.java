package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.commons.BaseService;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;
import com.leniao.huanbao.mapper.HbyReduceplanJoinProjectMapper;
import com.leniao.huanbao.mapper.ReduceplanJoinProjectMapper;
import com.leniao.huanbao.service.HbyReduceplanJoinProjectService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 减排方案关联
 * @author: jiangdy
 * @create: 2019-12-26 09:43
 **/
@Service
public class HbyReduceplanJoinProjectServiceImpl extends ServiceImpl<HbyReduceplanJoinProjectMapper, HbyReduceplanJoinProject> implements HbyReduceplanJoinProjectService {

    @Resource
    private ReduceplanJoinProjectMapper reduceplanJoinProjectMapper;
    @Resource
    private HbyReduceplanJoinProjectMapper hbyReduceplanJoinProjectMapper;

    @Override
    public long countByExample(HbyReduceplanJoinProjectExample example) {
        return hbyReduceplanJoinProjectMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(HbyReduceplanJoinProjectExample example) {
        return hbyReduceplanJoinProjectMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Long id) {
        return hbyReduceplanJoinProjectMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(HbyReduceplanJoinProject record) {
        return hbyReduceplanJoinProjectMapper.insert(record);
    }

    @Override
    public int insertSelective(HbyReduceplanJoinProject record) {
        return hbyReduceplanJoinProjectMapper.insertSelective(record);
    }

    @Override
    public List<HbyReduceplanJoinProject> selectByExample(HbyReduceplanJoinProjectExample example) {
        return hbyReduceplanJoinProjectMapper.selectByExample(example);
    }

    @Override
    public HbyReduceplanJoinProject selectByPrimaryKey(Long id) {
        return hbyReduceplanJoinProjectMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(HbyReduceplanJoinProject record, HbyReduceplanJoinProjectExample example) {
        return hbyReduceplanJoinProjectMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExample(HbyReduceplanJoinProject record, HbyReduceplanJoinProjectExample example) {
        return hbyReduceplanJoinProjectMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(HbyReduceplanJoinProject record) {
        return hbyReduceplanJoinProjectMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(HbyReduceplanJoinProject record) {
        return hbyReduceplanJoinProjectMapper.updateByPrimaryKey(record);
    }

    /**
     * 查询单位绑定方案信息
     * @param planId 方案id
     * @return Map<Integer, HbyReduceplanJoinProject> key: 单位id， value：HbyReduceplanJoinProject
     */
    @Override
    public Map<Integer, HbyReduceplanJoinProject> selectHbyReduceplanJoinProjectByPlanId(Long planId) {
        return reduceplanJoinProjectMapper.selectByExample(planId);
    }

    /**
     * 查询一个单位是否绑定了停限产方案
     */
    @Override
    public Boolean checkReducePlan(Integer unitId) {
        //创建条件对象
        QueryWrapper<HbyReduceplanJoinProject> queryWrapper = new QueryWrapper<>();

        queryWrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId,unitId);
        List<HbyReduceplanJoinProject> hbyReduceplanJoinProjectList = hbyReduceplanJoinProjectMapper.selectList(queryWrapper);
        if ((hbyReduceplanJoinProjectList.size()==0)||(hbyReduceplanJoinProjectList==null)){
            return false;
        }else {
            return true;
        }

    }

    /**
     * 更新绑定数量
     * @param planId
     * @param count
     * @return
     */
    @Override
    public boolean updateBindUnitCount(Long planId, int count) {
        return hbyReduceplanJoinProjectMapper.updateBindUnitCount(planId, count) > 0;
    }

    /**
     * 通过单位找出对应的停限产计划的Id
     * @param unitId
     * @return
     */
    @Override
    public Long selectPlanIdByUnitId(Integer unitId) {

        //创建条件对象
        QueryWrapper<HbyReduceplanJoinProject> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(HbyReduceplanJoinProject::getUnitId,unitId);
        HbyReduceplanJoinProject hbyReduceplanJoinProject = hbyReduceplanJoinProjectMapper.selectOne(queryWrapper);
        if (hbyReduceplanJoinProject==null){
            return null;
        }else {
            return hbyReduceplanJoinProject.getPlanId();
        }

    }
}
