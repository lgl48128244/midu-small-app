package com.leniao.huanbao.service;

import com.leniao.huanbao.entity.HbyOverlookJoin;

import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 16:49
 * @update
 */
public interface HbyOverlookJoinService {
    /**
     * 通过检测点id 查出产污设备id，治污设备id
     * */
    List<HbyOverlookJoin> finddevIdinfo(Long lookPointId);

    /**
     * 添加监测点与，产污设备，治污设备关系
     */
    boolean addLookJoin(HbyOverlookJoin hbyOverlookJoin);

    /**
     * 删除监测点产污与治污设备管理关系
     */
    boolean removeLookJoin(Long lookPointId);
}
