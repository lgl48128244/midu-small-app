package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.entity.Tblndeviceparainfo;
import com.leniao.huanbao.service.TblndeviceparainfoService;
import com.leniao.mapper.TblndeviceparainfoMapper;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author songtm
 * @date 2019/12/3 16:34
 */
@Service
public class TblndeviceparainfoServiceImpl implements TblndeviceparainfoService {

    @Resource
    private TblndeviceparainfoMapper tblndeviceparainfoMapper;

    //通过节点id查询出对应节点的阈值
    @Override
    public Object findValue(Integer devnodepk, Integer devidpk) {
        //创建条件
        QueryWrapper<Tblndeviceparainfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("paravalue").lambda().eq(Tblndeviceparainfo::getDevnodepk,devnodepk).eq(Tblndeviceparainfo::getDevidpk,devidpk);

        Tblndeviceparainfo tblndeviceparainfo = tblndeviceparainfoMapper.selectOne(queryWrapper);

        if (tblndeviceparainfo==null){
            return 99999999f;
        }else {
            return tblndeviceparainfo.getParavalue();
        }

    }


}
