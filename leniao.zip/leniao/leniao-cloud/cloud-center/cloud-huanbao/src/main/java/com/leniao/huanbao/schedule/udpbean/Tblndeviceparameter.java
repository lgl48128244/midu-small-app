package com.leniao.huanbao.schedule.udpbean;

 public  class Tblndeviceparameter {
    private String pid;

    private Integer devidpk;

    private String devsignature;

    private String setName;

    private String setmodel;

    private String switch1;

    private String switch2;

    private String switch3;

    private String switch4;

    private String switch1c;

    private String switch2c;

    private String switch3c;

    private String switch4c;

    private Integer switch1b;

    private Integer switch2b;

    private Integer switch3b;

    private Integer switch4b;

     public  String getPid() {
        return pid;
    }

     public  void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

     public  Integer getDevidpk() {
        return devidpk;
    }

     public  void setDevidpk(Integer devidpk) {
        this.devidpk = devidpk;
    }

     public  String getDevsignature() {
        return devsignature;
    }

     public  void setDevsignature(String devsignature) {
        this.devsignature = devsignature == null ? null : devsignature.trim();
    }

     public  String getsetName() {
        return setName;
    }

     public  void setsetName(String setName) {
        this.setName = setName == null ? null : setName.trim();
    }

     public  String getSetmodel() {
        return setmodel;
    }

     public  void setSetmodel(String setmodel) {
        this.setmodel = setmodel == null ? null : setmodel.trim();
    }

     public  String getSwitch1() {
        return switch1;
    }

     public  void setSwitch1(String switch1) {
        this.switch1 = switch1 == null ? null : switch1.trim();
    }

     public  String getSwitch2() {
        return switch2;
    }

     public  void setSwitch2(String switch2) {
        this.switch2 = switch2 == null ? null : switch2.trim();
    }

     public  String getSwitch3() {
        return switch3;
    }

     public  void setSwitch3(String switch3) {
        this.switch3 = switch3 == null ? null : switch3.trim();
    }

     public  String getSwitch4() {
        return switch4;
    }

     public  void setSwitch4(String switch4) {
        this.switch4 = switch4 == null ? null : switch4.trim();
    }

     public  String getSwitch1c() {
        return switch1c;
    }

     public  void setSwitch1c(String switch1c) {
        this.switch1c = switch1c == null ? null : switch1c.trim();
    }

     public  String getSwitch2c() {
        return switch2c;
    }

     public  void setSwitch2c(String switch2c) {
        this.switch2c = switch2c == null ? null : switch2c.trim();
    }

     public  String getSwitch3c() {
        return switch3c;
    }

     public  void setSwitch3c(String switch3c) {
        this.switch3c = switch3c == null ? null : switch3c.trim();
    }

     public  String getSwitch4c() {
        return switch4c;
    }

     public  void setSwitch4c(String switch4c) {
        this.switch4c = switch4c == null ? null : switch4c.trim();
    }

     public  Integer getSwitch1b() {
        return switch1b;
    }

     public  void setSwitch1b(Integer switch1b) {
        this.switch1b = switch1b;
    }

     public  Integer getSwitch2b() {
        return switch2b;
    }

     public  void setSwitch2b(Integer switch2b) {
        this.switch2b = switch2b;
    }

     public  Integer getSwitch3b() {
        return switch3b;
    }

     public  void setSwitch3b(Integer switch3b) {
        this.switch3b = switch3b;
    }

     public  Integer getSwitch4b() {
        return switch4b;
    }

     public  void setSwitch4b(Integer switch4b) {
        this.switch4b = switch4b;
    }
}