package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.entity.Tblndevicenodeinfo;
import com.leniao.huanbao.service.TblndevicenodeinfoService;
import com.leniao.mapper.TblndevicenodeinfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/26 8:58
 * @update
 * @description
 */
@Service
public class TblndevicenodeinfoServiceImpl implements TblndevicenodeinfoService {

    @Resource
    private TblndevicenodeinfoMapper tblndevicenodeinfoMapper;

    /**
     * 通过设备节点ID,找出所有的节点，并拼接成字符串
     */
    @Override
    public String findDevNode(Integer devTyId) {

        //创建查询条件
        QueryWrapper<Tblndevicenodeinfo> queryWrapper = new QueryWrapper<>();
        //通过设备节点id查询出对应的节点值
        queryWrapper.select("devnode1").lambda().eq(Tblndevicenodeinfo::getDevty,devTyId);

        List<Tblndevicenodeinfo> tblndevicenodeinfoList = tblndevicenodeinfoMapper.selectList(queryWrapper);

        //创建空字符串储存node
        String nodeStr = "";

        //拼出节点的字符串
        if ( tblndevicenodeinfoList.isEmpty() ){
            //如果list集合为空返回空字符串
            return nodeStr;
        }else {
            if (tblndevicenodeinfoList.size()==1){
                //长度为一直接返回
                return tblndevicenodeinfoList.get(0).getDevnode1();
            }else {
                for( int i = 0 ; i < tblndevicenodeinfoList.size()-1 ; i++){
                    nodeStr = nodeStr + tblndevicenodeinfoList.get(i).getDevnode1()+"-";
                }
                nodeStr = nodeStr +tblndevicenodeinfoList.get(tblndevicenodeinfoList.size()-1).getDevnode1();

                return nodeStr;
            }
        }
    }


    /**
     * 查询出节点的集合
     */
    @Override
    public List<Tblndevicenodeinfo> findNodeStr(Integer devTyId) {

        //创建查询条件
        QueryWrapper<Tblndevicenodeinfo> queryWrapper = new QueryWrapper<>();
        //通过设备节点id查询出对应的节点值
        queryWrapper.select("devnode1","pkid").lambda().eq(Tblndevicenodeinfo::getDevty,devTyId);

        List<Tblndevicenodeinfo> tblndevicenodeinfoList = tblndevicenodeinfoMapper.selectList(queryWrapper);

        return tblndevicenodeinfoList;
    }

    /**
     * 找出nodeId
     */
    @Override
    public Integer findNodeIdPk(Integer devTy, String node) {

        QueryWrapper<Tblndevicenodeinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("pkId").lambda().eq(Tblndevicenodeinfo::getDevty,devTy).eq(Tblndevicenodeinfo::getDevnode1,node);
        Tblndevicenodeinfo tblndevicenodeinfo= tblndevicenodeinfoMapper.selectOne(queryWrapper);
        if (tblndevicenodeinfo==null){
            return 0;
        }else {
            return tblndevicenodeinfo.getPkid();
        }

    }

}
