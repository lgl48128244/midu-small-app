package com.leniao.huanbao.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leniao.commons.BaseController;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.constant.ApiConstant;
import com.leniao.huanbao.constant.SystemConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.service.HbyReduceEmmissionService;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.service.TreeMenuService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.HbyAgencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 树形菜单
 * @author: jiangdy
 * @create: 2019-12-23 09:21
 **/
@RestController
@RequestMapping(ApiConstant.TREEMENU)
public class TreeMenuController extends BaseController {

    @Autowired
    private TreeMenuService treeMenuService;

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private HbyAgencyService hbyAgencyService;

    @Autowired
    private HbyReduceEmmissionService hbyReduceEmmissionService;


    /**
     * 查询树形结构菜单
     * @return
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT)
    public Object selectTreeMenu() {

        UserInfo userInfo = this.getUserInfo();

        List<TreeMenu> treeMenuList = null;
        if (userInfo.getGroupType() != 2) {
            // 非区域用户
            treeMenuList = treeMenuService.createTreeMenuByNotAreaUser(userInfo.getUserId(), userInfo.getPlatformId(), null);
        } else {
            // 区域用户
            // 获取区域码
            AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
            if (areaCode == null) {
                throw new CloudException(CloudErrorCode.OAUTH_FAIL_99998);
            }

            // 判断区域用户等级 0-全国用户，1-省份级用户，2-市区级用户，3-县区级用户
            int userGrade = UserUtil.getUserGrade(areaCode);

            treeMenuList = treeMenuService.createTreeMenuByAreaUser(userInfo.getGroupOnlyRead(), userInfo.getPlatformId(), null, areaCode, userGrade);
        }
        return renderResult(treeMenuList);
    }

    /**
     * 查询子节点信息
     * @param jsonObject
     * @return 子节点集合
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_CHILD, method = RequestMethod.POST)
    public Object selectChildTreemenu(@RequestBody JSONObject jsonObject) {
        Long parentNodeId = jsonObject.getLong("parentNodeId");
        Integer parentNodeType = jsonObject.getInteger("parentNodeType");
        Integer pageNum = jsonObject.getInteger("pageNum");
        Integer pageSize = jsonObject.getInteger("pageSize");
        Integer showAll = jsonObject.getInteger("showAll");
        if (parentNodeId == null || parentNodeId == 0 || parentNodeType == null || parentNodeType == 0) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING);
        }
        Map<String, Object> params = new HashMap<>();
        if (showAll != null) {
            params.put("showAll", showAll);
        } else {
            params.put("showAll", 0);
        }
        UserInfo userInfo = this.getUserInfo();
        List<TreeMenu> treeMenuList;
        if (parentNodeType == 1 && userInfo.getGroupType() != 2) {
            // 查询单位
            treeMenuList = treeMenuService.selectCanShowProjectByAgency(userInfo.getUserId(), parentNodeId, parentNodeType, pageNum, pageSize, params);
        } else {
            treeMenuList = treeMenuService.selectChildTreemenu(userInfo.getPlatformId(), userInfo.getGroupOnlyRead(), parentNodeId, parentNodeType, pageNum, pageSize, params);
        }
        if (pageNum != null && pageNum > 0) {
            return renderResult(new PageInfo<>(treeMenuList));
        }
        return renderResult(treeMenuList);
    }

    /**
     * 查询树形机构列表
     * @param agencyId 机构id
     * @return
     *
     * lds 修改
     */
    /*@RequestMapping(value = ApiConstant.TREEMENU_SELECT_AGENCY)
    public Object selectAgencyTree(@RequestParam(value = "agencyId", defaultValue = "0") Long agencyId,
                                   @RequestParam(value = "showAll", defaultValue = "0") int showAll) {

        UserInfo userInfo = this.getUserInfo();
        // 用户区域码
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", showAll);
        // 查询用户可见的所有机构
        List<TreeMenu> allMenuList = permissionService.selectCanShowAgencyByUserId(userInfo.getUserId(),
                areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), params);
        if (areaCode == null && agencyId.longValue() == 0) {
            return renderResult(allMenuList);
        }
        Integer userGrade;
            if (Integer.parseInt(String.valueOf(agencyId)) == 0) {
                userGrade = UserUtil.getUserGrade(areaCode);
                List<TreeMenu> menuList = allMenuList.stream().filter(tm ->
                        (userGrade.equals(0) && tm.getAreaCode().equals("000000") && tm.getCityCode().equals("000000"))
                                || (userGrade.equals(1) && tm.getCityCode().equals("000000"))
                                || (userGrade.equals(2) && tm.getAreaCode().equals("000000"))
                                || (userGrade.equals(3) && !tm.getAreaCode().equals("000000"))
                ).collect(Collectors.toList());
                List<TreeMenu> treeMenuList = new ArrayList<>();

                    for (TreeMenu menu : allMenuList ) {
                        if (menu.getCityCode().equals("000000")){
                            treeMenuList.add(menu);
                        }
                    }


            return renderResult(treeMenuList);
        }

        // 查询指定机构的子机构
        HbyAgency agency = hbyAgencyService.getById(agencyId);
        if (agency == null) {
            throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
        }
        userGrade = UserUtil.getUserGrade(new AreaCodeJoinOther(agency.getProvinceCode(), agency.getCityCode(), agency.getAreaCode()));
        List<TreeMenu> menuList = allMenuList.stream().filter(tm -> !tm.getNodeId().equals(agencyId)).filter(tm -> (userGrade.equals(1)
                && tm.getProvinceCode().equals(agency.getProvinceCode())&& !tm.getCityCode().equals("000000") && tm.getAreaCode().equals("000000"))
                || (userGrade.equals(2) && tm.getCityCode().equals(agency.getCityCode()) && !tm.getAreaCode().equals("000000"))
        ).collect(Collectors.toList());

        return renderResult(menuList);
    }*/

    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_AGENCY)
    public Object selectAgencyTree(@RequestParam(value = "agencyId", defaultValue = "0") Integer agencyId,
            @RequestParam(value = "showAll", defaultValue = "0") Integer showAll) {

        UserInfo userInfo = this.getUserInfo();
        // 用户区域码
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", showAll);
        // 查询用户可见的所有机构
        List<TreeMenu> allMenuList = permissionService.selectCanShowAgencyByUserId(userInfo.getUserId(),
                areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), params);
        Integer userGrade = UserUtil.getUserGrade(areaCode);
        if ((Integer.parseInt(String.valueOf(agencyId)) == 0)&&(userGrade!=null)) {
            List<TreeMenu> treeMenuList = new ArrayList<>();

                if ((userGrade ==1)||(userGrade==0)){
                    for (TreeMenu menu : allMenuList ) {
                        if (menu.getCityCode().equals("000000")){
                            treeMenuList.add(menu);
                        }
                    }
                    return renderResult(treeMenuList);
                }else if(userGrade==2){
                    for (TreeMenu menu : allMenuList ) {
                        if ((menu.getAreaCode().equals("000000"))&&(!menu.getCityCode().equals("000000"))){
                            treeMenuList.add(menu);
                        }
                    }
                    return renderResult(treeMenuList);
                }else if (userGrade==3){
                    for (TreeMenu menu : allMenuList ) {
                        if (!menu.getAreaCode().equals("000000")){
                            treeMenuList.add(menu);
                        }
                    }
                    return renderResult(treeMenuList);
                }
        }
        if ((Integer.parseInt(String.valueOf(agencyId)) == 0)&&(userGrade==null)){
            return renderResult(allMenuList);
        }


        // 查询指定机构的子机构
        HbyAgency agency = hbyAgencyService.getById(agencyId);
        if (userGrade!=null){
            if (agency == null) {
                throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
            }else {
                List<TreeMenu> treeMenuList = new ArrayList<>();
                if ((!agency.getProvinceCode().equals("000000"))&&(agency.getCityCode().equals("000000"))){
                    for (TreeMenu menu : allMenuList ) {
                        if ((menu.getProvinceCode().equals(agency.getProvinceCode())&&(!menu.getCityCode().equals("000000"))&&(menu.getAreaCode().equals("000000")))){
                            treeMenuList.add(menu);
                        }
                    }
                }
                if ((!agency.getCityCode().equals("000000"))&&(agency.getAreaCode().equals("000000"))){
                    for (TreeMenu menu : allMenuList ) {
                        if ((menu.getCityCode().equals(agency.getCityCode())&&(!menu.getAreaCode().equals("000000")))){
                            treeMenuList.add(menu);
                        }
                    }

                }
                return renderResult(treeMenuList);
            }
        }else {
            List<TreeMenu> treeMenuList = new ArrayList<>();
            return renderResult(treeMenuList);
        }


    }

    /**
     * 查询所有可见的单位列表
     * @pageNum 分页页码
     * @return
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_PROJECT)
    public Object selectAllProject(@RequestParam(value = "pageNum", defaultValue = "0") Integer pageNum) {

        UserInfo userInfo = this.getUserInfo();
        // 用户区域码
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (pageNum > 0) {
            PageHelper.startPage(pageNum, SystemConstant.PAGE_SIZE);
        }
        // 查询用户可见的所有单位
        List<TreeMenu> projectList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), null);
        if (projectList == null) {
            return renderResult();
        }
        if (pageNum > 0) {
            return renderResult(new PageInfo<>(projectList));
        }
        return renderResult(projectList);
    }

    /**
     * 查询所有可见的单位列表
     * @pageNum 分页页码
     * @return
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_PROJECT2)
    public Object selectAllProject2(@RequestBody JSONObject jsonObject) {

        Integer pageNum = jsonObject.getInteger("pageNum");
        Integer showAll = jsonObject.getInteger("showAll");
        Long agencyId = jsonObject.getLong("agencyId");
        if (showAll == null) {
            showAll = 0;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", showAll);
        UserInfo userInfo = this.getUserInfo();
        // 用户区域码
        AreaCodeJoinOther areaCode = permissionService.selectAreaCodeByUserId(userInfo.getUserId());
        if (pageNum != null && pageNum > 0) {
            PageHelper.startPage(pageNum, SystemConstant.PAGE_SIZE);
        }
        HbyAgency agency = null;
        if (agencyId != null && agencyId > 0) {
            // 查询指定机构的子机构
            agency = hbyAgencyService.getById(agencyId);
            if (agency == null) {
                throw new CloudException(CloudErrorCode.AGENCY_ISNULL);
            }
        }
        // 查询用户可见的所有单位
        //List<TreeMenu> projectList = permissionService.selectCanShowProjectByUserId(userInfo.getUserId(), areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), agency, params);
        List<TreeMenu> projectList = permissionService.selectCanShowProjectByUserId2(userInfo.getUserId(), areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), agency, params,userInfo.getPlatformId());
        if (userInfo.getGroupOnlyRead() == 0 && userInfo.getGroupType() == 2) {
            for (TreeMenu treeMenu : projectList) {
                treeMenu.setOnlyRead(0);
            }
        }
        if (projectList == null) {
            return renderResult();
        }
        if (pageNum != null && pageNum > 0) {
            return renderResult(new PageInfo<>(projectList));
        }
        return renderResult(projectList);
    }

    /**
     * 查询单位下的监测点
     * @param params
     * @return
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_OVERLOOKPOINT)
    public Object selectOverLookPoint(@RequestBody JSONObject params) {

        if (params == null || params.getInteger("projId") == null || params.getInteger("projId") == 0) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, "单位id错误");
        }
        return renderResult(treeMenuService.selectOverLookPointByProjId(params.getInteger("projId")));
    }

    /**
     * 查询机构和单位
     * @return
     */
    @RequestMapping(value = ApiConstant.TREEMENU_SELECT_AGENCY_AND_PROJECT)
    public Object selectAgencyAndProject() {
        UserInfo userInfo = this.getUserInfo();
        Map<String, Object> params = new HashMap<>();
        params.put("showAll", 0);
        return permissionService.selectCanShowAgencyAndProjectByUser(userInfo.getUserId(), params);
    }

}
