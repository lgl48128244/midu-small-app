package com.leniao.huanbao.schedule;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.leniao.commons.AbstractOperation;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.huanbao.dto.schedule.UnitBasicInfoDto;
import com.leniao.huanbao.service.CommonSimpleBeanInfoService;
import com.leniao.huanbao.service.HbScheduledService;
import com.leniao.huanbao.service.HbyProjectDayCountinfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @Description:    统计单位年数据的定时任务
 * @Author:         haosw
 * @CreateDate:     2020/1/7 10:02
 * @Version:        1.0
 */
@Slf4j
@Component
//@Profile("DEV")
public class ProjectYearMonthCountSchedule extends AbstractOperation {

    @Resource
    private HbScheduledService hbScheduledService;
    @Resource
    private HbyProjectDayCountinfoService hbyProjectDayCountinfoService;
    @Resource
    private CommonSimpleBeanInfoService commonSimpleBeanInfoService;

    /**
     * @description:    计算单位年月数据的定时任务
     * @author:         haosw
     * @date:           2020/1/7 14:03
     */
    @Scheduled(cron = "0 0/30 * * * ?")
    protected void begin(){
        log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++计算单位年月数据的定时任务开始++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        //获取当前年月
        DateTime now = DateTime.now();
        int year = now.getYear();
        int monthOfYear = now.getMonthOfYear();
        //查询当前所有单位的总表设备的用电量
        List<HashMap<String, Object>> unitEleUseList = hbScheduledService.findUnitCurrentMonthEleUse(year, monthOfYear);
        List<HbyProjectDayCountinfo> toDbList = new ArrayList<>();
        for (HashMap<String, Object> map : unitEleUseList) {
            Integer unitId = (Integer)map.get("unitId");
            Long agcyId = (Long)map.get("agcyId");
            Double eleUse = (Double)map.get("sumEleUse") == null ? 0 : (Double)map.get("sumEleUse");
            //获取单位当月的数据
            QueryWrapper<HbyProjectDayCountinfo> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(HbyProjectDayCountinfo::getUnitId, unitId)
                    .eq(HbyProjectDayCountinfo::getYear, year)
                    .eq(HbyProjectDayCountinfo::getMonth, monthOfYear)
                    .eq(HbyProjectDayCountinfo::getDay, 0);
            HbyProjectDayCountinfo monthInfo = this.hbyProjectDayCountinfoService.getOne(queryWrapper);

            UnitBasicInfoDto unitBasicInfo = this.commonSimpleBeanInfoService.findUnitBasicInfoByID(unitId);
            if (monthInfo == null) {
                monthInfo = new HbyProjectDayCountinfo();
                monthInfo.setDay(0);
                monthInfo.setAgcyId(agcyId);
                monthInfo.setMonth(monthOfYear);
                monthInfo.setYear(year);
                monthInfo.setTotalDevEleUse("0");
            }
            if (unitBasicInfo != null) {
                BeanUtils.copyProperties(unitBasicInfo, monthInfo);
                monthInfo.setIndustryIdpk(unitBasicInfo.getIndustryId());
            }

            monthInfo.setTotalDevEleUse(eleUse + "");
            toDbList.add(monthInfo);

            queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(HbyProjectDayCountinfo::getUnitId, unitId)
                    .eq(HbyProjectDayCountinfo::getYear, year)
                    .eq(HbyProjectDayCountinfo::getMonth, 0)
                    .eq(HbyProjectDayCountinfo::getDay, 0);
            HbyProjectDayCountinfo yearInfo = this.hbyProjectDayCountinfoService.getOne(queryWrapper);
            if (yearInfo == null) {
                yearInfo = new HbyProjectDayCountinfo();
                yearInfo.setDay(0);
                yearInfo.setMonth(0);
                yearInfo.setYear(year);
                yearInfo.setTotalDevEleUse("0");
            }
            if (unitBasicInfo != null) {
                BeanUtils.copyProperties(unitBasicInfo, yearInfo);
                yearInfo.setIndustryIdpk(unitBasicInfo.getIndustryId());
            }
            yearInfo.setTotalDevEleUse(eleUse + "");
            toDbList.add(yearInfo);
        }
        if (CollectionUtils.isNotEmpty(toDbList)) {
            this.hbyProjectDayCountinfoService.saveOrUpdateBatch(toDbList);
        }
    }





}
