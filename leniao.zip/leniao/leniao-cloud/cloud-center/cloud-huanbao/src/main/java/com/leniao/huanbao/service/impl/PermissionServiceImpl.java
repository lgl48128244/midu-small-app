package com.leniao.huanbao.service.impl;

import com.github.pagehelper.PageHelper;
import com.leniao.commons.BaseService;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.HbyAgency;
import com.leniao.huanbao.constant.SystemConstant;
import com.leniao.huanbao.dto.AreaCodeJoinOther;
import com.leniao.huanbao.dto.TreeMenu;
import com.leniao.huanbao.mapper.PermissionMapper;
import com.leniao.huanbao.service.PermissionService;
import com.leniao.huanbao.utils.UserUtil;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 权限相关服务
 * @author: jiangdy
 * @create: 2019-12-23 11:58
 **/
@Service
public class PermissionServiceImpl extends BaseService implements PermissionService {

    @Resource
    private PermissionMapper permissionMapper;

    /**
     * 查询当前用户可见的单位
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return Map<Integer, TreeMenu> Map<key:单位id, TreeMenu>
     */
    @Override
    public List<TreeMenu> selectCanShowProjectByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params) {
        if (params == null) {
            params = new HashMap<>();
        }
        if (params.get("showAll") == null) {
            params.put("showAll", 0);
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        if (isAreaUser) {
            // 区域用户
//            List<TreeMenu> menuList = permissionMapper.selectCanShowProjectByAreaUser(userId, userInfo.getPlatformId(), areaCode, userGrade, params);
            List<TreeMenu> menuList = permissionMapper.selectCanShowProjectByAreaUser3(userId, areaCode, userGrade, params, userInfo.getPlatformId());
            return UserUtil.setPermission(areaCode, menuList);

        }
//        List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByNotAreaUser(userId, userInfo.getPlatformId(), params);
        List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByNotAreaUser2(userId, userInfo.getPlatformId(), params);
//        treeMenuList.stream().forEach(tree -> {
//            if (tree.getOnlyRead() == 0) {
//                tree.setNodeName(tree.getNodeName() + "-分-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 1) {
//                tree.setNodeName(tree.getNodeName() + "-下-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 2) {
//                tree.setNodeName(tree.getNodeName() + "-权-有权");
//                tree.setOnlyRead(1);
//            } else if (tree.getOnlyRead() == 3) {
//                tree.setNodeName(tree.getNodeName() + "-创-有权");
//                tree.setOnlyRead(1);
//            }
//        });
        return treeMenuList;
    }

    /**
     * 查询当前用户可见的单位
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return Map<Integer, TreeMenu> Map<key:单位id, TreeMenu>
     */
    @Override
    public List<TreeMenu> selectCanShowProjectByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, HbyAgency agency, Map<String, Object> params) {
        if (params == null) {
            params = new HashMap<>();
        }
        if (params.get("showAll") == null) {
            params.put("showAll", 0);
        }
        params.put("agency", agency);
        UserInfo userInfo = GlobalConstant.getUserInfo();
        if (isAreaUser) {
            // 区域用户
            List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByAreaUser2(userId, userInfo.getPlatformId(), areaCode, userGrade, params);
            return UserUtil.setPermission(areaCode, treeMenuList);
        }
        List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByNotAreaUser2(userId, userInfo.getPlatformId(), params);
//        treeMenuList.stream().forEach(tree -> {
//            if (tree.getOnlyRead() == 0) {
//                tree.setNodeName(tree.getNodeName() + "-分-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 1) {
//                tree.setNodeName(tree.getNodeName() + "-下-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 2) {
//                tree.setNodeName(tree.getNodeName() + "-权-有权");
//                tree.setOnlyRead(1);
//            } else if (tree.getOnlyRead() == 3) {
//                tree.setNodeName(tree.getNodeName() + "-创-有权");
//                tree.setOnlyRead(1);
//            }
//        });
        return treeMenuList;
    }



    /**
     * 查询当前用户可见的单位---------------------------------------------------------------------------修改
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行业类型id industryId, 单位id projId 查询,key值严格要求相同
     * @return Map<Integer, TreeMenu> Map<key:单位id, TreeMenu>
     */
    @Override
    public List<TreeMenu> selectCanShowProjectByUserId2(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, HbyAgency agency, Map<String, Object> params,Integer platformId) {
        if (params == null) {
            params = new HashMap<>();
        }
        if (params.get("showAll") == null) {
            params.put("showAll", 0);
        }
        if (agency==null){

        }else {
            params.put("agency", agency);
        }
        if (isAreaUser) {
            // 区域用户
            List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByAreaUser3(userId, areaCode, userGrade, params, platformId);
            return UserUtil.setPermission(areaCode, treeMenuList);
        }
        List<TreeMenu> treeMenuList = permissionMapper.selectCanShowProjectByNotAreaUser2(userId, platformId, params);
//        treeMenuList.stream().forEach(tree -> {
//            if (tree.getOnlyRead() == 0) {
//                tree.setNodeName(tree.getNodeName() + "-分-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 1) {
//                tree.setNodeName(tree.getNodeName() + "-下-无权");
//                tree.setOnlyRead(0);
//            } else if (tree.getOnlyRead() == 2) {
//                tree.setNodeName(tree.getNodeName() + "-权-有权");
//                tree.setOnlyRead(1);
//            } else if (tree.getOnlyRead() == 3) {
//                tree.setNodeName(tree.getNodeName() + "-创-有权");
//                tree.setOnlyRead(1);
//            }
//        });
        return treeMenuList;
    }


    /**
     * 获取用户所在区域的区域码
     * @param userId 用户id
     * @return
     */
    @Override
    public AreaCodeJoinOther selectAreaCodeByUserId(Integer userId) {
        return permissionMapper.selectAreaCodeByUserId(userId);
    }


    /**
     * 查询用户可见的所有机构
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行政机构id agencyId,key值严格要求相同
     * @return
     */
     @Override
     public List<TreeMenu> selectCanShowAgencyByUserId(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params) {
         if (params == null) {
             params = new HashMap<>();
         }
         if (params.get("showAll") == null) {
             params.put("showAll", 0);
         }
         UserInfo userInfo = GlobalConstant.getUserInfo();
         if (isAreaUser) {
             // 区域用户
             List<TreeMenu> treeMenuList = permissionMapper.selectCanShowAgencyByAreaUser(userInfo.getPlatformId(), areaCode, userGrade, params);
             return UserUtil.setPermission(areaCode, treeMenuList);
         }
         List<TreeMenu> projList = permissionMapper.selectCanShowProjectByNotAreaUser2(userId, userInfo.getPlatformId(), params);
         if (projList == null || projList.size() == 0) {
             return new ArrayList<>();
         }
         List<Long> projIdList = projList.stream().map(a -> a.getNodeId()).collect(Collectors.toList());
         return permissionMapper.selectCanShowAgencyByProjIdList(userInfo.getPlatformId(), projIdList, params);
     }

    /**
     * 查询用户可见的所有机构-----------------------------------------修改--------------------------------
     * @param userId 用户id
     * @param isAreaUser 是否是区域用户 true-是 false-不是
     * @param areaCode 用户所在区域的区域码(区域用户才有，其他用户传null)
     * @param userGrade 用户等级(区域用户才有，其他用户传null)
     * @param params 查询条件参数 当前支持 行政机构id agencyId,key值严格要求相同
     * @return
     */
    @Override
    public List<TreeMenu> selectCanShowAgencyByUserId2(Integer userId, boolean isAreaUser, AreaCodeJoinOther areaCode, Integer userGrade, Map<String, Object> params) {
        if (params == null) {
            params = new HashMap<>();
        }
        if (params.get("showAll") == null) {
            params.put("showAll", 0);
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        if (isAreaUser) {
            // 区域用户
            return permissionMapper.selectCanShowAgencyByAreaUser3(userInfo.getPlatformId(), areaCode, userGrade, params);
        }
        List<TreeMenu> projList = permissionMapper.selectCanShowProjectByNotAreaUser2(userId, userInfo.getPlatformId(), params);
        if (projList == null || projList.size() == 0) {
            return new ArrayList<>();
        }
        List<Long> projIdList = projList.stream().map(a -> a.getNodeId()).collect(Collectors.toList());
        return permissionMapper.selectCanShowAgencyByProjIdList(userInfo.getPlatformId(), projIdList, params);
    }


    /**
     * 查询机构和单位
     * @param userId 用户id
     * @param params showAll 0
     * @return
     */
    @Override
    public List<TreeMenu> selectCanShowAgencyAndProjectByUser(Integer userId, Map<String, Object> params) {
         // 用户区域码
        if (params == null) {
            params = new HashMap<>();
        }
        if (params.get("showAll") == null) {
            params.put("showAll", 0);
        }
        UserInfo userInfo = GlobalConstant.getUserInfo();
        AreaCodeJoinOther areaCode = this.selectAreaCodeByUserId(userId);
         List<TreeMenu> projList = this.selectCanShowProjectByUserId(userId, areaCode != null, areaCode, UserUtil.getUserGrade(areaCode), params);
         List<Long> projIdList = projList.stream().map(a -> a.getNodeId()).collect(Collectors.toList());
        if (projList == null || projList.size() == 0) {
            return new ArrayList<>();
        }
        List<TreeMenu> agencyList = permissionMapper.selectCanShowAgencyByProjIdList(userInfo.getPlatformId(), projIdList, params);
        agencyList.stream().forEach(agency -> {
             projList.stream().forEach(proj -> {
                 if (agency.getProvinceCode().equals(proj.getProvinceCode())
                         && agency.getCityCode().equals(proj.getCityCode())
                         && agency.getAreaCode().equals(proj.getAreaCode())) {
                     agency.getChildTreeMenu().add(proj);
                     projIdList.remove(proj);
                 }
             });
        });
        return agencyList;
     }

    /**
     * 检测用户是否有权限查询、操作该单位
     *
     * @param userId
     * @param projId
     * @return -1-无权限，0-被分享或下级单位（查询权），1-自己创建或权限组成员创建或区域用户管辖的单位（查询、操作权限）
     */
    @Override
    public Integer checkPermission(Integer userId, Integer projId) {

        AreaCodeJoinOther code = this.selectAreaCodeByUserId(userId);
        Integer userGrade = UserUtil.getUserGrade(code);
        Map<String, Object> params = new HashMap<>(4);
        params.put("projId", projId);
        List<TreeMenu> treeMenuList = this.selectCanShowProjectByUserId(userId, code != null, code, userGrade, params);
        if (treeMenuList == null || treeMenuList.size() == 0) {
            return -1;
        }
        return treeMenuList.get(0).getOnlyRead();
    }

}
