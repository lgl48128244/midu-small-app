/**
 * @author guoliang.li
 * @date 2019/12/20 11:51
 * @description TODO 常量包
 */
package com.leniao.huanbao.constant;