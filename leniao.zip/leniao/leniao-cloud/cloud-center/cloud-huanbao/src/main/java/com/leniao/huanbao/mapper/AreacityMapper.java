package com.leniao.huanbao.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.Areacity;

public interface AreacityMapper extends BaseMapper<Areacity> {
}
