package com.leniao.huanbao.pojo.pagetopselecteneity;

/**
 * @author liudongshuai
 * @date 2019/12/30 10:10
 * @update
 * @description
 */
public class UnitRealDataInfo {
    //单位Id
    private Integer unitId;
    //单位名称
    private String unitName;
    //单位行业
    private String industry;
    //单位生产状态  0 生产 1 停产
    private Integer runStatus;
    //单位行政区域
    private String area;
    //单位异常状态
    private Integer errStatus;
    //单位地址
    private String location;
    //单位坐标 X
    private Float locationX;
    //单位坐标 Y
    private Float locationY;
    //产污设备个数
    private Integer pollDevs;
    //治污设备个数
    private Integer conDevs;
    //监测点个数
    private Integer lookPoints;
    //运行设备个数
    private Integer runDevs;
    //停机设备个数
    private Integer stopDevs;
    //失联设备个数
    private Integer lostDevs;

    //单位评分
    private int unitGrade;

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public Integer getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(Integer runStatus) {
        this.runStatus = runStatus;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Integer getErrStatus() {
        return errStatus;
    }

    public void setErrStatus(Integer errStatus) {
        this.errStatus = errStatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Float getLocationX() {
        return locationX;
    }

    public void setLocationX(Float locationX) {
        this.locationX = locationX;
    }

    public Float getLocationY() {
        return locationY;
    }

    public void setLocationY(Float locationY) {
        this.locationY = locationY;
    }

    public Integer getPollDevs() {
        return pollDevs;
    }

    public void setPollDevs(Integer pollDevs) {
        this.pollDevs = pollDevs;
    }

    public Integer getConDevs() {
        return conDevs;
    }

    public void setConDevs(Integer conDevs) {
        this.conDevs = conDevs;
    }

    public Integer getLookPoints() {
        return lookPoints;
    }

    public void setLookPoints(Integer lookPoints) {
        this.lookPoints = lookPoints;
    }

    public Integer getRunDevs() {
        return runDevs;
    }

    public void setRunDevs(Integer runDevs) {
        this.runDevs = runDevs;
    }

    public Integer getStopDevs() {
        return stopDevs;
    }

    public void setStopDevs(Integer stopDevs) {
        this.stopDevs = stopDevs;
    }

    public Integer getLostDevs() {
        return lostDevs;
    }

    public void setLostDevs(Integer lostDevs) {
        this.lostDevs = lostDevs;
    }

    public int getUnitGrade() {
        return unitGrade;
    }

    public void setUnitGrade(int unitGrade) {
        this.unitGrade = unitGrade;
    }

    @Override
    public String toString() {
        return "UnitRealDataInfo{" +
                "unitName='" + unitName + '\'' +
                ", industry='" + industry + '\'' +
                ", runStatus='" + runStatus + '\'' +
                ", area='" + area + '\'' +
                ", errStatus='" + errStatus + '\'' +
                ", location='" + location + '\'' +
                ", locationX='" + locationX + '\'' +
                ", locationY='" + locationY + '\'' +
                ", pollDevs='" + pollDevs + '\'' +
                ", conDevs='" + conDevs + '\'' +
                ", lookPoints='" + lookPoints + '\'' +
                ", runDevs='" + runDevs + '\'' +
                ", stopDevs='" + stopDevs + '\'' +
                ", lostDevs='" + lostDevs + '\'' +
                '}';
    }
}
