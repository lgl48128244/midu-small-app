package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@TableName("hby_reduceplan_join_project")
@ToString
public class HbyReduceplanJoinProject implements Serializable {
    @TableId
    private Long id;

    private Integer unitId;

    private Long planId;

    private Integer isViolat;

    private Integer isMark;

    private Long sumProTime;

    private Long errorId;

    private Date bindTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }

    public Integer getIsViolat() {
        return isViolat;
    }

    public void setIsViolat(Integer isViolat) {
        this.isViolat = isViolat;
    }

    public Integer getIsMark() {
        return isMark;
    }

    public void setIsMark(Integer isMark) {
        this.isMark = isMark;
    }

    public Long getSumProTime() {
        return sumProTime;
    }

    public void setSumProTime(Long sumProTime) {
        this.sumProTime = sumProTime;
    }

    public Long getErrorId() {
        return errorId;
    }

    public void setErrorId(Long errorId) {
        this.errorId = errorId;
    }

    public Date getBindTime() {
        return bindTime;
    }

    public void setBindTime(Date bindTime) {
        this.bindTime = bindTime;
    }
}