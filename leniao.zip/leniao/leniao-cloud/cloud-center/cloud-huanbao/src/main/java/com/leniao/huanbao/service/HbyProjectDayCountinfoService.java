package com.leniao.huanbao.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.entity.HbyProjectDayCountinfoExample;
import com.leniao.huanbao.dto.ExpendStatistic.ExecuteState;
import com.leniao.huanbao.dto.ExpendStatistic.LinkRelativeStatistic;
import com.leniao.huanbao.dto.ExpendStatistic.MaxStatistic;
import com.leniao.huanbao.dto.ExpendStatistic.UseEleRanking;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface HbyProjectDayCountinfoService extends IService<HbyProjectDayCountinfo> {

    long countByExample(HbyProjectDayCountinfoExample example);

    int deleteByExample(HbyProjectDayCountinfoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyProjectDayCountinfo record);

    int insertSelective(HbyProjectDayCountinfo record);

    List<HbyProjectDayCountinfo> selectByExample(HbyProjectDayCountinfoExample example);

    HbyProjectDayCountinfo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyProjectDayCountinfo record, @Param("example") HbyProjectDayCountinfoExample example);

    int updateByExample(@Param("record") HbyProjectDayCountinfo record, @Param("example") HbyProjectDayCountinfoExample example);

    int updateByPrimaryKeySelective(HbyProjectDayCountinfo record);

    int updateByPrimaryKey(HbyProjectDayCountinfo record);

    /**
     * 峰值统计
     * @param params
     * @return
     */
    List<MaxStatistic> selectPeakValue(JSONObject params);

    /**
     * 查询设备节点历史数据
     * @param devIdpk 设备id
     * @param beginTime 查询时间区间 -开始
     * @param endTime 查询时间区间 -结束
     * @param nodeArray 节点字符串 结构 "PA-PB-PC"
     * @param totalRows 查询时间区间内的 totalRows 行数据
     * @return
     */
    List<realValueList1> selectCurveChart(Integer devIdpk, String beginTime, String endTime, String nodeArray, int totalRows);

    /**
     * 查询多个单位（单位、行业、区域） 本日、本月、本年总用电量和 上日、上月、上年总用电量
     * 并计算趋势
     * @param projIdList 单位id集合
     * @return
     */
    List<LinkRelativeStatistic> selectEleLinkRelative(List<Integer> projIdList);

    /**
     * 批量查询单位日数据
     * @param projIdList 单位id集合
     * @param year 年
     * @param month 月
     * @param day 日
     * @return
     */
    List<HbyProjectDayCountinfo> selectHbyProjectDayCountinfoByProjIds(List<Integer> projIdList, int year, int month, int day);

    /**
     * 批量查询单位日数据
     * @param projIdList 单位id集合
     * @return
     */
    List<UseEleRanking> selectHbyProjectDayCountinfoByProjIds2(List<Integer> projIdList);

    /**
     * 获取单位当日的数据，不区分平台，用的时候请注意
     * @author haosw
     * @param unitId
     * @param year
     * @param month
     * @param day
     * @return
     */
    List<HbyProjectDayCountinfo> selectHbyProjectDayCountinfoByProjIds(Integer unitId, int year, int month, int day);

    /**
     * 单位下分组、设备用电量排名
     * @param projId 单位id
     * @param label 标签 1-分组，2-设备
     * @return
     */
    List<Map<String, Object>> findUseEleRankingProj(Integer projId, Integer label);

    /**
     * 查询柱状图-同比
     * @param projIdList 单位id集合
     * @param timeType 时间类型 1-日 2-月 3-年
     * @date 时间 可以不传
     * @return
     */
    Map<String, Object> selectEleBarGraphYoY(List<Integer> projIdList, Integer timeType, Date date);

    /**
     * 查询柱状图-环比
     * @param projIdList 单位id集合
     * @param timeType 时间类型 1-日 2-月 3-年
     * @date 时间 可以不传
     * @return
     */
    Map<String, Object> selectEleBarGraphLinkRelative(List<Integer> projIdList, Integer timeType, Date date);

    /**
     * 获取今日和昨日绑定方案的单位数量
     * @param projIdList 单位id集合
     * @return
     */
    ExecuteState findHomePlanBind(List<Integer> projIdList);

    /**
     * 更新单位的行业
     * @param unitId
     * @param industryId
     */
    void updateIndustryOfUnit(Integer unitId, Integer industryId);
}
