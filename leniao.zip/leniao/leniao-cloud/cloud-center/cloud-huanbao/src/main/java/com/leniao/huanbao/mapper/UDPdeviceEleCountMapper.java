package com.leniao.huanbao.mapper;

import java.util.List;

public interface UDPdeviceEleCountMapper {
    List<Integer> findAllUdpDeviceInOverLookPoint();

}
