package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.huanbao.entity.HbyOverlookJoin;
import com.leniao.huanbao.mapper.HbyOverlookJoinMapper;
import com.leniao.huanbao.service.HbyOverlookJoinService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author liudongshuai
 * @date 2019/12/19 16:49
 * @update
 */
@Service
public class HbyOverlookJoinServiceImpl extends ServiceImpl<HbyOverlookJoinMapper,HbyOverlookJoin> implements HbyOverlookJoinService {

    @Resource
    private HbyOverlookJoinMapper hbyOverlookJoinMapper;

    /**
     * 通过检测点id 查出产污设备id，治污设备id
     * */
    @Override
    public List<HbyOverlookJoin> finddevIdinfo(Long lookPointId) {
        //创建条件
        QueryWrapper<HbyOverlookJoin> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("poll_dev_id","con_dev_id").lambda().eq(HbyOverlookJoin::getLookId,lookPointId);

        List<HbyOverlookJoin> hbyOverlookJoinList = hbyOverlookJoinMapper.selectList(queryWrapper);
        if (hbyOverlookJoinList==null){
            List<HbyOverlookJoin> hbyOverlookJoins = new ArrayList<>();
            return hbyOverlookJoins;
        }else {
            return hbyOverlookJoinList;
        }

    }

    /**
     * 添加监测点与，产污设备，治污设备关系
     */
    @Override
    public boolean addLookJoin(HbyOverlookJoin hbyOverlookJoin) {

        return save(hbyOverlookJoin);
    }

    /**
     * 删除监测点产污与治污设备管理关系
     */
    @Override
    public boolean removeLookJoin(Long lookPointId) {
        UpdateWrapper<HbyOverlookJoin> updateWrapper = new UpdateWrapper<>();
        updateWrapper.lambda().eq(HbyOverlookJoin::getLookId,lookPointId);

        return remove(updateWrapper);

    }
}
