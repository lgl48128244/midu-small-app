package com.leniao.huanbao.utils;

import com.alibaba.fastjson.JSON;
import com.leniao.commons.util.math.BigDecimalUtils;
import com.leniao.commons.util.thrift.realValue1;
import com.leniao.commons.util.thrift.realValueList1;
import com.leniao.huanbao.dto.schedule.HbyErrorDto;
import com.leniao.huanbao.entity.HbyReduceEmmissionPlan;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Test;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description: 环保云模块定时任务所需的工具类
 * @Author: haosw
 * @CreateDate: 2019/12/20 17:59
 * @Version: 1.0
 */
@Slf4j
public class ScheduleNeedUtil {

    /**
     * @param now
     * @description: 获取当前时间的上一个时间区间从0分开始, 每20分钟为一个时间区间
     * @author: haosw
     * @param:
     * @return: DateTime[]:上一个时间区间的开始时间和结束时间
     * @date: 2019/12/20 18:08
     */
    public static DateTime[] getFrontTimeArea(Date now) {
        DateTime dateTime = new DateTime(now);
        //dateTime = dateTime.minus(10 * 60 * 1000);
        int hour = dateTime.hourOfDay().get();
        int minute = dateTime.minuteOfHour().get();
        int second = dateTime.secondOfMinute().get();

        DateTime[] dateTimes = new DateTime[2];
        if (minute >= 0 && minute < 20) {
            DateTime s1;
            if (hour == 0) {
                DateTime yestodayTime = dateTime.minusDays(1);
                s1 = new DateTime(yestodayTime.getYear(), yestodayTime.getMonthOfYear(), yestodayTime.getDayOfMonth(),
                        23, 40, 0, 0);
            } else {
                s1 = new DateTime(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(),
                        dateTime.getHourOfDay() - 1, 40, 0, 0);
            }
            DateTime e1 = s1.plus(19 * 60 * 1000 + 59 * 1000 + 999);
            dateTimes[0] = s1;
            dateTimes[1] = e1;
        } else if (minute >= 20 && minute < 40) {
            DateTime s1 = new DateTime(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(),
                    dateTime.getHourOfDay(), 0, 0, 0);
            DateTime e1 = s1.plus(19 * 60 * 1000 + 59 * 1000 + 999);
            dateTimes[0] = s1;
            dateTimes[1] = e1;
        } else {
            DateTime s1 = new DateTime(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(),
                    dateTime.getHourOfDay(), 20, 0, 0);

            DateTime e1 = s1.plus(19 * 60 * 1000 + 59 * 1000 + 999);
            dateTimes[0] = s1;
            dateTimes[1] = e1;
        }
        return dateTimes;
    }


    /**
     * 获取设备的状态 1:运行, 2:低负荷, 3:停机, 4:失联, 0:未知状态
     *
     * @param dataPackages 功率实时数据包
     * @param devSillVal   设备的功率阈值
     * @param devPower     设备的额定功率
     * @return
     */
    public static int getDevState(List<realValueList1> dataPackages, Integer devSillVal, Integer devPower) {
        //默认当前设备失联状态 4
        int state = 4;
        //此处只判断了第一个节点"PA" 的实时值
        if (dataPackages.get(0).getRows().size() > 0) {
            //获取平均功率
            double avgValue = 0;
            int size = 0;
            for (realValueList1 dataPackage : dataPackages) {
                Iterator<realValue1> rowsIterator = dataPackage.getRowsIterator();
                while (rowsIterator.hasNext()) {
                    size++;
                    realValue1 next = rowsIterator.next();
                    avgValue += Double.parseDouble(next.getVal());
                }
            }
            //计算平均值
            if (size > 0) {
                avgValue = BigDecimalUtils.calculate(avgValue).div(size).getBigDecimal().doubleValue();
            }
            //判断设备状态
            //停机---平均功率 < 启停功率
            if (BigDecimalUtils.is(avgValue).lt(devSillVal)) {
                return 3;
            } else if (BigDecimalUtils.is(avgValue).lt(BigDecimalUtils.calculate(devPower).multiply("0.3").getBigDecimal().doubleValue())) {
                //低负荷---平均功率 < 额定功率的30%
                return 2;
            } else if (BigDecimalUtils.is(avgValue).gteq(devSillVal)) {
                //运行---平均功率 >= 启停功率阈值
                return 1;
            } else {
                return 0;
            }

        } else {
            return state;
        }
    }

    /**
     * 判断当前时间是否在某时间段内
     *
     * @param beginTime 计划的开始日期
     * @param endTime   计划的结束日期
     * @param strTimes  开始和结束时间段
     * @param now       当前时间
     * @return true:违规, false:没有违规
     */
    public static HbyErrorDto.StopProErrChargeDto chargeTimeIsInTimeArea(Date beginTime, Date endTime, List<String> strTimes, Date now) {
        HbyErrorDto.StopProErrChargeDto stopProErrChargeDto = new HbyErrorDto.StopProErrChargeDto();
        if (CollectionUtils.isEmpty(strTimes) || beginTime == null || endTime == null) {
            stopProErrChargeDto.setInTimeArea(false);
        }
        DateTime begin = new DateTime(beginTime);
        DateTime end = new DateTime(endTime);
        DateTime nowTime = new DateTime(now);
        for (String strTime : strTimes) {
            String[] split = strTime.split("-");
            DateTime startTime = begin.plus((Integer.parseInt(split[0].split(":")[0])) * 60 * 60 * 1000
                    + (Integer.parseInt(split[0].split(":")[0]) * 60 * 1000));
            DateTime stopTime = end.plus((Integer.parseInt(split[1].split(":")[0])) * 60 * 60 * 1000
                    + (Integer.parseInt(split[1].split(":")[0]) * 60 * 1000));
            if (nowTime.isAfter(startTime) && nowTime.isBefore(stopTime)) {
                //当前时间在 时间段内 返回true
                stopProErrChargeDto.setInTimeArea(true);
                stopProErrChargeDto.setStartTime(startTime);
                stopProErrChargeDto.setEndTime(stopTime);
                return stopProErrChargeDto;
            }
        }
        stopProErrChargeDto.setInTimeArea(false);
        return stopProErrChargeDto;
    }

    /**
     * @description: 判断方案是否过期
     * @author: haosw
     * @param:
     * @return: true:当前时间在方案所限制的时间内  false: 当前时间不在方案所限制的时间内
     * @date: 2020/1/2 11:35
     */
    public static boolean isPlanInTimeArea(HbyReduceEmmissionPlan plan, Date now) {
        if (plan == null) {
            return false;
        }
        Date begin = plan.getBeginTime();
        DateTime endDateTime = new DateTime(plan.getEndTime());
        Date end = new DateTime(endDateTime.getYear(), endDateTime.getMonthOfYear(), endDateTime.getDayOfMonth(), 23, 59, 59).toDate();
        //停产
        if (plan.getPlanType().equals(1)) {
            String stopProducTimeList = plan.getStopProducTimeList();
            List<String> strings = JSON.parseArray(stopProducTimeList, String.class);
            HbyErrorDto.StopProErrChargeDto stopProErrChargeDto = ScheduleNeedUtil.chargeTimeIsInTimeArea(begin, end, strings, now);
            return stopProErrChargeDto.isInTimeArea();
        } else if (plan.getPlanType().equals(2)) {
            //限产
            DateTime nowTime = new DateTime(now);
            DateTime beginTime = new DateTime(begin);
            DateTime endTime = new DateTime(end);
            return (nowTime.isAfter(beginTime) && nowTime.isBefore(endTime));
        }
        return false;
    }


    /**
     * 判断当前方案是否过期
     *
     * @param plan
     * @return true: 当前时间在方案的结束时间之后，方案过期； false：当前时间不在方案结束时间之后，当前方案没有过期
     */
    public static boolean isPlanOutOfTime(HbyReduceEmmissionPlan plan) {
        if (plan == null) {
            return false;
        }
        DateTime now = DateTime.now();
        Date begin = plan.getBeginTime();
        Date end = plan.getEndTime();
        if (plan.getPlanType().equals(1)) {
            String strTimeList = plan.getStopProducTimeList();
            List<String> stopProducTimeList = JSON.parseArray(strTimeList, String.class);
            //Integer startNum = 23 * 60 * 60 * 1000;
            Integer endNum = 0;
            for (String strTime : stopProducTimeList) {
                String[] split = strTime.split("-");
                //Integer a = Integer.parseInt(split[0].split(":")[0]) * 60 * 60 * 1000 + Integer.parseInt(split[0].split(":")[0]) * 60 * 1000;
                Integer b = Integer.parseInt(split[1].split(":")[0]) * 60 * 60 * 1000 + Integer.parseInt(split[1].split(":")[1]) * 60 * 1000;
                /*if (startNum < a) {
                    startNum = a;
                }*/
                if (b > endNum) {
                    endNum = b;
                }
            }
            //DateTime startTime = new DateTime(begin).plus(startNum);
            DateTime endTime = new DateTime(end).plus(endNum);
            System.out.println(endTime.toString("yyyy-MM-dd HH:mm:ss"));
            return now.isAfter(endTime);

        } else if (plan.getPlanType().equals(2)) {
            DateTime endTime = new DateTime(end).withTime(23, 59, 59, 999);
            System.out.println(endTime.toString("yyyy-MM-dd HH:mm:ss"));
            return now.isAfter(endTime);
        }

        return false;
    }

    /**
     * 除以1000并保留两位小数
     *
     * @param value
     * @return
     */
    public static double valueDiv1000(Integer value) {
        if (value == null) {
            return 0;
        }
        double dcmd = BigDecimalUtils.calculate(value).div(1000).getBigDecimal().doubleValue();
        return Double.parseDouble(new DecimalFormat("#.00").format(dcmd));
    }

    /**
     * 除以1000并保留两位小数
     *
     * @param value
     * @return
     */
    public static double valueDiv1000(Double value) {
        if (value == null) {
            return 0;
        }
        double dcmd = BigDecimalUtils.calculate(value).div(1000).getBigDecimal().doubleValue();
        return Double.parseDouble(new DecimalFormat("#.00").format(dcmd));
    }

    public static Date getMaxEleTime(long startSecond, List<realValueList1> realValueList1s) {
        if (CollectionUtils.isEmpty(realValueList1s)) {
            return null;
        }
        List<realValueList1> collectQA = realValueList1s.stream().filter(real -> "QA".equalsIgnoreCase(real.getKeyname())).collect(Collectors.toList());
        List<realValueList1> collectQB = realValueList1s.stream().filter(real -> "QB".equalsIgnoreCase(real.getKeyname())).collect(Collectors.toList());
        List<realValueList1> collectQC = realValueList1s.stream().filter(real -> "QC".equalsIgnoreCase(real.getKeyname())).collect(Collectors.toList());
        List<realValue1> rowsQA = collectQA.get(0).getRows();
        List<realValue1> rowsQB = collectQB.get(0).getRows();
        List<realValue1> rowsQC = collectQC.get(0).getRows();
        double max = 0;
        Date time = null;

        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

        if (rowsQA.size() > 0) {
            for (int i = 0; i < rowsQA.size(); i++) {
                double qa = Double.parseDouble(rowsQA.get(i).getVal());
                double qb = Double.parseDouble(rowsQB.get(i).getVal());
                double qc = Double.parseDouble(rowsQC.get(i).getVal());
                double q = qa + qb + qc;

                String addtime = rowsQA.get(i).getAddtime();
                if (!addtime.startsWith("1200")) {
                    DateTime parse = DateTime.parse(addtime, dateTimeFormatter);
                    //如果当前电量大于上一个
                    if (BigDecimalUtils.is(q).gteq(max)) {
                        max = q;
                        time = parse.toDate();
                    }
                }
            }
        }
        return time;

    }

    @Test
    public void testGetMaxTime(){
        String nodeArray = "QA-QB-QC";
        List<realValueList1> realValueList1s = com.leniao.commons.util.HbaseUtil.GetListArrayByFilter("294971", "20200317130000", "20200328235959", nodeArray, "1000");
        DateTime dateTime = DateTime.now().withTime(13, 0, 0, 0);
        long start = dateTime.getMillis() / 1000;
        Date maxEleTime = getMaxEleTime(start, realValueList1s);
        System.out.println(maxEleTime);
    }

    @Test
    public void test() {
        HbyReduceEmmissionPlan plan = new HbyReduceEmmissionPlan();
        plan.setPlanId(110L);
        plan.setBeginTime(new DateTime(2020, 2, 2, 0, 0, 0).toDate());
        plan.setEndTime(new DateTime(2020, 3, 3, 0, 0, 0).toDate());
        String string = "[\"09:00-09:30\",\"10:00-17:30\"]";
        plan.setStopProducTimeList(string);
        plan.setPlanType(1);
        boolean planOutOfTime = ScheduleNeedUtil.isPlanOutOfTime(plan);
        if (planOutOfTime) {
            System.out.println("当前方案过期");
        } else {
            System.out.println("当前方案没有过期");
        }
    }


}
