package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;
@ToString
@TableName("hby_reduce_emmission_plan")
public class HbyReduceEmmissionPlan implements Serializable {
    private Long planId;

    private String planName;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    private Integer planType;

    private Date beginTime;

    private Date endTime;

    private Integer limitProducTimeCount;

    private Integer warnLevel;

    private String remark;

    private Integer isUsing;

    private Integer updateUser;

    private Date updateTime;

    private Integer createUser;

    private Date createTime;

    private Integer isDelete;

    private Integer bindUnitCount;

    private Integer platformId;

    private Long belongAgency;

    private String stopProducTimeList;

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName == null ? null : planName.trim();
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode == null ? null : areaCode.trim();
    }

    public Integer getPlanType() {
        return planType;
    }

    public void setPlanType(Integer planType) {
        this.planType = planType;
    }

    public Date getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Date beginTime) {
        this.beginTime = beginTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getLimitProducTimeCount() {
        return limitProducTimeCount;
    }

    public void setLimitProducTimeCount(Integer limitProducTimeCount) {
        this.limitProducTimeCount = limitProducTimeCount;
    }

    public Integer getWarnLevel() {
        return warnLevel;
    }

    public void setWarnLevel(Integer warnLevel) {
        this.warnLevel = warnLevel;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getIsUsing() {
        return isUsing;
    }

    public void setIsUsing(Integer isUsing) {
        this.isUsing = isUsing;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Integer getBindUnitCount() {
        return bindUnitCount;
    }

    public void setBindUnitCount(Integer bindUnitCount) {
        this.bindUnitCount = bindUnitCount;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    public Long getBelongAgency() {
        return belongAgency;
    }

    public void setBelongAgency(Long belongAgency) {
        this.belongAgency = belongAgency;
    }

    public String getStopProducTimeList() {
        return stopProducTimeList;
    }

    public void setStopProducTimeList(String stopProducTimeList) {
        this.stopProducTimeList = stopProducTimeList == null ? null : stopProducTimeList.trim();
    }
}