package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.Tblngroup;
import com.leniao.huanbao.entity.TblngroupExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblngroupMapper extends BaseMapper<Tblngroup> {
    int countByExample(TblngroupExample example);

    int deleteByExample(TblngroupExample example);

    int deleteByPrimaryKey(Integer groupid);

    int insert(Tblngroup record);

    int insertSelective(Tblngroup record);

    List<Tblngroup> selectByExample(TblngroupExample example);

    Tblngroup selectByPrimaryKey(Integer groupid);

    int updateByExampleSelective(@Param("record") Tblngroup record, @Param("example") TblngroupExample example);

    int updateByExample(@Param("record") Tblngroup record, @Param("example") TblngroupExample example);

    int updateByPrimaryKeySelective(Tblngroup record);

    int updateByPrimaryKey(Tblngroup record);
}