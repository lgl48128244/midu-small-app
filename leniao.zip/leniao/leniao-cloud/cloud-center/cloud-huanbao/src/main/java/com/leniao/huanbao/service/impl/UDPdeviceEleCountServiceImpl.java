package com.leniao.huanbao.service.impl;

import com.leniao.huanbao.mapper.TblndeviceparameterMapper;
import com.leniao.huanbao.mapper.UDPdeviceEleCountMapper;
import com.leniao.huanbao.schedule.udpbean.UshareCharge;
import com.leniao.huanbao.schedule.udpbean.UshareDeviceElectricuse;
import com.leniao.huanbao.schedule.udpbean.WebResult;
import com.leniao.huanbao.service.UDPdeviceEleCountService;
import com.leniao.huanbao.schedule.udpbean.DateUtil;
import com.leniao.mapper.TblndeviceinfoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class UDPdeviceEleCountServiceImpl implements UDPdeviceEleCountService {

    private Logger logger = LoggerFactory.getLogger(UDPdeviceEleCountServiceImpl.class);

    @Resource
    private UDPdeviceEleCountMapper udPdeviceEleCountMapper;
    @Resource
    private TblndeviceinfoMapper tblndeviceinfoMapper;
    @Resource
    private TblndeviceparameterMapper tblndeviceparameterMapper;


    @Override
    public List<Integer> findAllUdpDeviceInOverLookPoint() {
        return this.udPdeviceEleCountMapper.findAllUdpDeviceInOverLookPoint();
    }


    /**
     * 2019-10-29 修改
     * 2019-12-13 修改bug
     * @param devIdpk 设备主键id
     * @param realPower 实时用电量
     * @param time 时间
     * @param multiple 小数倍数
     * @return
     */
    @Override
    public WebResult saveDevicePower_v20191214(int devIdpk, int realPower, String time, int multiple) {
        WebResult Back = new WebResult();
        try {
            // 获取单位id
            Integer unitId = tblndeviceinfoMapper.selectDevUnitId(devIdpk);
            if (unitId == null) {
                Back.setBackCode(0);
                Back.setId("设备Id为:" + devIdpk + "的设备的单位不存在");
                return Back;
            }

            // 查询单位电价列表
            List<UshareCharge> ushareChargeList = tblndeviceparameterMapper.findUshareCharges(unitId);

            // 查询上一次上报的用电量信息
            UshareDeviceElectricuse lastData = tblndeviceparameterMapper.findUshareDeviceElectricuseByDevIdpk(devIdpk);

            // 判断是否是设备最新上报数据
            if (lastData == null) {
                // 添加新的数据
                addNewDataInfo_v20191214(time, devIdpk, unitId, realPower, multiple, ushareChargeList);
                Back.setBackCode(1);
                Back.setId(devIdpk + "本次新加成功" + time);
                return Back;
            }
            // 非最新数据, 存在跨日期，甚至跨几天的问题

            // 设备当前上传数据的时间转成日历
            Calendar today = this.getCalendar(DateUtil.strToLongDate(time));
            // 上一次数据上报时间转成日历
            Calendar lastday = this.getCalendar(lastData.getUpdateTime());

            // 60 秒 不处理历史数据或上报间隔小于60秒的数据
            if (today.getTime().getTime() - lastday.getTime().getTime() < 60000) {
                Back.setBackCode(0);
                Back.setId(devIdpk + "不处理历史数据或上报间隔小于60秒的数据。上次时间:" + DateUtil.dateToLongStr(lastday.getTime()) +
                        " 本次时间:" + time);
                return Back;
            }

            // 设备时间段内总耗电量
            BigDecimal usePower = null;
            int illegalData = this.isIllegalData2(devIdpk, realPower, lastData.getDevRealTotalQ(), today.getTime(), lastday.getTime());
            // 判断数据是否异常
            if (illegalData == -1) {
                // 数据异常，以当前上报的数据作为设备的实时用电量，并把当前上报的数据当作当前小时的耗电量
                usePower = new BigDecimal(realPower);
            } else if (illegalData == 0) {
                // 数据正常，统计用电量差值
                usePower = new BigDecimal(0);
                realPower = lastData.getDevRealTotalQ();
            } else {
                // 数据正常，统计用电量差值
                usePower = new BigDecimal(realPower - lastData.getDevRealTotalQ());
            }

            //时间差
            BigDecimal tmp = new BigDecimal((DateUtil.getLongSecondOfDate(today.getTime()) - DateUtil.getLongSecondOfDate(lastday.getTime())));//秒数
            // 平均每秒用电量
            BigDecimal avg = usePower.divide(tmp, 10, BigDecimal.ROUND_UP);

            //上次更新数据时的 开始和结束时间点
            Date[] lastStartAndEnd = DateUtil.getHourStartAndEndDate(lastday.getTime());

            // 处理前一部分未满一个小时的数据，返回是否结束 结束-true  未结束-false
            if (this.dealBefore(realPower, unitId, multiple, lastStartAndEnd, today, lastday, avg, ushareChargeList, lastData)) {
                Back.setBackCode(1);
                Back.setId(devIdpk + "本此处理成功: " + time);
                return Back;
            }

            // 定义一个临时日志时间
            Calendar tmpday = Calendar.getInstance();
            tmpday.setTime(lastStartAndEnd[1]);
            tmpday.add(Calendar.SECOND, 1);//0点整

            // 处理中间满一个小时或多个小时的数据, 返回临时日志时间
            lastData = this.dealMiddle(realPower, unitId, multiple, today, lastday, tmpday, avg, ushareChargeList, lastData);

            // 处理后一部分未满一个小时的数据
            this.dealAfter(realPower, unitId, multiple, today, lastday, tmpday, avg, ushareChargeList, lastData);

            Back.setBackCode(1);
            Back.setId(devIdpk + "本此处理成功: " + time);
            return Back;
        } catch (Exception e) {
            logger.error("[01010162]用电量处理异常" + e.toString());
            Back.setId("[01010162]用电量处理异常");
            Back.setBackCode(0);
        }
        return Back;
    }

    /**
     * 处理后一部分未满一个小时的数据
     *
     * @param realPower
     * @param unitId
     * @param multiple
     * @param today
     * @param lastday
     * @param tmpday
     * @param avg
     * @param ushareChargeList
     * @param lastData
     */
    private void dealAfter(int realPower, Integer unitId, int multiple, Calendar today, Calendar lastday, Calendar tmpday,
                           BigDecimal avg, List<UshareCharge> ushareChargeList, UshareDeviceElectricuse lastData) {

        //计算当前所在时段不满一小时的电量
        Date[] thisTimeStartAndEnd = DateUtil.getHourStartAndEndDate(today.getTime());
        double endValue = (DateUtil.getLongSecondOfDate(today.getTime()) - DateUtil.getLongSecondOfDate(thisTimeStartAndEnd[0])) * avg.doubleValue();

        if (!compareDate(lastday, tmpday) ) {  // 零点钟的情况
            // 跨天，创建新对象，保存当天的用电数据
            lastData = createOneEntity_v20191029(lastData, today, realPower, DateUtil.dateToShortStr(tmpday.getTime()));
            dealData_v20191214(lastData, ushareChargeList,tmpday.get(Calendar.HOUR_OF_DAY) +1, endValue, today, unitId, multiple, realPower);
            tblndeviceparameterMapper.addUshareDeviceElectricuse(lastData);//返回自增主键id
        } else {
            //本次上传数据的时间距离上次上传数据的时间的不足一小时
            dealData_v20191214(lastData, ushareChargeList, tmpday.get(Calendar.HOUR_OF_DAY) + 1, endValue, today, unitId, multiple, realPower);
            tblndeviceparameterMapper.updateUshareDeviceElectricuse(lastData);
        }

    }

    /**
     * 处理中间满一个小时或多个小时的数据, 返回最后的用电实体对象
     *
     * @param realPower
     * @param unitId
     * @param multiple
     * @param today
     * @param lastday
     * @param tmpday
     * @param avg
     * @param ushareChargeList
     * @param lastData
     * @return
     */
    private UshareDeviceElectricuse dealMiddle(int realPower, Integer unitId, int multiple, Calendar today, Calendar lastday, Calendar tmpday,
                                               BigDecimal avg, List<UshareCharge> ushareChargeList, UshareDeviceElectricuse lastData) {

        // 计算一个小时的耗电量
        double oneHourvalue = avg.doubleValue() * 3600;
        // 加一小时后还有整段时间的空间
        while ((tmpday.getTime().getTime() + 3600*1000) <= today.getTime().getTime()) {
            if (compareDate(lastday, tmpday) ) {
                //如果是同一天--更新
                this.dealData_v20191214(lastData, ushareChargeList,tmpday.get(Calendar.HOUR_OF_DAY) + 1, oneHourvalue, today, unitId, multiple, realPower);
            } else {

                tblndeviceparameterMapper.updateUshareDeviceElectricuse(lastData);
                // 跨天，创建新对象，保存当天的用电数据
                lastData = createOneEntity_v20191029(lastData, tmpday, realPower, DateUtil.dateToShortStr(tmpday.getTime()));

                this.dealData_v20191214(lastData, ushareChargeList,tmpday.get(Calendar.HOUR_OF_DAY) +1, oneHourvalue, today, unitId, multiple, realPower);
                tblndeviceparameterMapper.addUshareDeviceElectricuse(lastData);//返回自增主键id
                //上次上传时间也变为下一天
                lastday.setTime(tmpday.getTime());

            }
            tmpday.add(Calendar.HOUR_OF_DAY, 1); // 加一个小时
        }
        return lastData;
    }

    /**
     * 处理前一部分未满一个小时的数据，返回是否结束 结束-true  未结束-false
     * @param realPower
     * @param unitId
     * @param multiple
     * @param lastStartAndEnd
     * @param today
     * @param lastday
     * @param avg
     * @param ushareChargeList
     * @param lastData
     * @return
     */
    private boolean dealBefore(int realPower, int unitId, int multiple, Date[] lastStartAndEnd, Calendar today, Calendar lastday,
                               BigDecimal avg, List<UshareCharge> ushareChargeList, UshareDeviceElectricuse lastData) {
        double value = 0;
        boolean flag = false;
        // 判断是否是同一个小时
        if (DateUtil.getLongSecondOfDate(lastStartAndEnd[1]) + 1 - DateUtil.getLongSecondOfDate(today.getTime()) > 0) {
            // 同一个小时内 用电量差
            value = (DateUtil.getLongSecondOfDate(today.getTime()) - DateUtil.getLongSecondOfDate(lastday.getTime())) * avg.doubleValue();
            flag = true;
        } else {
            // 不是同一个小时  用电量差
            value = (DateUtil.getLongSecondOfDate(lastStartAndEnd[1]) + 1 - DateUtil.getLongSecondOfDate(lastday.getTime())) * avg.doubleValue();
        }
        // 更新上一次上报数据
        this.dealData_v20191214(lastData, ushareChargeList, lastday.get(Calendar.HOUR_OF_DAY) + 1, value, today, unitId, multiple, realPower);
        tblndeviceparameterMapper.updateUshareDeviceElectricuse(lastData);

        return flag;
    }

    /**
     * 判断设备上报数据是否异常
     * @param devIdpk
     * @param realPower
     * @param lastPower
     * @param realTime
     * @param lastTime
     * @return
     */
    private boolean isIllegalData(int devIdpk, int realPower, int lastPower, Date realTime, Date lastTime) {
        if (realPower - lastPower < 0) { // 异常数据 非法数据

            // 差值大于0.01，认为用电量被重置
            if ((new BigDecimal(lastPower - realPower).compareTo(new BigDecimal(1))) > 0) {
                logger.warn(String.format("[%d]用电量数据异常!!!--实时总用电量[%d]-时间[%s], 数据库保存的上一条总用电量[%d]-时间[%s], 设备耗电量为[%d]，差值大于 1。" +
                                "把实时总用电量当作时间段内耗电量，设备实时总用电量记录为[%d]。",
                        devIdpk, realPower, DateUtil.dateToLongStr(realTime), lastPower, DateUtil.dateToLongStr(lastTime),
                        realPower - lastPower, realPower));

                return true;

            } else { // 认为设备没有耗电，是计算存在的小误差
                logger.warn(String.format("[%d]用电量小误差!!!--实时总用电量[%d]-时间[%s], 数据库保存的上一条总用电量[%d]-时间[%s], 设备耗电量为[%d]，差值不大于 1。" +
                                "认为时间段内耗电量为0，设备实时总用电量记录为[%d]。",
                        devIdpk, realPower, DateUtil.dateToLongStr(realTime), lastPower, DateUtil.dateToLongStr(lastTime),
                        realPower - lastPower, lastPower));
            }
        }
        return false;
    }

    /**
     * 判断设备上报数据是否异常
     * @param devIdpk
     * @param realPower
     * @param lastPower
     * @param realTime
     * @param lastTime
     * @return
     */
    private int isIllegalData2(int devIdpk, int realPower, int lastPower, Date realTime, Date lastTime) {
        if (realPower - lastPower < 0) { // 异常数据 非法数据

            // 差值大于0.01，认为用电量被重置
            if ((new BigDecimal(lastPower - realPower).compareTo(new BigDecimal(lastPower / 2))) > 0) {
                logger.warn(String.format("[%d]用电量数据异常!!!--实时总用电量[%d]-时间[%s], 数据库保存的上一条总用电量[%d]-时间[%s], 设备耗电量为[%d]，差值大于 [%d]。" +
                                "把实时总用电量当作时间段内耗电量，设备实时总用电量记录为[%d]。",
                        devIdpk, realPower, DateUtil.dateToLongStr(realTime), lastPower, DateUtil.dateToLongStr(lastTime),
                        realPower - lastPower, lastPower / 2, realPower));

                return -1;

            } else { // 认为设备没有耗电，是计算存在的小误差
                logger.warn(String.format("[%d]用电量小误差!!!--实时总用电量[%d]-时间[%s], 数据库保存的上一条总用电量[%d]-时间[%s], 设备耗电量为[%d]，差值不大于 [%d]。" +
                                "认为时间段内耗电量为0，设备实时总用电量记录为[%d]。",
                        devIdpk, realPower, DateUtil.dateToLongStr(realTime), lastPower, DateUtil.dateToLongStr(lastTime),
                        realPower - lastPower, lastPower / 2, lastPower));
                return 0;
            }
        }
        return 1;
    }

    /**
     * 比较两个时间是否是同一天
     * @param cal1
     * @param cal2
     * @return
     */
    private boolean compareDate(Calendar cal1, Calendar cal2) {

        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH)
                && cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * 创建新的一天的数据实体，并统计上一天的总用电量和总电费
     * @param lastData
     * @param tmpDay
     * @param realPower
     * @param addTime
     * @return
     */
    private UshareDeviceElectricuse createOneEntity_v20191029(UshareDeviceElectricuse lastData, Calendar tmpDay, int realPower, String addTime) {

        //开始下一天
        UshareDeviceElectricuse todayData = new UshareDeviceElectricuse();

        todayData.setDevIdpk(lastData.getDevIdpk());
        todayData.setUnitId(lastData.getUnitId());
        todayData.setDayTotalQ(0); // 当天总用电量（每次统计电量，会进行累加）
        todayData.setDayTotalFee(0); // 当天总电费（每次统计电费，会进行累加）
        todayData.setDevTotalQ(lastData.getDevTotalQ()); // 2019-10-29弃用，为了兼容老版本，暂时保留
//        todayData.setAddtime(DateUtil.strToShortDate(DateUtil.dateToShortStr(thisTime)));
        todayData.setAddtime(DateUtil.strToShortDate(addTime));
        todayData.setUpdateTime(tmpDay.getTime());
        todayData.setDevRealTotalQ(realPower); // 实时用电量
        todayData.setElYear(tmpDay.get(Calendar.YEAR));
        todayData.setElMonth(tmpDay.get(Calendar.MONTH) + 1);
        todayData.setElWeek(tmpDay.get(Calendar.WEEK_OF_YEAR));

        if (lastData.getBeforeTodayTotalQ() > 0.5) { // 用0.5而不用0，屏蔽double精度问题
            // 今天之前的总用电量做过统计，今天的"今天之前的总用电量" = 昨天的"今天之前的总用电量" + 昨天的"当天总用电量"
            todayData.setBeforeTodayTotalQ(lastData.getBeforeTodayTotalQ() + lastData.getDayTotalQ());
        } else {
            // 数据库统计今天之前所有数据的 "当天总用电量"的总和
            Double totalHistoryPower = tblndeviceparameterMapper.summationHistoryPower(lastData.getDevIdpk(), todayData.getAddtime());
            if (totalHistoryPower == null) {
                totalHistoryPower = 0D;
            }
            todayData.setBeforeTodayTotalQ(totalHistoryPower);
        }

        if (lastData.getBeforeTodayTotalFee() > 0.5) { // 用0.5而不用0，屏蔽double精度问题
            // 今天之前的总用电量做过统计，今天的"今天之前的总电费" = 昨天的"今天之前的总电费" + 昨天的"当天总电费"
            todayData.setBeforeTodayTotalFee(lastData.getBeforeTodayTotalFee() + lastData.getDayTotalFee());
        } else {
            // 数据库统计今天之前所有数据的 "当天总电费"的总和
            Double totalHistoryFee = tblndeviceparameterMapper.summationHistoryFee(lastData.getDevIdpk(), todayData.getAddtime());
            if (totalHistoryFee == null) {
                totalHistoryFee = 0D;
            }
            todayData.setBeforeTodayTotalFee(totalHistoryFee);
        }

        return todayData;
    }

    /**
     * 计算当前小时key的用电量和电费
     * @param us
     * @param ushareChargeList
     * @param key
     * @param usePower
     * @param cal
     * @param unitId
     * @param multiple
     * @param realPower
     */
    private void dealData_v20191214 (UshareDeviceElectricuse us, List<UshareCharge> ushareChargeList, int key, double usePower, Calendar cal, int unitId, int multiple, int realPower) {
        if (us == null) {
            return;
        }

        // 计算电价
        double price = computePrice_v20191214(usePower, key, ushareChargeList);
        price = price / (double) multiple;
        usePower = usePower / (double) multiple;

        us.setDayTotalQ(us.getDayTotalQ() + usePower);
        us.setDayTotalFee(us.getDayTotalFee() + price);
        us.setDevTotalQ(us.getDevTotalQ() + usePower);
        us.setUpdateTime(cal.getTime());
        us.setDevRealTotalQ(realPower);

        switch (key) {
            case 1: {
                us.setH1(usePower + us.getH1());
                break;
            }
            case 2: {
                us.setH2(usePower + us.getH2());
                break;
            }
            case 3: {
                us.setH3(usePower + us.getH3());
                break;
            }
            case 4: {
                us.setH4(usePower + us.getH4());
                break;
            }
            case 5: {
                us.setH5(usePower + us.getH5());
                break;
            }
            case 6: {
                us.setH6(usePower + us.getH6());
                break;
            }
            case 7: {
                us.setH7(usePower + us.getH7());
                break;
            }
            case 8: {
                us.setH8(usePower + us.getH8());
                break;
            }
            case 9: {
                us.setH9(usePower + us.getH9());
                break;
            }
            case 10: {
                us.setH10(usePower + us.getH10());
                break;
            }
            case 11: {
                us.setH11(usePower + us.getH11());
                break;
            }
            case 12: {
                us.setH12(usePower + us.getH12());
                break;
            }
            case 13: {
                us.setH13(usePower + us.getH13());
                break;
            }
            case 14: {
                us.setH14(usePower + us.getH14());
                break;
            }
            case 15: {
                us.setH15(usePower + us.getH15());
                break;
            }
            case 16: {
                us.setH16(usePower + us.getH16());
                break;
            }
            case 17: {
                us.setH17(usePower + us.getH17());
                break;
            }
            case 18: {
                us.setH18(usePower + us.getH18());
                break;
            }
            case 19: {
                us.setH19(usePower + us.getH19());
                break;
            }
            case 20: {
                us.setH20(usePower + us.getH20());
                break;
            }
            case 21: {
                us.setH21(usePower + us.getH21());
                break;
            }
            case 22: {
                us.setH22(usePower + us.getH22());
                break;
            }
            case 23: {
                us.setH23(usePower + us.getH23());
                break;
            }
            case 24:
            case 0: {
                us.setH24(usePower + us.getH24());
                break;
            }

        }
        //return us;
    }

    private void addNewDataInfo_v20191214(String time, int devIdpk, int unitId, int realPower, int multiple, List<UshareCharge> ushareChargeList) {

        // 设备当前上传数据的时间转成日历
        Calendar today = getCalendar(DateUtil.strToLongDate(time));

        int h = today.get(Calendar.HOUR_OF_DAY);
        int m = today.get(Calendar.MINUTE);

        Calendar cal = Calendar.getInstance();
        cal.setTime(DateUtil.strToLongDate(time));

        UshareDeviceElectricuse todayData = new UshareDeviceElectricuse();

        //todayData.setIdPk(null);
        todayData.setDevIdpk(devIdpk);
        todayData.setUnitId(unitId);
        todayData.setDevTotalQ(0);
        todayData.setUpdateTime(DateUtil.strToLongDate(time));
        todayData.setAddtime(DateUtil.strToShortDate(time));
        // 实时总用电量
        todayData.setDevRealTotalQ(realPower);
        // 今天前总用电量
        todayData.setBeforeTodayTotalQ(0);
        // 今天前总电费
        todayData.setBeforeTodayTotalFee(0);
        todayData.setElYear(today.get(Calendar.YEAR));
        todayData.setElMonth(today.get(Calendar.MONTH) + 1);
        todayData.setElWeek(today.get(Calendar.WEEK_OF_YEAR));

        dealData_v20191214(todayData, ushareChargeList, (h + 1), realPower, cal, unitId, multiple, realPower);
        tblndeviceparameterMapper.addUshareDeviceElectricuse(todayData);
    }

    /**
     * 电价计算
     * @param power 当前小时用电量
     * @param hour 当前小时
     * @param ushareChargeList 峰谷电价列表
     * @return
     */
    private double computePrice_v20191214(double power, int hour, List<UshareCharge> ushareChargeList) {

        if (ushareChargeList == null || ushareChargeList.size() == 0) {
            // 未设置电量单价
            return 0;
        }

        // 常规价格
        double defultPrice = 0;

        // 找到当前小时的峰谷电价
        for (UshareCharge ushareCharge : ushareChargeList) {

            // 判断是否是常规电价
            if (ushareCharge.getStartTime() == null && ushareCharge.getStopTime() == null) {
                defultPrice = ushareCharge.getChargeVal();
                continue;
            }

            // 判断当前小时是否在一个峰谷电价时间段内 hour 的值 1-24，所以 开始时间是 hour-1
            if (hour - 1 >= ushareCharge.getStartTime() && hour <= ushareCharge.getStopTime()) {
                return power * ushareCharge.getChargeVal();
            }
        }

        // 找不到对应的峰谷电价，则使用默认电价
        return power * defultPrice;

    }

    /**
     * 获取一个当前时间的日历
     * @param date
     * @return
     */
    private Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }
}
