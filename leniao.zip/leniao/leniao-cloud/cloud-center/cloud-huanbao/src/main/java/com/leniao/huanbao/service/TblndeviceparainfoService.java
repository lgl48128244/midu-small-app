package com.leniao.huanbao.service;

public interface TblndeviceparainfoService {

    //通过节点id查询出对应节点的阈值
    Object findValue(Integer devnodepk, Integer devidp);

}
