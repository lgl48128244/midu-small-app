package com.leniao.huanbao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.leniao.huanbao.entity.HbyProjectstatus;
import com.leniao.huanbao.mapper.HbyProjectstatusMapper;
import com.leniao.huanbao.service.HbyProjectstatusService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author liudongshuai
 * @date 2019/12/27 16:13
 * @update
 * @description
 */
@Service
public class HbyProjectstatusServiceImpl extends ServiceImpl<HbyProjectstatusMapper,HbyProjectstatus> implements HbyProjectstatusService {

    @Resource
    private HbyProjectstatusMapper hbyProjectstatusMapper;
    @Resource
    private JdbcTemplate jdbcTemplate;

    /**
     * 通过单位id查出单位运行的全部状态数据
     */
    @Override
    public HbyProjectstatus findAllByUnitId(Integer unitId,Integer runStatus) {
        //创建查询条件构造器
        QueryWrapper<HbyProjectstatus> queryWrapper = new QueryWrapper<>();
        if (runStatus==1){
            queryWrapper.lambda().eq(HbyProjectstatus::getUnitId,unitId);
            HbyProjectstatus hbyProjectstatus = hbyProjectstatusMapper.selectOne(queryWrapper);
            if (hbyProjectstatus.getProducState()>0){
                return hbyProjectstatus;
            }else {
                return null;
            }
        }else if(runStatus==2){
            queryWrapper.lambda().eq(HbyProjectstatus::getUnitId,unitId);
            HbyProjectstatus hbyProjectstatus = hbyProjectstatusMapper.selectOne(queryWrapper);
            if (hbyProjectstatus.getProducState()==0){
                return hbyProjectstatus;
            }else {
                return null;
            }
        }else{
            queryWrapper.lambda().eq(HbyProjectstatus::getUnitId,unitId);
            return hbyProjectstatusMapper.selectOne(queryWrapper);
        }
    }

    @Override
    public void updateIndustryOfUnit(Integer unitId, Integer industryId) {
        String sql = "update hby_projectstatus set industry_id = ? where unit_id = ?";
        this.jdbcTemplate.update(sql, industryId, unitId);
    }
}
