package com.leniao.huanbao.dto.ExpendStatistic;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.leniao.huanbao.utils.DoubleSerialize;
import lombok.Data;

/**
 * @program: leniao-hbcloudV1.0
 * @description: 用电量统计
 * @author: jiangdy
 * @create: 2020-01-02 14:44
 **/
@Data
public class UseEleRanking {

    /**
     * 排名 暂时未使用
     */
    private int ranking;

    private Long id;

    private Long groupId;

    private String name;

    @JsonSerialize(using = DoubleSerialize.class)
    private Double value;
}
