package com.leniao.huanbao.constant;

/**
 * @Description:    存储定时任务模块所涉及到的常量
 * @Author:         haosw
 * @CreateDate:     2019/12/23 14:10
 * @Version:        1.0
 */
public interface ScheduleConstant {

    /**
     * 环保云定时任务的 Redis key 前缀
     */
    String HBY_SCHEDULE_PREFIX = "HbySchedule:";
    /**
     * Redis key
     * 环保云定时任务的 建立了监测点的单位的设备简单信息key,与 HBY_SCHEDULE_PREFIX联合使用
     */
    String DEVICE_OF_OVERLOOK_POINT = "DevicesOfUnit";
    /**
     * Redis key
     * 原异常表中同步过的最大异常ID值的key
     */
    String MAX_RAW_WARN_ID = "MaxRawWarnID";
    /**
     * 时间区间的0分钟
     */
    int TIME_AREA_0 = 0;
    /**
     * 时间区间的20分钟
     */
    int TIME_AREA_20 = 20;
    /**
     * 时间区间的40分钟
     */
    int TIME_AREA_40 = 40;
    /**
     * 环保云监测设备使用的功率节点
     */
    String HBY_DEV_POWER_NODE_ARRAY = "PA-PB-PC";
    /**
     * 环保云监测设备使用的功率节点
     */
    String HBY_DEV_ELEMENT_NODE_ARRAY = "QA-QB-QC";

    /**
     * 修改了行业的单位数据缓存Redis key
     */
    String UNIT_INDUSTRY_UPDATE_INFO = "unitIndustryUpdateInfo";
}
