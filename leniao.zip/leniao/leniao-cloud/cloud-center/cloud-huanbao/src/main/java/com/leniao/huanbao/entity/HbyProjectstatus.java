package com.leniao.huanbao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;
@ToString
@TableName("hby_projectstatus")
public class HbyProjectstatus {
    @TableId
    private Integer unitId;

    private Long industryId;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    private Integer producState;

    private Integer isErrState;

    private Integer stopDevNum;

    private Integer lostDevNum;

    private Integer runDevNum;

    private Integer pollDevNum;

    private Integer allDeviceNum;

    private Integer conDevNum;

    private Date addtime;

    private Integer platformId;

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Long getIndustryId() {
        return industryId;
    }

    public void setIndustryId(Long industryId) {
        this.industryId = industryId;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode == null ? null : areaCode.trim();
    }

    public Integer getProducState() {
        return producState;
    }

    public void setProducState(Integer producState) {
        this.producState = producState;
    }

    public Integer getIsErrState() {
        return isErrState;
    }

    public void setIsErrState(Integer isErrState) {
        this.isErrState = isErrState;
    }

    public Integer getStopDevNum() {
        return stopDevNum;
    }

    public void setStopDevNum(Integer stopDevNum) {
        this.stopDevNum = stopDevNum;
    }

    public Integer getLostDevNum() {
        return lostDevNum;
    }

    public void setLostDevNum(Integer lostDevNum) {
        this.lostDevNum = lostDevNum;
    }

    public Integer getRunDevNum() {
        return runDevNum;
    }

    public void setRunDevNum(Integer runDevNum) {
        this.runDevNum = runDevNum;
    }

    public Integer getPollDevNum() {
        return pollDevNum;
    }

    public void setPollDevNum(Integer pollDevNum) {
        this.pollDevNum = pollDevNum;
    }

    public Integer getAllDeviceNum() {
        return allDeviceNum;
    }

    public void setAllDeviceNum(Integer allDeviceNum) {
        this.allDeviceNum = allDeviceNum;
    }

    public Integer getConDevNum() {
        return conDevNum;
    }

    public void setConDevNum(Integer conDevNum) {
        this.conDevNum = conDevNum;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }
}