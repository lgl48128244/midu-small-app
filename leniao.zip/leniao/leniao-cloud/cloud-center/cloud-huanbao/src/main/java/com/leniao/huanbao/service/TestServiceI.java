package com.leniao.huanbao.service;

import com.leniao.entity.HbyProjectErrorInfo;

public interface TestServiceI {

    HbyProjectErrorInfo defaultCache(Long param);

    HbyProjectErrorInfo redisCache1min(Long param);

    HbyProjectErrorInfo redisCache10min(Long param);

    HbyProjectErrorInfo redisCache30min(Long param);

    HbyProjectErrorInfo redisCache60min(Long param);

    HbyProjectErrorInfo getById(Long param);

    int updateById(Long param);

    void testAsync();

    void insertTx();

    void deleteTx(Long id);
}