package com.leniao.huanbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.huanbao.entity.HbyReduceplanJoinProject;
import com.leniao.huanbao.entity.HbyReduceplanJoinProjectExample;
import org.apache.ibatis.annotations.MapKey;

import java.util.List;
import java.util.Map;

public interface ReduceplanJoinProjectMapper {

    @MapKey("unitId")
    Map<Integer, HbyReduceplanJoinProject> selectByExample(Long planId);
}
