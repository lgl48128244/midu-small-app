package com.leniao.huanbao;


import com.leniao.commons.util.thrift.realValue1;
import com.leniao.commons.util.thrift.realValueByNode1;
import com.leniao.commons.util.thrift.realValueList1;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.junit.Test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class HbaseUtil {
    //====================================================================

    //外网地址
    public static final String zkAddress = "hb-proxy-pub-2zez9857h1otyjl10-001.hbase.rds.aliyuncs.com:2181,hb-proxy-pub-2zez9857h1otyjl10-002.hbase.rds.aliyuncs.com:2181,hb-proxy-pub-2zez9857h1otyjl10-003.hbase.rds.aliyuncs.com:2181";

    //public static final String zkAddress = "hb-bp1592f115xpov7gx-002.hbase.rds.aliyuncs.com:2181,hb-bp1592f115xpov7gx-001.hbase.rds.aliyuncs.com:2181,hb-bp1592f115xpov7gx-003.hbase.rds.aliyuncs.com:2181";
    //内网地址
    //public static final String zkAddress = "hb-2zez9857h1otyjl10-001.hbase.rds.aliyuncs.com:2181,hb-2zez9857h1otyjl10-002.hbase.rds.aliyuncs.com:2181,hb-2zez9857h1otyjl10-003.hbase.rds.aliyuncs.com:2181";

    public static Configuration config = null;
    public static Connection connection = null;

    public static final String TABLE_NAME = "leniao-realvar1";//表名称
    //public static final String CF_DEFAULT = "realVal";//列族
    public static final byte[] CF_DEFAULT_ARRAY = "realVal".getBytes();//列族的byte数组

    public static final byte[] QUALIFIER = "val".getBytes();//列：数值
    public static final byte[] QUALIFIER_TIME = "addtime".getBytes();//列：时间

    //======================================================================

    /**
     * 静态构造函数，创建连接
     */
    static {

        CreatConnect();
    }

    @Test
    public void test(){
        //HbaseUtil.CreatConnect();

        //String nodeArray = "CSQ";
        //String nodeArray = "CSQ-VC-NC-SC-LM-JY";
        //String nodeArray = "L1-Va-T1-Ia-Qa-Qb-Qc-Pa-Pb-Pc";
        //String nodeArray = "CSQ-IN2-BLA-ADA-RST";
        String nodeArray = "NC-SC-LM-JY-VC-CSQ-";

        List<realValueByNode1> realValueByNode1s = HbaseUtil.GetMaxSingleArrayByFilter("34578", "20180101000000", "20191217235959", nodeArray);
        System.out.println(realValueByNode1s.size());


        List<realValueList1> realValueList1s = HbaseUtil.GetListArrayByFilter("34578","20180101000000", "20191217235959",nodeArray,"100");
//        Optional<realValueList1> first = realValueList1s.stream().filter(a -> a.keyname .equals("NC") ).findFirst();
//        realValueList1 realValueList1 = first.get();
//        System.out.println(realValueList1.rows.size());

        List<realValueList1> nc = realValueList1s.stream().filter(a -> a.keyname.equals("NC")).collect(Collectors.toList());
        List<realValueList1> sc = realValueList1s.stream().filter(a -> a.keyname.equals("SC")).collect(Collectors.toList());
        List<List<realValue1>> nc1 = realValueList1s.stream().filter(a -> a.keyname.equals("NC")).map(a -> a.rows).collect(Collectors.toList());
        for (int i = 0; i < nc.size(); i++) {
            System.out.println(nc1.get(1).get(1).val);
            System.out.println(nc.get(i).rows.get(i).val);
        }

        System.out.println("123");
    }

    /**
     * 创建连接函数
     */
    public static void CreatConnect(){
        if(connection == null || connection.isClosed()){
            try {
                if(config == null){
                    config = HBaseConfiguration.create();
                    config.set("hbase.cluster.distributed", "true");
                    config.set("zookeeper.session.timeout", "300000000");
                    config.set("hbase.hregion.majorcompaction", "0");
                    config.set("hbase.regionserver.regionSplitLimit", "1");
                    config.set("dfs.client.socket-timeout", "600000000");
                    config.set("hbase.regionserver.handler.count", "20000");
                    config.set("hbase.rpc.timeout", "180000000");
                    config.set("hbase.client.scanner.timeout.period", "180000000");
                    //1G
                    config.set("hbase.client.keyvalue.maxsize", "1048576000");
                    config.set(HConstants.ZOOKEEPER_QUORUM, zkAddress);
                }
                connection = ConnectionFactory.createConnection(config);
            } catch (IOException e) {
                System.out.println("构造连接报错");
                e.printStackTrace();
            }
        }
    }

    /**
     * 关闭连接函数
     */
    public static void CloseConnect() {
        if (connection != null && !connection.isClosed()) {
            try {
                connection.close();
            } catch (IOException e) {
                System.out.println("关闭连接函数出错");
                e.printStackTrace();
            }
        }
    }

    //======================================================================

    /**
     * 获取时间信息函数
     * @return
     */
    private static String[] GetDateArray() {
        String[] BackArray = new String[2];
        Date date = new Date();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        BackArray[0] = dateFormat.format(date.getTime());

        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss");
        BackArray[1] = dateFormat1.format(date.getTime());

        return BackArray;
    }

    /**
     * 左面补齐0，字符串修改
     * @param str 要修改的字符串
     * @param strLength 补齐长度
     * @return 修改后的字符串
     */
    private static String addZeroForNum(String str, int strLength) {
        int strLen = str.length();
        StringBuffer sb = null;
        while (strLen < strLength) {
            sb = new StringBuffer();
            sb.append("0").append(str);// 左补0
            str = sb.toString();
            strLen = str.length();
        }
        return str.toUpperCase();
    }

    /**
     * rowkey前缀13个字符不一致
     * @return 特定的realValue对象
     */
    private static realValue1 GetNullrealValue(){
        realValue1 r = new realValue1();
        r.setVal("00.0");
        r.setAddtime("1200-01-01 00:00:01");
        return r;
    }

    //======================================================================

    /**
     * 获取指定表所有数据函数
     * @return 表中所有的数据
     */
    private static List<realValue1>  GetALLListInner(){
        List<realValue1> LI = new ArrayList<realValue1>();
        try {

            Table table = connection.getTable(TableName.valueOf(TABLE_NAME));
            try {
                ResultScanner rs = table.getScanner(new Scan());
                for (Result r1 : rs) {
                    realValue1 R= new realValue1();
                    for(Cell cell:r1.rawCells()){
                        if(cell.getQualifierLength() == 3)   {
                            R.setVal(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                        else{
                            R.setAddtime(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                    }
                    LI.add(R);
                }
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (table != null) {
                    table.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LI = null;
        }
        finally {
            return LI;
        }
    }

    /**
     * 根据起始和结束rowkey。查找对应的数据
     * @param beginrowkey 起始rowkey
     * @param endrowkey 结束rowkey
     * @return 按条件查找到的信息
     */
    private static List<realValue1>  GetListBySearch(String beginrowkey, String endrowkey){
        List<realValue1> LI = new ArrayList<realValue1>();
        try {
            Table table = connection.getTable(TableName.valueOf(TABLE_NAME));
            try {

                Scan scan = new Scan();
                scan.setStartRow(beginrowkey.getBytes());//开始的行集
                scan.setStopRow(endrowkey.getBytes());//结束的行集

                ResultScanner rs = table.getScanner(scan);
                for (Result r1 : rs) {
                    realValue1 R= new realValue1();
                    for(Cell cell:r1.rawCells()){
                        if(cell.getQualifierLength() == 3){
                            R.setVal(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                        else{
                            R.setAddtime(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                    }
                    LI.add(R);
                }
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (table != null) table.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            LI = null;
        }
        finally {
            return LI;
        }
    }

    /**
     * 根据起始和结束rowkey。查找对应的数据，通过筛选器
     * @param beginrowkey 起始rowkey
     * @param endrowkey 结束rowkey
     * @return 按条件查找到的信息
     */
    private static List<realValue1>  GetListBySearchByFilter(String beginrowkey, String endrowkey){
        List<realValue1> LI = new ArrayList<realValue1>();
        try {
            Table table = connection.getTable(TableName.valueOf(TABLE_NAME));
            try {
                String Prefix0 = beginrowkey.substring(0,13);
                byte[] beginrowkeyarray = beginrowkey.getBytes();
                byte[] endrowkeyarray = endrowkey.getBytes();

                FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);

                //前缀为特定的前13个字符
                PrefixFilter filter1 = new PrefixFilter((Prefix0).getBytes());
                filterList.addFilter(filter1);

                // RowKey最小日期过滤
                RowFilter minRowFilter = new RowFilter(CompareFilter.CompareOp.GREATER_OR_EQUAL,new BinaryComparator(beginrowkeyarray));
                filterList.addFilter(minRowFilter);

                // RowKey最大日期过滤
                RowFilter maxRowFilter = new RowFilter(CompareFilter.CompareOp.LESS_OR_EQUAL,new BinaryComparator(endrowkeyarray));
                filterList.addFilter(maxRowFilter);


                Scan scan = new Scan();

                //scan.setMaxVersions();//获取版本个数
                scan.setFilter(filterList);//过滤器

                scan.setStartRow(beginrowkeyarray);//开始的行集
                scan.setStopRow(endrowkeyarray);//结束的行集

                scan.setCaching(700);
                scan.setCacheBlocks(false);

                ResultScanner rs = table.getScanner(scan);
                for (Result r1 : rs) {
                    realValue1 R= new realValue1();
                    for(Cell cell:r1.rawCells()){
                        if(cell.getQualifierLength() == 3){
                            R.setVal(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                        else{
                            R.setAddtime(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                    }
                    LI.add(R);
                }
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (table != null) {
                    table.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LI = null;
        }
        finally {
            return LI;
        }
    }

    /**
     * 根据起始和结束rowkey。查找对应的数据，通过筛选器,获取最大的一行
     * @param beginrowkey 起始rowkey
     * @param endrowkey 结束rowkey
     * @return 按条件查找到的信息
     */
    private static List<realValue1>  GetListBySearchByFilterSingle(String beginrowkey, String endrowkey){
        List<realValue1> LI = new ArrayList<realValue1>();
        try {
            Table table = connection.getTable(TableName.valueOf(TABLE_NAME));
            try {
                String Prefix0 = beginrowkey.substring(0,13);
                byte[] beginrowkeyarray = beginrowkey.getBytes();
                byte[] endrowkeyarray = endrowkey.getBytes();

                FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);

                //前缀为特定的前13个字符
                PrefixFilter filter1 = new PrefixFilter((Prefix0).getBytes());
                filterList.addFilter(filter1);

                // RowKey最小日期过滤
                RowFilter minRowFilter = new RowFilter(CompareFilter.CompareOp.GREATER_OR_EQUAL,new BinaryComparator(beginrowkeyarray));
                filterList.addFilter(minRowFilter);

                // RowKey最大日期过滤
                RowFilter maxRowFilter = new RowFilter(CompareFilter.CompareOp.LESS_OR_EQUAL,new BinaryComparator(endrowkeyarray));
                filterList.addFilter(maxRowFilter);


                Scan scan = new Scan();

                //scan.setMaxVersions();//获取版本个数
                scan.setFilter(filterList);//过滤器

                scan.setStartRow(endrowkeyarray);//开始的行集,反转
                scan.setStopRow(beginrowkeyarray);//结束的行集，反转

                scan.setCaching(700);
                scan.setCacheBlocks(false);

                scan.setReversed(true);
                ResultScanner rs = table.getScanner(scan);

                //==========================================

                Result r1 = rs.next();
                if(r1!=null){
                    realValue1 R= new realValue1();
                    for(Cell cell:r1.rawCells()){
                        if(cell.getQualifierLength() == 3){
                            R.setVal(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                        else{
                            R.setAddtime(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                    }
                    LI.add(R);
                }

                //==========================================

                /*
                for (Result r1 : rs) {
                    realValue R= new realValue();
                    for(Cell cell:r1.rawCells()){
                        if(cell.getQualifierLength() == 3){
                            R.setVal(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                        else{
                            R.setAddtime(Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                        }
                    }
                    LI.add(R);
                }
                */

                //==========================================

                rs.close();

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (table != null) {
                    table.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LI = null;
        }
        finally {
            return LI;
        }
    }

    //======================================================================

    /**
     * 以数组的形式添加多行数据
     * @param ROWKEY ROWKEY数组
     * @param ValueArray 数据数组
     * @param Time 时间数组
     * @return 添加结果
     */
    private static int AddRowArray(String[] ROWKEY, String[] ValueArray,String[] Time) {
        int BackID = 0;
        try {
            Table table = connection.getTable(TableName.valueOf(TABLE_NAME));
            try {
                byte[] TimeArray = Time[0].getBytes();
                List<Put> lists = new ArrayList<Put>();
                for(int i=0;i<ROWKEY.length;i++){
                    Put put = new Put(ROWKEY[i].getBytes());
                    put.addColumn(CF_DEFAULT_ARRAY, QUALIFIER, ValueArray[i].getBytes());
                    put.addColumn(CF_DEFAULT_ARRAY, QUALIFIER_TIME, TimeArray);
                    lists.add(put);
                }
                table.put(lists);
            } catch (Exception e) {
                BackID = 1;
                e.printStackTrace();
            } finally {
                if (table != null) {
                    table.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            BackID = 2;
        }
        finally {
            return BackID;
        }
    }

    //======================================================================


    /**
     * 按开始rowkey和结束rowkey条件查询
     * @param beginrowkey 开始rowkey
     * @param endrowkey 结束rowkey
     * @return 查询结果列表
     */
    public static List<realValue1> GetList(String beginrowkey, String endrowkey){
        String Prefix0 = beginrowkey.substring(0,13);
        String Prefix1 = endrowkey.substring(0,13);
        if(Prefix0.equals(Prefix1)){
            return GetListBySearch(beginrowkey,endrowkey);
        }
        else {
            List<realValue1> LI = new ArrayList<realValue1>();
            LI.add(GetNullrealValue());
            return LI;
        }
    }

    /**
     * 按开始rowkey和结束rowkey条件查询，并返回指定数量的集合
     * @param beginrowkey 开始rowkey
     * @param endrowkey 结束rowkey
     * @param rowcount 指定数量
     * @return 查询结果列表
     */
    public static List<realValue1> GetList(String beginrowkey,String endrowkey,String rowcount){
        List<realValue1> List = GetListBySearch(beginrowkey,endrowkey);

        if(List == null || List.size()==0){
            return List;
        }

        int _rowcount = 0;
        int ListSize = List.size();
        try {
            _rowcount = Integer.parseInt(rowcount);
        } catch (NumberFormatException e) {
            _rowcount = ListSize;
        }

        if(_rowcount >= ListSize){
            return List;
        }
        else{

            int AddPoint =  (int) Math.ceil((double) ListSize / _rowcount);
            List<realValue1> InnerList = new ArrayList<realValue1>();
            int index = 0;

            while(index < ListSize){
                InnerList.add(List.get(index));
                index = index + AddPoint;
            }

            int _count = InnerList.size();
            if(_count < _rowcount){
                InnerList.add(List.get(ListSize -1));
            }
            else if(_count == _rowcount){
                InnerList.set(_count - 1,List.get(ListSize -1));
            }

            List.clear();
            return InnerList;
        }
    }

    //====================================================================

    /**
     * 按开始rowkey和结束rowkey条件查询，使用过滤器
     * @param beginrowkey 开始rowkey
     * @param endrowkey 结束rowkey
     * @return 查询结果列表
     */
    public static List<realValue1> GetListByFilter(String beginrowkey,String endrowkey){

        String Prefix0 = beginrowkey.substring(0,13);
        String Prefix1 = endrowkey.substring(0,13);
        if(Prefix0.equals(Prefix1)){
            return GetListBySearchByFilter(beginrowkey,endrowkey);
        }
        else {
            List<realValue1> LI = new ArrayList<realValue1>();
            LI.add(GetNullrealValue());
            return LI;
        }
    }

    /**
     * 按开始rowkey和结束rowkey条件查询，使用过滤器
     * @param beginrowkey 开始rowkey
     * @param endrowkey 结束rowkey
     * @param rowcount 指定数量
     * @return 查询结果列表
     */
    public static List<realValue1> GetListByFilter(String beginrowkey,String endrowkey,String rowcount){
        List<realValue1> List = GetListBySearchByFilter(beginrowkey,endrowkey);

        if(List == null || List.size()==0){
            return List;
        }

        int _rowcount = 0;
        int ListSize = List.size();
        try {
            _rowcount = Integer.parseInt(rowcount);
        } catch (NumberFormatException e) {
            _rowcount = ListSize;
        }

        if(_rowcount >= ListSize){
            return List;
        }
        else{

            int AddPoint =  (int) Math.ceil((double) ListSize / _rowcount);
            List<realValue1> InnerList = new ArrayList<realValue1>();
            int index = 0;

            while(index < ListSize){
                InnerList.add(List.get(index));
                index = index + AddPoint;
            }

            int _count = InnerList.size();
            if(_count < _rowcount){
                InnerList.add(List.get(ListSize -1));
            }
            else if(_count == _rowcount){
                InnerList.set(_count - 1,List.get(ListSize -1));
            }

            List.clear();
            return InnerList;
        }
    }

    //==================================================================

    /**
     * 添加实时数值记录
     * @param ID 设备关键字
     * //@param Valuelist 数值字符串，竖线分割
     * @param NameList 回路号字符串，竖线分割
     * @return 添加结果，0为正常
     */
    public static int AddRow(String ID,String ValueList,String NameList){
        int BackID = 0;
        int IDLength = ID.length();
        if(IDLength >10){
            BackID = 3;//数字长度超过10
            return BackID;
        }
        else{
            ID = addZeroForNum(ID,10);
        }
        String[] ValArray = ValueList.split("\\|");
        String[] NameArray = NameList.split("\\|");

        if(ValArray.length != NameArray.length){
            BackID = 4;//数值数组和名称数组长度不一致
            return BackID;
        }

        for(int i=0;i<NameArray.length;i++){
            if(NameArray[i].length()<3){
                NameArray[i] = addZeroForNum(NameArray[i],3);
            }
        }

        String[] Time = GetDateArray();
        String[] RowKey = new String[ValArray.length];
        for(int i=0;i<ValArray.length;i++ ){
            RowKey[i] = ID + NameArray[i] + Time[1];
        }

        return AddRowArray(RowKey,ValArray,Time);
    }

    /**
     * 添加实时数值记录
     * @param ID 设备关键字
     * //@param Valuelist 数值字符串，竖线分割
     * @param NameList 回路号字符串，竖线分割
     * @return 添加结果，0为正常
     */
    public static int AddRow(String ID,String ValueList,String NameList, Date date){
        int BackID = 0;
        int IDLength = ID.length();
        if(IDLength >10){
            BackID = 3;//数字长度超过10
            return BackID;
        }
        else{
            ID = addZeroForNum(ID,10);
        }
        String[] ValArray = ValueList.split("\\|");
        String[] NameArray = NameList.split("\\|");

        if(ValArray.length != NameArray.length){
            BackID = 4;//数值数组和名称数组长度不一致
            return BackID;
        }

        for(int i=0;i<NameArray.length;i++){
            if(NameArray[i].length()<3){
                NameArray[i] = addZeroForNum(NameArray[i],3);
            }
        }

        String[] Time = GetDateArray2(date);
        String[] RowKey = new String[ValArray.length];
        for(int i=0;i<ValArray.length;i++ ){
            RowKey[i] = ID + NameArray[i] + Time[1];
        }

        return AddRowArray(RowKey,ValArray,Time);
    }
    /**
     * 获取时间信息函数
     * @return
     */
    private static String[] GetDateArray2(Date date) {
        String[] BackArray = new String[2];
        //Date date = new Date();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        BackArray[0] = dateFormat.format(date.getTime());

        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss");
        BackArray[1] = dateFormat1.format(date.getTime());

        return BackArray;
    }

    //===================================================================

    /**
     * 按开始rowkey和结束rowkey条件查询，返回最大的一行
     * @param beginrowkey 开始rowkey
     * @param endrowkey 结束rowkey
     * @return 查询结果列表
     */
    public static List<realValue1> GetMaxSingleByFilter(String beginrowkey,String endrowkey){
        String Prefix0 = beginrowkey.substring(0,13);
        String Prefix1 = endrowkey.substring(0,13);
        if(Prefix0.equals(Prefix1)){
            List<realValue1> List =  GetListBySearchByFilterSingle(beginrowkey,endrowkey);
            if(List == null || List.size()==0){
                return List;
            }
            else{
                realValue1 r = List.get(0);
                realValue1 r1 = new realValue1();
                r1.setVal(r.getVal());
                r1.setAddtime(r.getAddtime());
                List.clear();

                List<realValue1> LI = new ArrayList<realValue1>();
                LI.add(r1);
                return LI;
            }
        }
        else {
            List<realValue1> LI = new ArrayList<realValue1>();
            LI.add(GetNullrealValue());
            return LI;
        }
    }

    //===================================================================

    /**
     * 批量返回回路号数组的最大行信息
     * @param Code 设备编码，转为10位
     * @param BeginTime 开始时间，标准格式
     * @param EndTime 结束时间，标准格式
     * @param NodeArray 回路号字符串，- 横线拆分
     * @return 结果列表
     */
    public static List<realValueByNode1> GetMaxSingleArrayByFilter(String Code, String BeginTime, String EndTime, String NodeArray){
        String[] NodeValueArray = NodeArray.split("-");
        List<realValueByNode1> LI = new ArrayList<realValueByNode1>();
        realValue1 r = GetNullrealValue();
        String code1 = addZeroForNum(Code,10);

        for(int i=0;i<NodeValueArray.length;i++){
            String NodeValue = addZeroForNum(NodeValueArray[i],3);
            String beginrowkey = code1 + NodeValue + BeginTime;
            String endrowkey = code1 + NodeValue + EndTime;

            realValueByNode1 rn = new realValueByNode1();
            List<realValue1> List =  GetListBySearchByFilterSingle(beginrowkey,endrowkey);
            if(List == null || List.size()==0){
                rn.setVal(r.getVal());
                rn.setAddtime(r.getAddtime());
                rn.setNode(NodeValueArray[i]);
            }
            else{
                realValue1 r1 = List.get(0);
                rn.setVal(r1.getVal());
                rn.setAddtime(r1.getAddtime());
                rn.setNode(NodeValueArray[i]);
            }
            List.clear();
            LI.add(rn);
        }

        return LI;
    }

    //===================================================================

    /**
     * 批量返回指定行数的集合
     * @param Code 设备编码
     * @param BeginTime 开始时间
     * @param EndTime 结束时间
     * @param NodeArray 回路号集合
     * @param Number 要选取的行数
     * @return 返回的集合
     */
    public static List<realValueList1> GetListArrayByFilter(String Code, String BeginTime, String EndTime, String NodeArray, String Number){
        String[] NodeValueArray = NodeArray.split("-");
        List<realValueList1> LI = new ArrayList<realValueList1>();
        String code1 = addZeroForNum(Code,10);

        for(int i=0;i<NodeValueArray.length;i++){
            String NodeValue = addZeroForNum(NodeValueArray[i],3);
            String beginrowkey = code1 + NodeValue + BeginTime;
            String endrowkey = code1 + NodeValue + EndTime;

            realValueList1 rn = new realValueList1();
            List<realValue1> List =  GetListByFilter(beginrowkey,endrowkey,Number);

            rn.setRows(List);
            rn.setKeyname(NodeValueArray[i].toUpperCase());

            LI.add(rn);
        }

        return LI;
    }

}
