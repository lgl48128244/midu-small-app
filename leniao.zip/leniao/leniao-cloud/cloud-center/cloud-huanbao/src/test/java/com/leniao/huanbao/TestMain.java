package com.leniao.huanbao;


import com.leniao.commons.config.SnowflakeConfig;
import com.leniao.huanbao.utils.DevUtils;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;


public class TestMain {

    @Test
    public void test() {
        /*List<String> list1 = new ArrayList<>();
        list1.add("1");
        list1.add("2");
        List<String> list2 = new ArrayList<>();
        list2.add("1");
        list2.add("3");

        System.out.println(DevUtils.getRepetition(list1,list2));

        final Duration duration = Duration.ofDays(365);
        final long seconds = duration.getSeconds();
        System.out.println(seconds);*/

        System.out.println(new SnowflakeConfig().nextId());
        //45227268271767552
        //45228785506713600
        //45229078894084096
        //45244792661082112
        //45245242454048768
        //45255662774517760
        //45256229181718528
        //45256498321817600
        //45256812726845440
        //45260450903883776
        //45260699353481216
        //45260904413003776
        //45261120902004736
    }

    public static void main(String[] args) {
//        Integer aaa = 0;
//        Integer bbb = 11;
//        Double ccc = 0D;
//        System.out.println(ccc);
//        System.out.println(ccc==0);
//
//        System.out.println(Math.sqrt(aaa));
//        System.out.println(bbb/aaa);
        Double aaa = 1111.67456;

        System.out.println(new BigDecimal(aaa).setScale(1, RoundingMode.DOWN));
    }
}
