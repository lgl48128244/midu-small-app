package com.leniao.huanbao;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.CompareOperator;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.PageFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.ValueFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DeleteData {
    //外网地址
    public static final String zkAddress = "hb-proxy-pub-2zez9857h1otyjl10-001.hbase.rds.aliyuncs.com:2181,hb-proxy-pub-2zez9857h1otyjl10-002.hbase.rds.aliyuncs.com:2181,hb-proxy-pub-2zez9857h1otyjl10-003.hbase.rds.aliyuncs.com:2181";

    public static void main(String[] args) throws IOException {

        Configuration config = HBaseConfiguration.create();
        config.set("hbase.cluster.distributed", "true");
        config.set("zookeeper.session.timeout", "300000000");
        config.set("hbase.hregion.majorcompaction", "0");
        config.set("hbase.regionserver.regionSplitLimit", "1");
        config.set("dfs.client.socket-timeout", "600000000");
        config.set("hbase.regionserver.handler.count", "20000");
        config.set("hbase.rpc.timeout", "180000000");
        config.set("hbase.client.scanner.timeout.period", "180000000");
        config.set(HConstants.ZOOKEEPER_QUORUM, zkAddress);

        FilterList filterList = new FilterList();
//        Filter filter = new RowFilter(CompareOperator.LESS_OR_EQUAL, new RegexStringComparator("20170101"));
//        filterList.addFilter(filter);
        PageFilter pageFilter = new PageFilter(200);
        filterList.addFilter(pageFilter);
        ValueFilter valueFilter = new ValueFilter(CompareOperator.EQUAL, new RegexStringComparator("2018-12-01 00"));
        filterList.addFilter(valueFilter);
//        Filter timestampsFilter = new TimestampsFilter(Lists.newArrayList(1576812649424L, 1575121814200L), true);
//        filterList.addFilter(timestampsFilter);
        Scan scan = new Scan();
        scan.setFilter(filterList);
//        scan.setLimit(20);
        scan.setCaching(2000);
        scan.setMaxResultSize(2000);
        try (Connection connection = ConnectionFactory.createConnection(config);
//             Table table = connection.getTable(TableName.valueOf("mytable"));
             Table table = connection.getTable(TableName.valueOf("leniao-realvar1"));
             ResultScanner scanner = table.getScanner(scan)) {
            List<Delete> deleteList = new ArrayList<>();
            for (Result res : scanner) {
                System.out.println(new String(res.getRow()) + "\t" + new String(res.value()));
                deleteList.add(new Delete(res.getRow()));
            }
            table.delete(deleteList);
            System.out.println(deleteList.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}