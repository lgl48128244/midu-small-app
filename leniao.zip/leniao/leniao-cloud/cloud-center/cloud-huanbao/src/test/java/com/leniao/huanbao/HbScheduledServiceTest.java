package com.leniao.huanbao;

public class HbScheduledServiceTest extends BaseTest {
}
