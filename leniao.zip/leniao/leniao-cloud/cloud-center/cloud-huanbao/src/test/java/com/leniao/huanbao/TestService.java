package com.leniao.huanbao;

import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.leniao.commons.AbstractOperation;
import com.leniao.commons.util.SpringUtils;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.entity.HbyProjectErrorInfoExample;
import com.leniao.huanbao.entity.HbyDevalTimeStatus;
import com.leniao.huanbao.entity.HbyDevalTimeStatusExample;
import com.leniao.huanbao.mapper.HbyDevalTimeStatusMapper;
import com.leniao.huanbao.service.TestServiceI;
import com.leniao.mapper.BussinessExMapper;
import com.leniao.mapper.HbyProjectErrorInfoMapper;
import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.service.HbyProjectErrorInfoService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestService extends BaseTest {

    @Resource
    private Environment environment;

    @Resource
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @Before
    public void before() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    public void test() {
        System.out.println(environment);
    }

    @Test
    public void test1() {
        //调用接口，传入添加的用户参数
      /*  mockMvc.perform(MockMvcRequestBuilders.get("/style/listStyleById")
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("")
                .andDo(MockMvcResultHandlers.print());*/
    }

    @Resource
    private DataSource dataSource;

    @Test
    public void test3() {

        System.out.println("数据源>>>>>>" + dataSource.getClass());

        DruidDataSource druidDataSource = (DruidDataSource) dataSource;
        System.out.println("druidDataSource 数据源最大连接数：" + druidDataSource.getMaxActive());
        System.out.println("druidDataSource 数据源初始化连接数：" + druidDataSource.getInitialSize());

    }

    @Test
    public void test4() {
//        util.hashOperations.put("hash","hashmap","value");
//        Object o = util.hashOperations.get("hash", "hashmap");
        List<String> keys = AbstractOperation.keys("*", 100);
//        Set<String> keys = redisTemplate.keys("*");

        keys.forEach(System.out::print);

    }

    @Test
    public void test5() {
        RedisTemplate bean = SpringUtils.getBean("redisTemplate", RedisTemplate.class);
        System.out.println(bean);
    }

    @Resource
    private TestServiceI testService;


    @Test
    public void test7() {
        DruidDataSource druidDataSource = (DruidDataSource) dataSource;
        int maxActive = druidDataSource.getMaxActive();
        int initialSize = druidDataSource.getInitialSize();
        int minIdle = druidDataSource.getMinIdle();
        long maxEvictableIdleTimeMillis = druidDataSource.getMaxEvictableIdleTimeMillis();
        System.out.println(maxActive);
        System.out.println(initialSize);
        System.out.println(minIdle);
        System.out.println(maxEvictableIdleTimeMillis);
        String url = druidDataSource.getUrl();
        System.out.println(url);
        String password = druidDataSource.getPassword();
        System.out.println(password);
    }

    @Resource
    private HbyProjectErrorInfoMapper hbyProjectErrorInfoMapper;

    @Resource
    private HbyDevalTimeStatusMapper hbyDevalTimeStatusMapper;

    @Test
    public void test10() {

        Page<HbyProjectErrorInfo> page = new Page<>(1, 5);
        Page<HbyProjectErrorInfo> selectPage = hbyProjectErrorInfoMapper.selectPage(page, null);
        List<HbyProjectErrorInfo> records = selectPage.getRecords();
        records.forEach(System.out::println);

        PageHelper.startPage(1, 4);
        List<HbyProjectErrorInfo> hbyProjectErrorInfos = hbyProjectErrorInfoMapper.selectByExample(new HbyProjectErrorInfoExample());
        hbyProjectErrorInfos.forEach(System.out::println);

    }

    @Test
    public void test11(){
        HbyDevalTimeStatusExample example = new HbyDevalTimeStatusExample();
        example.createCriteria().andIdEqualTo(11111111111111111L);
        HbyDevalTimeStatus hbyDevalTimeStatus = hbyDevalTimeStatusMapper.selectByExample(example).get(0);
        System.out.println(hbyDevalTimeStatus);
    }

    @Resource
    private BussinessExMapper bussinessExMapper;

    @Resource
    private HbyProjectErrorInfoService hbyProjectErrorInfoService;

    @Test
    public void test13(){
        com.leniao.model.vo.Page page = new com.leniao.model.vo.Page();
        List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> businessExStatisticsAgencyLists = bussinessExMapper.selectErrorStatisticsAgencyList(page);
        businessExStatisticsAgencyLists.forEach(System.out::println);
    }

    @Test
    public void test14(){
        String sql = "update test set b =:status where a in (:ids)";
        Map<String, Object> params = new HashMap<>(2);
        params.put("status", 0);
        params.put("ids", Lists.newArrayList(2,3,4));
        namedParameterJdbcTemplate.update(sql, params);
    }

    @Test
    public void test15(){
        final BaseBusinessExDTO.BusinessExSearchDetail businessExSearchDetail = hbyProjectErrorInfoService.selectErrorSearchDetail(155L);
        System.out.println(businessExSearchDetail);
    }
}