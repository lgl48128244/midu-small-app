package com.leniao.commons;

import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.baidu.unbiz.fluentvalidator.Result;
import com.baidu.unbiz.fluentvalidator.ResultCollectors;
import com.baidu.unbiz.fluentvalidator.jsr303.HibernateSupportedValidator;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.ResultEcho;
import com.leniao.model.vo.UserInfo;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Validator;

/**
 * BaseController
 *
 * @author guoliang.li
 * @description TODO 基础控制器
 */
public abstract class BaseController extends AbstractOperation {

    @Resource
    protected Validator validator;

    @Resource
    protected HttpServletRequest request;

    /**
     * 参数校验
     */
    protected <T> void checkArgs(T t) {
        Result result = FluentValidator.checkAll()
                .on(t, new HibernateSupportedValidator<T>().setHiberanteValidator(validator)).doValidate()
                .result(ResultCollectors.toSimple());
        if (!result.isSuccess()) {
            throw new CloudException(CloudErrorCode.PARAM_INVALID, result.getErrors().toString());
        }
    }

    protected UserInfo getUserInfo() {
        return GlobalConstant.getUserInfo();
    }

    /**
     * 渲染成功数据（带数据）
     *
     * @return result
     */
    protected ResultEcho renderResult() {
        return new ResultEcho();
    }

    /**
     * 渲染成功数据（带数据）
     *
     * @param obj 需要返回的对象
     * @return result
     */
    protected ResultEcho renderResult(Object obj) {
        return new ResultEcho(obj);
    }

    /**
     * 渲染成功数据（带数据）
     *
     * @param obj     需要返回的对象
     * @param status  状态码
     * @param message 消息
     * @return result
     */
    protected ResultEcho renderResult(Object obj, int status, String message) {
        return new ResultEcho(obj, status, message);
    }
}