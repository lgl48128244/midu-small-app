package com.leniao.commons.config;

import com.leniao.commons.interceptor.AccessTokenInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

/**
 * MVC全局配置
 *
 * @author guoliang.li
 */
@Configuration
@Order(0)
public class MvcConfig implements WebMvcConfigurer {

    @Resource
    private AccessTokenInterceptor accessTokenInterceptor;

    /**
     * MVC ViewControllerRegistry
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
//        registry.addRedirectViewController("/", "/swagger-ui.html");
        registry.addRedirectViewController("/", "/server/health");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(accessTokenInterceptor)
                .addPathPatterns("/**")
                .order(0)
                .excludePathPatterns("/", "/test/**", "/server/health", "/druid/**");
    }
}