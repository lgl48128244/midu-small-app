package com.leniao.commons.config;

import com.leniao.commons.AppServerParams;
import com.leniao.commons.util.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.web.context.WebServerInitializedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Twitter的Snowflake 算法<br>
 * 分布式系统中，有一些需要使用全局唯一ID的场景，有些时候我们希望能使用一种简单一些的ID，并且希望ID能够按照时间有序生成。
 * <p>
 * <p>
 * snowflake的结构如下(每部分用-分开):<br>
 *
 * <pre>
 * 0 - 0000000000 0000000000 0000000000 0000000000 0 - 00000 - 00000 - 000000000000
 * </pre>
 * <p>
 * 第一位为未使用，接下来的41位为毫秒级时间(41位的长度可以使用69年)<br>
 * 然后是5位datacenterId和5位workerId(10位的长度最多支持部署1024个节点）<br>
 * 最后12位是毫秒内的计数（12位的计数顺序号支持每个节点每毫秒产生4096个ID序号）
 * <p>
 * <p>
 * 参考：http://www.cnblogs.com/relucent/p/4955340.html
 * <p>
 * java edition of Twitter <b>Snowflake</b>, a network service for generating
 * unique ID numbers at high scale with some simple guarantees.
 * <p>
 * https://github.com/twitter/snowflake
 *
 * @author guoliang.li
 * @description ID唯一生成器
 */
@Component
public class SnowflakeConfig implements ApplicationListener<WebServerInitializedEvent> {

    @Resource
    private AppServerParams appServerParams;

    private int serverPort;

    private long workerId;

    private long datacenterId;

    private long sequence = 0L;

    private long workerIdBits = 5L;
    /**
     * 业务线id左移位数
     */
    private long datacenterIdBits = 5L;
    /**
     * 最大支持机器节点数0~31，一共32个
     */
    private long maxWorkerId = ~(-1L << workerIdBits);
    /**
     * 最大支持数据中心节点数0~31，一共32个
     */
    private long maxDatacenterId = ~(-1L << datacenterIdBits);
    /**
     * 序列号12位
     */
    private long sequenceBits = 12L;

    private long workerIdShift = sequenceBits;
    private long datacenterIdShift = sequenceBits + workerIdBits;
    private long timestampLeftShift = sequenceBits + workerIdBits + datacenterIdBits;
    private long sequenceMask = ~(-1L << sequenceBits);

    private long lastTimestamp = -1L;

    private int serverCode;

    @Override
    public void onApplicationEvent(@NonNull WebServerInitializedEvent event) {
        this.serverPort = event.getWebServer().getPort();
    }

    @PostConstruct
    public void init() {
        // sanity check for workerId
        if (workerId > maxWorkerId || workerId < 0) {
            throw new IllegalArgumentException(String.format("worker Id can't be greater than %d or less than 0",
                    maxWorkerId));
        }
        if (datacenterId > maxDatacenterId || datacenterId < 0) {
            throw new IllegalArgumentException(String.format("datacenter Id can't be greater than %d or less than 0",
                    maxDatacenterId));
        }

        String appName = appServerParams.getAppName();
        if (StringUtils.isBlank(appName)) {
            throw new NullPointerException("[" + appName + "] not found");
        }

        EnumUtils.ServerName serverName = EnumUtils.ServerName.valueOf(appName.toUpperCase());
        this.datacenterId = this.serverCode = serverName.getCode();
        this.workerId = this.initWorkerId();
    }

    private long initWorkerId() {
        InetAddress address;
        try {
            address = InetAddress.getLocalHost();
        } catch (final UnknownHostException e) {
            throw new IllegalStateException("Cannot get LocalHost InetAddress, please check your network!");
        }
        byte[] ipAddressByteArray = address.getAddress();
        long workerId = 0L;
        // IPV4
        if (ipAddressByteArray.length == 4) {
            for (byte byteNum : ipAddressByteArray) {
                workerId += byteNum & 0xFF;
            }
            // IPV6
        } else if (ipAddressByteArray.length == 16) {
            for (byte byteNum : ipAddressByteArray) {
                workerId += byteNum & 0B111111;
            }
        } else {
            throw new IllegalStateException("Bad LocalHost InetAddress, please check your network!");
        }
        return workerId;
    }

    /**
     * 将端口号位数相加
     *
     * @param serverPort 应用端口号
     * @return 结果集
     */
    private int getServerPortSum(int serverPort) {
        int sum = 0;
        while (serverPort != 0) {
            sum += serverPort % 10;
            serverPort /= 10;
        }
        return sum;
    }

    /**
     * 全局唯一ID
     *
     * @return 结果集
     */
    public synchronized Long nextId() {
        //只执行一次
        if (this.datacenterId == this.serverCode) {
            this.datacenterId = this.getServerPortSum(this.serverPort) + this.serverCode;
        }

        long timestamp = timeGen();

        if (timestamp < lastTimestamp) {
            throw new RuntimeException(String.format(
                    "Clock moved backwards.  Refusing to generate id for %d milliseconds", lastTimestamp - timestamp));
        }

        /*if (lastTimestamp == timestamp) {
            sequence = (sequence + 1) & sequenceMask;
            if (sequence == 0) {
                timestamp = tilNextMillis(lastTimestamp);
            }
        } else {
            sequence = 0L;
        }*/
        /**
         * 加入时间回拨处理 ------------------------------------
         */
        //如果是同一时间生成的，则进行毫秒内序列
        if (timestamp == lastTimestamp) {
            // 相同毫秒内序列号自增
            sequence = (sequence + 1) & sequenceMask;
            //毫秒内序列溢出
            if (sequence == 0) {
                //阻塞到下一个毫秒,获得新的时间戳
                //防止重复阻塞出现
                timestamp = tilNextMillis(lastTimestamp-1);
            }
        } else {
            // 不同毫秒内，序列号置为 basicSequence
            sequence = sequenceBits;
        }


        //指定时间戳起点
        long twepoch = 1568450102267L;

        return ((timestamp - twepoch) << timestampLeftShift) | (datacenterId << datacenterIdShift)
                | (workerId << workerIdShift) | sequence;
    }

    private long tilNextMillis(long lastTimestamp) {
        long timestamp = timeGen();
        while (timestamp <= lastTimestamp) {
            timestamp = timeGen();
        }
        return timestamp;
    }

    private long timeGen() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return System.currentTimeMillis();
    }
}