package com.leniao.commons.exception;

import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * @author guoliang.li
 */
public class CloudException extends RuntimeException {

    private CloudErrorCode ec;
    private String exceptionErrorMsg;

    public CloudException(CloudErrorCode ec) {
        super(ec.getCode() + " " + ec.getMsg());
        this.ec = ec;
    }

    public CloudException(CloudErrorCode ec, Exception e) {
        super(ec.getCode() + " " + ec.getMsg(), e);
        this.ec = ec;
        this.exceptionErrorMsg = ExceptionUtils.getStackTrace(e);
    }

    public CloudException(CloudErrorCode ec, String errorMsg) {
        super(ec.getCode() + " " + errorMsg);
        this.ec = ec;
        this.exceptionErrorMsg = errorMsg;
    }

    public CloudErrorCode getEc() {
        return ec;
    }

    public void setEc(CloudErrorCode ec) {
        this.ec = ec;
    }

    public String getExceptionErrorMsg() {
        return exceptionErrorMsg;
    }

    public void setExceptionErrorMsg(String exceptionErrorMsg) {
        this.exceptionErrorMsg = exceptionErrorMsg;
    }
}