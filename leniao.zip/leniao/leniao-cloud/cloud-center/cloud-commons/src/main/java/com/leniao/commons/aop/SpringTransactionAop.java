package com.leniao.commons.aop;

import cn.hutool.json.JSONArray;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.toolkit.DynamicDataSourceContextHolder;
import com.google.common.collect.Lists;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.List;

/**
 * AOP全局事务处理，不需要@Transaction
 *
 * @author guoliang.li
 * todo @Order
 * 值越小，越优先执行
 * 要优于事务的执行
 */
@Aspect
@Component
@Order(1)
@Slf4j
public class SpringTransactionAop {

    /**
     * 第一个*代表所有的返回值类型；第二个*代表所有的类；第三个*代表类所有方法；..代表子或者孙子包；最后一个..代表所有的参数
     */
    private static final String AOP_POINTCUT_EXPRESSION =
            "execution(public * com.leniao.*.service..*.*(..)) " +
                    "|| execution(public * com.leniao.service.impl.*.*(..))";

    @Resource
    private PlatformTransactionManager transactionManager;

    @Bean
    public TransactionInterceptor transactionAdvice() {
        //REQUIRED 表示：支持当前事务，如果当前没有事务，就新建一个事务。这是最常见的选择。
        DefaultTransactionAttribute writeAttribute = new DefaultTransactionAttribute();
        writeAttribute.rollbackOn(new Throwable());
        //SUPPORTS 表示：支持当前事务，如果当前没有事务，就以非事务方式执行。
        DefaultTransactionAttribute readAttribute = new DefaultTransactionAttribute();
        readAttribute.setPropagationBehavior(TransactionDefinition.PROPAGATION_SUPPORTS);
        readAttribute.setReadOnly(true);

        NameMatchTransactionAttributeSource source = new NameMatchTransactionAttributeSource();
        source.addTransactionalMethod("init*", writeAttribute);
        source.addTransactionalMethod("update*", writeAttribute);
        source.addTransactionalMethod("save*", writeAttribute);
        source.addTransactionalMethod("create*", writeAttribute);
        source.addTransactionalMethod("delete*", writeAttribute);
        source.addTransactionalMethod("execute*", writeAttribute);
        source.addTransactionalMethod("insert*", writeAttribute);
        source.addTransactionalMethod("add*", writeAttribute);
        source.addTransactionalMethod("register*", writeAttribute);
        source.addTransactionalMethod("modify*", writeAttribute);
        source.addTransactionalMethod("edit*", writeAttribute);
        source.addTransactionalMethod("batch*", writeAttribute);
        source.addTransactionalMethod("remove*", writeAttribute);

        source.addTransactionalMethod("get*", readAttribute);
        source.addTransactionalMethod("find*", readAttribute);
        source.addTransactionalMethod("select*", readAttribute);
        source.addTransactionalMethod("load*", readAttribute);
        source.addTransactionalMethod("search*", readAttribute);
        source.addTransactionalMethod("show*", readAttribute);
        source.addTransactionalMethod("count*", readAttribute);
        source.addTransactionalMethod("list*", readAttribute);
        source.addTransactionalMethod("read*", readAttribute);
        source.addTransactionalMethod("query*", readAttribute);
        source.addTransactionalMethod("check*", readAttribute);

        return new TransactionInterceptor(transactionManager, source);
    }

    @Bean
    public Advisor txAdviceAdvisor(TransactionInterceptor transactionAdvice) {
        AspectJExpressionPointcut transactionPointcut = new AspectJExpressionPointcut();
        transactionPointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(transactionPointcut, transactionAdvice);
    }

    private static final String MASTER = "master";

    private static final String SLAVE = "slave";

    private static final List<String> METHOD_LIST = Lists.newArrayList(
            "find", "get", "select", "load", "search",
            "show", "count", "list", "read", "query", "check",
            "init", "update", "save", "create", "delete", "execute", "insert", "add", "register", "modify",
            "edit", "batch", "remove", "get", "find", "select", "load", "search", "show", "count", "list", "read", "query", "check"
    );

    private static final JSONArray JSON_ARRAY = new JSONArray();

    static {
        JSON_ARRAY.addAll(METHOD_LIST);
    }

    @Before(AOP_POINTCUT_EXPRESSION)
    public void process(JoinPoint joinPoint) throws NoSuchMethodException {
        String methodName = joinPoint.getSignature().getName();
        Class<?> clazz = joinPoint.getTarget().getClass();
        if (clazz.isAnnotationPresent(DS.class)) {
            //类上的注解DS
            return;
        }
        Class<?>[] parameterTypes = ((MethodSignature) joinPoint.getSignature()).getMethod().getParameterTypes();
        Method method = clazz.getMethod(methodName, parameterTypes);
        if (method.isAnnotationPresent(DS.class)) {
            //方法上的注解DS
            return;
        }
        boolean readExists = StringUtils.startsWithAny(methodName, "find", "get", "select", "load", "search",
                "show", "count", "list", "read", "query", "check");
        if (readExists) {
            log.info("\n当前执行的库：" + SLAVE);
            DynamicDataSourceContextHolder.push(SLAVE);
            return;
        }
        boolean writeExists = StringUtils.startsWithAny(methodName,
                "init", "update", "save", "create", "delete", "execute", "insert", "add", "register", "modify",
                "edit", "batch", "remove", "get", "find", "select", "load", "search", "show", "count", "list", "read", "query", "check");
        if (writeExists) {
            log.info("\n当前执行的库：" + MASTER);
            DynamicDataSourceContextHolder.push(MASTER);
        } else {
            throw new CloudException(CloudErrorCode.METHOD_NAME_ERROR, "当前方法[" + methodName + "]前缀不在以下合法命名范围内：\n" + JSON_ARRAY.toString());
        }
    }

    @After(AOP_POINTCUT_EXPRESSION)
    public void afterAdvice() {
        DynamicDataSourceContextHolder.poll();
    }
}