package com.leniao.commons.util;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Objects;

/**
 * @author guoliang.li
 * @description TODO(上下文工具类)
 */
public class ContextHolderUtils {

    /**
     * SpringMvc下获取request
     */
    public static HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
    }

    /**
     * SpringMvc下获取session
     */
    public static HttpSession getSession() {
        return getRequest().getSession();
    }
}