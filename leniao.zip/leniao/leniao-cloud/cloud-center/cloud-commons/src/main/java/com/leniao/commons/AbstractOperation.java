package com.leniao.commons;

import com.google.common.collect.Lists;
import org.apache.commons.lang3.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.reactive.function.client.WebClient;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author guoliang.li
 */
public abstract class AbstractOperation {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    protected ThreadPoolTaskExecutor taskExecutor;

    @Resource
    protected ThreadPoolTaskScheduler taskScheduler;

    @Resource
    protected JdbcTemplate jdbcTemplate;

    @Resource
    protected NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Resource
    protected WebClient webClient;

    /**
     * stringRedisTemplate
     */
    @Resource
    protected StringRedisTemplate stringRedisTemplate;

    /**
     * 基础命令(例如:删除Key,设置过期时间等)
     */
    @Resource
    protected RedisTemplate<String, Object> redisTemplate;

    /**
     * 字符串操作
     */
    @Resource(name = "redisTemplate")
    protected ValueOperations<String, Object> valueOperations;

    /**
     * 散列操作
     */
    @Resource(name = "redisTemplate")
    protected HashOperations<String, String, Object> hashOperations;

    /**
     * 列表操作
     */
    @Resource(name = "redisTemplate")
    protected ListOperations<String, Object> listOperations;

    /**
     * 无序集合
     */
    @Resource(name = "redisTemplate")
    protected SetOperations<String, Object> setOperations;

    /**
     * 有序集合
     */
    @Resource(name = "redisTemplate")
    protected ZSetOperations<String, Object> zSetOperations;

    private static AbstractOperation operation;

    /**
     * 为静态方法引入普通对象
     */
    @PostConstruct
    public void init() {
        operation = this;
    }

    protected void set(String key, Object value) {
        //默认失效期为30-60天.
        this.set(key, value, RandomUtils.nextInt(30 * 24 * 60, 60 * 24 * 60), TimeUnit.MINUTES);
    }

    protected void set(String key, Object value, int days) {
        this.set(key, value, days, TimeUnit.DAYS);
    }

    protected void set(String key, Object value, long timeout, TimeUnit unit) {
        valueOperations.set(key, value, timeout, unit);
    }

    protected void set(String key, Object value, Date date) {
        valueOperations.set(key, value);
        redisTemplate.expireAt(key, date);
    }

    public static List<String> keys(String pattern) {
        //默认取出1000个
        return keys(pattern, 1000);
    }

    /**
     * scan命令可替换keys命令
     *
     * @param pattern 通配符
     * @param count   查询数量
     * @return 返回key结果集
     */
    public static List<String> keys(String pattern, Integer count) {
        if (count == null || count == 0) {
            return Collections.emptyList();
        }
        return operation.redisTemplate.execute((RedisConnection redisConnection) -> {
            List<String> keys = Lists.newArrayListWithExpectedSize(count);
            try (Cursor<byte[]> cursor = redisConnection
                    .scan(ScanOptions.scanOptions().count(count).match(pattern).build())) {
                while (cursor.hasNext()) {
                    keys.add(new String(cursor.next()));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return keys;
        });
        //方式二：通过jedis获取
        /*try (Jedis jedis = jedisPool.getResource()) {
            ScanParams params = new ScanParams();
            params.match(pattern);
            params.count(count);
            ScanResult<String> scan = jedis.scan("0", params);
            return scan.getResult();
        }*/
    }
}