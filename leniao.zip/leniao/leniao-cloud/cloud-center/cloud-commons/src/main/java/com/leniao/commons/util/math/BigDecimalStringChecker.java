package com.leniao.commons.util.math;

/**
 * @author guoliang.li
 */
public interface BigDecimalStringChecker {

    /**
     * 验证参数是否为空
     * @param value 参数
     */
    static void check(String value) {
        if (value.isEmpty()){
            throw new NullPointerException("String can not be an empty value.");
        }
    }
}