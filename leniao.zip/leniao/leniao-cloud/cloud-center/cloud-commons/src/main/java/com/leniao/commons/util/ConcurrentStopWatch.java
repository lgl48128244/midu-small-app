package com.leniao.commons.util;

import org.springframework.util.StopWatch;


/**
 * @author guoliang.li
 * @date 2019年12月26日16点57分
 * @description 支持多线程的代码执行耗时监控类，以空间换时间，多线程情况下，为每个线程提供一个StopWatch对象，支持更高的并发，
 * 相比synchronized的以时间换空间方式，不需要加锁，性能更好
 */
public class ConcurrentStopWatch {

    private ThreadLocal<StopWatch> stopWatch;

    public ConcurrentStopWatch() {
        this.stopWatch = ThreadLocal.withInitial(StopWatch::new);
    }

    public ConcurrentStopWatch(final String name) {
        this.stopWatch = ThreadLocal.withInitial(() -> new StopWatch(name));
    }

    public void start(String taskName) {
        if (!this.stopWatch.get().isRunning()) {
            this.stopWatch.get().start(taskName);
        } else {
            this.stopWatch.get().stop();
        }
    }

    public void stop() {
        if (this.stopWatch.get().isRunning()) {
            this.stopWatch.get().stop();
        }
    }

    public void remove() {
        this.stopWatch.remove();
    }

    public long getTotalTimeMillis() {
        return this.stopWatch.get().getTotalTimeMillis();
    }
}