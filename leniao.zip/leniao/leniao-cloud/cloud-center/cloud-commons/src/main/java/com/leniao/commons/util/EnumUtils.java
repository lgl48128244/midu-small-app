package com.leniao.commons.util;

import com.leniao.model.constant.GlobalConstant;
import lombok.Getter;

/**
 * 枚举工具类
 *
 * @author guoliang.li
 */
public class EnumUtils {

    /**
     * 枚举接口
     */
    public interface CodeEnum<T> {
        /**
         * 枚举编码
         *
         * @return code
         */
        T getCode();

        /**
         * 枚举文本
         *
         * @return text
         */
        T getText();
    }

    /**
     * 获取枚举(用code)
     *
     * @return 枚举对象
     */
    public static <T extends CodeEnum<Object>> T getByCode(Object code, Class<T> enumClass) {
        if (code == null) {
            return null;
        }
        try {
            for (T e : enumClass.getEnumConstants()) {
                if (code.equals(e.getCode())) {
                    return e;
                }
            }
        } catch (final IllegalArgumentException ignore) {
        }
        return null;
    }

    /**
     * 获取枚举(用text)
     *
     * @return 枚举对象
     */
    public static <T extends CodeEnum<Object>> T getByText(Object text, Class<T> enumClass) {
        if (text == null) {
            return null;
        }
        try {
            for (T e : enumClass.getEnumConstants()) {
                if (text.equals(e.getText())) {
                    return e;
                }
            }
        } catch (final IllegalArgumentException ignore) {
        }
        return null;
    }

    /**
     * 审核通过状态
     */
    @Getter
    public enum ExVerifyResult implements CodeEnum<Object> {
        /**
         * 审核状态：1：通过，2：不通过
         */
        VERIFY_RESULT1(1, "审核通过"),
        VERIFY_RESULT2(2, "审核不通过");

        private Integer code;
        private String text;

        ExVerifyResult(Integer code, String text) {
            this.code= code;
            this.text = text;
        }
    }

    /**
     * 异常状态
     */
    @Getter
    public enum ExStatus implements CodeEnum<Object> {
        /**
         * 异常处理状态：0:未处理,1:已处理无需申报(除产污设备的停限产异常外), 2: 已处理待申报,3:已申报待审核,4:审核通过, 5:审核失败待重申报
         */
        STATUS0(0, "未处理"),
        STATUS1(1, "已处理无需申报(除产污设备的停限产异常外)"),
        STATUS2(2, "已处理待申报"),
        STATUS3(3, "已申报待审核"),
        STATUS4(4, "审核通过"),
        STATUS5(5, "审核失败待重申报");

        private Integer code;
        private String text;

        ExStatus(Integer code, String text) {
            this.code = code;
            this.text = text;
        }
    }

    /**
     * 异常类型
     */
    @Getter
    public enum ExType implements CodeEnum<Object> {
        /**
         * 异常类型：1:产污设备异常,2:治污设备异常(这两种设备的具体异常可查看同步过来的其他字段), 3:停产异常, 4:限产异常(治污设备没有3,4), 5:电量异常, 6:停机异常
         */
        TYPE1(1, "产污设备异常"),
        TYPE2(2, "治污设备异常(这两种设备的具体异常可查看同步过来的其他字段)"),
        TYPE3(3, "停产异常"),
        TYPE4(4, "限产异常(治污设备没有3,4)"),
        TYPE5(5, "电量异常"),
        TYPE6(6, "停机异常");

        private Integer code;
        private String text;

        ExType(Integer code, String text) {
            this.code = code;
            this.text = text;
        }
    }

    /**
     * 服务应用标识
     */
    public enum ServerName {
        /**
         * 管理系统服务
         */
        ADMIN(1, GlobalConstant.SERVER_ADMIN),
        /**
         * 环保服务
         */
        HUANBAO(2, GlobalConstant.SERVER_HUANBAO);

        int code;
        String name;

        ServerName(int code, String name) {
            this.code = code;
            this.name = name;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}