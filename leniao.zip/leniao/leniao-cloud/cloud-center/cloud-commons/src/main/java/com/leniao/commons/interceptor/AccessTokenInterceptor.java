package com.leniao.commons.interceptor;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.entity.TbLnUserInfo;
import com.leniao.model.constant.GlobalConstant;
import com.leniao.model.vo.UserInfo;
import com.leniao.service.TbLnUserInfoService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author guoliang.li
 * @date 2020/1/2 9:36
 * @description TODO
 */
@Component
public class AccessTokenInterceptor implements HandlerInterceptor {

    /**
     * 散列操作
     */
    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private TbLnUserInfoService tbLnUserInfoService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        GlobalConstant.USER_INFO.remove();
        String accessToken = request.getHeader("access_token");
        if (StringUtils.isBlank(accessToken)) {
            throw new CloudException(CloudErrorCode.PARAM_MISSING, "access_token参数为空");
        }
        UserInfo userInfo = redisTemplate.execute((RedisConnection redisConnection) -> {
            String hashKey = "LN.IOT.User:" + accessToken;
            byte[] bytes = redisConnection.hGet(hashKey.getBytes(), "LN.LoginUserList".getBytes());
            if (!ArrayUtil.isEmpty(bytes)) {
                String json = new String(bytes);
                JSONObject jsonObject = JSONUtil.parseObj(json);
                UserInfo user = new UserInfo();
                user.setUserId(jsonObject.getInt("user_id"));
                user.setGroupType(jsonObject.getInt("group_type"));
                user.setPlatformId(jsonObject.getInt("platform_id"));
                user.setGroupOnlyRead(jsonObject.getInt("group_onlyread"));
                return user;
            }
            return null;
        });
        if (userInfo == null) {
            throw new CloudException(CloudErrorCode.OBJ_NULL, "用户信息不存在，请确保有效的access_token");
        }
        TbLnUserInfo tbLnUserInfo = tbLnUserInfoService.getById(userInfo.getUserId());
        if (tbLnUserInfo != null) {
            userInfo.setUsername(tbLnUserInfo.getUsername());
            GlobalConstant.USER_INFO.set(userInfo);
        }
        return true;
    }
}