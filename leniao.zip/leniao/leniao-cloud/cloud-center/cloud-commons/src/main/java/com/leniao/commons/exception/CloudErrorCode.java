package com.leniao.commons.exception;

import org.apache.commons.lang3.StringUtils;

/**
 * ErrorCode ErrorCode
 *
 * @author guoliang.li
 */
public enum CloudErrorCode {
    /**
     *
     */
    API_RESPONSE_TIME_ERROR(501, "接口响应时间太长，请稍候再试"),

    SYS_ERROR(100000, "系统繁忙，请稍后再试"),

    SYS_TIMEOUT(99999, "系统过期或未登陆，请重新登录"),

    PARAM_INVALID(100001, "参数错误"),

    PARAM_MISSING(100002, "参数缺失"),

    PARAM_EXIST(1000021, "参数已存在"),

    SYS_EMPTY(100003, "无数据"),

    PRIMARY_KEY_EMPTY(100004, "主键为空"),

    OBJ_NULL(1000041, "此数据不存在"),

    SYS_DUPLICATE(100005, "重复定义"),

    METHOD_NAME_ERROR(100006, "Service方法命名不规范"),

    BIZ_EXCEPTION(400000, "业务异常"),

    PHONE_EXCEPTION_NULL(600005, "手机号不存在"),

    PHONE_ENCRYPT_NULL(600006, "手机密钥不存在"),

    LOGIN_INVALID(200001, "登陆信息无效！"),

    LOGIN_ERROR(200001, "用户名或密码错误！"),

    USER_LOGERR_2004(2004, "该账号不存在"),

    USER_LOGERR_2005(2005, "账号未激活"),

    USER_LOGERR_2006(2006, "账号已被锁定"),

    OAUTH_FAIL_99997(99997, "鉴权端失败"),

    OAUTH_FAIL_99998(99998, "无访问权限"),

    OAUTH_INVALID_CREDENTIALS(90009, "INVALID CREDENTIALS"),

    INVALID_BROWSER_ACCESS(444001, "非法的浏览器访问"),
    INVALID_BROWSER_CHECK(444002, "对访问浏览器检查异常"),

    SYS_FAIL_ADD(400002, "添加失败"),
    SYS_FAIL_MODIFY(400003, "修改失败"),
    SYS_FAIL_DELETE(400004, "删除失败"),

    /**
     * 机构异常信息
     */
    AGENCY_ISNULL(300001, "行政机构不存在"),

    /**
     * 减产减排管理
     */
    REDUCE_EMMISSION_EMPTY(400001, "减产减排方案不存在"),
    PLAN_JION_PROJECT(400005, "方案正在使用，不可删除、修改"),


    /**
     * 文件上传错误码
     */
    UPLOAD_FILE_CHECK(235000, "未上传附件，请重新上传"),
    UPLOAD_SIZE_CHECK(235001, "上传图片不能大于10MB"),
    UPLOAD_EXT_CHECK(235002, "上传图片格式错误，图片仅限jpg、png"),
    UPLOAD_FAIL(235999, "上传失败，请重新上传");


    private int code;

    private String msg;

    CloudErrorCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    /**
     * 根据信息获取code 不存在返回-1
     */
    public static int getCode(String msg) {
        for (CloudErrorCode errorCode : CloudErrorCode.values()) {
            if (StringUtils.equals(msg, errorCode.getMsg())) {
                return errorCode.getCode();
            }
        }
        return -1;
    }

    /**
     * 根据code获取信息值 不存在返回null
     */
    public static String getMsg(int code) {
        for (CloudErrorCode errorCode : CloudErrorCode.values()) {
            if (code == errorCode.getCode()) {
                return errorCode.getMsg();
            }
        }
        return null;
    }

    public static CloudErrorCode getByCode(int code) {
        for (CloudErrorCode errorCode : CloudErrorCode.values()) {
            if (code == errorCode.getCode()) {
                return errorCode;
            }
        }
        return null;
    }
}