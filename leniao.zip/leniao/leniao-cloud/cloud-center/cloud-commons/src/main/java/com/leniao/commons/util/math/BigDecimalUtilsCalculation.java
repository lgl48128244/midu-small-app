package com.leniao.commons.util.math;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.leniao.commons.util.math.BigDecimalStringChecker.check;

/**
 * @author guoliang.li
 */
public class BigDecimalUtilsCalculation extends AbstractCalculation{

    BigDecimalUtilsCalculation(BigDecimal value) {
        super(value);
    }

    BigDecimalUtilsCalculation(BigDecimal value,int scale) {
        super(value,scale);
    }

    BigDecimalUtilsCalculation(BigDecimal value,int scale ,RoundingMode mode) {
        super(value,scale,mode);
    }

    BigDecimalUtilsCalculation(String value) {
        super(value);
    }

    BigDecimalUtilsCalculation(String value,int scale) {
        super(value,scale);
    }

    BigDecimalUtilsCalculation(String value,int scale ,RoundingMode mode) {
        super(value,scale,mode);
    }

    BigDecimalUtilsCalculation(double value) {
        super(value);
    }

    BigDecimalUtilsCalculation(double value,int scale) {
        super(value,scale);
    }

    BigDecimalUtilsCalculation(double value,int scale ,RoundingMode mode) {
        super(value,scale,mode);
    }

    BigDecimalUtilsCalculation(long value) {
        super(value);
    }

    BigDecimalUtilsCalculation(long value,int scale) {
        super(value,scale);
    }

    /**
     * 加法
     */
    @Override
    public BigDecimalUtilsCalculation add(BigDecimal bigDecimal){
        super.add(bigDecimal);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation add(String value){
        check(value);
        super.add(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation add(double value){
        super.add(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation add(long value){
        super.add(value);
        return this;
    }

    /**
     * 减法
     */
    @Override
    public BigDecimalUtilsCalculation subtract(BigDecimal bigDecimal){
        super.subtract(bigDecimal);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation subtract(String value){
        check(value);
        super.subtract(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation subtract(double value){
        super.subtract(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation subtract(long value){
        super.subtract(value);
        return this;
    }

    /**
     * 乘法
     */
    @Override
    public BigDecimalUtilsCalculation multiply(BigDecimal bigDecimal){
        super.multiply(bigDecimal);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation multiply(String value){
        check(value);
        super.multiply(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation multiply(double value){
        super.multiply(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation multiply(long value){
        super.multiply(value);
        return this;
    }

    /**
     * 除法
     */
    @Override
    public BigDecimalUtilsCalculation div(BigDecimal bigDecimal){
        super.div(bigDecimal);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation div(String value){
        check(value);
        super.div(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation div(double value){
        super.div(value);
        return this;
    }

    @Override
    public BigDecimalUtilsCalculation div(long value){
        super.div(value);
        return this;
    }

    @Override
    public BigDecimal getBigDecimal(){
        return super.amount;
    }
}