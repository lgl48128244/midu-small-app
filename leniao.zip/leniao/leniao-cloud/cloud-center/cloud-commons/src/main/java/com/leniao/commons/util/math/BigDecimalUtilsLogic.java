package com.leniao.commons.util.math;

import java.math.BigDecimal;

import static com.leniao.commons.util.math.BigDecimalStringChecker.check;

/**
 * @author guoliang.li
 */
public class BigDecimalUtilsLogic {

    private final BigDecimal amount;

    BigDecimalUtilsLogic(BigDecimal bigDecimal) {
        this.amount = bigDecimal;
    }

    BigDecimalUtilsLogic(String value) {
        check(value);
        this.amount = new BigDecimal(value);
    }

    BigDecimalUtilsLogic(double value) {
        this.amount = BigDecimal.valueOf(value);
    }

    BigDecimalUtilsLogic(long value) {
        this.amount = BigDecimal.valueOf(value);
    }

    /**
     * 等于
     */
    public boolean eq(BigDecimal bigDecimal) {
        return this.amount.compareTo(bigDecimal) == 0;
    }

    public boolean eq(String value) {
        check(value);
        return this.amount.compareTo(new BigDecimal(value)) == 0;
    }

    public boolean eq(double value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) == 0;
    }

    public boolean eq(long value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) == 0;
    }

    /**
     * 大于
     */
    public boolean gt(BigDecimal bigDecimal) {
        return this.amount.compareTo(bigDecimal) > 0;
    }

    public boolean gt(String value) {
        check(value);
        return this.amount.compareTo(new BigDecimal(value)) > 0;
    }

    public boolean gt(double value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) > 0;
    }

    public boolean gt(long value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) > 0;
    }

    /**
     * 大于等于
     */
    public boolean gteq(BigDecimal bigDecimal) {
        return this.amount.compareTo(bigDecimal) >= 0;
    }

    public boolean gteq(String value) {
        check(value);
        return this.amount.compareTo(new BigDecimal(value)) >= 0;
    }

    public boolean gteq(double value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) >= 0;
    }

    public boolean gteq(long value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) >= 0;
    }

    /**
     * 小于
     */
    public boolean lt(BigDecimal bigDecimal) {
        return this.amount.compareTo(bigDecimal) < 0;
    }

    public boolean lt(String value) {
        check(value);
        return this.amount.compareTo(new BigDecimal(value)) < 0;
    }

    public boolean lt(double value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) < 0;
    }

    public boolean lt(long value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) < 0;
    }

    /**
     * 小于等于
     */
    public boolean lteq(BigDecimal bigDecimal) {
        return this.amount.compareTo(bigDecimal) <= 0;
    }

    public boolean lteq(String value) {
        check(value);
        return this.amount.compareTo(new BigDecimal(value)) <= 0;
    }

    public boolean lteq(double value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) <= 0;
    }

    public boolean lteq(long value) {
        return this.amount.compareTo(BigDecimal.valueOf(value)) <= 0;
    }
}