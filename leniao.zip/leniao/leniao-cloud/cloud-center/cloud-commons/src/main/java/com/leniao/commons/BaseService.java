package com.leniao.commons;

/**
 * @author guoliang.li
 * @date 2019/12/19 14:28
 * @description TODO 基础业务类
 */
public abstract class BaseService extends AbstractOperation {

}
