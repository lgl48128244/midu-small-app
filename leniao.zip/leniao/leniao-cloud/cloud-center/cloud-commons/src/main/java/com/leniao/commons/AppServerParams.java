package com.leniao.commons;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author guoliang.li
 * @description 微服务系统参数设置类
 */
@Component
public class AppServerParams {

    @Resource
    private Environment env;

    public String getActive() {
        return env.getProperty("spring.profiles.active");
    }

    public String getAppName() {
        return env.getProperty("spring.application.name");
    }
}