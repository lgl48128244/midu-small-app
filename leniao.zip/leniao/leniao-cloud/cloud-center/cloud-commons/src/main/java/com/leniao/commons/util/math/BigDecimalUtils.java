package com.leniao.commons.util.math;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author guoliang.li
 */
public class BigDecimalUtils {

    /**
     * Do logic operation with BigDecimal like a > b, a >= b, a < b, a <= b.
     */
    public static BigDecimalUtilsLogic is(BigDecimal bigDecimal) {
        return new BigDecimalUtilsLogic(bigDecimal);
    }

    public static BigDecimalUtilsLogic is(String value) {
        return new BigDecimalUtilsLogic(value);
    }

    public static BigDecimalUtilsLogic is(double value) {
        return new BigDecimalUtilsLogic(value);
    }

    public static BigDecimalUtilsLogic is(long value) {
        return new BigDecimalUtilsLogic(value);
    }

    /**
     * Do calculation operation with BigDecimal like a - b, a / b.
     */
    public static BigDecimalUtilsCalculation calculate(BigDecimal bigDecimal) {
        return new BigDecimalUtilsCalculation(bigDecimal);
    }

    public static BigDecimalUtilsCalculation calculate(BigDecimal bigDecimal, int scale) {
        return new BigDecimalUtilsCalculation(bigDecimal,scale);
    }

    public static BigDecimalUtilsCalculation calculate(BigDecimal bigDecimal, int scale, RoundingMode mode) {
        return new BigDecimalUtilsCalculation(bigDecimal,scale,mode);
    }

    public static BigDecimalUtilsCalculation calculate(String value) {
        return new BigDecimalUtilsCalculation(value);
    }

    public static BigDecimalUtilsCalculation calculate(String value, int scale) {
        return new BigDecimalUtilsCalculation(value,scale);
    }

    public static BigDecimalUtilsCalculation calculate(String value , int scale, RoundingMode mode) {
        return new BigDecimalUtilsCalculation(value,scale,mode);
    }

    public static BigDecimalUtilsCalculation calculate(double value) {
        return new BigDecimalUtilsCalculation(value);
    }

    public static BigDecimalUtilsCalculation calculate(double value, int scale) {
        return new BigDecimalUtilsCalculation(value,scale);
    }

    public static BigDecimalUtilsCalculation calculate(double value, int scale, RoundingMode mode) {
        return new BigDecimalUtilsCalculation(value,scale,mode);
    }

    public static BigDecimalUtilsCalculation calculate(long value) {
        return new BigDecimalUtilsCalculation(value);
    }

    public static BigDecimalUtilsCalculation calculate(long value, int scale) {
        return new BigDecimalUtilsCalculation(value,scale);
    }
}