package com.leniao.commons.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;
import com.leniao.model.constant.GlobalConstant;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

/**
 * @author guoliang.li
 * @date 2019/12/24 22:02
 * @description TODO
 */
@Configuration
public class MyBatisPlusConfig implements MetaObjectHandler {

    /**
     * 乐观锁
     */
    @Bean
    public OptimisticLockerInterceptor optimisticLockerInterceptor() {
        return new OptimisticLockerInterceptor();
    }

    @Override
    public void insertFill(MetaObject metaObject) {
        setFieldValByName("createTime", new Date(), metaObject);
        setFieldValByName("updateTime", new Date(), metaObject);
        setFieldValByName("createUser", GlobalConstant.getUserInfo().getUsername(), metaObject);
        setFieldValByName("updateUser", GlobalConstant.getUserInfo().getUsername(), metaObject);
        setFieldValByName("deleted", 0, metaObject);
        setFieldValByName("version", 1, metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        setFieldValByName("updateTime", new Date(), metaObject);
        setFieldValByName("updateUser", GlobalConstant.getUserInfo().getUsername(), metaObject);
    }

    /**
     * 分页插件
     */
   /* @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }*/
}