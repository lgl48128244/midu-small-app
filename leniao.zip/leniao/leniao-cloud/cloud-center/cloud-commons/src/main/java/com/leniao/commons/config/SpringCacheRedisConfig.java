package com.leniao.commons.config;

import com.google.common.collect.Maps;
import com.leniao.commons.AppServerParams;
import com.leniao.commons.util.FstRedisSerializer;
import com.leniao.model.constant.SpringCacheConstants;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleCacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.List;
import java.util.Map;

/**
 * SpringCache 缓存配置
 * TODO @Configuration 中所有带 @Bean 注解的方法都会被动态代理，因此调用该方法返回的都是同一个实例。
 * TODO @如果是变成@Component之后，此时返回的就不是一个实例了，每次都会创建一个实例。此时也是一个实例（用@Autowired 注入）
 * <p>
 * TODO @Configuration 标记的类必须符合下面的要求：
 * TODO 配置类必须以类的形式提供（不能是工厂方法返回的实例），允许通过生成子类在运行时增强（cglib 动态代理）。
 * TODO 配置类不能是 final 类（没法动态代理）。
 * TODO 配置注解通常为了通过 @Bean 注解生成 Spring 容器管理的类，
 * TODO 配置类必须是非本地的（即不能在方法中声明，不能是 private）。
 * TODO 任何嵌套配置类都必须声明为static。
 * TODO @Bean 方法可能不会反过来创建进一步的配置类（也就是返回的 bean 如果带有 @Configuration，也不会被特殊处理，只会作为普通的 bean）。
 *
 * @author guoliang.li
 */
@Slf4j
@Setter
@Getter
@Configuration
@EnableCaching
@ConditionalOnExpression
@ConfigurationProperties(prefix = "spring.cache")
public class SpringCacheRedisConfig extends CachingConfigurerSupport {

    private List<SpringCacheAttrs> configs;

    private Map<String, RedisCacheConfiguration> redisCacheConfigurationHashMap = Maps.newHashMap();

    @Resource
    private AppServerParams appServerParams;

    @Resource
    private RedisConnectionFactory connectionFactory;

    @PostConstruct
    public void init() {
        this.configs.forEach(a -> {
            RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
                    //设置缓存的失效时间
                    .entryTtl(a.expires)
                    //不缓存空值
                    .disableCachingNullValues()
                    //序列化KEY设置
                    .serializeKeysWith(SerializationPair.fromSerializer(new StringRedisSerializer()))
                    //序列化VALUE设置
                    .serializeValuesWith(SerializationPair.fromSerializer(new FstRedisSerializer()));
            redisCacheConfigurationHashMap.put(a.cacheName, redisCacheConfiguration);
        });
    }

    /**
     * 默认使用的是 : {@link org.springframework.cache.interceptor.SimpleKeyGenerator}
     */
    @Bean
    @Override
    public KeyGenerator keyGenerator() {
        return (Object target, Method method, Object... params) -> {
            StringBuilder sb = new StringBuilder();
            //应用标识
            sb.append(appServerParams.getAppName())
                    .append(":")
                    .append(target.getClass().getName())
                    .append(":")
                    .append(method.getName());
            for (Object obj : params) {
                sb.append(":").append(obj.toString());
            }
            return sb.toString();
        };
    }

    /**
     * 错误处理
     */
    @Bean
    @Override
    public CacheErrorHandler errorHandler() {
        return new SimpleCacheErrorHandler() {
            @Override
            public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
                log.error("cache : {} , key : {}", cache, key);
                log.error("handleCacheGetError", exception);
                super.handleCacheGetError(exception, cache, key);
            }

            @Override
            public void handleCachePutError(RuntimeException exception, Cache cache, Object key, Object value) {
                log.error("cache : {} , key : {} , value : {} ", cache, key, value);
                log.error("handleCachePutError", exception);
                super.handleCachePutError(exception, cache, key, value);
            }

            @Override
            public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
                log.error("cache : {} , key : {}", cache, key);
                log.error("handleCacheEvictError", exception);
                super.handleCacheEvictError(exception, cache, key);
            }

            @Override
            public void handleCacheClearError(RuntimeException exception, Cache cache) {
                log.error("cache : {} ", cache);
                log.error("handleCacheClearError", exception);
                super.handleCacheClearError(exception, cache);
            }
        };
    }

    @Bean
    @Override
    public CacheManager cacheManager() {
        return RedisCacheManager
                .builder(RedisCacheWriter.nonLockingRedisCacheWriter(connectionFactory))
                //设置缓存默认配置
                .cacheDefaults(this.redisCacheConfigurationHashMap.get(SpringCacheConstants.DEFAULT_CACHE_NAME))
                //开启事务功能
                .transactionAware()
                //设置缓存配置(多种策略)
                .withInitialCacheConfigurations(redisCacheConfigurationHashMap)
                .build();
    }

    @Data
    private static class SpringCacheAttrs {

        private String cacheName;

        private Duration expires;
    }
}