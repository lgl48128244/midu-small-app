package com.leniao.commons.aop;

import cn.hutool.json.JSONUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.leniao.commons.exception.CloudErrorCode;
import com.leniao.commons.exception.CloudException;
import com.leniao.commons.util.ConcurrentStopWatch;
import com.leniao.commons.util.ContextHolderUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Map;

/**
 * Controller日志打印
 *
 * @author guoliang.li
 */
@Slf4j
@Aspect
@Component
public class ControllerLogAop {

    private ConcurrentStopWatch stopWatch = new ConcurrentStopWatch("ControllerLogAop");

    /**
     * 注解里要使用的变量只能是常量类型
     */
    private static final String POINT = "execution(public * com.leniao.*.controller.*.*(..))";

    @Before(POINT)
    public void doBeforeInServiceLayer(JoinPoint pjp) {
        //1、开始时间
        stopWatch.start(Thread.currentThread().getName());
    }

    @After(POINT)
    public void doAfterInServiceLayer(JoinPoint pjp) {
        //2、结束时间
        stopWatch.stop();
        //3、消耗的时间
        long consumeTime = stopWatch.getTotalTimeMillis();
        //4、移除当前线程
        stopWatch.remove();
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        String name = signature.getDeclaringType().getName();
        String methodName = signature.getName();
        String[] parameterNames = signature.getParameterNames();
        Map<String, Object> map = Maps.newHashMap();
        if (parameterNames != null) {
            for (int i = 0; i < parameterNames.length; i++) {
                map.put(parameterNames[i], pjp.getArgs()[i]);
            }
        }
        HttpServletRequest request = ContextHolderUtils.getRequest();
        String methodInfo = String.format("\n请求路径: %s \n请求类名: %s \n请求方法: %s \n耗费时间: %s \n请求参数: \n%s",
                request.getRequestURI(), name, methodName, consumeTime + "ms", JSONUtil.toJsonStr(map));
        log.info("{}", methodInfo);
        final ArrayList<String> list = Lists.newArrayList("unitDataInfo","devDataInfo","countAnalysis");
        final boolean contains = list.contains(request.getRequestURI());
        if (contains) {
            return;
        }
        //500ms
        /*int timeMillis = 500;
        if (consumeTime >= timeMillis) {
            throw new CloudException(CloudErrorCode.API_RESPONSE_TIME_ERROR);
        }*/
    }
}