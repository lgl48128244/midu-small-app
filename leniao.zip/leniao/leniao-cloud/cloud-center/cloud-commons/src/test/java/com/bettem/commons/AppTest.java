package com.bettem.commons;

import com.baomidou.dynamic.datasource.toolkit.CryptoUtils;
import org.joda.time.DateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        System.out.println(123);
    }
    @Test
    public void test(){
        String date = new DateTime(1568450092172L).toString("yyyy-MM-dd HH:mm:ss");
        System.out.println(date);
        System.out.println(System.currentTimeMillis());
    }
    @Test
    public void test1() throws Exception {
        String password = "aidedianzi@2018!";
        String encodePassword = CryptoUtils.encrypt(password);
        System.out.println(encodePassword);

        //自定义publicKey
        String[] arr = CryptoUtils.genKeyPair(512);
        System.out.println("privateKey:" + arr[0]);
        System.out.println("publicKey:" + arr[1]);
        System.out.println("password:" + CryptoUtils.encrypt(arr[0], password));
    }
    /*@Autowired
    StringEncryptor stringEncryptor;

    @Test
    public void encrypt() {
        System.out.println("PWD: " + stringEncryptor.encrypt("yourpassword"));
    }*/
}
