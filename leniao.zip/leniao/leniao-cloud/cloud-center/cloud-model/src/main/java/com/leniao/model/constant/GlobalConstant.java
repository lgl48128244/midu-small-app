package com.leniao.model.constant;

import com.leniao.model.vo.UserInfo;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author guoliang.li
 */
public interface GlobalConstant {

    /**
     * 管理系统服务
     */
    String SERVER_ADMIN = "admin";

    /**
     * 环保服务
     */
    String SERVER_HUANBAO = "huanbao";

    /**
     * 全局HashMap
     */
    ConcurrentHashMap<String, Object> CONCURRENT_HASH_MAP = new ConcurrentHashMap<>();

    /**
     * 保存用户登录信息
     */
    ThreadLocal<UserInfo> USER_INFO = new ThreadLocal<>();

    /**
     * 获取用户登录信息
     *
     * @return 用户信息
     */
    static UserInfo getUserInfo() {
        UserInfo userInfo = USER_INFO.get();
        if (userInfo == null) {
            userInfo = new UserInfo();
        }
        return userInfo;
    }
}