package com.leniao.model.vo;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/21 16:29
 * @description TODO
 */
public class Page {

    @NotNull(message = "分页参数page不能为空")
    private Integer page;

    @NotNull(message = "分页参数rows不能为空")
    private Integer rows;

    /**
     * 用来存放用户所能看到的单位
     */
    private List<Long> projIds;

    private Integer platformId;

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getRows() {
        return rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    public List<Long> getProjIds() {
        return projIds;
    }

    public void setProjIds(List<Long> projIds) {
        this.projIds = projIds;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }
}