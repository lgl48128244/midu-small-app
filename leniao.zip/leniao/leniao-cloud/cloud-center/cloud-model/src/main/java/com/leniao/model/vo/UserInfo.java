package com.leniao.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author guoliang.li
 * @date 2019/12/27 11:08
 * @description TODO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {

    private String username = "system";
    private Integer userId;
    private Integer groupType;
    private Integer platformId;
    private Integer groupOnlyRead;

    /*
     * {
     * "access_token": "3DA8FA6A10D807839C805333DABF05CF",
     * "expires_in": 345600,
     * "refresh_token": "B4E227CE962DB64B969A31ED14C5940A",
     * "user_key": "186A157B2992E7DAED3677CE8E9FE40F",
     * "user_id": 1404,
     * "platform_id": 1,
     * "channel_id": 0,
     * "group_type": 1,
     * "group_onlyread": 0,
     * "secret_key": "EF7AAB34",
     * "begin_time": "/Date(1573801578349+0000)/",
     * "end_time": "/Date(1574147178349+0000)/",
     * "start_ticks": 637094271783494500,
     * "middle_ticks": 637095999783494500,
     * "end_ticks": 637097727783494500
     * }
     */
}