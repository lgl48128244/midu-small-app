package com.leniao.model.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author guoliang.li
 * @date 2019/12/20 17:20
 * @description TODO
 */
@Data
public class AreaDTO implements Serializable {
    private String id;
    private String name;

}
