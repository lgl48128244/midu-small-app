/**
 * @author guoliang.li
 * @date 2019/12/23 9:39
 * @description TODO 公共DTO
 */
package com.leniao.model.dto;