/**
 * @author guoliang.li
 * @date 2019/12/23 9:39
 * @description TODO 公共VO
 */
package com.leniao.model.vo;