package com.leniao.model.vo;

import lombok.ToString;

import java.util.Date;

/**
 * @author guoliang.li
 */
@ToString
public class ResultEcho {

    /**
     * 状态码
     */
    private int code = 200;

    /**
     * 提示信息
     */
    private String message = "操作成功";

    /**
     * 当前时间戳
     */
    private long timestamp = System.currentTimeMillis();

    /**
     * 当前时间
     */
    private Date date = new Date();

    /**
     * 返回数据
     */
    private Object data;

    public ResultEcho() {

    }

    public ResultEcho(Object data) {
        this.data = data;
    }

    public ResultEcho(Object data, int code) {
        this.data = data;
        this.code = code;
    }

    public ResultEcho(Object data, int code, String message) {
        this.data = data;
        this.code = code;
        this.message = message;
    }

    public boolean isSuccess() {
        return this.getCode() == 200;
    }

    public Object getData() {
        return this.data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public Date getDate() {
        return date;
    }
}