package com.leniao.model.dto;

import com.leniao.model.vo.Page;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.swing.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @author haosw
 * @date 2020/03/10 10:59
 * @description 机构用户的基本DTO
 */
public abstract class BaseAgencyUserDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AgencyUserSave {
        @NotNull(message = "平台ID不能为空")
        private Integer platformId;
        @NotBlank(message = "省名称不能为空")
        private String provinceName;
        @NotBlank(message = "省code不能为空")
        private String provinceCode;
        //@NotBlank(message = "市名称不能为空")
        private String cityName;
        @NotBlank(message = "市code不能为空")
        private String cityCode;
        //@NotBlank(message = "区名称不能为空")
        private String areaName;
        @NotBlank(message = "区code不能为空")
        private String areaCode;
        //机构id
        @NotNull(message = "机构ID不能为空")
        private Long agencyId;
        //机构名称
        @NotBlank(message = "机构名称不能为空")
        private String agencyName;
        @NotBlank(message = "手机号码不能为空")
        private String userPhone;
        @NotBlank(message = "用户姓名不能为空")
        private String userName;
        //职务名称--暂时先放到groupinfo表的name中
        //@NotBlank(message = "职务不能为空")
        private String position;
        @NotBlank(message = "添加人不能为空")
        private String addUser;
    }

    @EqualsAndHashCode(callSuper = true)
    @Data
    public static  class AgencyUserPage extends Page {
        @NotNull(message = "平台ID不能为空")
        private Integer platformId;
        //@NotBlank(message = "省code不能为空")
        private String provinceCode;
        //@NotBlank(message = "市code不能为空")
        private String cityCode;
        //@NotBlank(message = "区code不能为空")
        private String areaCode;
        //机构id
        private String agencyName;
    }

    @Data
    public static class AgencyUserList{
        private Integer userId;
        private String agcyName;
        private String userName;
        private String userPhone;
        private Date addTime;
        private String agencyArea;
        private String position;
    }

    @Data
    public static class AgencyUserView {
        private Long agencyId;
        private String agcyName;
        private String agcyAddress;
        private String provinceCode;
        private String cityCode;
        private String areaCode;
        private String provinceName;
        private String cityName;
        private String areaName;
        private Integer userId;
        private String userName;
        private String userPhone;
        private Date addTime;
        private String agencyArea;
        private String position;
    }

}
