package com.leniao.model.dto;

import com.leniao.model.vo.Page;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Date;

/**
 * @author guoliang.li
 * @date 2019/12/23 17:26
 * @description TODO
 */
public abstract class BaseIndustryDTO {

    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class IndustryReq extends Page {

        private String industryName;

        private Integer numStart;

        private Integer numEnd;
    }

    @Data
    public static class IndustryList implements Serializable {

        private Long id;

        private String industryName;

        private Integer bindNum;

        private Date createTime;
    }

    @Data
    public static class IndustrySave {

        private Long id;

        @NotBlank(message = "行业名称不能为空")
        private String industryName;
    }
}