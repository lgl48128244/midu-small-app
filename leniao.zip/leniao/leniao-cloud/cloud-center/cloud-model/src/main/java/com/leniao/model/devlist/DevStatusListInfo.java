package com.leniao.model.devlist;

/**
 * @author liudongshuai
 * @date 2020/1/6 18:03
 * @update
 */
public class DevStatusListInfo {

    private Integer unitId;
    private String area;

    private String unitName;
    private String groupName;
    private String lookPointName;
    private Integer devTy;

    private String devSignature;
    private Integer devWorkStatus;
    //设备安装位置
    private String devLocation;
    //启停阈值
    private Integer devPowerSillVal;
    //门限时间
    private Integer devPowerLiveTime;
    //电量启停阈值
    private Integer devEleSillVal;
    //额定功率
    private Integer devPower;

    public Integer getDevEleSillVal() {
        return devEleSillVal;
    }

    public void setDevEleSillVal(Integer devEleSillVal) {
        this.devEleSillVal = devEleSillVal;
    }

    public String getDevLocation() {
        return devLocation;
    }

    public void setDevLocation(String devLocation) {
        this.devLocation = devLocation;
    }

    public Integer getDevPowerSillVal() {
        return devPowerSillVal;
    }

    public void setDevPowerSillVal(Integer devPowerSillVal) {
        this.devPowerSillVal = devPowerSillVal;
    }

    public Integer getDevPowerLiveTime() {
        return devPowerLiveTime;
    }

    public void setDevPowerLiveTime(Integer devPowerLiveTime) {
        this.devPowerLiveTime = devPowerLiveTime;
    }

    public Integer getDevPower() {
        return devPower;
    }

    public void setDevPower(Integer devPower) {
        this.devPower = devPower;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getLookPointName() {
        return lookPointName;
    }

    public void setLookPointName(String lookPointName) {
        this.lookPointName = lookPointName;
    }

    public Integer getDevTy() {
        return devTy;
    }

    public void setDevTy(Integer devTy) {
        this.devTy = devTy;
    }

    public String getDevSignature() {
        return devSignature;
    }

    public void setDevSignature(String devSignature) {
        this.devSignature = devSignature;
    }

    public Integer getDevWorkStatus() {
        return devWorkStatus;
    }

    public void setDevWorkStatus(Integer devWorkStatus) {
        this.devWorkStatus = devWorkStatus;
    }
}
