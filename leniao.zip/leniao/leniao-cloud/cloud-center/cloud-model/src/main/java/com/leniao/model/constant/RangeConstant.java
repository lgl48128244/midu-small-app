package com.leniao.model.constant;

/**
 * 存储以后有可能变化的常量
 */
public interface RangeConstant {

    /**
     * 直辖市的省级code
     */
    String[] ZHIXIASHI_CODE = {"110000","120000","310000","500000"};

    /**
     * 环保云首页异常统计柱状图显示的长度
     */
    int INDEX_PAGE_ERR_COUNT_LIST_SIZE = 20;

}
