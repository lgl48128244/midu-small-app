package com.leniao.model.constant;

/**
 * @author guoliang.li
 * @description spring cache 常量
 */
public interface SpringCacheConstants {

    /**
     * 默认KEY生成规则
     */
    String DEFAULT_CACHE_KEY_GENERATOR = "keyGenerator";
    /**
     * 默认缓存名称(30天)
     */
    String DEFAULT_CACHE_NAME = "redisCacheDefault";
    /**
     * 1分钟缓存名称
     */
    String REDIS_CACHE_1MIN_NAME = "redisCache1min";
    /**
     * 10分钟缓存名称
     */
    String REDIS_CACHE_10MIN_NAME = "redisCache10min";
    /**
     * 30分钟缓存名称
     */
    String REDIS_CACHE_30MIN_NAME = "redisCache30min";
    /**
     * 60分钟缓存名称
     */
    String REDIS_CACHE_60MIN_NAME = "redisCache60min";
}