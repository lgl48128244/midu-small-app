package com.leniao.model.devlist;

import java.io.Serializable;

/**
 * @author liudongshuai
 * @date 2020/1/9 16:44
 * @update
 */
public class CountUnitAnalysisInfo implements Serializable,Comparable<CountUnitAnalysisInfo> {

    //名称
    private String name;
    //单位数量
    private Integer unitNum = 0;
    //在线单位
    private Integer onlineUnitNum = 0;
    //失联单位
    private Integer outlineUnitNum = 0;
    //产污设备
    private Integer pollDevNum = 0;
    //治污设备
    private Integer conDevNum = 0;
    //运行设备
    private Integer runDevNum = 0;
    //停机设备
    private Integer stopDevNum = 0;
    //失联设备
    private Integer lostDevNum = 0;

    //在线单位比例
    private Integer proportion;

    @Override
    public int compareTo(CountUnitAnalysisInfo o) {
        return this.unitNum.compareTo(o.getUnitNum());
    }

    public Integer getProportion() {
        return proportion;
    }

    public void setProportion(Integer proportion) {
        this.proportion = proportion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getUnitNum() {
        return unitNum;
    }

    public void setUnitNum(Integer unitNum) {
        this.unitNum = unitNum;
    }

    public Integer getOnlineUnitNum() {
        return onlineUnitNum;
    }

    public void setOnlineUnitNum(Integer onlineUnitNum) {
        this.onlineUnitNum = onlineUnitNum;
    }

    public Integer getOutlineUnitNum() {
        return outlineUnitNum;
    }

    public void setOutlineUnitNum(Integer outlineUnitNum) {
        this.outlineUnitNum = outlineUnitNum;
    }

    public Integer getPollDevNum() {
        return pollDevNum;
    }

    public void setPollDevNum(Integer pollDevNum) {
        this.pollDevNum = pollDevNum;
    }

    public Integer getConDevNum() {
        return conDevNum;
    }

    public void setConDevNum(Integer conDevNum) {
        this.conDevNum = conDevNum;
    }

    public Integer getRunDevNum() {
        return runDevNum;
    }

    public void setRunDevNum(Integer runDevNum) {
        this.runDevNum = runDevNum;
    }

    public Integer getStopDevNum() {
        return stopDevNum;
    }

    public void setStopDevNum(Integer stopDevNum) {
        this.stopDevNum = stopDevNum;
    }

    public Integer getLostDevNum() {
        return lostDevNum;
    }

    public void setLostDevNum(Integer lostDevNum) {
        this.lostDevNum = lostDevNum;
    }

    @Override
    public String toString() {
        return "countUnitAnalysisInfo{" +
                "name='" + name + '\'' +
                ", unitNum=" + unitNum +
                ", onlineUnitNum=" + onlineUnitNum +
                ", outlineUnitNum=" + outlineUnitNum +
                ", pollDevNum=" + pollDevNum +
                ", conDevNum=" + conDevNum +
                ", runDevNum=" + runDevNum +
                ", stopDevNum=" + stopDevNum +
                ", lostDevNum=" + lostDevNum +
                '}';
    }
}
