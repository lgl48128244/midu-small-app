package com.leniao.model.dto;

import com.leniao.model.vo.Page;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/25 17:02
 * @description TODO
 */
@Data
public abstract class BaseBusinessExDTO {

    /**
     * 异常ID
     */
    private Long id;

    /**
     * 异常类型
     */
    private Integer type;

    /**
     * 单位名称
     */
    private String companyName;

    /**
     * 分组名称
     */
    private String groupName;

    /**
     * 设备名称
     */
    private String devLocation;

    /**
     * 监测点名称
     */
    private String overLookName;

    /**
     * 设备编号
     */
    private String devSignature;

    /**
     * 异常时间
     */
    private Date errorTime;

    /**
     * 异常时间
     */
    private Integer dealStatus;

    /**
     * 异常查询请求参数
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExSearchReq extends Page {

        //@NotBlank(message = "省区域编码不能为空")
        private String provinceCode;

        //@NotBlank(message = "市区域编码不能为空")
        private String cityCode;

        //@NotBlank(message = "县区域编码不能为空")
        private String areaCode;

        /**
         * 开始时间
         */
        private String startTime;

        /**
         * 结束时间
         */
        private String endTime;

        /**
         * 机构名称
         */
        //@NotBlank(message = "机构不能为空")
        //private String agcyName;
        //@NotNull(message = "机构ID不能为空")
        private Long agcyId;

        /**
         * 单位名称
         */
        //private String companyName;
        private Integer unitId;

        /**
         * 分组名称
         */
        //private String groupName;
        private Integer groupId;

        /**
         * 监测点名称
         */
        //private String overLookName;
        private Long overLookId;

        /**
         * 设备位置
         */
        private String devLocation;

        /**
         * 异常类型
         */
        private Integer type;

        /**
         * 设置编号
         */
        private String devSignature;

        /**
         * 设备ids
         */
        private List<Long> devIds;
        /**
         * 单位id
         */
        private List<Long> unitIds;

        /**
         * 处理状态
         */
        private Integer dealStatus;
    }

    /**
     * 异常查询
     */
    @Data
    public static class BusinessExSearch {
        /**
         * 异常ID
         */
        @NotNull(message = "异常ID不能为空")
        private Long id;

        /**
         * 备注
         */
        private String remark;
    }

    /**
     * 异常查询列表
     */
    @Data
    public static class BusinessExSearchList implements Serializable {

        /**
         * 异常ID
         */
        private Long id;

        /**
         * 异常类型
         */
        private Integer type;

        /**
         * 单位名称
         */
        private String companyName;

        /**
         * 异常时间
         */
        private Date errorTime;

        /**
         * 机构名称
         */
        private String agcyName;

        /**
         * 异常描述
         */
        private String errorDesc;

        /**
         * 异常状态
         */
        private Integer dealStatus;
    }

    /**
     * 异常查询详情
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExSearchDetail extends BaseBusinessExDTO implements Serializable {

        /**
         * 异常描述
         */
        private String errorDesc;

        /**
         * 核查人
         */
        private String checkUserName;

        /**
         * 核查时间
         */
        private Date checkTime;

        /**
         * 核查结果
         */
        private Integer checkResult;

        /**
         * 审核人
         */
        private String verifyUserName;

        /**
         * 审核时间
         */
        private Date verifyTime;

        /**
         * 审核结果
         */
        private Integer verifyResult;

        /**
         * 详情描述
         */
        private String checkDesc;

        /**
         * 备注
         */
        private String remark;

        /**
         * 附件地址
         */
        private String fjUrl;

        /**
         * 附件描述
         */
        private String fjDesc;
    }

    /**
     * 异常处理
     */
    @Data
    public static class BusinessExHandler {

        /**
         * 异常ID
         */
        @NotNull(message = "异常ID不能为空")
        private Long id;

        /**
         * 核查人
         */
        private Integer checkUser;
        private String checkUserName;

        /**
         * 核查时间
         */
        private Date checkTime;

        /**
         * 核查结果
         */
        private Integer checkResult;

        /**
         * 详情描述
         */
        private String checkDesc;

        /**
         * 备注
         */
        private String remark;

        /**
         * 附件地址
         */
        private String fjUrl;

        /**
         * 附件描述
         */
        private String fjDesc;

        /**
         * 异常状态
         */
        private Integer dealStatus;
    }

    /**
     * 异常处理详情
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExHandlerDetail extends BaseBusinessExDTO implements Serializable {

        /**
         * 异常原因
         */
        private String errorReason;

        /**
         * 详情描述
         */
        private String checkDesc;

        /**
         * 备注
         */
        private String remark;

        /**
         * 附件地址
         */
        private String fjUrl;

        /**
         * 附件描述
         */
        private String fjDesc;

        /**
         * 审核人
         */
        private String verifyUserName;

        /**
         * 审核结果  1：通过 2：未通过
         */
        private Integer verifyResult;

        /**
         * 审核时间
         */
        private Date verifyTime;

        /**
         * 审核时间
         */
        private String verifySugg;


    }

    /**
     * 异常审核详情
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExExamineDetail extends BaseBusinessExDTO implements Serializable {

        /**
         * 异常描述
         */
        private String errorDesc;

        /**
         * 核查人
         */
        private String checkUserName;

        /**
         * 核查时间
         */
        private Date checkTime;

        /**
         * 核查结果
         */
        private Integer checkResult;

        /**
         * 详情描述
         */
        private String checkDesc;

        /**
         * 备注
         */
        private String remark;

        /**
         * 附件地址
         */
        private String fjUrl;

        /**
         * 附件描述
         */
        private String fjDesc;

        /**
         * 审核意见
         */
        private String verifySugg;
    }

    /**
     * 异常审核
     */
    @Data
    public static class BusinessExExamine {
        /**
         * 异常ID
         */
        @NotNull(message = "异常ID不能为空")
        private Long id;

        /**
         * 审核人
         */
        private Integer verifyUser;
        private String verifyUserName;

        /**
         * 审核时间
         */
        private Date verifyTime;

        /**
         * 审核结果
         */
        private Integer verifyResult;

        /**
         * 审核意见
         */
        private String verifySugg;

        /**
         * 异常状态
         */
        private Integer dealStatus;
    }

    /**
     * 异常统计查询参数
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExStatisticsReq extends Page {

        //@NotBlank(message = "省区域编码不能为空")
        private String provinceCode;

        //@NotBlank(message = "市区域编码不能为空")
        private String cityCode;

        //@NotBlank(message = "县区域编码不能为空")
        private String areaCode;

        /**
         * 机构名称
         */
        //@NotBlank(message = "机构不能为空")
        private String agcyName;

        /**
         * 单位名称
         */
        private String companyName;

        /**
         * 行业ID
         */
        private Long industryId;

        /**
         * 单位ID
         */
        private Integer unitId;
    }

    /**
     * 异常统计列表
     */
    @Data
    public static class BusinessExStatisticsList implements Serializable {
        /**
         * 机构名称
         */
        private String agcyName;

        /**
         * 行业名称
         */
        private String industryName;

        /**
         * 单位名称
         */
        private String companyName;

        /**
         * 总表设备异常
         */
        private Integer type0;
        /**
         * 产污设备异常
         */
        private Integer type1;
        /**
         * 治污设备异常
         */
        private Integer type2;
        /**
         * 停产异常
         */
        private Integer type3;
        /**
         * 限产异常
         */
        private Integer type4;
        /**
         * 电量异常
         */
        private Integer type5;
        /**
         * 功率异常
         */
        private Integer type6;
        /**
         * 停机异常
         */
        private Integer type7;
        /**
         * 异常总数
         */
        private Integer total;
    }

    /**
     * 异常统计（根据机构名称，柱状图）
     */
    @Data
    public static class BusinessExStatisticsAgencyList implements Serializable {
        /**
         * 机构名称
         */
        private String agcyName;

        /**
         * 异常总数
         */
        private Integer total;
    }

    /**
     * 异常统计（根据行业名称，饼状图）
     */
    @Data
    public static class BusinessExStatisticsIndustryList implements Serializable {
        /**
         * 行业名称
         */
        private String industryName;

        /**
         * 异常总数
         */
        private Integer total;
    }

    /**
     * 设备异常情况统计（根据日期统计）
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BusinessExDeviceInfo implements Serializable {
        /**
         * 异常单位
         */
        private Integer unitCount;

        /**
         * 设备总数
         */
        private Integer deviceCount;
        /**
         * 已申报企业数
         */
        private Integer declareCount;
    }

    /**
     * 异常首页滚动参数
     */
    @Data
    public static class BusinessExRollingReq {

        @NotBlank(message = "省区域编码不能为空")
        private String provinceCode;

        @NotBlank(message = "市区域编码不能为空")
        private String cityCode;

        @NotBlank(message = "县区域编码不能为空")
        private String areaCode;

        private List<Long> projIds;
    }

    /**
     * 异常首页滚动列表
     */
    @Data
    public static class BusinessExHomeRollingList implements Serializable {
        /**
         * 单位名称
         */
        private String companyName;
        /**
         * 异常类型
         */
        private Integer type;
        /**
         * 异常描述
         */
        private String errorDesc;
        /**
         * 异常时间
         */
        private String errorTime;
        /**
         * 异常状态
         */
        private Integer dealStatus;
    }

    /**
     * 错峰生产异常请求参数（一周内停限产异常）
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BusinessExCuoFengReq extends Page {
        /**
         * 单位Id
         */
        @NotNull(message = "单位ID不能为空")
        private Integer unitId;
    }

    /**
     * 错峰生产异常列表（一周内停限产异常）
     */
    @Data
    public static class BusinessExCuoFengList implements Serializable {
        /**
         * 设备名称
         */
        private String devLocation;
        /**
         * 绑定方案
         */
        private String planName;
        /**
         * 异常描述
         */
        private String errorDesc;
        /**
         * 异常时间
         */
        private Date errorTime;
        /**
         * 分组名称
         */
        private String groupName;
    }
}