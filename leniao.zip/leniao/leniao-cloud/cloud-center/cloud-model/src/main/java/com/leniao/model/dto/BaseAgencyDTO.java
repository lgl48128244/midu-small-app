package com.leniao.model.dto;

import com.leniao.model.vo.Page;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @author guoliang.li
 * @date 2019/12/21 15:46
 * @description TODO
 */
public abstract class BaseAgencyDTO {

    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class AgencyReq extends Page {

        private Integer platformId;
        private String provinceCode;
        private String cityCode;
        private String areaCode;
        private String agcyName;
        private String telePhone;
    }

    @Data
    public static class AgencyReq2 {
        private Integer platformId;
        private String provinceCode;
        private String cityCode;
        private String areaCode;
        private String agcyName;
        private String telePhone;
    }

    @Data
    public static class AgencyList implements Serializable {

        private Long id;

        private String agcyName;

        private String agcyAddress;

        private String telePhone;

        private String provinceName;

        private String cityName;

        private String countyName;

        private String provinceCode;

        private String cityCode;

        private String areaCode;

        private Date createTime;
    }

    @Data
    public static class AgencySave {

        @NotNull(message = "平台不能为空")
        private Integer platformId;

        private Long id;

        @NotBlank(message = "机构名称不能为空")
        private String agcyName;

        @NotBlank(message = "机构地址不能为空")
        private String agcyAddress;

        @NotBlank(message = "机构电话不能为空")
        private String telePhone;

        @NotBlank(message = "省区域编码不能为空")
        private String provinceCode;

        @NotBlank(message = "市区域编码不能为空")
        private String cityCode;

        @NotBlank(message = "县区域编码不能为空")
        private String areaCode;
    }
}