package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

@TableName("tblndevicenodeinfo")
@ToString
public class Tblndevicenodeinfo {
    private Integer pkid;

    private Integer devty;

    private String devnode1;

    private String devnode1desc;

    private String devuint;

    public Integer getPkid() {
        return pkid;
    }

    public void setPkid(Integer pkid) {
        this.pkid = pkid;
    }

    public Integer getDevty() {
        return devty;
    }

    public void setDevty(Integer devty) {
        this.devty = devty;
    }

    public String getDevnode1() {
        return devnode1;
    }

    public void setDevnode1(String devnode1) {
        this.devnode1 = devnode1 == null ? null : devnode1.trim();
    }

    public String getDevnode1desc() {
        return devnode1desc;
    }

    public void setDevnode1desc(String devnode1desc) {
        this.devnode1desc = devnode1desc == null ? null : devnode1desc.trim();
    }

    public String getDevuint() {
        return devuint;
    }

    public void setDevuint(String devuint) {
        this.devuint = devuint == null ? null : devuint.trim();
    }
}