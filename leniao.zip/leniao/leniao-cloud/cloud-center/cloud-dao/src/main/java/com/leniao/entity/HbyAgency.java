package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

/**
 * @author 乐鸟研发
 */
@ToString(callSuper = true)
@TableName("hby_agency")
public class HbyAgency extends BaseEntity {

    private String agcyName;

    private Integer platformId;

    private String agcyAddress;

    private String telePhone;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    public String getAgcyName() {
        return agcyName;
    }

    public void setAgcyName(String agcyName) {
        this.agcyName = agcyName;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    public String getAgcyAddress() {
        return agcyAddress;
    }

    public void setAgcyAddress(String agcyAddress) {
        this.agcyAddress = agcyAddress;
    }

    public String getTelePhone() {
        return telePhone;
    }

    public void setTelePhone(String telePhone) {
        this.telePhone = telePhone;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }
}