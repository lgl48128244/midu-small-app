package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;

@ToString
@TableName("tblndeviceinfo")
public class Tblndeviceinfo {
    @TableId
    private Integer devidpk;

    private Integer devsysid;

    private Integer devparentidpk;

    private Integer firmid;

    private Integer projid;

    private String devsignature;

    private Integer devid;

    private String devty;

    private Date devlogintime;

    private Date devproducttime;

    private Integer devisscrap;

    private Date devscraptime;

    private Integer drawingid;

    private Float devplotx;

    private Float devploty;

    private String devremark;

    private Integer isdelete;

    private Integer road;

    private String installlocation;

    private String issendother;

    private Integer devgroupid;

    private Integer devtyid;

    private String issend;

    private String systemid;

    private String olddevsignature;

    private Date changetime;

    private String picurl;

    private Byte ismasknet;

    private String machineno;

    private Byte isclose;

    public Integer getDevidpk() {
        return devidpk;
    }

    public void setDevidpk(Integer devidpk) {
        this.devidpk = devidpk;
    }

    public Integer getDevsysid() {
        return devsysid;
    }

    public void setDevsysid(Integer devsysid) {
        this.devsysid = devsysid;
    }

    public Integer getDevparentidpk() {
        return devparentidpk;
    }

    public void setDevparentidpk(Integer devparentidpk) {
        this.devparentidpk = devparentidpk;
    }

    public Integer getFirmid() {
        return firmid;
    }

    public void setFirmid(Integer firmid) {
        this.firmid = firmid;
    }

    public Integer getProjid() {
        return projid;
    }

    public void setProjid(Integer projid) {
        this.projid = projid;
    }

    public String getDevsignature() {
        return devsignature;
    }

    public void setDevsignature(String devsignature) {
        this.devsignature = devsignature == null ? null : devsignature.trim();
    }

    public Integer getDevid() {
        return devid;
    }

    public void setDevid(Integer devid) {
        this.devid = devid;
    }

    public String getDevty() {
        return devty;
    }

    public void setDevty(String devty) {
        this.devty = devty == null ? null : devty.trim();
    }

    public Date getDevlogintime() {
        return devlogintime;
    }

    public void setDevlogintime(Date devlogintime) {
        this.devlogintime = devlogintime;
    }

    public Date getDevproducttime() {
        return devproducttime;
    }

    public void setDevproducttime(Date devproducttime) {
        this.devproducttime = devproducttime;
    }

    public Integer getDevisscrap() {
        return devisscrap;
    }

    public void setDevisscrap(Integer devisscrap) {
        this.devisscrap = devisscrap;
    }

    public Date getDevscraptime() {
        return devscraptime;
    }

    public void setDevscraptime(Date devscraptime) {
        this.devscraptime = devscraptime;
    }

    public Integer getDrawingid() {
        return drawingid;
    }

    public void setDrawingid(Integer drawingid) {
        this.drawingid = drawingid;
    }

    public Float getDevplotx() {
        return devplotx;
    }

    public void setDevplotx(Float devplotx) {
        this.devplotx = devplotx;
    }

    public Float getDevploty() {
        return devploty;
    }

    public void setDevploty(Float devploty) {
        this.devploty = devploty;
    }

    public String getDevremark() {
        return devremark;
    }

    public void setDevremark(String devremark) {
        this.devremark = devremark == null ? null : devremark.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getRoad() {
        return road;
    }

    public void setRoad(Integer road) {
        this.road = road;
    }

    public String getInstalllocation() {
        return installlocation;
    }

    public void setInstalllocation(String installlocation) {
        this.installlocation = installlocation == null ? null : installlocation.trim();
    }

    public String getIssendother() {
        return issendother;
    }

    public void setIssendother(String issendother) {
        this.issendother = issendother == null ? null : issendother.trim();
    }

    public Integer getDevgroupid() {
        return devgroupid;
    }

    public void setDevgroupid(Integer devgroupid) {
        this.devgroupid = devgroupid;
    }

    public Integer getDevtyid() {
        return devtyid;
    }

    public void setDevtyid(Integer devtyid) {
        this.devtyid = devtyid;
    }

    public String getIssend() {
        return issend;
    }

    public void setIssend(String issend) {
        this.issend = issend == null ? null : issend.trim();
    }

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid == null ? null : systemid.trim();
    }

    public String getOlddevsignature() {
        return olddevsignature;
    }

    public void setOlddevsignature(String olddevsignature) {
        this.olddevsignature = olddevsignature == null ? null : olddevsignature.trim();
    }

    public Date getChangetime() {
        return changetime;
    }

    public void setChangetime(Date changetime) {
        this.changetime = changetime;
    }

    public String getPicurl() {
        return picurl;
    }

    public void setPicurl(String picurl) {
        this.picurl = picurl == null ? null : picurl.trim();
    }

    public Byte getIsmasknet() {
        return ismasknet;
    }

    public void setIsmasknet(Byte ismasknet) {
        this.ismasknet = ismasknet;
    }

    public String getMachineno() {
        return machineno;
    }

    public void setMachineno(String machineno) {
        this.machineno = machineno == null ? null : machineno.trim();
    }

    public Byte getIsclose() {
        return isclose;
    }

    public void setIsclose(Byte isclose) {
        this.isclose = isclose;
    }
}