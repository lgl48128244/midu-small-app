package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;
@ToString
@TableName("tblngroupaddress")
public class TblnGroupAddress {
    @TableId
    private String adid;

    private Integer userid;

    private String adprovince;

    private String adcity;

    private String adarea;

    private String cprovincecode;

    private String ccitycode;

    private String careacode;

    private Integer onlyread;

    private String adduser;

    private Date addtime;

    private Integer isdel;

    private Integer islock;

    private String groupid;

    public String getAdid() {
        return adid;
    }

    public void setAdid(String adid) {
        this.adid = adid == null ? null : adid.trim();
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getAdprovince() {
        return adprovince;
    }

    public void setAdprovince(String adprovince) {
        this.adprovince = adprovince == null ? null : adprovince.trim();
    }

    public String getAdcity() {
        return adcity;
    }

    public void setAdcity(String adcity) {
        this.adcity = adcity == null ? null : adcity.trim();
    }

    public String getAdarea() {
        return adarea;
    }

    public void setAdarea(String adarea) {
        this.adarea = adarea == null ? null : adarea.trim();
    }

    public String getCprovincecode() {
        return cprovincecode;
    }

    public void setCprovincecode(String cprovincecode) {
        this.cprovincecode = cprovincecode == null ? null : cprovincecode.trim();
    }

    public String getCcitycode() {
        return ccitycode;
    }

    public void setCcitycode(String ccitycode) {
        this.ccitycode = ccitycode == null ? null : ccitycode.trim();
    }

    public String getCareacode() {
        return careacode;
    }

    public void setCareacode(String careacode) {
        this.careacode = careacode == null ? null : careacode.trim();
    }

    public Integer getOnlyread() {
        return onlyread;
    }

    public void setOnlyread(Integer onlyread) {
        this.onlyread = onlyread;
    }

    public String getAdduser() {
        return adduser;
    }

    public void setAdduser(String adduser) {
        this.adduser = adduser == null ? null : adduser.trim();
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public Integer getIsdel() {
        return isdel;
    }

    public void setIsdel(Integer isdel) {
        this.isdel = isdel;
    }

    public Integer getIslock() {
        return islock;
    }

    public void setIslock(Integer islock) {
        this.islock = islock;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid == null ? null : groupid.trim();
    }
}