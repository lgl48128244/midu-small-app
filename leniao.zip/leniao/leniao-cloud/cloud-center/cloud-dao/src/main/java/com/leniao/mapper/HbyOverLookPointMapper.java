package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyOverLookPoint;
import com.leniao.entity.HbyOverLookPointExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyOverLookPointMapper extends BaseMapper<HbyOverLookPoint> {
    long countByExample(HbyOverLookPointExample example);

    int deleteByExample(HbyOverLookPointExample example);

    int deleteByPrimaryKey(Long id);

    int insertSelective(HbyOverLookPoint record);

    List<HbyOverLookPoint> selectByExample(HbyOverLookPointExample example);

    HbyOverLookPoint selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyOverLookPoint record, @Param("example") HbyOverLookPointExample example);

    int updateByExample(@Param("record") HbyOverLookPoint record, @Param("example") HbyOverLookPointExample example);

    int updateByPrimaryKeySelective(HbyOverLookPoint record);

    int updateByPrimaryKey(HbyOverLookPoint record);
}