package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.math.BigDecimal;

@TableName("hby_month_and_year_ele_count")
@ToString
public class HbyMonthAndYearEleCount {
    private Long id;

    private Integer unitId;

    private Integer devIdpk;

    private Integer year;

    private Integer month;

    private BigDecimal eleTotal;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Integer getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(Integer devIdpk) {
        this.devIdpk = devIdpk;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public BigDecimal getEleTotal() {
        return eleTotal;
    }

    public void setEleTotal(BigDecimal eleTotal) {
        this.eleTotal = eleTotal;
    }
}