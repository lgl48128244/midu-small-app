package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyProjectDayCountinfo;
import com.leniao.entity.HbyProjectDayCountinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyProjectDayCountinfoMapper extends BaseMapper<HbyProjectDayCountinfo> {
    long countByExample(HbyProjectDayCountinfoExample example);

    int deleteByExample(HbyProjectDayCountinfoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyProjectDayCountinfo record);

    int insertSelective(HbyProjectDayCountinfo record);

    List<HbyProjectDayCountinfo> selectByExample(HbyProjectDayCountinfoExample example);

    HbyProjectDayCountinfo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyProjectDayCountinfo record, @Param("example") HbyProjectDayCountinfoExample example);

    int updateByExample(@Param("record") HbyProjectDayCountinfo record, @Param("example") HbyProjectDayCountinfoExample example);

    int updateByPrimaryKeySelective(HbyProjectDayCountinfo record);

    int updateByPrimaryKey(HbyProjectDayCountinfo record);
}