package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.WebSiteInfo;
import com.leniao.entity.WebSiteInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WebSiteInfoMapper extends BaseMapper<WebSiteInfo> {
    long countByExample(WebSiteInfoExample example);

    int deleteByExample(WebSiteInfoExample example);

    int deleteByPrimaryKey(Integer wid);

    int insertSelective(WebSiteInfo record);

    List<WebSiteInfo> selectByExample(WebSiteInfoExample example);

    WebSiteInfo selectByPrimaryKey(Integer wid);

    int updateByExampleSelective(@Param("record") WebSiteInfo record, @Param("example") WebSiteInfoExample example);

    int updateByExample(@Param("record") WebSiteInfo record, @Param("example") WebSiteInfoExample example);

    int updateByPrimaryKeySelective(WebSiteInfo record);

    int updateByPrimaryKey(WebSiteInfo record);
}