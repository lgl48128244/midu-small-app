package com.leniao.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class TblndeviceparainfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblndeviceparainfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDevnodepkIsNull() {
            addCriterion("devNodepk is null");
            return (Criteria) this;
        }

        public Criteria andDevnodepkIsNotNull() {
            addCriterion("devNodepk is not null");
            return (Criteria) this;
        }

        public Criteria andDevnodepkEqualTo(Integer value) {
            addCriterion("devNodepk =", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkNotEqualTo(Integer value) {
            addCriterion("devNodepk <>", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkGreaterThan(Integer value) {
            addCriterion("devNodepk >", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devNodepk >=", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkLessThan(Integer value) {
            addCriterion("devNodepk <", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkLessThanOrEqualTo(Integer value) {
            addCriterion("devNodepk <=", value, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkIn(List<Integer> values) {
            addCriterion("devNodepk in", values, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkNotIn(List<Integer> values) {
            addCriterion("devNodepk not in", values, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkBetween(Integer value1, Integer value2) {
            addCriterion("devNodepk between", value1, value2, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevnodepkNotBetween(Integer value1, Integer value2) {
            addCriterion("devNodepk not between", value1, value2, "devnodepk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNull() {
            addCriterion("devIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNotNull() {
            addCriterion("devIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevidpkEqualTo(Integer value) {
            addCriterion("devIdpk =", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotEqualTo(Integer value) {
            addCriterion("devIdpk <>", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThan(Integer value) {
            addCriterion("devIdpk >", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIdpk >=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThan(Integer value) {
            addCriterion("devIdpk <", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThanOrEqualTo(Integer value) {
            addCriterion("devIdpk <=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIn(List<Integer> values) {
            addCriterion("devIdpk in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotIn(List<Integer> values) {
            addCriterion("devIdpk not in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk not between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andParavalueIsNull() {
            addCriterion("paraValue is null");
            return (Criteria) this;
        }

        public Criteria andParavalueIsNotNull() {
            addCriterion("paraValue is not null");
            return (Criteria) this;
        }

        public Criteria andParavalueEqualTo(BigDecimal value) {
            addCriterion("paraValue =", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueNotEqualTo(BigDecimal value) {
            addCriterion("paraValue <>", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueGreaterThan(BigDecimal value) {
            addCriterion("paraValue >", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("paraValue >=", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueLessThan(BigDecimal value) {
            addCriterion("paraValue <", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueLessThanOrEqualTo(BigDecimal value) {
            addCriterion("paraValue <=", value, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueIn(List<BigDecimal> values) {
            addCriterion("paraValue in", values, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueNotIn(List<BigDecimal> values) {
            addCriterion("paraValue not in", values, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("paraValue between", value1, value2, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParavalueNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("paraValue not between", value1, value2, "paravalue");
            return (Criteria) this;
        }

        public Criteria andParaisopenIsNull() {
            addCriterion("paraIsOpen is null");
            return (Criteria) this;
        }

        public Criteria andParaisopenIsNotNull() {
            addCriterion("paraIsOpen is not null");
            return (Criteria) this;
        }

        public Criteria andParaisopenEqualTo(String value) {
            addCriterion("paraIsOpen =", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenNotEqualTo(String value) {
            addCriterion("paraIsOpen <>", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenGreaterThan(String value) {
            addCriterion("paraIsOpen >", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenGreaterThanOrEqualTo(String value) {
            addCriterion("paraIsOpen >=", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenLessThan(String value) {
            addCriterion("paraIsOpen <", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenLessThanOrEqualTo(String value) {
            addCriterion("paraIsOpen <=", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenLike(String value) {
            addCriterion("paraIsOpen like", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenNotLike(String value) {
            addCriterion("paraIsOpen not like", value, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenIn(List<String> values) {
            addCriterion("paraIsOpen in", values, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenNotIn(List<String> values) {
            addCriterion("paraIsOpen not in", values, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenBetween(String value1, String value2) {
            addCriterion("paraIsOpen between", value1, value2, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParaisopenNotBetween(String value1, String value2) {
            addCriterion("paraIsOpen not between", value1, value2, "paraisopen");
            return (Criteria) this;
        }

        public Criteria andParapropIsNull() {
            addCriterion("paraProp is null");
            return (Criteria) this;
        }

        public Criteria andParapropIsNotNull() {
            addCriterion("paraProp is not null");
            return (Criteria) this;
        }

        public Criteria andParapropEqualTo(Integer value) {
            addCriterion("paraProp =", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropNotEqualTo(Integer value) {
            addCriterion("paraProp <>", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropGreaterThan(Integer value) {
            addCriterion("paraProp >", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropGreaterThanOrEqualTo(Integer value) {
            addCriterion("paraProp >=", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropLessThan(Integer value) {
            addCriterion("paraProp <", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropLessThanOrEqualTo(Integer value) {
            addCriterion("paraProp <=", value, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropIn(List<Integer> values) {
            addCriterion("paraProp in", values, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropNotIn(List<Integer> values) {
            addCriterion("paraProp not in", values, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropBetween(Integer value1, Integer value2) {
            addCriterion("paraProp between", value1, value2, "paraprop");
            return (Criteria) this;
        }

        public Criteria andParapropNotBetween(Integer value1, Integer value2) {
            addCriterion("paraProp not between", value1, value2, "paraprop");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}