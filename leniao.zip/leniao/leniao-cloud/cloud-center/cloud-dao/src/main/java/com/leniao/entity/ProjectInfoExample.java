package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProjectInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ProjectInfoExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andProjidIsNull() {
            addCriterion("projId is null");
            return (Criteria) this;
        }

        public Criteria andProjidIsNotNull() {
            addCriterion("projId is not null");
            return (Criteria) this;
        }

        public Criteria andProjidEqualTo(Integer value) {
            addCriterion("projId =", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotEqualTo(Integer value) {
            addCriterion("projId <>", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThan(Integer value) {
            addCriterion("projId >", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThanOrEqualTo(Integer value) {
            addCriterion("projId >=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThan(Integer value) {
            addCriterion("projId <", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThanOrEqualTo(Integer value) {
            addCriterion("projId <=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidIn(List<Integer> values) {
            addCriterion("projId in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotIn(List<Integer> values) {
            addCriterion("projId not in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidBetween(Integer value1, Integer value2) {
            addCriterion("projId between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotBetween(Integer value1, Integer value2) {
            addCriterion("projId not between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andIndustryidIsNull() {
            addCriterion("industryId is null");
            return (Criteria) this;
        }

        public Criteria andIndustryidIsNotNull() {
            addCriterion("industryId is not null");
            return (Criteria) this;
        }

        public Criteria andIndustryidEqualTo(Long value) {
            addCriterion("industryId =", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidNotEqualTo(Long value) {
            addCriterion("industryId <>", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidGreaterThan(Long value) {
            addCriterion("industryId >", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidGreaterThanOrEqualTo(Long value) {
            addCriterion("industryId >=", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidLessThan(Long value) {
            addCriterion("industryId <", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidLessThanOrEqualTo(Long value) {
            addCriterion("industryId <=", value, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidIn(List<Long> values) {
            addCriterion("industryId in", values, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidNotIn(List<Long> values) {
            addCriterion("industryId not in", values, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidBetween(Long value1, Long value2) {
            addCriterion("industryId between", value1, value2, "industryid");
            return (Criteria) this;
        }

        public Criteria andIndustryidNotBetween(Long value1, Long value2) {
            addCriterion("industryId not between", value1, value2, "industryid");
            return (Criteria) this;
        }

        public Criteria andProjnameIsNull() {
            addCriterion("projName is null");
            return (Criteria) this;
        }

        public Criteria andProjnameIsNotNull() {
            addCriterion("projName is not null");
            return (Criteria) this;
        }

        public Criteria andProjnameEqualTo(String value) {
            addCriterion("projName =", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameNotEqualTo(String value) {
            addCriterion("projName <>", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameGreaterThan(String value) {
            addCriterion("projName >", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameGreaterThanOrEqualTo(String value) {
            addCriterion("projName >=", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameLessThan(String value) {
            addCriterion("projName <", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameLessThanOrEqualTo(String value) {
            addCriterion("projName <=", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameLike(String value) {
            addCriterion("projName like", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameNotLike(String value) {
            addCriterion("projName not like", value, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameIn(List<String> values) {
            addCriterion("projName in", values, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameNotIn(List<String> values) {
            addCriterion("projName not in", values, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameBetween(String value1, String value2) {
            addCriterion("projName between", value1, value2, "projname");
            return (Criteria) this;
        }

        public Criteria andProjnameNotBetween(String value1, String value2) {
            addCriterion("projName not between", value1, value2, "projname");
            return (Criteria) this;
        }

        public Criteria andProjlocationxIsNull() {
            addCriterion("projLocationX is null");
            return (Criteria) this;
        }

        public Criteria andProjlocationxIsNotNull() {
            addCriterion("projLocationX is not null");
            return (Criteria) this;
        }

        public Criteria andProjlocationxEqualTo(Float value) {
            addCriterion("projLocationX =", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxNotEqualTo(Float value) {
            addCriterion("projLocationX <>", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxGreaterThan(Float value) {
            addCriterion("projLocationX >", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxGreaterThanOrEqualTo(Float value) {
            addCriterion("projLocationX >=", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxLessThan(Float value) {
            addCriterion("projLocationX <", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxLessThanOrEqualTo(Float value) {
            addCriterion("projLocationX <=", value, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxIn(List<Float> values) {
            addCriterion("projLocationX in", values, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxNotIn(List<Float> values) {
            addCriterion("projLocationX not in", values, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxBetween(Float value1, Float value2) {
            addCriterion("projLocationX between", value1, value2, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationxNotBetween(Float value1, Float value2) {
            addCriterion("projLocationX not between", value1, value2, "projlocationx");
            return (Criteria) this;
        }

        public Criteria andProjlocationyIsNull() {
            addCriterion("projLocationY is null");
            return (Criteria) this;
        }

        public Criteria andProjlocationyIsNotNull() {
            addCriterion("projLocationY is not null");
            return (Criteria) this;
        }

        public Criteria andProjlocationyEqualTo(Float value) {
            addCriterion("projLocationY =", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyNotEqualTo(Float value) {
            addCriterion("projLocationY <>", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyGreaterThan(Float value) {
            addCriterion("projLocationY >", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyGreaterThanOrEqualTo(Float value) {
            addCriterion("projLocationY >=", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyLessThan(Float value) {
            addCriterion("projLocationY <", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyLessThanOrEqualTo(Float value) {
            addCriterion("projLocationY <=", value, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyIn(List<Float> values) {
            addCriterion("projLocationY in", values, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyNotIn(List<Float> values) {
            addCriterion("projLocationY not in", values, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyBetween(Float value1, Float value2) {
            addCriterion("projLocationY between", value1, value2, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProjlocationyNotBetween(Float value1, Float value2) {
            addCriterion("projLocationY not between", value1, value2, "projlocationy");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeIsNull() {
            addCriterion("proCreateTime is null");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeIsNotNull() {
            addCriterion("proCreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeEqualTo(Date value) {
            addCriterion("proCreateTime =", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeNotEqualTo(Date value) {
            addCriterion("proCreateTime <>", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeGreaterThan(Date value) {
            addCriterion("proCreateTime >", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("proCreateTime >=", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeLessThan(Date value) {
            addCriterion("proCreateTime <", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("proCreateTime <=", value, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeIn(List<Date> values) {
            addCriterion("proCreateTime in", values, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeNotIn(List<Date> values) {
            addCriterion("proCreateTime not in", values, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeBetween(Date value1, Date value2) {
            addCriterion("proCreateTime between", value1, value2, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProcreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("proCreateTime not between", value1, value2, "procreatetime");
            return (Criteria) this;
        }

        public Criteria andProjlocationIsNull() {
            addCriterion("projLocation is null");
            return (Criteria) this;
        }

        public Criteria andProjlocationIsNotNull() {
            addCriterion("projLocation is not null");
            return (Criteria) this;
        }

        public Criteria andProjlocationEqualTo(String value) {
            addCriterion("projLocation =", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationNotEqualTo(String value) {
            addCriterion("projLocation <>", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationGreaterThan(String value) {
            addCriterion("projLocation >", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationGreaterThanOrEqualTo(String value) {
            addCriterion("projLocation >=", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationLessThan(String value) {
            addCriterion("projLocation <", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationLessThanOrEqualTo(String value) {
            addCriterion("projLocation <=", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationLike(String value) {
            addCriterion("projLocation like", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationNotLike(String value) {
            addCriterion("projLocation not like", value, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationIn(List<String> values) {
            addCriterion("projLocation in", values, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationNotIn(List<String> values) {
            addCriterion("projLocation not in", values, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationBetween(String value1, String value2) {
            addCriterion("projLocation between", value1, value2, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProjlocationNotBetween(String value1, String value2) {
            addCriterion("projLocation not between", value1, value2, "projlocation");
            return (Criteria) this;
        }

        public Criteria andProprovinceIsNull() {
            addCriterion("proProvince is null");
            return (Criteria) this;
        }

        public Criteria andProprovinceIsNotNull() {
            addCriterion("proProvince is not null");
            return (Criteria) this;
        }

        public Criteria andProprovinceEqualTo(String value) {
            addCriterion("proProvince =", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceNotEqualTo(String value) {
            addCriterion("proProvince <>", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceGreaterThan(String value) {
            addCriterion("proProvince >", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceGreaterThanOrEqualTo(String value) {
            addCriterion("proProvince >=", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceLessThan(String value) {
            addCriterion("proProvince <", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceLessThanOrEqualTo(String value) {
            addCriterion("proProvince <=", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceLike(String value) {
            addCriterion("proProvince like", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceNotLike(String value) {
            addCriterion("proProvince not like", value, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceIn(List<String> values) {
            addCriterion("proProvince in", values, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceNotIn(List<String> values) {
            addCriterion("proProvince not in", values, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceBetween(String value1, String value2) {
            addCriterion("proProvince between", value1, value2, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProprovinceNotBetween(String value1, String value2) {
            addCriterion("proProvince not between", value1, value2, "proprovince");
            return (Criteria) this;
        }

        public Criteria andProcityIsNull() {
            addCriterion("proCity is null");
            return (Criteria) this;
        }

        public Criteria andProcityIsNotNull() {
            addCriterion("proCity is not null");
            return (Criteria) this;
        }

        public Criteria andProcityEqualTo(String value) {
            addCriterion("proCity =", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityNotEqualTo(String value) {
            addCriterion("proCity <>", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityGreaterThan(String value) {
            addCriterion("proCity >", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityGreaterThanOrEqualTo(String value) {
            addCriterion("proCity >=", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityLessThan(String value) {
            addCriterion("proCity <", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityLessThanOrEqualTo(String value) {
            addCriterion("proCity <=", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityLike(String value) {
            addCriterion("proCity like", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityNotLike(String value) {
            addCriterion("proCity not like", value, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityIn(List<String> values) {
            addCriterion("proCity in", values, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityNotIn(List<String> values) {
            addCriterion("proCity not in", values, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityBetween(String value1, String value2) {
            addCriterion("proCity between", value1, value2, "procity");
            return (Criteria) this;
        }

        public Criteria andProcityNotBetween(String value1, String value2) {
            addCriterion("proCity not between", value1, value2, "procity");
            return (Criteria) this;
        }

        public Criteria andProareaIsNull() {
            addCriterion("proArea is null");
            return (Criteria) this;
        }

        public Criteria andProareaIsNotNull() {
            addCriterion("proArea is not null");
            return (Criteria) this;
        }

        public Criteria andProareaEqualTo(String value) {
            addCriterion("proArea =", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaNotEqualTo(String value) {
            addCriterion("proArea <>", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaGreaterThan(String value) {
            addCriterion("proArea >", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaGreaterThanOrEqualTo(String value) {
            addCriterion("proArea >=", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaLessThan(String value) {
            addCriterion("proArea <", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaLessThanOrEqualTo(String value) {
            addCriterion("proArea <=", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaLike(String value) {
            addCriterion("proArea like", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaNotLike(String value) {
            addCriterion("proArea not like", value, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaIn(List<String> values) {
            addCriterion("proArea in", values, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaNotIn(List<String> values) {
            addCriterion("proArea not in", values, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaBetween(String value1, String value2) {
            addCriterion("proArea between", value1, value2, "proarea");
            return (Criteria) this;
        }

        public Criteria andProareaNotBetween(String value1, String value2) {
            addCriterion("proArea not between", value1, value2, "proarea");
            return (Criteria) this;
        }

        public Criteria andFireguardidIsNull() {
            addCriterion("fireGuardId is null");
            return (Criteria) this;
        }

        public Criteria andFireguardidIsNotNull() {
            addCriterion("fireGuardId is not null");
            return (Criteria) this;
        }

        public Criteria andFireguardidEqualTo(Integer value) {
            addCriterion("fireGuardId =", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotEqualTo(Integer value) {
            addCriterion("fireGuardId <>", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidGreaterThan(Integer value) {
            addCriterion("fireGuardId >", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidGreaterThanOrEqualTo(Integer value) {
            addCriterion("fireGuardId >=", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidLessThan(Integer value) {
            addCriterion("fireGuardId <", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidLessThanOrEqualTo(Integer value) {
            addCriterion("fireGuardId <=", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidIn(List<Integer> values) {
            addCriterion("fireGuardId in", values, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotIn(List<Integer> values) {
            addCriterion("fireGuardId not in", values, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidBetween(Integer value1, Integer value2) {
            addCriterion("fireGuardId between", value1, value2, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotBetween(Integer value1, Integer value2) {
            addCriterion("fireGuardId not between", value1, value2, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidIsNull() {
            addCriterion("legalPersonId is null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidIsNotNull() {
            addCriterion("legalPersonId is not null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidEqualTo(Integer value) {
            addCriterion("legalPersonId =", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotEqualTo(Integer value) {
            addCriterion("legalPersonId <>", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidGreaterThan(Integer value) {
            addCriterion("legalPersonId >", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidGreaterThanOrEqualTo(Integer value) {
            addCriterion("legalPersonId >=", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidLessThan(Integer value) {
            addCriterion("legalPersonId <", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidLessThanOrEqualTo(Integer value) {
            addCriterion("legalPersonId <=", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidIn(List<Integer> values) {
            addCriterion("legalPersonId in", values, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotIn(List<Integer> values) {
            addCriterion("legalPersonId not in", values, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidBetween(Integer value1, Integer value2) {
            addCriterion("legalPersonId between", value1, value2, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotBetween(Integer value1, Integer value2) {
            addCriterion("legalPersonId not between", value1, value2, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andProjintroductionIsNull() {
            addCriterion("projIntroduction is null");
            return (Criteria) this;
        }

        public Criteria andProjintroductionIsNotNull() {
            addCriterion("projIntroduction is not null");
            return (Criteria) this;
        }

        public Criteria andProjintroductionEqualTo(String value) {
            addCriterion("projIntroduction =", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionNotEqualTo(String value) {
            addCriterion("projIntroduction <>", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionGreaterThan(String value) {
            addCriterion("projIntroduction >", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionGreaterThanOrEqualTo(String value) {
            addCriterion("projIntroduction >=", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionLessThan(String value) {
            addCriterion("projIntroduction <", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionLessThanOrEqualTo(String value) {
            addCriterion("projIntroduction <=", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionLike(String value) {
            addCriterion("projIntroduction like", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionNotLike(String value) {
            addCriterion("projIntroduction not like", value, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionIn(List<String> values) {
            addCriterion("projIntroduction in", values, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionNotIn(List<String> values) {
            addCriterion("projIntroduction not in", values, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionBetween(String value1, String value2) {
            addCriterion("projIntroduction between", value1, value2, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjintroductionNotBetween(String value1, String value2) {
            addCriterion("projIntroduction not between", value1, value2, "projintroduction");
            return (Criteria) this;
        }

        public Criteria andProjremarkIsNull() {
            addCriterion("projRemark is null");
            return (Criteria) this;
        }

        public Criteria andProjremarkIsNotNull() {
            addCriterion("projRemark is not null");
            return (Criteria) this;
        }

        public Criteria andProjremarkEqualTo(String value) {
            addCriterion("projRemark =", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkNotEqualTo(String value) {
            addCriterion("projRemark <>", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkGreaterThan(String value) {
            addCriterion("projRemark >", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkGreaterThanOrEqualTo(String value) {
            addCriterion("projRemark >=", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkLessThan(String value) {
            addCriterion("projRemark <", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkLessThanOrEqualTo(String value) {
            addCriterion("projRemark <=", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkLike(String value) {
            addCriterion("projRemark like", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkNotLike(String value) {
            addCriterion("projRemark not like", value, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkIn(List<String> values) {
            addCriterion("projRemark in", values, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkNotIn(List<String> values) {
            addCriterion("projRemark not in", values, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkBetween(String value1, String value2) {
            addCriterion("projRemark between", value1, value2, "projremark");
            return (Criteria) this;
        }

        public Criteria andProjremarkNotBetween(String value1, String value2) {
            addCriterion("projRemark not between", value1, value2, "projremark");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isDelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isDelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Integer value) {
            addCriterion("isDelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Integer value) {
            addCriterion("isDelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Integer value) {
            addCriterion("isDelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("isDelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Integer value) {
            addCriterion("isDelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Integer value) {
            addCriterion("isDelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Integer> values) {
            addCriterion("isDelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Integer> values) {
            addCriterion("isDelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Integer value1, Integer value2) {
            addCriterion("isDelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("isDelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andFilenameIsNull() {
            addCriterion("fileName is null");
            return (Criteria) this;
        }

        public Criteria andFilenameIsNotNull() {
            addCriterion("fileName is not null");
            return (Criteria) this;
        }

        public Criteria andFilenameEqualTo(String value) {
            addCriterion("fileName =", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameNotEqualTo(String value) {
            addCriterion("fileName <>", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameGreaterThan(String value) {
            addCriterion("fileName >", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameGreaterThanOrEqualTo(String value) {
            addCriterion("fileName >=", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameLessThan(String value) {
            addCriterion("fileName <", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameLessThanOrEqualTo(String value) {
            addCriterion("fileName <=", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameLike(String value) {
            addCriterion("fileName like", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameNotLike(String value) {
            addCriterion("fileName not like", value, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameIn(List<String> values) {
            addCriterion("fileName in", values, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameNotIn(List<String> values) {
            addCriterion("fileName not in", values, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameBetween(String value1, String value2) {
            addCriterion("fileName between", value1, value2, "filename");
            return (Criteria) this;
        }

        public Criteria andFilenameNotBetween(String value1, String value2) {
            addCriterion("fileName not between", value1, value2, "filename");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeIsNull() {
            addCriterion("proProvinceCode is null");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeIsNotNull() {
            addCriterion("proProvinceCode is not null");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeEqualTo(String value) {
            addCriterion("proProvinceCode =", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeNotEqualTo(String value) {
            addCriterion("proProvinceCode <>", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeGreaterThan(String value) {
            addCriterion("proProvinceCode >", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeGreaterThanOrEqualTo(String value) {
            addCriterion("proProvinceCode >=", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeLessThan(String value) {
            addCriterion("proProvinceCode <", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeLessThanOrEqualTo(String value) {
            addCriterion("proProvinceCode <=", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeLike(String value) {
            addCriterion("proProvinceCode like", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeNotLike(String value) {
            addCriterion("proProvinceCode not like", value, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeIn(List<String> values) {
            addCriterion("proProvinceCode in", values, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeNotIn(List<String> values) {
            addCriterion("proProvinceCode not in", values, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeBetween(String value1, String value2) {
            addCriterion("proProvinceCode between", value1, value2, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProprovincecodeNotBetween(String value1, String value2) {
            addCriterion("proProvinceCode not between", value1, value2, "proprovincecode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeIsNull() {
            addCriterion("proCityCode is null");
            return (Criteria) this;
        }

        public Criteria andProcitycodeIsNotNull() {
            addCriterion("proCityCode is not null");
            return (Criteria) this;
        }

        public Criteria andProcitycodeEqualTo(String value) {
            addCriterion("proCityCode =", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeNotEqualTo(String value) {
            addCriterion("proCityCode <>", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeGreaterThan(String value) {
            addCriterion("proCityCode >", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeGreaterThanOrEqualTo(String value) {
            addCriterion("proCityCode >=", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeLessThan(String value) {
            addCriterion("proCityCode <", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeLessThanOrEqualTo(String value) {
            addCriterion("proCityCode <=", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeLike(String value) {
            addCriterion("proCityCode like", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeNotLike(String value) {
            addCriterion("proCityCode not like", value, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeIn(List<String> values) {
            addCriterion("proCityCode in", values, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeNotIn(List<String> values) {
            addCriterion("proCityCode not in", values, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeBetween(String value1, String value2) {
            addCriterion("proCityCode between", value1, value2, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProcitycodeNotBetween(String value1, String value2) {
            addCriterion("proCityCode not between", value1, value2, "procitycode");
            return (Criteria) this;
        }

        public Criteria andProareacodeIsNull() {
            addCriterion("proAreaCode is null");
            return (Criteria) this;
        }

        public Criteria andProareacodeIsNotNull() {
            addCriterion("proAreaCode is not null");
            return (Criteria) this;
        }

        public Criteria andProareacodeEqualTo(String value) {
            addCriterion("proAreaCode =", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeNotEqualTo(String value) {
            addCriterion("proAreaCode <>", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeGreaterThan(String value) {
            addCriterion("proAreaCode >", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeGreaterThanOrEqualTo(String value) {
            addCriterion("proAreaCode >=", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeLessThan(String value) {
            addCriterion("proAreaCode <", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeLessThanOrEqualTo(String value) {
            addCriterion("proAreaCode <=", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeLike(String value) {
            addCriterion("proAreaCode like", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeNotLike(String value) {
            addCriterion("proAreaCode not like", value, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeIn(List<String> values) {
            addCriterion("proAreaCode in", values, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeNotIn(List<String> values) {
            addCriterion("proAreaCode not in", values, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeBetween(String value1, String value2) {
            addCriterion("proAreaCode between", value1, value2, "proareacode");
            return (Criteria) this;
        }

        public Criteria andProareacodeNotBetween(String value1, String value2) {
            addCriterion("proAreaCode not between", value1, value2, "proareacode");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNull() {
            addCriterion("platformId is null");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNotNull() {
            addCriterion("platformId is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformidEqualTo(Integer value) {
            addCriterion("platformId =", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotEqualTo(Integer value) {
            addCriterion("platformId <>", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThan(Integer value) {
            addCriterion("platformId >", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThanOrEqualTo(Integer value) {
            addCriterion("platformId >=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThan(Integer value) {
            addCriterion("platformId <", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThanOrEqualTo(Integer value) {
            addCriterion("platformId <=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIn(List<Integer> values) {
            addCriterion("platformId in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotIn(List<Integer> values) {
            addCriterion("platformId not in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidBetween(Integer value1, Integer value2) {
            addCriterion("platformId between", value1, value2, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotBetween(Integer value1, Integer value2) {
            addCriterion("platformId not between", value1, value2, "platformid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}