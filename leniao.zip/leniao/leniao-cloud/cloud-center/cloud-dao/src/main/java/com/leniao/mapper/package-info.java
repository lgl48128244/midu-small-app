/**
 * @author guoliang.li
 * @date 2019/12/23 9:27
 * @description TODO 表mapper接口
 */
package com.leniao.mapper;