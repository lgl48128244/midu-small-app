package com.leniao.mapper;

import com.leniao.model.dto.BaseBusinessExDTO;
import com.leniao.model.vo.Page;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author guoliang.li
 * @date 2019/12/27 13:40
 * @description TODO
 */
public interface BussinessExMapper {

    List<BaseBusinessExDTO.BusinessExSearchList> selectErrorSearchList( BaseBusinessExDTO.BusinessExSearchReq req);

    BaseBusinessExDTO.BusinessExSearchDetail selectErrorSearchDetail(@Param("id") Long id);

    BaseBusinessExDTO.BusinessExHandlerDetail selectErrorHandlerDetail(@Param("id") Long id);

    BaseBusinessExDTO.BusinessExExamineDetail selectErrorExamineDetail(@Param("id") Long id);

    List<BaseBusinessExDTO.BusinessExStatisticsList> selectErrorStatisticsList(@Param("req") BaseBusinessExDTO.BusinessExStatisticsReq req, @Param("userGrade") Integer userGrade);

    List<Integer> selectByOverLookName(BaseBusinessExDTO.BusinessExSearchReq req);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsAgencyList(Page page);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryList(Page page);

    List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListByNormalUser(@Param("userId") Integer userId, @Param("projIds") List<Long> projIdsAboutUser);

    List<BaseBusinessExDTO.BusinessExHomeRollingList> selectErrorHomeRollingListBySpecifyUser(BaseBusinessExDTO.BusinessExRollingReq req);

    List<BaseBusinessExDTO.BusinessExCuoFengList> selectErrorCuoFengList(@Param("unitId") Integer unitId);

    /**
     * 今日单位数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayUnitCount(@Param("list") List<Long> projIdsAboutUser);

    /**
     * 今日设备数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayDeviceCount(@Param("list")List<Long> projIdsAboutUser);

    /**
     * 今日企业已申报数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectTodayDeclareCount(@Param("list")List<Long> projIdsAboutUser);

    /**
     * 昨日单位数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayUnitCount(@Param("list") List<Long> projIdsAboutUser);

    /**
     * 昨日设备数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayDeviceCount(List<Long> projIdsAboutUser);

    /**
     * 昨日企业已申报数量
     * @return int
     * @param projIdsAboutUser
     */
    int selectYesTodayDeclareCount(List<Long> projIdsAboutUser);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyByAreaCode(@Param("userGrade") Integer userGrade,@Param("provinceCode")  String provinceCode,
                                                                                  @Param("cityCode") String cityCode,@Param("areaCode")  String areaCode);

    /**
     * 全国账号查看首页异常统计柱状图
     * @param platformId
     * @return
     */
    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyErrCountByCountryUser(Integer platformId);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyErrCountByProvinceUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyErrCountByProvinceZXSUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyErrCountByCityUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode, @Param("cityCode")String cityCode);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectAgencyErrCountByCityZXSUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode, @Param("cityCode")String cityCode);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectUnitErrCountByAreaUser(@Param("projIds") List<Long> projIds);

    Integer findRootPointDevIdpkOfUnit(Integer unitId);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryListByCountryUser(Integer platformId);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryListByProZXSUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryListBYCityUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode,@Param("cityCode") String cityCode);

    List<BaseBusinessExDTO.BusinessExStatisticsIndustryList> selectErrorStatisticsIndustryListBYAreaUser(@Param("platformId") Integer platformId, @Param("provinceCode") String provinceCode,@Param("cityCode") String cityCode, @Param("areaCode") String areaCode);

    List<BaseBusinessExDTO.BusinessExStatisticsAgencyList> selectErrorStatisticsProjectList(@Param("projIds") List<Long> projIds);
}
