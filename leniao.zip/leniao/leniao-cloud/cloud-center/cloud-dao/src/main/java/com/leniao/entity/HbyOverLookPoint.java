package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;

@ToString
@TableName("hby_overlookpoint")
public class HbyOverLookPoint extends BaseEntity {

    private Long id;

    private Integer unitId;

    private String overLookName;

    private Integer devGroupId;

    private Integer isDemoBox;

    private String devUsing;

    private String remark;

    private Integer pointType;

    private Integer pollDevPower;

    private Integer pollDevRatedVoltg;

    private Integer pollDevPowerSillVal;

    private Integer pollDevPowerLiveTime;

    private Integer pollDevEleSillVal;

    private Integer pollDevEleLiveTime;

    private Integer pollDevType;

    private Integer conDevPower;

    private Integer conDevRatedVoltg;

    private Integer conDevPowerSillVal;

    private Integer conDevPowerLiveTime;

    private Integer conDevEleSillVal;

    private Integer conDevEleLiveTime;

    private Integer conDevType;

    private Integer platformId;

    private Date createTime;

    private String createUser;

    private Date updateTime;

    private String updateUser;

    private Integer deleted;

    private Integer version;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public String getOverLookName() {
        return overLookName;
    }

    public void setOverLookName(String overLookName) {
        this.overLookName = overLookName;
    }

    public Integer getDevGroupId() {
        return devGroupId;
    }

    public void setDevGroupId(Integer devGroupId) {
        this.devGroupId = devGroupId;
    }

    public Integer getIsDemoBox() {
        return isDemoBox;
    }

    public void setIsDemoBox(Integer isDemoBox) {
        this.isDemoBox = isDemoBox;
    }

    public String getDevUsing() {
        return devUsing;
    }

    public void setDevUsing(String devUsing) {
        this.devUsing = devUsing;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getPointType() {
        return pointType;
    }

    public void setPointType(Integer pointType) {
        this.pointType = pointType;
    }

    public Integer getPollDevPower() {
        return pollDevPower;
    }

    public void setPollDevPower(Integer pollDevPower) {
        this.pollDevPower = pollDevPower;
    }

    public Integer getPollDevRatedVoltg() {
        return pollDevRatedVoltg;
    }

    public void setPollDevRatedVoltg(Integer pollDevRatedVoltg) {
        this.pollDevRatedVoltg = pollDevRatedVoltg;
    }

    public Integer getPollDevPowerSillVal() {
        return pollDevPowerSillVal;
    }

    public void setPollDevPowerSillVal(Integer pollDevPowerSillVal) {
        this.pollDevPowerSillVal = pollDevPowerSillVal;
    }

    public Integer getPollDevPowerLiveTime() {
        return pollDevPowerLiveTime;
    }

    public void setPollDevPowerLiveTime(Integer pollDevPowerLiveTime) {
        this.pollDevPowerLiveTime = pollDevPowerLiveTime;
    }

    public Integer getPollDevEleSillVal() {
        return pollDevEleSillVal;
    }

    public void setPollDevEleSillVal(Integer pollDevEleSillVal) {
        this.pollDevEleSillVal = pollDevEleSillVal;
    }

    public Integer getPollDevEleLiveTime() {
        return pollDevEleLiveTime;
    }

    public void setPollDevEleLiveTime(Integer pollDevEleLiveTime) {
        this.pollDevEleLiveTime = pollDevEleLiveTime;
    }

    public Integer getPollDevType() {
        return pollDevType;
    }

    public void setPollDevType(Integer pollDevType) {
        this.pollDevType = pollDevType;
    }

    public Integer getConDevPower() {
        return conDevPower;
    }

    public void setConDevPower(Integer conDevPower) {
        this.conDevPower = conDevPower;
    }

    public Integer getConDevRatedVoltg() {
        return conDevRatedVoltg;
    }

    public void setConDevRatedVoltg(Integer conDevRatedVoltg) {
        this.conDevRatedVoltg = conDevRatedVoltg;
    }

    public Integer getConDevPowerSillVal() {
        return conDevPowerSillVal;
    }

    public void setConDevPowerSillVal(Integer conDevPowerSillVal) {
        this.conDevPowerSillVal = conDevPowerSillVal;
    }

    public Integer getConDevPowerLiveTime() {
        return conDevPowerLiveTime;
    }

    public void setConDevPowerLiveTime(Integer conDevPowerLiveTime) {
        this.conDevPowerLiveTime = conDevPowerLiveTime;
    }

    public Integer getConDevEleSillVal() {
        return conDevEleSillVal;
    }

    public void setConDevEleSillVal(Integer conDevEleSillVal) {
        this.conDevEleSillVal = conDevEleSillVal;
    }

    public Integer getConDevEleLiveTime() {
        return conDevEleLiveTime;
    }

    public void setConDevEleLiveTime(Integer conDevEleLiveTime) {
        this.conDevEleLiveTime = conDevEleLiveTime;
    }

    public Integer getConDevType() {
        return conDevType;
    }

    public void setConDevType(Integer conDevType) {
        this.conDevType = conDevType;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    @Override
    public Date getCreateTime() {
        return createTime;
    }

    @Override
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String getCreateUser() {
        return createUser;
    }

    @Override
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    @Override
    public Date getUpdateTime() {
        return updateTime;
    }

    @Override
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String getUpdateUser() {
        return updateUser;
    }

    @Override
    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    @Override
    public Integer getDeleted() {
        return deleted;
    }

    @Override
    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    @Override
    public Integer getVersion() {
        return version;
    }

    @Override
    public void setVersion(Integer version) {
        this.version = version;
    }
}