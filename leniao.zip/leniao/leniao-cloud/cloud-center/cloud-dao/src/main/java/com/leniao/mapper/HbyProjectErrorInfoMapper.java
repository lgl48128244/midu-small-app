package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyProjectErrorInfo;
import com.leniao.entity.HbyProjectErrorInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyProjectErrorInfoMapper extends BaseMapper<HbyProjectErrorInfo> {
    long countByExample(HbyProjectErrorInfoExample example);

    int deleteByExample(HbyProjectErrorInfoExample example);

    int deleteByPrimaryKey(Long id);

    int insertSelective(HbyProjectErrorInfo record);

    List<HbyProjectErrorInfo> selectByExample(HbyProjectErrorInfoExample example);

    HbyProjectErrorInfo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyProjectErrorInfo record, @Param("example") HbyProjectErrorInfoExample example);

    int updateByExample(@Param("record") HbyProjectErrorInfo record, @Param("example") HbyProjectErrorInfoExample example);

    int updateByPrimaryKeySelective(HbyProjectErrorInfo record);

    int updateByPrimaryKey(HbyProjectErrorInfo record);
}