package com.leniao.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class TblngridGradehistoryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblngridGradehistoryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("Id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("Id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("Id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("Id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("Id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("Id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("Id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("Id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("Id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("Id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("Id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("Id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andProjidIsNull() {
            addCriterion("projId is null");
            return (Criteria) this;
        }

        public Criteria andProjidIsNotNull() {
            addCriterion("projId is not null");
            return (Criteria) this;
        }

        public Criteria andProjidEqualTo(String value) {
            addCriterion("projId =", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotEqualTo(String value) {
            addCriterion("projId <>", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThan(String value) {
            addCriterion("projId >", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThanOrEqualTo(String value) {
            addCriterion("projId >=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThan(String value) {
            addCriterion("projId <", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThanOrEqualTo(String value) {
            addCriterion("projId <=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLike(String value) {
            addCriterion("projId like", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotLike(String value) {
            addCriterion("projId not like", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidIn(List<String> values) {
            addCriterion("projId in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotIn(List<String> values) {
            addCriterion("projId not in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidBetween(String value1, String value2) {
            addCriterion("projId between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotBetween(String value1, String value2) {
            addCriterion("projId not between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andUnitidIsNull() {
            addCriterion("unitId is null");
            return (Criteria) this;
        }

        public Criteria andUnitidIsNotNull() {
            addCriterion("unitId is not null");
            return (Criteria) this;
        }

        public Criteria andUnitidEqualTo(Integer value) {
            addCriterion("unitId =", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotEqualTo(Integer value) {
            addCriterion("unitId <>", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidGreaterThan(Integer value) {
            addCriterion("unitId >", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidGreaterThanOrEqualTo(Integer value) {
            addCriterion("unitId >=", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidLessThan(Integer value) {
            addCriterion("unitId <", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidLessThanOrEqualTo(Integer value) {
            addCriterion("unitId <=", value, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidIn(List<Integer> values) {
            addCriterion("unitId in", values, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotIn(List<Integer> values) {
            addCriterion("unitId not in", values, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidBetween(Integer value1, Integer value2) {
            addCriterion("unitId between", value1, value2, "unitid");
            return (Criteria) this;
        }

        public Criteria andUnitidNotBetween(Integer value1, Integer value2) {
            addCriterion("unitId not between", value1, value2, "unitid");
            return (Criteria) this;
        }

        public Criteria andProcdateIsNull() {
            addCriterion("procDate is null");
            return (Criteria) this;
        }

        public Criteria andProcdateIsNotNull() {
            addCriterion("procDate is not null");
            return (Criteria) this;
        }

        public Criteria andProcdateEqualTo(Date value) {
            addCriterionForJDBCDate("procDate =", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("procDate <>", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateGreaterThan(Date value) {
            addCriterionForJDBCDate("procDate >", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("procDate >=", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateLessThan(Date value) {
            addCriterionForJDBCDate("procDate <", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("procDate <=", value, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateIn(List<Date> values) {
            addCriterionForJDBCDate("procDate in", values, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("procDate not in", values, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("procDate between", value1, value2, "procdate");
            return (Criteria) this;
        }

        public Criteria andProcdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("procDate not between", value1, value2, "procdate");
            return (Criteria) this;
        }

        public Criteria andWarnwiIsNull() {
            addCriterion("warnwi is null");
            return (Criteria) this;
        }

        public Criteria andWarnwiIsNotNull() {
            addCriterion("warnwi is not null");
            return (Criteria) this;
        }

        public Criteria andWarnwiEqualTo(BigDecimal value) {
            addCriterion("warnwi =", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiNotEqualTo(BigDecimal value) {
            addCriterion("warnwi <>", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiGreaterThan(BigDecimal value) {
            addCriterion("warnwi >", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("warnwi >=", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiLessThan(BigDecimal value) {
            addCriterion("warnwi <", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("warnwi <=", value, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiIn(List<BigDecimal> values) {
            addCriterion("warnwi in", values, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiNotIn(List<BigDecimal> values) {
            addCriterion("warnwi not in", values, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("warnwi between", value1, value2, "warnwi");
            return (Criteria) this;
        }

        public Criteria andWarnwiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("warnwi not between", value1, value2, "warnwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiIsNull() {
            addCriterion("faultwi is null");
            return (Criteria) this;
        }

        public Criteria andFaultwiIsNotNull() {
            addCriterion("faultwi is not null");
            return (Criteria) this;
        }

        public Criteria andFaultwiEqualTo(BigDecimal value) {
            addCriterion("faultwi =", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiNotEqualTo(BigDecimal value) {
            addCriterion("faultwi <>", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiGreaterThan(BigDecimal value) {
            addCriterion("faultwi >", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("faultwi >=", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiLessThan(BigDecimal value) {
            addCriterion("faultwi <", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("faultwi <=", value, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiIn(List<BigDecimal> values) {
            addCriterion("faultwi in", values, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiNotIn(List<BigDecimal> values) {
            addCriterion("faultwi not in", values, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("faultwi between", value1, value2, "faultwi");
            return (Criteria) this;
        }

        public Criteria andFaultwiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("faultwi not between", value1, value2, "faultwi");
            return (Criteria) this;
        }

        public Criteria andServicewiIsNull() {
            addCriterion("servicewi is null");
            return (Criteria) this;
        }

        public Criteria andServicewiIsNotNull() {
            addCriterion("servicewi is not null");
            return (Criteria) this;
        }

        public Criteria andServicewiEqualTo(BigDecimal value) {
            addCriterion("servicewi =", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiNotEqualTo(BigDecimal value) {
            addCriterion("servicewi <>", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiGreaterThan(BigDecimal value) {
            addCriterion("servicewi >", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("servicewi >=", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiLessThan(BigDecimal value) {
            addCriterion("servicewi <", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("servicewi <=", value, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiIn(List<BigDecimal> values) {
            addCriterion("servicewi in", values, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiNotIn(List<BigDecimal> values) {
            addCriterion("servicewi not in", values, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("servicewi between", value1, value2, "servicewi");
            return (Criteria) this;
        }

        public Criteria andServicewiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("servicewi not between", value1, value2, "servicewi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiIsNull() {
            addCriterion("feedbackwi is null");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiIsNotNull() {
            addCriterion("feedbackwi is not null");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiEqualTo(BigDecimal value) {
            addCriterion("feedbackwi =", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiNotEqualTo(BigDecimal value) {
            addCriterion("feedbackwi <>", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiGreaterThan(BigDecimal value) {
            addCriterion("feedbackwi >", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("feedbackwi >=", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiLessThan(BigDecimal value) {
            addCriterion("feedbackwi <", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("feedbackwi <=", value, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiIn(List<BigDecimal> values) {
            addCriterion("feedbackwi in", values, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiNotIn(List<BigDecimal> values) {
            addCriterion("feedbackwi not in", values, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("feedbackwi between", value1, value2, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andFeedbackwiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("feedbackwi not between", value1, value2, "feedbackwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiIsNull() {
            addCriterion("operationwi is null");
            return (Criteria) this;
        }

        public Criteria andOperationwiIsNotNull() {
            addCriterion("operationwi is not null");
            return (Criteria) this;
        }

        public Criteria andOperationwiEqualTo(BigDecimal value) {
            addCriterion("operationwi =", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiNotEqualTo(BigDecimal value) {
            addCriterion("operationwi <>", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiGreaterThan(BigDecimal value) {
            addCriterion("operationwi >", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("operationwi >=", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiLessThan(BigDecimal value) {
            addCriterion("operationwi <", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("operationwi <=", value, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiIn(List<BigDecimal> values) {
            addCriterion("operationwi in", values, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiNotIn(List<BigDecimal> values) {
            addCriterion("operationwi not in", values, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("operationwi between", value1, value2, "operationwi");
            return (Criteria) this;
        }

        public Criteria andOperationwiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("operationwi not between", value1, value2, "operationwi");
            return (Criteria) this;
        }

        public Criteria andWarncountIsNull() {
            addCriterion("warnCount is null");
            return (Criteria) this;
        }

        public Criteria andWarncountIsNotNull() {
            addCriterion("warnCount is not null");
            return (Criteria) this;
        }

        public Criteria andWarncountEqualTo(Integer value) {
            addCriterion("warnCount =", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountNotEqualTo(Integer value) {
            addCriterion("warnCount <>", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountGreaterThan(Integer value) {
            addCriterion("warnCount >", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountGreaterThanOrEqualTo(Integer value) {
            addCriterion("warnCount >=", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountLessThan(Integer value) {
            addCriterion("warnCount <", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountLessThanOrEqualTo(Integer value) {
            addCriterion("warnCount <=", value, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountIn(List<Integer> values) {
            addCriterion("warnCount in", values, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountNotIn(List<Integer> values) {
            addCriterion("warnCount not in", values, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountBetween(Integer value1, Integer value2) {
            addCriterion("warnCount between", value1, value2, "warncount");
            return (Criteria) this;
        }

        public Criteria andWarncountNotBetween(Integer value1, Integer value2) {
            addCriterion("warnCount not between", value1, value2, "warncount");
            return (Criteria) this;
        }

        public Criteria andFaultcountIsNull() {
            addCriterion("faultCount is null");
            return (Criteria) this;
        }

        public Criteria andFaultcountIsNotNull() {
            addCriterion("faultCount is not null");
            return (Criteria) this;
        }

        public Criteria andFaultcountEqualTo(Integer value) {
            addCriterion("faultCount =", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountNotEqualTo(Integer value) {
            addCriterion("faultCount <>", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountGreaterThan(Integer value) {
            addCriterion("faultCount >", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("faultCount >=", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountLessThan(Integer value) {
            addCriterion("faultCount <", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountLessThanOrEqualTo(Integer value) {
            addCriterion("faultCount <=", value, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountIn(List<Integer> values) {
            addCriterion("faultCount in", values, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountNotIn(List<Integer> values) {
            addCriterion("faultCount not in", values, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountBetween(Integer value1, Integer value2) {
            addCriterion("faultCount between", value1, value2, "faultcount");
            return (Criteria) this;
        }

        public Criteria andFaultcountNotBetween(Integer value1, Integer value2) {
            addCriterion("faultCount not between", value1, value2, "faultcount");
            return (Criteria) this;
        }

        public Criteria andServicecountIsNull() {
            addCriterion("serviceCount is null");
            return (Criteria) this;
        }

        public Criteria andServicecountIsNotNull() {
            addCriterion("serviceCount is not null");
            return (Criteria) this;
        }

        public Criteria andServicecountEqualTo(Integer value) {
            addCriterion("serviceCount =", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountNotEqualTo(Integer value) {
            addCriterion("serviceCount <>", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountGreaterThan(Integer value) {
            addCriterion("serviceCount >", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountGreaterThanOrEqualTo(Integer value) {
            addCriterion("serviceCount >=", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountLessThan(Integer value) {
            addCriterion("serviceCount <", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountLessThanOrEqualTo(Integer value) {
            addCriterion("serviceCount <=", value, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountIn(List<Integer> values) {
            addCriterion("serviceCount in", values, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountNotIn(List<Integer> values) {
            addCriterion("serviceCount not in", values, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountBetween(Integer value1, Integer value2) {
            addCriterion("serviceCount between", value1, value2, "servicecount");
            return (Criteria) this;
        }

        public Criteria andServicecountNotBetween(Integer value1, Integer value2) {
            addCriterion("serviceCount not between", value1, value2, "servicecount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountIsNull() {
            addCriterion("feedbackCount is null");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountIsNotNull() {
            addCriterion("feedbackCount is not null");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountEqualTo(Integer value) {
            addCriterion("feedbackCount =", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountNotEqualTo(Integer value) {
            addCriterion("feedbackCount <>", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountGreaterThan(Integer value) {
            addCriterion("feedbackCount >", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("feedbackCount >=", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountLessThan(Integer value) {
            addCriterion("feedbackCount <", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountLessThanOrEqualTo(Integer value) {
            addCriterion("feedbackCount <=", value, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountIn(List<Integer> values) {
            addCriterion("feedbackCount in", values, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountNotIn(List<Integer> values) {
            addCriterion("feedbackCount not in", values, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountBetween(Integer value1, Integer value2) {
            addCriterion("feedbackCount between", value1, value2, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andFeedbackcountNotBetween(Integer value1, Integer value2) {
            addCriterion("feedbackCount not between", value1, value2, "feedbackcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountIsNull() {
            addCriterion("operationCount is null");
            return (Criteria) this;
        }

        public Criteria andOperationcountIsNotNull() {
            addCriterion("operationCount is not null");
            return (Criteria) this;
        }

        public Criteria andOperationcountEqualTo(Integer value) {
            addCriterion("operationCount =", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountNotEqualTo(Integer value) {
            addCriterion("operationCount <>", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountGreaterThan(Integer value) {
            addCriterion("operationCount >", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("operationCount >=", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountLessThan(Integer value) {
            addCriterion("operationCount <", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountLessThanOrEqualTo(Integer value) {
            addCriterion("operationCount <=", value, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountIn(List<Integer> values) {
            addCriterion("operationCount in", values, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountNotIn(List<Integer> values) {
            addCriterion("operationCount not in", values, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountBetween(Integer value1, Integer value2) {
            addCriterion("operationCount between", value1, value2, "operationcount");
            return (Criteria) this;
        }

        public Criteria andOperationcountNotBetween(Integer value1, Integer value2) {
            addCriterion("operationCount not between", value1, value2, "operationcount");
            return (Criteria) this;
        }

        public Criteria andWarngradeIsNull() {
            addCriterion("warngrade is null");
            return (Criteria) this;
        }

        public Criteria andWarngradeIsNotNull() {
            addCriterion("warngrade is not null");
            return (Criteria) this;
        }

        public Criteria andWarngradeEqualTo(BigDecimal value) {
            addCriterion("warngrade =", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeNotEqualTo(BigDecimal value) {
            addCriterion("warngrade <>", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeGreaterThan(BigDecimal value) {
            addCriterion("warngrade >", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("warngrade >=", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeLessThan(BigDecimal value) {
            addCriterion("warngrade <", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("warngrade <=", value, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeIn(List<BigDecimal> values) {
            addCriterion("warngrade in", values, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeNotIn(List<BigDecimal> values) {
            addCriterion("warngrade not in", values, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("warngrade between", value1, value2, "warngrade");
            return (Criteria) this;
        }

        public Criteria andWarngradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("warngrade not between", value1, value2, "warngrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeIsNull() {
            addCriterion("faultgrade is null");
            return (Criteria) this;
        }

        public Criteria andFaultgradeIsNotNull() {
            addCriterion("faultgrade is not null");
            return (Criteria) this;
        }

        public Criteria andFaultgradeEqualTo(BigDecimal value) {
            addCriterion("faultgrade =", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeNotEqualTo(BigDecimal value) {
            addCriterion("faultgrade <>", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeGreaterThan(BigDecimal value) {
            addCriterion("faultgrade >", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("faultgrade >=", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeLessThan(BigDecimal value) {
            addCriterion("faultgrade <", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("faultgrade <=", value, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeIn(List<BigDecimal> values) {
            addCriterion("faultgrade in", values, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeNotIn(List<BigDecimal> values) {
            addCriterion("faultgrade not in", values, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("faultgrade between", value1, value2, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andFaultgradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("faultgrade not between", value1, value2, "faultgrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeIsNull() {
            addCriterion("servicegrade is null");
            return (Criteria) this;
        }

        public Criteria andServicegradeIsNotNull() {
            addCriterion("servicegrade is not null");
            return (Criteria) this;
        }

        public Criteria andServicegradeEqualTo(BigDecimal value) {
            addCriterion("servicegrade =", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeNotEqualTo(BigDecimal value) {
            addCriterion("servicegrade <>", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeGreaterThan(BigDecimal value) {
            addCriterion("servicegrade >", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("servicegrade >=", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeLessThan(BigDecimal value) {
            addCriterion("servicegrade <", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("servicegrade <=", value, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeIn(List<BigDecimal> values) {
            addCriterion("servicegrade in", values, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeNotIn(List<BigDecimal> values) {
            addCriterion("servicegrade not in", values, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("servicegrade between", value1, value2, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andServicegradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("servicegrade not between", value1, value2, "servicegrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeIsNull() {
            addCriterion("feedbackgrade is null");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeIsNotNull() {
            addCriterion("feedbackgrade is not null");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeEqualTo(BigDecimal value) {
            addCriterion("feedbackgrade =", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeNotEqualTo(BigDecimal value) {
            addCriterion("feedbackgrade <>", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeGreaterThan(BigDecimal value) {
            addCriterion("feedbackgrade >", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("feedbackgrade >=", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeLessThan(BigDecimal value) {
            addCriterion("feedbackgrade <", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("feedbackgrade <=", value, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeIn(List<BigDecimal> values) {
            addCriterion("feedbackgrade in", values, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeNotIn(List<BigDecimal> values) {
            addCriterion("feedbackgrade not in", values, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("feedbackgrade between", value1, value2, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andFeedbackgradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("feedbackgrade not between", value1, value2, "feedbackgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeIsNull() {
            addCriterion("operationgrade is null");
            return (Criteria) this;
        }

        public Criteria andOperationgradeIsNotNull() {
            addCriterion("operationgrade is not null");
            return (Criteria) this;
        }

        public Criteria andOperationgradeEqualTo(BigDecimal value) {
            addCriterion("operationgrade =", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeNotEqualTo(BigDecimal value) {
            addCriterion("operationgrade <>", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeGreaterThan(BigDecimal value) {
            addCriterion("operationgrade >", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("operationgrade >=", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeLessThan(BigDecimal value) {
            addCriterion("operationgrade <", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("operationgrade <=", value, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeIn(List<BigDecimal> values) {
            addCriterion("operationgrade in", values, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeNotIn(List<BigDecimal> values) {
            addCriterion("operationgrade not in", values, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("operationgrade between", value1, value2, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andOperationgradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("operationgrade not between", value1, value2, "operationgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeIsNull() {
            addCriterion("totalgrade is null");
            return (Criteria) this;
        }

        public Criteria andTotalgradeIsNotNull() {
            addCriterion("totalgrade is not null");
            return (Criteria) this;
        }

        public Criteria andTotalgradeEqualTo(BigDecimal value) {
            addCriterion("totalgrade =", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeNotEqualTo(BigDecimal value) {
            addCriterion("totalgrade <>", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeGreaterThan(BigDecimal value) {
            addCriterion("totalgrade >", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("totalgrade >=", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeLessThan(BigDecimal value) {
            addCriterion("totalgrade <", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("totalgrade <=", value, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeIn(List<BigDecimal> values) {
            addCriterion("totalgrade in", values, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeNotIn(List<BigDecimal> values) {
            addCriterion("totalgrade not in", values, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("totalgrade between", value1, value2, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andTotalgradeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("totalgrade not between", value1, value2, "totalgrade");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNull() {
            addCriterion("addtime is null");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNotNull() {
            addCriterion("addtime is not null");
            return (Criteria) this;
        }

        public Criteria andAddtimeEqualTo(Date value) {
            addCriterion("addtime =", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotEqualTo(Date value) {
            addCriterion("addtime <>", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThan(Date value) {
            addCriterion("addtime >", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("addtime >=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThan(Date value) {
            addCriterion("addtime <", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThanOrEqualTo(Date value) {
            addCriterion("addtime <=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeIn(List<Date> values) {
            addCriterion("addtime in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotIn(List<Date> values) {
            addCriterion("addtime not in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeBetween(Date value1, Date value2) {
            addCriterion("addtime between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotBetween(Date value1, Date value2) {
            addCriterion("addtime not between", value1, value2, "addtime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}