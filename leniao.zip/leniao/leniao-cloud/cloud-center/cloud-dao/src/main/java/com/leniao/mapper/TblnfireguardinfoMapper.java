package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.Tblnfireguardinfo;
import com.leniao.entity.TblnfireguardinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblnfireguardinfoMapper extends BaseMapper<Tblnfireguardinfo> {
    int countByExample(TblnfireguardinfoExample example);

    int deleteByExample(TblnfireguardinfoExample example);

    int deleteByPrimaryKey(Integer fireguardid);

    int insert(Tblnfireguardinfo record);

    int insertSelective(Tblnfireguardinfo record);

    List<Tblnfireguardinfo> selectByExample(TblnfireguardinfoExample example);

    Tblnfireguardinfo selectByPrimaryKey(Integer fireguardid);

    int updateByExampleSelective(@Param("record") Tblnfireguardinfo record, @Param("example") TblnfireguardinfoExample example);

    int updateByExample(@Param("record") Tblnfireguardinfo record, @Param("example") TblnfireguardinfoExample example);

    int updateByPrimaryKeySelective(Tblnfireguardinfo record);

    int updateByPrimaryKey(Tblnfireguardinfo record);
}