package com.leniao.mapper;

import com.leniao.model.dto.BaseAgencyDTO;

import java.util.List;

public interface AgencyMapper {

    List<BaseAgencyDTO.AgencyList> selectByBody(BaseAgencyDTO.AgencyReq req);
}