package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.TblnGroupAddress;
import com.leniao.entity.TblnGroupAddressExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblnGroupAddressMapper extends BaseMapper<TblnGroupAddress> {
    int countByExample(TblnGroupAddressExample example);

    int deleteByExample(TblnGroupAddressExample example);

    int deleteByPrimaryKey(String adid);

    int insert(TblnGroupAddress record);

    int insertSelective(TblnGroupAddress record);

    List<TblnGroupAddress> selectByExample(TblnGroupAddressExample example);

    TblnGroupAddress selectByPrimaryKey(String adid);

    int updateByExampleSelective(@Param("record") TblnGroupAddress record, @Param("example") TblnGroupAddressExample example);

    int updateByExample(@Param("record") TblnGroupAddress record, @Param("example") TblnGroupAddressExample example);

    int updateByPrimaryKeySelective(TblnGroupAddress record);

    int updateByPrimaryKey(TblnGroupAddress record);
}