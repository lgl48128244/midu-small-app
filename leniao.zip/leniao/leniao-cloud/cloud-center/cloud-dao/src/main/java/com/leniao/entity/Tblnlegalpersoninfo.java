package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

@TableName("tblnlegalpersoninfo")
@ToString
public class Tblnlegalpersoninfo {
    private Integer legalpersonid;

    private String legalpersonname;

    private String legalpersonphone;

    private String legalpersontel;

    private String legalremark;

    private Integer isdelete;

    private Integer userid;

    private Integer platformid;

    public Integer getLegalpersonid() {
        return legalpersonid;
    }

    public void setLegalpersonid(Integer legalpersonid) {
        this.legalpersonid = legalpersonid;
    }

    public String getLegalpersonname() {
        return legalpersonname;
    }

    public void setLegalpersonname(String legalpersonname) {
        this.legalpersonname = legalpersonname == null ? null : legalpersonname.trim();
    }

    public String getLegalpersonphone() {
        return legalpersonphone;
    }

    public void setLegalpersonphone(String legalpersonphone) {
        this.legalpersonphone = legalpersonphone == null ? null : legalpersonphone.trim();
    }

    public String getLegalpersontel() {
        return legalpersontel;
    }

    public void setLegalpersontel(String legalpersontel) {
        this.legalpersontel = legalpersontel == null ? null : legalpersontel.trim();
    }

    public String getLegalremark() {
        return legalremark;
    }

    public void setLegalremark(String legalremark) {
        this.legalremark = legalremark == null ? null : legalremark.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getPlatformid() {
        return platformid;
    }

    public void setPlatformid(Integer platformid) {
        this.platformid = platformid;
    }
}