package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyAgency;
import com.leniao.entity.HbyAgencyExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyAgencyMapper extends BaseMapper<HbyAgency> {
    long countByExample(HbyAgencyExample example);

    int deleteByExample(HbyAgencyExample example);

    int deleteByPrimaryKey(Long id);

    int insertSelective(HbyAgency record);

    List<HbyAgency> selectByExample(HbyAgencyExample example);

    HbyAgency selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyAgency record, @Param("example") HbyAgencyExample example);

    int updateByExample(@Param("record") HbyAgency record, @Param("example") HbyAgencyExample example);

    int updateByPrimaryKeySelective(HbyAgency record);

    int updateByPrimaryKey(HbyAgency record);
}