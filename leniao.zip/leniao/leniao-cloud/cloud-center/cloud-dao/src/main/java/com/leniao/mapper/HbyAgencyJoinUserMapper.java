package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyAgencyJoinUser;
import com.leniao.entity.HbyAgencyJoinUserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyAgencyJoinUserMapper extends BaseMapper<HbyAgencyJoinUser> {
    int countByExample(HbyAgencyJoinUserExample example);

    int deleteByExample(HbyAgencyJoinUserExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HbyAgencyJoinUser record);

    int insertSelective(HbyAgencyJoinUser record);

    List<HbyAgencyJoinUser> selectByExample(HbyAgencyJoinUserExample example);

    HbyAgencyJoinUser selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyAgencyJoinUser record, @Param("example") HbyAgencyJoinUserExample example);

    int updateByExample(@Param("record") HbyAgencyJoinUser record, @Param("example") HbyAgencyJoinUserExample example);

    int updateByPrimaryKeySelective(HbyAgencyJoinUser record);

    int updateByPrimaryKey(HbyAgencyJoinUser record);
}