package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyIndustry;
import com.leniao.entity.HbyIndustryExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyIndustryMapper extends BaseMapper<HbyIndustry> {
    long countByExample(HbyIndustryExample example);

    int deleteByExample(HbyIndustryExample example);

    int deleteByPrimaryKey(Long id);

    int insertSelective(HbyIndustry record);

    List<HbyIndustry> selectByExample(HbyIndustryExample example);

    HbyIndustry selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyIndustry record, @Param("example") HbyIndustryExample example);

    int updateByExample(@Param("record") HbyIndustry record, @Param("example") HbyIndustryExample example);

    int updateByPrimaryKeySelective(HbyIndustry record);

    int updateByPrimaryKey(HbyIndustry record);
}