package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.TbLnUserInfo;
import com.leniao.entity.TbLnUserInfoExample;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface TbLnUserInfoMapper extends BaseMapper<TbLnUserInfo> {

    long countByExample(TbLnUserInfoExample example);

    int deleteByExample(TbLnUserInfoExample example);

    int deleteByPrimaryKey(Integer userid);

    /**
     * 此方法用于返回用户自增主键id，不要删除
     * @param record
     * @return
     * haosw
     */
    int insert(TbLnUserInfo record);

    int insertSelective(TbLnUserInfo record);

    List<TbLnUserInfo> selectByExample(TbLnUserInfoExample example);

    TbLnUserInfo selectByPrimaryKey(Integer userid);

    int updateByExampleSelective(@Param("record") TbLnUserInfo record, @Param("example") TbLnUserInfoExample example);

    int updateByExample(@Param("record") TbLnUserInfo record, @Param("example") TbLnUserInfoExample example);

    int updateByPrimaryKeySelective(TbLnUserInfo record);

    int updateByPrimaryKey(TbLnUserInfo record);
}