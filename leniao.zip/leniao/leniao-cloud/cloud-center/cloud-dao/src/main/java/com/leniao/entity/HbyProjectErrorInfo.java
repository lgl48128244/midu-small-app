package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@ToString
@TableName("hby_project_errorinfo")
public class HbyProjectErrorInfo extends BaseEntity {

    private Integer unitId;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    private Long industryId;

    private Integer type;

    private Integer devIdpk;

    private String devSignature;

    private String overlookId;

    private Long planId;

    private Integer pollOrCon;

    private Date errorTime;

    private Date normalTime;

    private Integer dealStatus;

    private Integer errorEventType;

    private String errorDesc;

    private BigDecimal volChargeRatio;

    private BigDecimal eleChargeRatio;

    private Date pushTime;

    private Integer isPush;

    private String remark;

    private Integer checkUser;

    private String checkUserName;

    private Date checkTime;

    private Integer checkResult;

    private String checkDesc;

    private String fjUrl;

    private String fjDesc;

    private Integer verifyUser;

    private String verifyUserName;

    private Date verifyTime;

    private String verifySugg;

    private Integer verifyResult;

    private Integer rawErrid;

    private String rawNode;

    private Integer rawType;

    private BigDecimal rawValue;

    private String rawUnit;

    private String rawUuid;

    private Integer platformId;

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode == null ? null : areaCode.trim();
    }

    public Long getIndustryId() {
        return industryId;
    }

    public void setIndustryId(Long industryId) {
        this.industryId = industryId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(Integer devIdpk) {
        this.devIdpk = devIdpk;
    }

    public String getDevSignature() {
        return devSignature;
    }

    public void setDevSignature(String devSignature) {
        this.devSignature = devSignature == null ? null : devSignature.trim();
    }

    public String getOverlookId() {
        return overlookId;
    }

    public void setOverlookId(String overlookId) {
        this.overlookId = overlookId == null ? null : overlookId.trim();
    }

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }

    public Integer getPollOrCon() {
        return pollOrCon;
    }

    public void setPollOrCon(Integer pollOrCon) {
        this.pollOrCon = pollOrCon;
    }

    public Date getErrorTime() {
        return errorTime;
    }

    public void setErrorTime(Date errorTime) {
        this.errorTime = errorTime;
    }

    public Date getNormalTime() {
        return normalTime;
    }

    public void setNormalTime(Date normalTime) {
        this.normalTime = normalTime;
    }

    public Integer getDealStatus() {
        return dealStatus;
    }

    public void setDealStatus(Integer dealStatus) {
        this.dealStatus = dealStatus;
    }

    public Integer getErrorEventType() {
        return errorEventType;
    }

    public void setErrorEventType(Integer errorEventType) {
        this.errorEventType = errorEventType;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc == null ? null : errorDesc.trim();
    }

    public BigDecimal getVolChargeRatio() {
        return volChargeRatio;
    }

    public void setVolChargeRatio(BigDecimal volChargeRatio) {
        this.volChargeRatio = volChargeRatio;
    }

    public BigDecimal getEleChargeRatio() {
        return eleChargeRatio;
    }

    public void setEleChargeRatio(BigDecimal eleChargeRatio) {
        this.eleChargeRatio = eleChargeRatio;
    }

    public Date getPushTime() {
        return pushTime;
    }

    public void setPushTime(Date pushTime) {
        this.pushTime = pushTime;
    }

    public Integer getIsPush() {
        return isPush;
    }

    public void setIsPush(Integer isPush) {
        this.isPush = isPush;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(Integer checkUser) {
        this.checkUser = checkUser;
    }

    public String getCheckUserName() {
        return checkUserName;
    }

    public void setCheckUserName(String checkUserName) {
        this.checkUserName = checkUserName == null ? null : checkUserName.trim();
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Integer getCheckResult() {
        return checkResult;
    }

    public void setCheckResult(Integer checkResult) {
        this.checkResult = checkResult;
    }

    public String getCheckDesc() {
        return checkDesc;
    }

    public void setCheckDesc(String checkDesc) {
        this.checkDesc = checkDesc == null ? null : checkDesc.trim();
    }

    public String getFjUrl() {
        return fjUrl;
    }

    public void setFjUrl(String fjUrl) {
        this.fjUrl = fjUrl == null ? null : fjUrl.trim();
    }

    public String getFjDesc() {
        return fjDesc;
    }

    public void setFjDesc(String fjDesc) {
        this.fjDesc = fjDesc == null ? null : fjDesc.trim();
    }

    public Integer getVerifyUser() {
        return verifyUser;
    }

    public void setVerifyUser(Integer verifyUser) {
        this.verifyUser = verifyUser;
    }

    public String getVerifyUserName() {
        return verifyUserName;
    }

    public void setVerifyUserName(String verifyUserName) {
        this.verifyUserName = verifyUserName == null ? null : verifyUserName.trim();
    }

    public Date getVerifyTime() {
        return verifyTime;
    }

    public void setVerifyTime(Date verifyTime) {
        this.verifyTime = verifyTime;
    }

    public String getVerifySugg() {
        return verifySugg;
    }

    public void setVerifySugg(String verifySugg) {
        this.verifySugg = verifySugg == null ? null : verifySugg.trim();
    }

    public Integer getVerifyResult() {
        return verifyResult;
    }

    public void setVerifyResult(Integer verifyResult) {
        this.verifyResult = verifyResult;
    }

    public Integer getRawErrid() {
        return rawErrid;
    }

    public void setRawErrid(Integer rawErrid) {
        this.rawErrid = rawErrid;
    }

    public String getRawNode() {
        return rawNode;
    }

    public void setRawNode(String rawNode) {
        this.rawNode = rawNode == null ? null : rawNode.trim();
    }

    public Integer getRawType() {
        return rawType;
    }

    public void setRawType(Integer rawType) {
        this.rawType = rawType;
    }

    public BigDecimal getRawValue() {
        return rawValue;
    }

    public void setRawValue(BigDecimal rawValue) {
        this.rawValue = rawValue;
    }

    public String getRawUnit() {
        return rawUnit;
    }

    public void setRawUnit(String rawUnit) {
        this.rawUnit = rawUnit == null ? null : rawUnit.trim();
    }

    public String getRawUuid() {
        return rawUuid;
    }

    public void setRawUuid(String rawUuid) {
        this.rawUuid = rawUuid == null ? null : rawUuid.trim();
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }
}