package com.leniao.entity;

import java.util.ArrayList;
import java.util.List;

public class TblnlegalpersoninfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblnlegalpersoninfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLegalpersonidIsNull() {
            addCriterion("legalPersonId is null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidIsNotNull() {
            addCriterion("legalPersonId is not null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidEqualTo(Integer value) {
            addCriterion("legalPersonId =", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotEqualTo(Integer value) {
            addCriterion("legalPersonId <>", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidGreaterThan(Integer value) {
            addCriterion("legalPersonId >", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidGreaterThanOrEqualTo(Integer value) {
            addCriterion("legalPersonId >=", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidLessThan(Integer value) {
            addCriterion("legalPersonId <", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidLessThanOrEqualTo(Integer value) {
            addCriterion("legalPersonId <=", value, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidIn(List<Integer> values) {
            addCriterion("legalPersonId in", values, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotIn(List<Integer> values) {
            addCriterion("legalPersonId not in", values, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidBetween(Integer value1, Integer value2) {
            addCriterion("legalPersonId between", value1, value2, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonidNotBetween(Integer value1, Integer value2) {
            addCriterion("legalPersonId not between", value1, value2, "legalpersonid");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameIsNull() {
            addCriterion("legalPersonName is null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameIsNotNull() {
            addCriterion("legalPersonName is not null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameEqualTo(String value) {
            addCriterion("legalPersonName =", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameNotEqualTo(String value) {
            addCriterion("legalPersonName <>", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameGreaterThan(String value) {
            addCriterion("legalPersonName >", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameGreaterThanOrEqualTo(String value) {
            addCriterion("legalPersonName >=", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameLessThan(String value) {
            addCriterion("legalPersonName <", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameLessThanOrEqualTo(String value) {
            addCriterion("legalPersonName <=", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameLike(String value) {
            addCriterion("legalPersonName like", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameNotLike(String value) {
            addCriterion("legalPersonName not like", value, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameIn(List<String> values) {
            addCriterion("legalPersonName in", values, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameNotIn(List<String> values) {
            addCriterion("legalPersonName not in", values, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameBetween(String value1, String value2) {
            addCriterion("legalPersonName between", value1, value2, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonnameNotBetween(String value1, String value2) {
            addCriterion("legalPersonName not between", value1, value2, "legalpersonname");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneIsNull() {
            addCriterion("legalPersonPhone is null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneIsNotNull() {
            addCriterion("legalPersonPhone is not null");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneEqualTo(String value) {
            addCriterion("legalPersonPhone =", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneNotEqualTo(String value) {
            addCriterion("legalPersonPhone <>", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneGreaterThan(String value) {
            addCriterion("legalPersonPhone >", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneGreaterThanOrEqualTo(String value) {
            addCriterion("legalPersonPhone >=", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneLessThan(String value) {
            addCriterion("legalPersonPhone <", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneLessThanOrEqualTo(String value) {
            addCriterion("legalPersonPhone <=", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneLike(String value) {
            addCriterion("legalPersonPhone like", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneNotLike(String value) {
            addCriterion("legalPersonPhone not like", value, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneIn(List<String> values) {
            addCriterion("legalPersonPhone in", values, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneNotIn(List<String> values) {
            addCriterion("legalPersonPhone not in", values, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneBetween(String value1, String value2) {
            addCriterion("legalPersonPhone between", value1, value2, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersonphoneNotBetween(String value1, String value2) {
            addCriterion("legalPersonPhone not between", value1, value2, "legalpersonphone");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelIsNull() {
            addCriterion("legalPersonTel is null");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelIsNotNull() {
            addCriterion("legalPersonTel is not null");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelEqualTo(String value) {
            addCriterion("legalPersonTel =", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelNotEqualTo(String value) {
            addCriterion("legalPersonTel <>", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelGreaterThan(String value) {
            addCriterion("legalPersonTel >", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelGreaterThanOrEqualTo(String value) {
            addCriterion("legalPersonTel >=", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelLessThan(String value) {
            addCriterion("legalPersonTel <", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelLessThanOrEqualTo(String value) {
            addCriterion("legalPersonTel <=", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelLike(String value) {
            addCriterion("legalPersonTel like", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelNotLike(String value) {
            addCriterion("legalPersonTel not like", value, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelIn(List<String> values) {
            addCriterion("legalPersonTel in", values, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelNotIn(List<String> values) {
            addCriterion("legalPersonTel not in", values, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelBetween(String value1, String value2) {
            addCriterion("legalPersonTel between", value1, value2, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalpersontelNotBetween(String value1, String value2) {
            addCriterion("legalPersonTel not between", value1, value2, "legalpersontel");
            return (Criteria) this;
        }

        public Criteria andLegalremarkIsNull() {
            addCriterion("legalRemark is null");
            return (Criteria) this;
        }

        public Criteria andLegalremarkIsNotNull() {
            addCriterion("legalRemark is not null");
            return (Criteria) this;
        }

        public Criteria andLegalremarkEqualTo(String value) {
            addCriterion("legalRemark =", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkNotEqualTo(String value) {
            addCriterion("legalRemark <>", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkGreaterThan(String value) {
            addCriterion("legalRemark >", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkGreaterThanOrEqualTo(String value) {
            addCriterion("legalRemark >=", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkLessThan(String value) {
            addCriterion("legalRemark <", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkLessThanOrEqualTo(String value) {
            addCriterion("legalRemark <=", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkLike(String value) {
            addCriterion("legalRemark like", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkNotLike(String value) {
            addCriterion("legalRemark not like", value, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkIn(List<String> values) {
            addCriterion("legalRemark in", values, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkNotIn(List<String> values) {
            addCriterion("legalRemark not in", values, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkBetween(String value1, String value2) {
            addCriterion("legalRemark between", value1, value2, "legalremark");
            return (Criteria) this;
        }

        public Criteria andLegalremarkNotBetween(String value1, String value2) {
            addCriterion("legalRemark not between", value1, value2, "legalremark");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isDelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isDelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Integer value) {
            addCriterion("isDelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Integer value) {
            addCriterion("isDelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Integer value) {
            addCriterion("isDelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("isDelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Integer value) {
            addCriterion("isDelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Integer value) {
            addCriterion("isDelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Integer> values) {
            addCriterion("isDelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Integer> values) {
            addCriterion("isDelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Integer value1, Integer value2) {
            addCriterion("isDelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("isDelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("userId is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userId is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userId =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userId <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userId >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userId >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userId <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userId <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userId in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userId not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userId between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userId not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNull() {
            addCriterion("platformId is null");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNotNull() {
            addCriterion("platformId is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformidEqualTo(Integer value) {
            addCriterion("platformId =", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotEqualTo(Integer value) {
            addCriterion("platformId <>", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThan(Integer value) {
            addCriterion("platformId >", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThanOrEqualTo(Integer value) {
            addCriterion("platformId >=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThan(Integer value) {
            addCriterion("platformId <", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThanOrEqualTo(Integer value) {
            addCriterion("platformId <=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIn(List<Integer> values) {
            addCriterion("platformId in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotIn(List<Integer> values) {
            addCriterion("platformId not in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidBetween(Integer value1, Integer value2) {
            addCriterion("platformId between", value1, value2, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotBetween(Integer value1, Integer value2) {
            addCriterion("platformId not between", value1, value2, "platformid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}