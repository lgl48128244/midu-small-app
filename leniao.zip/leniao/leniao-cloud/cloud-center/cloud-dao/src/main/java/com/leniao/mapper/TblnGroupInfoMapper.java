package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.TblnGroupInfo;
import com.leniao.entity.TblnGroupInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblnGroupInfoMapper extends BaseMapper<TblnGroupInfo> {
    int countByExample(TblnGroupInfoExample example);

    int deleteByExample(TblnGroupInfoExample example);

    int deleteByPrimaryKey(String groupid);

    int insert(TblnGroupInfo record);

    int insertSelective(TblnGroupInfo record);

    List<TblnGroupInfo> selectByExample(TblnGroupInfoExample example);

    TblnGroupInfo selectByPrimaryKey(String groupid);

    int updateByExampleSelective(@Param("record") TblnGroupInfo record, @Param("example") TblnGroupInfoExample example);

    int updateByExample(@Param("record") TblnGroupInfo record, @Param("example") TblnGroupInfoExample example);

    int updateByPrimaryKeySelective(TblnGroupInfo record);

    int updateByPrimaryKey(TblnGroupInfo record);
}