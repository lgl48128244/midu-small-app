package com.leniao.mapper;

import com.leniao.model.dto.BaseAgencyUserDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AgencyUserMapper {

    List<BaseAgencyUserDTO.AgencyUserList> selectByPage(BaseAgencyUserDTO.AgencyUserPage page);

    BaseAgencyUserDTO.AgencyUserView selectItemDesc(@Param("userId") Integer userId,@Param("platformId") Integer platformId);
}
