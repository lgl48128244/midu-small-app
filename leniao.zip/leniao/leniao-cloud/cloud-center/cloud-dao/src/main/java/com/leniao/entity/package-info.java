/**
 * @author guoliang.li
 * @date 2019/12/23 9:26
 * @description TODO 表实体类包
 */
package com.leniao.entity;