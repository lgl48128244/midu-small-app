package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TblnfireguardinfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblnfireguardinfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFireguardidIsNull() {
            addCriterion("fireGuardId is null");
            return (Criteria) this;
        }

        public Criteria andFireguardidIsNotNull() {
            addCriterion("fireGuardId is not null");
            return (Criteria) this;
        }

        public Criteria andFireguardidEqualTo(Integer value) {
            addCriterion("fireGuardId =", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotEqualTo(Integer value) {
            addCriterion("fireGuardId <>", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidGreaterThan(Integer value) {
            addCriterion("fireGuardId >", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidGreaterThanOrEqualTo(Integer value) {
            addCriterion("fireGuardId >=", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidLessThan(Integer value) {
            addCriterion("fireGuardId <", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidLessThanOrEqualTo(Integer value) {
            addCriterion("fireGuardId <=", value, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidIn(List<Integer> values) {
            addCriterion("fireGuardId in", values, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotIn(List<Integer> values) {
            addCriterion("fireGuardId not in", values, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidBetween(Integer value1, Integer value2) {
            addCriterion("fireGuardId between", value1, value2, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardidNotBetween(Integer value1, Integer value2) {
            addCriterion("fireGuardId not between", value1, value2, "fireguardid");
            return (Criteria) this;
        }

        public Criteria andFireguardnameIsNull() {
            addCriterion("fireGuardName is null");
            return (Criteria) this;
        }

        public Criteria andFireguardnameIsNotNull() {
            addCriterion("fireGuardName is not null");
            return (Criteria) this;
        }

        public Criteria andFireguardnameEqualTo(String value) {
            addCriterion("fireGuardName =", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameNotEqualTo(String value) {
            addCriterion("fireGuardName <>", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameGreaterThan(String value) {
            addCriterion("fireGuardName >", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameGreaterThanOrEqualTo(String value) {
            addCriterion("fireGuardName >=", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameLessThan(String value) {
            addCriterion("fireGuardName <", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameLessThanOrEqualTo(String value) {
            addCriterion("fireGuardName <=", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameLike(String value) {
            addCriterion("fireGuardName like", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameNotLike(String value) {
            addCriterion("fireGuardName not like", value, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameIn(List<String> values) {
            addCriterion("fireGuardName in", values, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameNotIn(List<String> values) {
            addCriterion("fireGuardName not in", values, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameBetween(String value1, String value2) {
            addCriterion("fireGuardName between", value1, value2, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardnameNotBetween(String value1, String value2) {
            addCriterion("fireGuardName not between", value1, value2, "fireguardname");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneIsNull() {
            addCriterion("fireGuardPhone is null");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneIsNotNull() {
            addCriterion("fireGuardPhone is not null");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneEqualTo(String value) {
            addCriterion("fireGuardPhone =", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneNotEqualTo(String value) {
            addCriterion("fireGuardPhone <>", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneGreaterThan(String value) {
            addCriterion("fireGuardPhone >", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneGreaterThanOrEqualTo(String value) {
            addCriterion("fireGuardPhone >=", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneLessThan(String value) {
            addCriterion("fireGuardPhone <", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneLessThanOrEqualTo(String value) {
            addCriterion("fireGuardPhone <=", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneLike(String value) {
            addCriterion("fireGuardPhone like", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneNotLike(String value) {
            addCriterion("fireGuardPhone not like", value, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneIn(List<String> values) {
            addCriterion("fireGuardPhone in", values, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneNotIn(List<String> values) {
            addCriterion("fireGuardPhone not in", values, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneBetween(String value1, String value2) {
            addCriterion("fireGuardPhone between", value1, value2, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardphoneNotBetween(String value1, String value2) {
            addCriterion("fireGuardPhone not between", value1, value2, "fireguardphone");
            return (Criteria) this;
        }

        public Criteria andFireguardtelIsNull() {
            addCriterion("fireGuardTel is null");
            return (Criteria) this;
        }

        public Criteria andFireguardtelIsNotNull() {
            addCriterion("fireGuardTel is not null");
            return (Criteria) this;
        }

        public Criteria andFireguardtelEqualTo(String value) {
            addCriterion("fireGuardTel =", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelNotEqualTo(String value) {
            addCriterion("fireGuardTel <>", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelGreaterThan(String value) {
            addCriterion("fireGuardTel >", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelGreaterThanOrEqualTo(String value) {
            addCriterion("fireGuardTel >=", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelLessThan(String value) {
            addCriterion("fireGuardTel <", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelLessThanOrEqualTo(String value) {
            addCriterion("fireGuardTel <=", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelLike(String value) {
            addCriterion("fireGuardTel like", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelNotLike(String value) {
            addCriterion("fireGuardTel not like", value, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelIn(List<String> values) {
            addCriterion("fireGuardTel in", values, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelNotIn(List<String> values) {
            addCriterion("fireGuardTel not in", values, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelBetween(String value1, String value2) {
            addCriterion("fireGuardTel between", value1, value2, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireguardtelNotBetween(String value1, String value2) {
            addCriterion("fireGuardTel not between", value1, value2, "fireguardtel");
            return (Criteria) this;
        }

        public Criteria andFireremarkIsNull() {
            addCriterion("fireRemark is null");
            return (Criteria) this;
        }

        public Criteria andFireremarkIsNotNull() {
            addCriterion("fireRemark is not null");
            return (Criteria) this;
        }

        public Criteria andFireremarkEqualTo(String value) {
            addCriterion("fireRemark =", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkNotEqualTo(String value) {
            addCriterion("fireRemark <>", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkGreaterThan(String value) {
            addCriterion("fireRemark >", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkGreaterThanOrEqualTo(String value) {
            addCriterion("fireRemark >=", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkLessThan(String value) {
            addCriterion("fireRemark <", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkLessThanOrEqualTo(String value) {
            addCriterion("fireRemark <=", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkLike(String value) {
            addCriterion("fireRemark like", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkNotLike(String value) {
            addCriterion("fireRemark not like", value, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkIn(List<String> values) {
            addCriterion("fireRemark in", values, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkNotIn(List<String> values) {
            addCriterion("fireRemark not in", values, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkBetween(String value1, String value2) {
            addCriterion("fireRemark between", value1, value2, "fireremark");
            return (Criteria) this;
        }

        public Criteria andFireremarkNotBetween(String value1, String value2) {
            addCriterion("fireRemark not between", value1, value2, "fireremark");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isDelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isDelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Integer value) {
            addCriterion("isDelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Integer value) {
            addCriterion("isDelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Integer value) {
            addCriterion("isDelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("isDelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Integer value) {
            addCriterion("isDelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Integer value) {
            addCriterion("isDelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Integer> values) {
            addCriterion("isDelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Integer> values) {
            addCriterion("isDelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Integer value1, Integer value2) {
            addCriterion("isDelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("isDelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("userId is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userId is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userId =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userId <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userId >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userId >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userId <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userId <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userId in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userId not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userId between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userId not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNull() {
            addCriterion("platformId is null");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNotNull() {
            addCriterion("platformId is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformidEqualTo(Integer value) {
            addCriterion("platformId =", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotEqualTo(Integer value) {
            addCriterion("platformId <>", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThan(Integer value) {
            addCriterion("platformId >", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThanOrEqualTo(Integer value) {
            addCriterion("platformId >=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThan(Integer value) {
            addCriterion("platformId <", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThanOrEqualTo(Integer value) {
            addCriterion("platformId <=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIn(List<Integer> values) {
            addCriterion("platformId in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotIn(List<Integer> values) {
            addCriterion("platformId not in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidBetween(Integer value1, Integer value2) {
            addCriterion("platformId between", value1, value2, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotBetween(Integer value1, Integer value2) {
            addCriterion("platformId not between", value1, value2, "platformid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}