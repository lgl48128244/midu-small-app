package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;

@TableName("tblnprojectinfo")
@ToString
public class ProjectInfo {
    @TableId
    private Integer projid;

    private Long industryid;

    private String projname;

    private Float projlocationx;

    private Float projlocationy;

    private Date procreatetime;

    private String projlocation;

    private String proprovince;

    private String procity;

    private String proarea;

    private Integer fireguardid;

    private Integer legalpersonid;

    private String projintroduction;

    private String projremark;

    private Integer isdelete;

    private String filename;

    private String proprovincecode;

    private String procitycode;

    private String proareacode;

    private Integer platformid;

    public Integer getProjid() {
        return projid;
    }

    public void setProjid(Integer projid) {
        this.projid = projid;
    }

    public Long getIndustryid() {
        return industryid;
    }

    public void setIndustryid(Long industryid) {
        this.industryid = industryid;
    }

    public String getProjname() {
        return projname;
    }

    public void setProjname(String projname) {
        this.projname = projname == null ? null : projname.trim();
    }

    public Float getProjlocationx() {
        return projlocationx;
    }

    public void setProjlocationx(Float projlocationx) {
        this.projlocationx = projlocationx;
    }

    public Float getProjlocationy() {
        return projlocationy;
    }

    public void setProjlocationy(Float projlocationy) {
        this.projlocationy = projlocationy;
    }

    public Date getProcreatetime() {
        return procreatetime;
    }

    public void setProcreatetime(Date procreatetime) {
        this.procreatetime = procreatetime;
    }

    public String getProjlocation() {
        return projlocation;
    }

    public void setProjlocation(String projlocation) {
        this.projlocation = projlocation == null ? null : projlocation.trim();
    }

    public String getProprovince() {
        return proprovince;
    }

    public void setProprovince(String proprovince) {
        this.proprovince = proprovince == null ? null : proprovince.trim();
    }

    public String getProcity() {
        return procity;
    }

    public void setProcity(String procity) {
        this.procity = procity == null ? null : procity.trim();
    }

    public String getProarea() {
        return proarea;
    }

    public void setProarea(String proarea) {
        this.proarea = proarea == null ? null : proarea.trim();
    }

    public Integer getFireguardid() {
        return fireguardid;
    }

    public void setFireguardid(Integer fireguardid) {
        this.fireguardid = fireguardid;
    }

    public Integer getLegalpersonid() {
        return legalpersonid;
    }

    public void setLegalpersonid(Integer legalpersonid) {
        this.legalpersonid = legalpersonid;
    }

    public String getProjintroduction() {
        return projintroduction;
    }

    public void setProjintroduction(String projintroduction) {
        this.projintroduction = projintroduction == null ? null : projintroduction.trim();
    }

    public String getProjremark() {
        return projremark;
    }

    public void setProjremark(String projremark) {
        this.projremark = projremark == null ? null : projremark.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename == null ? null : filename.trim();
    }

    public String getProprovincecode() {
        return proprovincecode;
    }

    public void setProprovincecode(String proprovincecode) {
        this.proprovincecode = proprovincecode == null ? null : proprovincecode.trim();
    }

    public String getProcitycode() {
        return procitycode;
    }

    public void setProcitycode(String procitycode) {
        this.procitycode = procitycode == null ? null : procitycode.trim();
    }

    public String getProareacode() {
        return proareacode;
    }

    public void setProareacode(String proareacode) {
        this.proareacode = proareacode == null ? null : proareacode.trim();
    }

    public Integer getPlatformid() {
        return platformid;
    }

    public void setPlatformid(Integer platformid) {
        this.platformid = platformid;
    }
}