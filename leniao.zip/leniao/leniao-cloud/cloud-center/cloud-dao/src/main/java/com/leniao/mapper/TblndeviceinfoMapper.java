package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.Tblndeviceinfo;
import com.leniao.entity.TblndeviceinfoExample;
import com.leniao.model.devlist.DevStatusListInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface TblndeviceinfoMapper extends BaseMapper<Tblndeviceinfo> {
    long countByExample(TblndeviceinfoExample example);

    int deleteByExample(TblndeviceinfoExample example);

    int deleteByPrimaryKey(Integer devidpk);

    int insertSelective(Tblndeviceinfo record);

    List<Tblndeviceinfo> selectByExample(TblndeviceinfoExample example);

    Tblndeviceinfo selectByPrimaryKey(Integer devidpk);

    int updateByExampleSelective(@Param("record") Tblndeviceinfo record, @Param("example") TblndeviceinfoExample example);

    int updateByExample(@Param("record") Tblndeviceinfo record, @Param("example") TblndeviceinfoExample example);

    int updateByPrimaryKeySelective(Tblndeviceinfo record);

    int updateByPrimaryKey(Tblndeviceinfo record);


    //根据项目id  系统id 分页查询设备信息
    List<Tblndeviceinfo> selectByPaging(Map<String, Object> paramter);


    List<DevStatusListInfo> findDevStatusList(String sql);

    Integer selectDevUnitId(int devIdpk);
}