package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.Tblndevicenodeinfo;
import com.leniao.entity.TblndevicenodeinfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TblndevicenodeinfoMapper extends BaseMapper<Tblndevicenodeinfo> {
    int countByExample(TblndevicenodeinfoExample example);

    int deleteByExample(TblndevicenodeinfoExample example);

    int deleteByPrimaryKey(Integer pkid);

    int insertSelective(Tblndevicenodeinfo record);

    List<Tblndevicenodeinfo> selectByExample(TblndevicenodeinfoExample example);

    Tblndevicenodeinfo selectByPrimaryKey(Integer pkid);

    int updateByExampleSelective(@Param("record") Tblndevicenodeinfo record, @Param("example") TblndevicenodeinfoExample example);

    int updateByExample(@Param("record") Tblndevicenodeinfo record, @Param("example") TblndevicenodeinfoExample example);

    int updateByPrimaryKeySelective(Tblndevicenodeinfo record);

    int updateByPrimaryKey(Tblndevicenodeinfo record);
}