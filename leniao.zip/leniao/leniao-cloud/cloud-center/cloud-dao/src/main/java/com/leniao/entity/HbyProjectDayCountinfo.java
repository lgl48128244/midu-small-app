package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;

@TableName("hby_project_day_countinfo")
@ToString
public class HbyProjectDayCountinfo {
    private Long id;

    private Integer unitId;

    private Long industryIdpk;

    private Long agcyId;

    private Integer year;

    private Integer month;

    private Integer day;

    private String pollDevEleUse;

    private String conDevEleUse;

    private String totalDevEleUse;

    private Long pollDevErrNum;

    private Long conDevErrNum;

    private Long stopOrLimitErrNum;

    private Long eleErrNum;

    private Long powerErrNum;

    private Long devStopErrNum;

    private Integer bothDevNum;

    private Integer pollDevNum;

    private Integer conDevNum;

    private Integer runDevNum;

    private Integer stopDevNum;

    private Integer lostDevNum;

    private String powerMax;

    private String eleMax;

    private Date maxPowerTime;

    private Date maxEleTime;

    private Integer platformId;

    private Integer producState;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Long getIndustryIdpk() {
        return industryIdpk;
    }

    public void setIndustryIdpk(Long industryIdpk) {
        this.industryIdpk = industryIdpk;
    }

    public Long getAgcyId() {
        return agcyId;
    }

    public void setAgcyId(Long agcyId) {
        this.agcyId = agcyId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public String getPollDevEleUse() {
        return pollDevEleUse;
    }

    public void setPollDevEleUse(String pollDevEleUse) {
        this.pollDevEleUse = pollDevEleUse == null ? null : pollDevEleUse.trim();
    }

    public String getConDevEleUse() {
        return conDevEleUse;
    }

    public void setConDevEleUse(String conDevEleUse) {
        this.conDevEleUse = conDevEleUse == null ? null : conDevEleUse.trim();
    }

    public String getTotalDevEleUse() {
        return totalDevEleUse;
    }

    public void setTotalDevEleUse(String totalDevEleUse) {
        this.totalDevEleUse = totalDevEleUse == null ? null : totalDevEleUse.trim();
    }

    public Long getPollDevErrNum() {
        return pollDevErrNum;
    }

    public void setPollDevErrNum(Long pollDevErrNum) {
        this.pollDevErrNum = pollDevErrNum;
    }

    public Long getConDevErrNum() {
        return conDevErrNum;
    }

    public void setConDevErrNum(Long conDevErrNum) {
        this.conDevErrNum = conDevErrNum;
    }

    public Long getStopOrLimitErrNum() {
        return stopOrLimitErrNum;
    }

    public void setStopOrLimitErrNum(Long stopOrLimitErrNum) {
        this.stopOrLimitErrNum = stopOrLimitErrNum;
    }

    public Long getEleErrNum() {
        return eleErrNum;
    }

    public void setEleErrNum(Long eleErrNum) {
        this.eleErrNum = eleErrNum;
    }

    public Long getPowerErrNum() {
        return powerErrNum;
    }

    public void setPowerErrNum(Long powerErrNum) {
        this.powerErrNum = powerErrNum;
    }

    public Long getDevStopErrNum() {
        return devStopErrNum;
    }

    public void setDevStopErrNum(Long devStopErrNum) {
        this.devStopErrNum = devStopErrNum;
    }

    public Integer getBothDevNum() {
        return bothDevNum;
    }

    public void setBothDevNum(Integer bothDevNum) {
        this.bothDevNum = bothDevNum;
    }

    public Integer getPollDevNum() {
        return pollDevNum;
    }

    public void setPollDevNum(Integer pollDevNum) {
        this.pollDevNum = pollDevNum;
    }

    public Integer getConDevNum() {
        return conDevNum;
    }

    public void setConDevNum(Integer conDevNum) {
        this.conDevNum = conDevNum;
    }

    public Integer getRunDevNum() {
        return runDevNum;
    }

    public void setRunDevNum(Integer runDevNum) {
        this.runDevNum = runDevNum;
    }

    public Integer getStopDevNum() {
        return stopDevNum;
    }

    public void setStopDevNum(Integer stopDevNum) {
        this.stopDevNum = stopDevNum;
    }

    public Integer getLostDevNum() {
        return lostDevNum;
    }

    public void setLostDevNum(Integer lostDevNum) {
        this.lostDevNum = lostDevNum;
    }

    public String getPowerMax() {
        return powerMax;
    }

    public void setPowerMax(String powerMax) {
        this.powerMax = powerMax == null ? null : powerMax.trim();
    }

    public String getEleMax() {
        return eleMax;
    }

    public void setEleMax(String eleMax) {
        this.eleMax = eleMax == null ? null : eleMax.trim();
    }

    public Date getMaxPowerTime() {
        return maxPowerTime;
    }

    public void setMaxPowerTime(Date maxPowerTime) {
        this.maxPowerTime = maxPowerTime;
    }

    public Date getMaxEleTime() {
        return maxEleTime;
    }

    public void setMaxEleTime(Date maxEleTime) {
        this.maxEleTime = maxEleTime;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    public Integer getProducState() {
        return producState;
    }

    public void setProducState(Integer producState) {
        this.producState = producState;
    }
}