package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TblnGroupAddressExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblnGroupAddressExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAdidIsNull() {
            addCriterion("ADID is null");
            return (Criteria) this;
        }

        public Criteria andAdidIsNotNull() {
            addCriterion("ADID is not null");
            return (Criteria) this;
        }

        public Criteria andAdidEqualTo(String value) {
            addCriterion("ADID =", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidNotEqualTo(String value) {
            addCriterion("ADID <>", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidGreaterThan(String value) {
            addCriterion("ADID >", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidGreaterThanOrEqualTo(String value) {
            addCriterion("ADID >=", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidLessThan(String value) {
            addCriterion("ADID <", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidLessThanOrEqualTo(String value) {
            addCriterion("ADID <=", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidLike(String value) {
            addCriterion("ADID like", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidNotLike(String value) {
            addCriterion("ADID not like", value, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidIn(List<String> values) {
            addCriterion("ADID in", values, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidNotIn(List<String> values) {
            addCriterion("ADID not in", values, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidBetween(String value1, String value2) {
            addCriterion("ADID between", value1, value2, "adid");
            return (Criteria) this;
        }

        public Criteria andAdidNotBetween(String value1, String value2) {
            addCriterion("ADID not between", value1, value2, "adid");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("UserID is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("UserID is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("UserID =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("UserID <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("UserID >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("UserID >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("UserID <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("UserID <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("UserID in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("UserID not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("UserID between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("UserID not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andAdprovinceIsNull() {
            addCriterion("AdProvince is null");
            return (Criteria) this;
        }

        public Criteria andAdprovinceIsNotNull() {
            addCriterion("AdProvince is not null");
            return (Criteria) this;
        }

        public Criteria andAdprovinceEqualTo(String value) {
            addCriterion("AdProvince =", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceNotEqualTo(String value) {
            addCriterion("AdProvince <>", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceGreaterThan(String value) {
            addCriterion("AdProvince >", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceGreaterThanOrEqualTo(String value) {
            addCriterion("AdProvince >=", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceLessThan(String value) {
            addCriterion("AdProvince <", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceLessThanOrEqualTo(String value) {
            addCriterion("AdProvince <=", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceLike(String value) {
            addCriterion("AdProvince like", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceNotLike(String value) {
            addCriterion("AdProvince not like", value, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceIn(List<String> values) {
            addCriterion("AdProvince in", values, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceNotIn(List<String> values) {
            addCriterion("AdProvince not in", values, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceBetween(String value1, String value2) {
            addCriterion("AdProvince between", value1, value2, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdprovinceNotBetween(String value1, String value2) {
            addCriterion("AdProvince not between", value1, value2, "adprovince");
            return (Criteria) this;
        }

        public Criteria andAdcityIsNull() {
            addCriterion("AdCity is null");
            return (Criteria) this;
        }

        public Criteria andAdcityIsNotNull() {
            addCriterion("AdCity is not null");
            return (Criteria) this;
        }

        public Criteria andAdcityEqualTo(String value) {
            addCriterion("AdCity =", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityNotEqualTo(String value) {
            addCriterion("AdCity <>", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityGreaterThan(String value) {
            addCriterion("AdCity >", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityGreaterThanOrEqualTo(String value) {
            addCriterion("AdCity >=", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityLessThan(String value) {
            addCriterion("AdCity <", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityLessThanOrEqualTo(String value) {
            addCriterion("AdCity <=", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityLike(String value) {
            addCriterion("AdCity like", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityNotLike(String value) {
            addCriterion("AdCity not like", value, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityIn(List<String> values) {
            addCriterion("AdCity in", values, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityNotIn(List<String> values) {
            addCriterion("AdCity not in", values, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityBetween(String value1, String value2) {
            addCriterion("AdCity between", value1, value2, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdcityNotBetween(String value1, String value2) {
            addCriterion("AdCity not between", value1, value2, "adcity");
            return (Criteria) this;
        }

        public Criteria andAdareaIsNull() {
            addCriterion("AdArea is null");
            return (Criteria) this;
        }

        public Criteria andAdareaIsNotNull() {
            addCriterion("AdArea is not null");
            return (Criteria) this;
        }

        public Criteria andAdareaEqualTo(String value) {
            addCriterion("AdArea =", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaNotEqualTo(String value) {
            addCriterion("AdArea <>", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaGreaterThan(String value) {
            addCriterion("AdArea >", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaGreaterThanOrEqualTo(String value) {
            addCriterion("AdArea >=", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaLessThan(String value) {
            addCriterion("AdArea <", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaLessThanOrEqualTo(String value) {
            addCriterion("AdArea <=", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaLike(String value) {
            addCriterion("AdArea like", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaNotLike(String value) {
            addCriterion("AdArea not like", value, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaIn(List<String> values) {
            addCriterion("AdArea in", values, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaNotIn(List<String> values) {
            addCriterion("AdArea not in", values, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaBetween(String value1, String value2) {
            addCriterion("AdArea between", value1, value2, "adarea");
            return (Criteria) this;
        }

        public Criteria andAdareaNotBetween(String value1, String value2) {
            addCriterion("AdArea not between", value1, value2, "adarea");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeIsNull() {
            addCriterion("CProvinceCode is null");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeIsNotNull() {
            addCriterion("CProvinceCode is not null");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeEqualTo(String value) {
            addCriterion("CProvinceCode =", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeNotEqualTo(String value) {
            addCriterion("CProvinceCode <>", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeGreaterThan(String value) {
            addCriterion("CProvinceCode >", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeGreaterThanOrEqualTo(String value) {
            addCriterion("CProvinceCode >=", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeLessThan(String value) {
            addCriterion("CProvinceCode <", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeLessThanOrEqualTo(String value) {
            addCriterion("CProvinceCode <=", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeLike(String value) {
            addCriterion("CProvinceCode like", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeNotLike(String value) {
            addCriterion("CProvinceCode not like", value, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeIn(List<String> values) {
            addCriterion("CProvinceCode in", values, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeNotIn(List<String> values) {
            addCriterion("CProvinceCode not in", values, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeBetween(String value1, String value2) {
            addCriterion("CProvinceCode between", value1, value2, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCprovincecodeNotBetween(String value1, String value2) {
            addCriterion("CProvinceCode not between", value1, value2, "cprovincecode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeIsNull() {
            addCriterion("CCityCode is null");
            return (Criteria) this;
        }

        public Criteria andCcitycodeIsNotNull() {
            addCriterion("CCityCode is not null");
            return (Criteria) this;
        }

        public Criteria andCcitycodeEqualTo(String value) {
            addCriterion("CCityCode =", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeNotEqualTo(String value) {
            addCriterion("CCityCode <>", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeGreaterThan(String value) {
            addCriterion("CCityCode >", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeGreaterThanOrEqualTo(String value) {
            addCriterion("CCityCode >=", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeLessThan(String value) {
            addCriterion("CCityCode <", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeLessThanOrEqualTo(String value) {
            addCriterion("CCityCode <=", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeLike(String value) {
            addCriterion("CCityCode like", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeNotLike(String value) {
            addCriterion("CCityCode not like", value, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeIn(List<String> values) {
            addCriterion("CCityCode in", values, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeNotIn(List<String> values) {
            addCriterion("CCityCode not in", values, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeBetween(String value1, String value2) {
            addCriterion("CCityCode between", value1, value2, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCcitycodeNotBetween(String value1, String value2) {
            addCriterion("CCityCode not between", value1, value2, "ccitycode");
            return (Criteria) this;
        }

        public Criteria andCareacodeIsNull() {
            addCriterion("CAreaCode is null");
            return (Criteria) this;
        }

        public Criteria andCareacodeIsNotNull() {
            addCriterion("CAreaCode is not null");
            return (Criteria) this;
        }

        public Criteria andCareacodeEqualTo(String value) {
            addCriterion("CAreaCode =", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeNotEqualTo(String value) {
            addCriterion("CAreaCode <>", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeGreaterThan(String value) {
            addCriterion("CAreaCode >", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeGreaterThanOrEqualTo(String value) {
            addCriterion("CAreaCode >=", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeLessThan(String value) {
            addCriterion("CAreaCode <", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeLessThanOrEqualTo(String value) {
            addCriterion("CAreaCode <=", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeLike(String value) {
            addCriterion("CAreaCode like", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeNotLike(String value) {
            addCriterion("CAreaCode not like", value, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeIn(List<String> values) {
            addCriterion("CAreaCode in", values, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeNotIn(List<String> values) {
            addCriterion("CAreaCode not in", values, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeBetween(String value1, String value2) {
            addCriterion("CAreaCode between", value1, value2, "careacode");
            return (Criteria) this;
        }

        public Criteria andCareacodeNotBetween(String value1, String value2) {
            addCriterion("CAreaCode not between", value1, value2, "careacode");
            return (Criteria) this;
        }

        public Criteria andOnlyreadIsNull() {
            addCriterion("OnlyRead is null");
            return (Criteria) this;
        }

        public Criteria andOnlyreadIsNotNull() {
            addCriterion("OnlyRead is not null");
            return (Criteria) this;
        }

        public Criteria andOnlyreadEqualTo(Integer value) {
            addCriterion("OnlyRead =", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadNotEqualTo(Integer value) {
            addCriterion("OnlyRead <>", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadGreaterThan(Integer value) {
            addCriterion("OnlyRead >", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadGreaterThanOrEqualTo(Integer value) {
            addCriterion("OnlyRead >=", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadLessThan(Integer value) {
            addCriterion("OnlyRead <", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadLessThanOrEqualTo(Integer value) {
            addCriterion("OnlyRead <=", value, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadIn(List<Integer> values) {
            addCriterion("OnlyRead in", values, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadNotIn(List<Integer> values) {
            addCriterion("OnlyRead not in", values, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadBetween(Integer value1, Integer value2) {
            addCriterion("OnlyRead between", value1, value2, "onlyread");
            return (Criteria) this;
        }

        public Criteria andOnlyreadNotBetween(Integer value1, Integer value2) {
            addCriterion("OnlyRead not between", value1, value2, "onlyread");
            return (Criteria) this;
        }

        public Criteria andAdduserIsNull() {
            addCriterion("ADDUSER is null");
            return (Criteria) this;
        }

        public Criteria andAdduserIsNotNull() {
            addCriterion("ADDUSER is not null");
            return (Criteria) this;
        }

        public Criteria andAdduserEqualTo(String value) {
            addCriterion("ADDUSER =", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserNotEqualTo(String value) {
            addCriterion("ADDUSER <>", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserGreaterThan(String value) {
            addCriterion("ADDUSER >", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserGreaterThanOrEqualTo(String value) {
            addCriterion("ADDUSER >=", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserLessThan(String value) {
            addCriterion("ADDUSER <", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserLessThanOrEqualTo(String value) {
            addCriterion("ADDUSER <=", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserLike(String value) {
            addCriterion("ADDUSER like", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserNotLike(String value) {
            addCriterion("ADDUSER not like", value, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserIn(List<String> values) {
            addCriterion("ADDUSER in", values, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserNotIn(List<String> values) {
            addCriterion("ADDUSER not in", values, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserBetween(String value1, String value2) {
            addCriterion("ADDUSER between", value1, value2, "adduser");
            return (Criteria) this;
        }

        public Criteria andAdduserNotBetween(String value1, String value2) {
            addCriterion("ADDUSER not between", value1, value2, "adduser");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNull() {
            addCriterion("ADDTIME is null");
            return (Criteria) this;
        }

        public Criteria andAddtimeIsNotNull() {
            addCriterion("ADDTIME is not null");
            return (Criteria) this;
        }

        public Criteria andAddtimeEqualTo(Date value) {
            addCriterion("ADDTIME =", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotEqualTo(Date value) {
            addCriterion("ADDTIME <>", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThan(Date value) {
            addCriterion("ADDTIME >", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ADDTIME >=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThan(Date value) {
            addCriterion("ADDTIME <", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeLessThanOrEqualTo(Date value) {
            addCriterion("ADDTIME <=", value, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeIn(List<Date> values) {
            addCriterion("ADDTIME in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotIn(List<Date> values) {
            addCriterion("ADDTIME not in", values, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeBetween(Date value1, Date value2) {
            addCriterion("ADDTIME between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andAddtimeNotBetween(Date value1, Date value2) {
            addCriterion("ADDTIME not between", value1, value2, "addtime");
            return (Criteria) this;
        }

        public Criteria andIsdelIsNull() {
            addCriterion("ISDEL is null");
            return (Criteria) this;
        }

        public Criteria andIsdelIsNotNull() {
            addCriterion("ISDEL is not null");
            return (Criteria) this;
        }

        public Criteria andIsdelEqualTo(Integer value) {
            addCriterion("ISDEL =", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelNotEqualTo(Integer value) {
            addCriterion("ISDEL <>", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelGreaterThan(Integer value) {
            addCriterion("ISDEL >", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelGreaterThanOrEqualTo(Integer value) {
            addCriterion("ISDEL >=", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelLessThan(Integer value) {
            addCriterion("ISDEL <", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelLessThanOrEqualTo(Integer value) {
            addCriterion("ISDEL <=", value, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelIn(List<Integer> values) {
            addCriterion("ISDEL in", values, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelNotIn(List<Integer> values) {
            addCriterion("ISDEL not in", values, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelBetween(Integer value1, Integer value2) {
            addCriterion("ISDEL between", value1, value2, "isdel");
            return (Criteria) this;
        }

        public Criteria andIsdelNotBetween(Integer value1, Integer value2) {
            addCriterion("ISDEL not between", value1, value2, "isdel");
            return (Criteria) this;
        }

        public Criteria andIslockIsNull() {
            addCriterion("ISLOCK is null");
            return (Criteria) this;
        }

        public Criteria andIslockIsNotNull() {
            addCriterion("ISLOCK is not null");
            return (Criteria) this;
        }

        public Criteria andIslockEqualTo(Integer value) {
            addCriterion("ISLOCK =", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockNotEqualTo(Integer value) {
            addCriterion("ISLOCK <>", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockGreaterThan(Integer value) {
            addCriterion("ISLOCK >", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockGreaterThanOrEqualTo(Integer value) {
            addCriterion("ISLOCK >=", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockLessThan(Integer value) {
            addCriterion("ISLOCK <", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockLessThanOrEqualTo(Integer value) {
            addCriterion("ISLOCK <=", value, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockIn(List<Integer> values) {
            addCriterion("ISLOCK in", values, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockNotIn(List<Integer> values) {
            addCriterion("ISLOCK not in", values, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockBetween(Integer value1, Integer value2) {
            addCriterion("ISLOCK between", value1, value2, "islock");
            return (Criteria) this;
        }

        public Criteria andIslockNotBetween(Integer value1, Integer value2) {
            addCriterion("ISLOCK not between", value1, value2, "islock");
            return (Criteria) this;
        }

        public Criteria andGroupidIsNull() {
            addCriterion("GroupID is null");
            return (Criteria) this;
        }

        public Criteria andGroupidIsNotNull() {
            addCriterion("GroupID is not null");
            return (Criteria) this;
        }

        public Criteria andGroupidEqualTo(String value) {
            addCriterion("GroupID =", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidNotEqualTo(String value) {
            addCriterion("GroupID <>", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidGreaterThan(String value) {
            addCriterion("GroupID >", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidGreaterThanOrEqualTo(String value) {
            addCriterion("GroupID >=", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidLessThan(String value) {
            addCriterion("GroupID <", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidLessThanOrEqualTo(String value) {
            addCriterion("GroupID <=", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidLike(String value) {
            addCriterion("GroupID like", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidNotLike(String value) {
            addCriterion("GroupID not like", value, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidIn(List<String> values) {
            addCriterion("GroupID in", values, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidNotIn(List<String> values) {
            addCriterion("GroupID not in", values, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidBetween(String value1, String value2) {
            addCriterion("GroupID between", value1, value2, "groupid");
            return (Criteria) this;
        }

        public Criteria andGroupidNotBetween(String value1, String value2) {
            addCriterion("GroupID not between", value1, value2, "groupid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}