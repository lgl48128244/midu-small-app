package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyOverLookDevJoin;
import com.leniao.entity.HbyOverLookDevJoinExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HbyOverLookDevJoinMapper extends BaseMapper<HbyOverLookDevJoin> {
    long countByExample(HbyOverLookDevJoinExample example);

    int deleteByExample(HbyOverLookDevJoinExample example);

    int deleteByPrimaryKey(Long id);

    int insertSelective(HbyOverLookDevJoin record);

    List<HbyOverLookDevJoin> selectByExample(HbyOverLookDevJoinExample example);

    HbyOverLookDevJoin selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyOverLookDevJoin record, @Param("example") HbyOverLookDevJoinExample example);

    int updateByExample(@Param("record") HbyOverLookDevJoin record, @Param("example") HbyOverLookDevJoinExample example);

    int updateByPrimaryKeySelective(HbyOverLookDevJoin record);

    int updateByPrimaryKey(HbyOverLookDevJoin record);
}