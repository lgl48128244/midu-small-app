package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HbyProjectDayCountinfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public HbyProjectDayCountinfoExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNull() {
            addCriterion("unit_id is null");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNotNull() {
            addCriterion("unit_id is not null");
            return (Criteria) this;
        }

        public Criteria andUnitIdEqualTo(Integer value) {
            addCriterion("unit_id =", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotEqualTo(Integer value) {
            addCriterion("unit_id <>", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThan(Integer value) {
            addCriterion("unit_id >", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("unit_id >=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThan(Integer value) {
            addCriterion("unit_id <", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThanOrEqualTo(Integer value) {
            addCriterion("unit_id <=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdIn(List<Integer> values) {
            addCriterion("unit_id in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotIn(List<Integer> values) {
            addCriterion("unit_id not in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdBetween(Integer value1, Integer value2) {
            addCriterion("unit_id between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotBetween(Integer value1, Integer value2) {
            addCriterion("unit_id not between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkIsNull() {
            addCriterion("industry_idpk is null");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkIsNotNull() {
            addCriterion("industry_idpk is not null");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkEqualTo(Long value) {
            addCriterion("industry_idpk =", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkNotEqualTo(Long value) {
            addCriterion("industry_idpk <>", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkGreaterThan(Long value) {
            addCriterion("industry_idpk >", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkGreaterThanOrEqualTo(Long value) {
            addCriterion("industry_idpk >=", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkLessThan(Long value) {
            addCriterion("industry_idpk <", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkLessThanOrEqualTo(Long value) {
            addCriterion("industry_idpk <=", value, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkIn(List<Long> values) {
            addCriterion("industry_idpk in", values, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkNotIn(List<Long> values) {
            addCriterion("industry_idpk not in", values, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkBetween(Long value1, Long value2) {
            addCriterion("industry_idpk between", value1, value2, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andIndustryIdpkNotBetween(Long value1, Long value2) {
            addCriterion("industry_idpk not between", value1, value2, "industryIdpk");
            return (Criteria) this;
        }

        public Criteria andAgcyIdIsNull() {
            addCriterion("agcy_id is null");
            return (Criteria) this;
        }

        public Criteria andAgcyIdIsNotNull() {
            addCriterion("agcy_id is not null");
            return (Criteria) this;
        }

        public Criteria andAgcyIdEqualTo(Long value) {
            addCriterion("agcy_id =", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdNotEqualTo(Long value) {
            addCriterion("agcy_id <>", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdGreaterThan(Long value) {
            addCriterion("agcy_id >", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdGreaterThanOrEqualTo(Long value) {
            addCriterion("agcy_id >=", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdLessThan(Long value) {
            addCriterion("agcy_id <", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdLessThanOrEqualTo(Long value) {
            addCriterion("agcy_id <=", value, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdIn(List<Long> values) {
            addCriterion("agcy_id in", values, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdNotIn(List<Long> values) {
            addCriterion("agcy_id not in", values, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdBetween(Long value1, Long value2) {
            addCriterion("agcy_id between", value1, value2, "agcyId");
            return (Criteria) this;
        }

        public Criteria andAgcyIdNotBetween(Long value1, Long value2) {
            addCriterion("agcy_id not between", value1, value2, "agcyId");
            return (Criteria) this;
        }

        public Criteria andYearIsNull() {
            addCriterion("year is null");
            return (Criteria) this;
        }

        public Criteria andYearIsNotNull() {
            addCriterion("year is not null");
            return (Criteria) this;
        }

        public Criteria andYearEqualTo(Integer value) {
            addCriterion("year =", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotEqualTo(Integer value) {
            addCriterion("year <>", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearGreaterThan(Integer value) {
            addCriterion("year >", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearGreaterThanOrEqualTo(Integer value) {
            addCriterion("year >=", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearLessThan(Integer value) {
            addCriterion("year <", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearLessThanOrEqualTo(Integer value) {
            addCriterion("year <=", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearIn(List<Integer> values) {
            addCriterion("year in", values, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotIn(List<Integer> values) {
            addCriterion("year not in", values, "year");
            return (Criteria) this;
        }

        public Criteria andYearBetween(Integer value1, Integer value2) {
            addCriterion("year between", value1, value2, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotBetween(Integer value1, Integer value2) {
            addCriterion("year not between", value1, value2, "year");
            return (Criteria) this;
        }

        public Criteria andMonthIsNull() {
            addCriterion("month is null");
            return (Criteria) this;
        }

        public Criteria andMonthIsNotNull() {
            addCriterion("month is not null");
            return (Criteria) this;
        }

        public Criteria andMonthEqualTo(Integer value) {
            addCriterion("month =", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotEqualTo(Integer value) {
            addCriterion("month <>", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthGreaterThan(Integer value) {
            addCriterion("month >", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthGreaterThanOrEqualTo(Integer value) {
            addCriterion("month >=", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthLessThan(Integer value) {
            addCriterion("month <", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthLessThanOrEqualTo(Integer value) {
            addCriterion("month <=", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthIn(List<Integer> values) {
            addCriterion("month in", values, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotIn(List<Integer> values) {
            addCriterion("month not in", values, "month");
            return (Criteria) this;
        }

        public Criteria andMonthBetween(Integer value1, Integer value2) {
            addCriterion("month between", value1, value2, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotBetween(Integer value1, Integer value2) {
            addCriterion("month not between", value1, value2, "month");
            return (Criteria) this;
        }

        public Criteria andDayIsNull() {
            addCriterion("day is null");
            return (Criteria) this;
        }

        public Criteria andDayIsNotNull() {
            addCriterion("day is not null");
            return (Criteria) this;
        }

        public Criteria andDayEqualTo(Integer value) {
            addCriterion("day =", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotEqualTo(Integer value) {
            addCriterion("day <>", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThan(Integer value) {
            addCriterion("day >", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThanOrEqualTo(Integer value) {
            addCriterion("day >=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThan(Integer value) {
            addCriterion("day <", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThanOrEqualTo(Integer value) {
            addCriterion("day <=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayIn(List<Integer> values) {
            addCriterion("day in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotIn(List<Integer> values) {
            addCriterion("day not in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayBetween(Integer value1, Integer value2) {
            addCriterion("day between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotBetween(Integer value1, Integer value2) {
            addCriterion("day not between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseIsNull() {
            addCriterion("poll_dev_ele_use is null");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseIsNotNull() {
            addCriterion("poll_dev_ele_use is not null");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseEqualTo(String value) {
            addCriterion("poll_dev_ele_use =", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseNotEqualTo(String value) {
            addCriterion("poll_dev_ele_use <>", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseGreaterThan(String value) {
            addCriterion("poll_dev_ele_use >", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseGreaterThanOrEqualTo(String value) {
            addCriterion("poll_dev_ele_use >=", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseLessThan(String value) {
            addCriterion("poll_dev_ele_use <", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseLessThanOrEqualTo(String value) {
            addCriterion("poll_dev_ele_use <=", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseLike(String value) {
            addCriterion("poll_dev_ele_use like", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseNotLike(String value) {
            addCriterion("poll_dev_ele_use not like", value, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseIn(List<String> values) {
            addCriterion("poll_dev_ele_use in", values, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseNotIn(List<String> values) {
            addCriterion("poll_dev_ele_use not in", values, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseBetween(String value1, String value2) {
            addCriterion("poll_dev_ele_use between", value1, value2, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevEleUseNotBetween(String value1, String value2) {
            addCriterion("poll_dev_ele_use not between", value1, value2, "pollDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseIsNull() {
            addCriterion("con_dev_ele_use is null");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseIsNotNull() {
            addCriterion("con_dev_ele_use is not null");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseEqualTo(String value) {
            addCriterion("con_dev_ele_use =", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseNotEqualTo(String value) {
            addCriterion("con_dev_ele_use <>", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseGreaterThan(String value) {
            addCriterion("con_dev_ele_use >", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseGreaterThanOrEqualTo(String value) {
            addCriterion("con_dev_ele_use >=", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseLessThan(String value) {
            addCriterion("con_dev_ele_use <", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseLessThanOrEqualTo(String value) {
            addCriterion("con_dev_ele_use <=", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseLike(String value) {
            addCriterion("con_dev_ele_use like", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseNotLike(String value) {
            addCriterion("con_dev_ele_use not like", value, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseIn(List<String> values) {
            addCriterion("con_dev_ele_use in", values, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseNotIn(List<String> values) {
            addCriterion("con_dev_ele_use not in", values, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseBetween(String value1, String value2) {
            addCriterion("con_dev_ele_use between", value1, value2, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andConDevEleUseNotBetween(String value1, String value2) {
            addCriterion("con_dev_ele_use not between", value1, value2, "conDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseIsNull() {
            addCriterion("total_dev_ele_use is null");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseIsNotNull() {
            addCriterion("total_dev_ele_use is not null");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseEqualTo(String value) {
            addCriterion("total_dev_ele_use =", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseNotEqualTo(String value) {
            addCriterion("total_dev_ele_use <>", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseGreaterThan(String value) {
            addCriterion("total_dev_ele_use >", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseGreaterThanOrEqualTo(String value) {
            addCriterion("total_dev_ele_use >=", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseLessThan(String value) {
            addCriterion("total_dev_ele_use <", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseLessThanOrEqualTo(String value) {
            addCriterion("total_dev_ele_use <=", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseLike(String value) {
            addCriterion("total_dev_ele_use like", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseNotLike(String value) {
            addCriterion("total_dev_ele_use not like", value, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseIn(List<String> values) {
            addCriterion("total_dev_ele_use in", values, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseNotIn(List<String> values) {
            addCriterion("total_dev_ele_use not in", values, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseBetween(String value1, String value2) {
            addCriterion("total_dev_ele_use between", value1, value2, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andTotalDevEleUseNotBetween(String value1, String value2) {
            addCriterion("total_dev_ele_use not between", value1, value2, "totalDevEleUse");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumIsNull() {
            addCriterion("poll_dev_err_num is null");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumIsNotNull() {
            addCriterion("poll_dev_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumEqualTo(Long value) {
            addCriterion("poll_dev_err_num =", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumNotEqualTo(Long value) {
            addCriterion("poll_dev_err_num <>", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumGreaterThan(Long value) {
            addCriterion("poll_dev_err_num >", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("poll_dev_err_num >=", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumLessThan(Long value) {
            addCriterion("poll_dev_err_num <", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumLessThanOrEqualTo(Long value) {
            addCriterion("poll_dev_err_num <=", value, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumIn(List<Long> values) {
            addCriterion("poll_dev_err_num in", values, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumNotIn(List<Long> values) {
            addCriterion("poll_dev_err_num not in", values, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumBetween(Long value1, Long value2) {
            addCriterion("poll_dev_err_num between", value1, value2, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andPollDevErrNumNotBetween(Long value1, Long value2) {
            addCriterion("poll_dev_err_num not between", value1, value2, "pollDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumIsNull() {
            addCriterion("con_dev_err_num is null");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumIsNotNull() {
            addCriterion("con_dev_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumEqualTo(Long value) {
            addCriterion("con_dev_err_num =", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumNotEqualTo(Long value) {
            addCriterion("con_dev_err_num <>", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumGreaterThan(Long value) {
            addCriterion("con_dev_err_num >", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("con_dev_err_num >=", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumLessThan(Long value) {
            addCriterion("con_dev_err_num <", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumLessThanOrEqualTo(Long value) {
            addCriterion("con_dev_err_num <=", value, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumIn(List<Long> values) {
            addCriterion("con_dev_err_num in", values, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumNotIn(List<Long> values) {
            addCriterion("con_dev_err_num not in", values, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumBetween(Long value1, Long value2) {
            addCriterion("con_dev_err_num between", value1, value2, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andConDevErrNumNotBetween(Long value1, Long value2) {
            addCriterion("con_dev_err_num not between", value1, value2, "conDevErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumIsNull() {
            addCriterion("stop_or_limit_err_num is null");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumIsNotNull() {
            addCriterion("stop_or_limit_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumEqualTo(Long value) {
            addCriterion("stop_or_limit_err_num =", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumNotEqualTo(Long value) {
            addCriterion("stop_or_limit_err_num <>", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumGreaterThan(Long value) {
            addCriterion("stop_or_limit_err_num >", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("stop_or_limit_err_num >=", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumLessThan(Long value) {
            addCriterion("stop_or_limit_err_num <", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumLessThanOrEqualTo(Long value) {
            addCriterion("stop_or_limit_err_num <=", value, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumIn(List<Long> values) {
            addCriterion("stop_or_limit_err_num in", values, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumNotIn(List<Long> values) {
            addCriterion("stop_or_limit_err_num not in", values, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumBetween(Long value1, Long value2) {
            addCriterion("stop_or_limit_err_num between", value1, value2, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andStopOrLimitErrNumNotBetween(Long value1, Long value2) {
            addCriterion("stop_or_limit_err_num not between", value1, value2, "stopOrLimitErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumIsNull() {
            addCriterion("ele_err_num is null");
            return (Criteria) this;
        }

        public Criteria andEleErrNumIsNotNull() {
            addCriterion("ele_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andEleErrNumEqualTo(Long value) {
            addCriterion("ele_err_num =", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumNotEqualTo(Long value) {
            addCriterion("ele_err_num <>", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumGreaterThan(Long value) {
            addCriterion("ele_err_num >", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("ele_err_num >=", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumLessThan(Long value) {
            addCriterion("ele_err_num <", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumLessThanOrEqualTo(Long value) {
            addCriterion("ele_err_num <=", value, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumIn(List<Long> values) {
            addCriterion("ele_err_num in", values, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumNotIn(List<Long> values) {
            addCriterion("ele_err_num not in", values, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumBetween(Long value1, Long value2) {
            addCriterion("ele_err_num between", value1, value2, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andEleErrNumNotBetween(Long value1, Long value2) {
            addCriterion("ele_err_num not between", value1, value2, "eleErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumIsNull() {
            addCriterion("power_err_num is null");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumIsNotNull() {
            addCriterion("power_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumEqualTo(Long value) {
            addCriterion("power_err_num =", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumNotEqualTo(Long value) {
            addCriterion("power_err_num <>", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumGreaterThan(Long value) {
            addCriterion("power_err_num >", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("power_err_num >=", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumLessThan(Long value) {
            addCriterion("power_err_num <", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumLessThanOrEqualTo(Long value) {
            addCriterion("power_err_num <=", value, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumIn(List<Long> values) {
            addCriterion("power_err_num in", values, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumNotIn(List<Long> values) {
            addCriterion("power_err_num not in", values, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumBetween(Long value1, Long value2) {
            addCriterion("power_err_num between", value1, value2, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andPowerErrNumNotBetween(Long value1, Long value2) {
            addCriterion("power_err_num not between", value1, value2, "powerErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumIsNull() {
            addCriterion("dev_stop_err_num is null");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumIsNotNull() {
            addCriterion("dev_stop_err_num is not null");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumEqualTo(Long value) {
            addCriterion("dev_stop_err_num =", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumNotEqualTo(Long value) {
            addCriterion("dev_stop_err_num <>", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumGreaterThan(Long value) {
            addCriterion("dev_stop_err_num >", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumGreaterThanOrEqualTo(Long value) {
            addCriterion("dev_stop_err_num >=", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumLessThan(Long value) {
            addCriterion("dev_stop_err_num <", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumLessThanOrEqualTo(Long value) {
            addCriterion("dev_stop_err_num <=", value, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumIn(List<Long> values) {
            addCriterion("dev_stop_err_num in", values, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumNotIn(List<Long> values) {
            addCriterion("dev_stop_err_num not in", values, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumBetween(Long value1, Long value2) {
            addCriterion("dev_stop_err_num between", value1, value2, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andDevStopErrNumNotBetween(Long value1, Long value2) {
            addCriterion("dev_stop_err_num not between", value1, value2, "devStopErrNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumIsNull() {
            addCriterion("both_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andBothDevNumIsNotNull() {
            addCriterion("both_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andBothDevNumEqualTo(Integer value) {
            addCriterion("both_dev_num =", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumNotEqualTo(Integer value) {
            addCriterion("both_dev_num <>", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumGreaterThan(Integer value) {
            addCriterion("both_dev_num >", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("both_dev_num >=", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumLessThan(Integer value) {
            addCriterion("both_dev_num <", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("both_dev_num <=", value, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumIn(List<Integer> values) {
            addCriterion("both_dev_num in", values, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumNotIn(List<Integer> values) {
            addCriterion("both_dev_num not in", values, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumBetween(Integer value1, Integer value2) {
            addCriterion("both_dev_num between", value1, value2, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andBothDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("both_dev_num not between", value1, value2, "bothDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumIsNull() {
            addCriterion("poll_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andPollDevNumIsNotNull() {
            addCriterion("poll_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andPollDevNumEqualTo(Integer value) {
            addCriterion("poll_dev_num =", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumNotEqualTo(Integer value) {
            addCriterion("poll_dev_num <>", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumGreaterThan(Integer value) {
            addCriterion("poll_dev_num >", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("poll_dev_num >=", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumLessThan(Integer value) {
            addCriterion("poll_dev_num <", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("poll_dev_num <=", value, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumIn(List<Integer> values) {
            addCriterion("poll_dev_num in", values, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumNotIn(List<Integer> values) {
            addCriterion("poll_dev_num not in", values, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumBetween(Integer value1, Integer value2) {
            addCriterion("poll_dev_num between", value1, value2, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andPollDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("poll_dev_num not between", value1, value2, "pollDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumIsNull() {
            addCriterion("con_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andConDevNumIsNotNull() {
            addCriterion("con_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andConDevNumEqualTo(Integer value) {
            addCriterion("con_dev_num =", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumNotEqualTo(Integer value) {
            addCriterion("con_dev_num <>", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumGreaterThan(Integer value) {
            addCriterion("con_dev_num >", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("con_dev_num >=", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumLessThan(Integer value) {
            addCriterion("con_dev_num <", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("con_dev_num <=", value, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumIn(List<Integer> values) {
            addCriterion("con_dev_num in", values, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumNotIn(List<Integer> values) {
            addCriterion("con_dev_num not in", values, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumBetween(Integer value1, Integer value2) {
            addCriterion("con_dev_num between", value1, value2, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andConDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("con_dev_num not between", value1, value2, "conDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumIsNull() {
            addCriterion("run_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andRunDevNumIsNotNull() {
            addCriterion("run_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andRunDevNumEqualTo(Integer value) {
            addCriterion("run_dev_num =", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumNotEqualTo(Integer value) {
            addCriterion("run_dev_num <>", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumGreaterThan(Integer value) {
            addCriterion("run_dev_num >", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("run_dev_num >=", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumLessThan(Integer value) {
            addCriterion("run_dev_num <", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("run_dev_num <=", value, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumIn(List<Integer> values) {
            addCriterion("run_dev_num in", values, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumNotIn(List<Integer> values) {
            addCriterion("run_dev_num not in", values, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumBetween(Integer value1, Integer value2) {
            addCriterion("run_dev_num between", value1, value2, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andRunDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("run_dev_num not between", value1, value2, "runDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumIsNull() {
            addCriterion("stop_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andStopDevNumIsNotNull() {
            addCriterion("stop_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andStopDevNumEqualTo(Integer value) {
            addCriterion("stop_dev_num =", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumNotEqualTo(Integer value) {
            addCriterion("stop_dev_num <>", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumGreaterThan(Integer value) {
            addCriterion("stop_dev_num >", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("stop_dev_num >=", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumLessThan(Integer value) {
            addCriterion("stop_dev_num <", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("stop_dev_num <=", value, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumIn(List<Integer> values) {
            addCriterion("stop_dev_num in", values, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumNotIn(List<Integer> values) {
            addCriterion("stop_dev_num not in", values, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumBetween(Integer value1, Integer value2) {
            addCriterion("stop_dev_num between", value1, value2, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andStopDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("stop_dev_num not between", value1, value2, "stopDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumIsNull() {
            addCriterion("lost_dev_num is null");
            return (Criteria) this;
        }

        public Criteria andLostDevNumIsNotNull() {
            addCriterion("lost_dev_num is not null");
            return (Criteria) this;
        }

        public Criteria andLostDevNumEqualTo(Integer value) {
            addCriterion("lost_dev_num =", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumNotEqualTo(Integer value) {
            addCriterion("lost_dev_num <>", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumGreaterThan(Integer value) {
            addCriterion("lost_dev_num >", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("lost_dev_num >=", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumLessThan(Integer value) {
            addCriterion("lost_dev_num <", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumLessThanOrEqualTo(Integer value) {
            addCriterion("lost_dev_num <=", value, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumIn(List<Integer> values) {
            addCriterion("lost_dev_num in", values, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumNotIn(List<Integer> values) {
            addCriterion("lost_dev_num not in", values, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumBetween(Integer value1, Integer value2) {
            addCriterion("lost_dev_num between", value1, value2, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andLostDevNumNotBetween(Integer value1, Integer value2) {
            addCriterion("lost_dev_num not between", value1, value2, "lostDevNum");
            return (Criteria) this;
        }

        public Criteria andPowerMaxIsNull() {
            addCriterion("power_max is null");
            return (Criteria) this;
        }

        public Criteria andPowerMaxIsNotNull() {
            addCriterion("power_max is not null");
            return (Criteria) this;
        }

        public Criteria andPowerMaxEqualTo(String value) {
            addCriterion("power_max =", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxNotEqualTo(String value) {
            addCriterion("power_max <>", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxGreaterThan(String value) {
            addCriterion("power_max >", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxGreaterThanOrEqualTo(String value) {
            addCriterion("power_max >=", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxLessThan(String value) {
            addCriterion("power_max <", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxLessThanOrEqualTo(String value) {
            addCriterion("power_max <=", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxLike(String value) {
            addCriterion("power_max like", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxNotLike(String value) {
            addCriterion("power_max not like", value, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxIn(List<String> values) {
            addCriterion("power_max in", values, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxNotIn(List<String> values) {
            addCriterion("power_max not in", values, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxBetween(String value1, String value2) {
            addCriterion("power_max between", value1, value2, "powerMax");
            return (Criteria) this;
        }

        public Criteria andPowerMaxNotBetween(String value1, String value2) {
            addCriterion("power_max not between", value1, value2, "powerMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxIsNull() {
            addCriterion("ele_max is null");
            return (Criteria) this;
        }

        public Criteria andEleMaxIsNotNull() {
            addCriterion("ele_max is not null");
            return (Criteria) this;
        }

        public Criteria andEleMaxEqualTo(String value) {
            addCriterion("ele_max =", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxNotEqualTo(String value) {
            addCriterion("ele_max <>", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxGreaterThan(String value) {
            addCriterion("ele_max >", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxGreaterThanOrEqualTo(String value) {
            addCriterion("ele_max >=", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxLessThan(String value) {
            addCriterion("ele_max <", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxLessThanOrEqualTo(String value) {
            addCriterion("ele_max <=", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxLike(String value) {
            addCriterion("ele_max like", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxNotLike(String value) {
            addCriterion("ele_max not like", value, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxIn(List<String> values) {
            addCriterion("ele_max in", values, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxNotIn(List<String> values) {
            addCriterion("ele_max not in", values, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxBetween(String value1, String value2) {
            addCriterion("ele_max between", value1, value2, "eleMax");
            return (Criteria) this;
        }

        public Criteria andEleMaxNotBetween(String value1, String value2) {
            addCriterion("ele_max not between", value1, value2, "eleMax");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeIsNull() {
            addCriterion("max_power_time is null");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeIsNotNull() {
            addCriterion("max_power_time is not null");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeEqualTo(Date value) {
            addCriterion("max_power_time =", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeNotEqualTo(Date value) {
            addCriterion("max_power_time <>", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeGreaterThan(Date value) {
            addCriterion("max_power_time >", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("max_power_time >=", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeLessThan(Date value) {
            addCriterion("max_power_time <", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeLessThanOrEqualTo(Date value) {
            addCriterion("max_power_time <=", value, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeIn(List<Date> values) {
            addCriterion("max_power_time in", values, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeNotIn(List<Date> values) {
            addCriterion("max_power_time not in", values, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeBetween(Date value1, Date value2) {
            addCriterion("max_power_time between", value1, value2, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxPowerTimeNotBetween(Date value1, Date value2) {
            addCriterion("max_power_time not between", value1, value2, "maxPowerTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeIsNull() {
            addCriterion("max_ele_time is null");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeIsNotNull() {
            addCriterion("max_ele_time is not null");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeEqualTo(Date value) {
            addCriterion("max_ele_time =", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeNotEqualTo(Date value) {
            addCriterion("max_ele_time <>", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeGreaterThan(Date value) {
            addCriterion("max_ele_time >", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("max_ele_time >=", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeLessThan(Date value) {
            addCriterion("max_ele_time <", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeLessThanOrEqualTo(Date value) {
            addCriterion("max_ele_time <=", value, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeIn(List<Date> values) {
            addCriterion("max_ele_time in", values, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeNotIn(List<Date> values) {
            addCriterion("max_ele_time not in", values, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeBetween(Date value1, Date value2) {
            addCriterion("max_ele_time between", value1, value2, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andMaxEleTimeNotBetween(Date value1, Date value2) {
            addCriterion("max_ele_time not between", value1, value2, "maxEleTime");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("platform_id is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("platform_id is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Integer value) {
            addCriterion("platform_id =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Integer value) {
            addCriterion("platform_id <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Integer value) {
            addCriterion("platform_id >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("platform_id >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Integer value) {
            addCriterion("platform_id <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Integer value) {
            addCriterion("platform_id <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Integer> values) {
            addCriterion("platform_id in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Integer> values) {
            addCriterion("platform_id not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Integer value1, Integer value2) {
            addCriterion("platform_id between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Integer value1, Integer value2) {
            addCriterion("platform_id not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andProducStateIsNull() {
            addCriterion("produc_state is null");
            return (Criteria) this;
        }

        public Criteria andProducStateIsNotNull() {
            addCriterion("produc_state is not null");
            return (Criteria) this;
        }

        public Criteria andProducStateEqualTo(Integer value) {
            addCriterion("produc_state =", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateNotEqualTo(Integer value) {
            addCriterion("produc_state <>", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateGreaterThan(Integer value) {
            addCriterion("produc_state >", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("produc_state >=", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateLessThan(Integer value) {
            addCriterion("produc_state <", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateLessThanOrEqualTo(Integer value) {
            addCriterion("produc_state <=", value, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateIn(List<Integer> values) {
            addCriterion("produc_state in", values, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateNotIn(List<Integer> values) {
            addCriterion("produc_state not in", values, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateBetween(Integer value1, Integer value2) {
            addCriterion("produc_state between", value1, value2, "producState");
            return (Criteria) this;
        }

        public Criteria andProducStateNotBetween(Integer value1, Integer value2) {
            addCriterion("produc_state not between", value1, value2, "producState");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}