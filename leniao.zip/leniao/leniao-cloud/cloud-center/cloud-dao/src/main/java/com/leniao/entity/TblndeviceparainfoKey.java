package com.leniao.entity;

public class TblndeviceparainfoKey {
    private Integer devnodepk;

    private Integer devidpk;

    public Integer getDevnodepk() {
        return devnodepk;
    }

    public void setDevnodepk(Integer devnodepk) {
        this.devnodepk = devnodepk;
    }

    public Integer getDevidpk() {
        return devidpk;
    }

    public void setDevidpk(Integer devidpk) {
        this.devidpk = devidpk;
    }
}