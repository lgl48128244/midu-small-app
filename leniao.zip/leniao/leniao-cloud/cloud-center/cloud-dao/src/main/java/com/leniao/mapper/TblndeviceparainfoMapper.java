package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.Tblndeviceparainfo;
import com.leniao.entity.TblndeviceparainfoExample;
import com.leniao.entity.TblndeviceparainfoKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblndeviceparainfoMapper extends BaseMapper<Tblndeviceparainfo>{
    int countByExample(TblndeviceparainfoExample example);

    int deleteByExample(TblndeviceparainfoExample example);

    int deleteByPrimaryKey(TblndeviceparainfoKey key);

    int insert(Tblndeviceparainfo record);

    int insertSelective(Tblndeviceparainfo record);

    List<Tblndeviceparainfo> selectByExample(TblndeviceparainfoExample example);

    Tblndeviceparainfo selectByPrimaryKey(TblndeviceparainfoKey key);

    int updateByExampleSelective(@Param("record") Tblndeviceparainfo record, @Param("example") TblndeviceparainfoExample example);

    int updateByExample(@Param("record") Tblndeviceparainfo record, @Param("example") TblndeviceparainfoExample example);

    int updateByPrimaryKeySelective(Tblndeviceparainfo record);

    int updateByPrimaryKey(Tblndeviceparainfo record);
}