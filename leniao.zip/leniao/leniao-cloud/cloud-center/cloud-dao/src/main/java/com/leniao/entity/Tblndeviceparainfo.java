package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.math.BigDecimal;

@ToString
@TableName("tblndeviceparainfo")
public class Tblndeviceparainfo extends TblndeviceparainfoKey {
    private BigDecimal paravalue;

    private String paraisopen;

    private Integer paraprop;

    public BigDecimal getParavalue() {
        return paravalue;
    }

    public void setParavalue(BigDecimal paravalue) {
        this.paravalue = paravalue;
    }

    public String getParaisopen() {
        return paraisopen;
    }

    public void setParaisopen(String paraisopen) {
        this.paraisopen = paraisopen == null ? null : paraisopen.trim();
    }

    public Integer getParaprop() {
        return paraprop;
    }

    public void setParaprop(Integer paraprop) {
        this.paraprop = paraprop;
    }
}