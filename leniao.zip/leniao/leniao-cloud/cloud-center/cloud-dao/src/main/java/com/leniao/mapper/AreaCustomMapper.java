package com.leniao.mapper;

import com.leniao.entity.Area;

import java.util.List;

public interface AreaCustomMapper {
    /**
     * 省信息查询
     * @param areaId 区域ID
     * @return 区域信息
     */
    List<Area> selectProvinceList(String areaId);

    /**
     * 市信息查询
     * @param provinceId 省区域ID
     * @return 市区域信息
     */
    List<Area> selectCityList(String provinceId);

    /**
     * 县信息查询
     * @param cityId 市区域ID
     * @return 县区域信息
     */
    List<Area> selectCountyList(String cityId);
}