package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.TblngridGradehistory;
import com.leniao.entity.TblngridGradehistoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblngridGradehistoryMapper extends BaseMapper<TblngridGradehistory> {
    int countByExample(TblngridGradehistoryExample example);

    int deleteByExample(TblngridGradehistoryExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TblngridGradehistory record);

    int insertSelective(TblngridGradehistory record);

    List<TblngridGradehistory> selectByExample(TblngridGradehistoryExample example);

    TblngridGradehistory selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TblngridGradehistory record, @Param("example") TblngridGradehistoryExample example);

    int updateByExample(@Param("record") TblngridGradehistory record, @Param("example") TblngridGradehistoryExample example);

    int updateByPrimaryKeySelective(TblngridGradehistory record);

    int updateByPrimaryKey(TblngridGradehistory record);
}