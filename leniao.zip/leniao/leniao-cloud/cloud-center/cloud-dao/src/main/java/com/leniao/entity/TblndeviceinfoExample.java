package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TblndeviceinfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TblndeviceinfoExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDevidpkIsNull() {
            addCriterion("devIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevidpkIsNotNull() {
            addCriterion("devIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevidpkEqualTo(Integer value) {
            addCriterion("devIdpk =", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotEqualTo(Integer value) {
            addCriterion("devIdpk <>", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThan(Integer value) {
            addCriterion("devIdpk >", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIdpk >=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThan(Integer value) {
            addCriterion("devIdpk <", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkLessThanOrEqualTo(Integer value) {
            addCriterion("devIdpk <=", value, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkIn(List<Integer> values) {
            addCriterion("devIdpk in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotIn(List<Integer> values) {
            addCriterion("devIdpk not in", values, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevidpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devIdpk not between", value1, value2, "devidpk");
            return (Criteria) this;
        }

        public Criteria andDevsysidIsNull() {
            addCriterion("devSysId is null");
            return (Criteria) this;
        }

        public Criteria andDevsysidIsNotNull() {
            addCriterion("devSysId is not null");
            return (Criteria) this;
        }

        public Criteria andDevsysidEqualTo(Integer value) {
            addCriterion("devSysId =", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidNotEqualTo(Integer value) {
            addCriterion("devSysId <>", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidGreaterThan(Integer value) {
            addCriterion("devSysId >", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidGreaterThanOrEqualTo(Integer value) {
            addCriterion("devSysId >=", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidLessThan(Integer value) {
            addCriterion("devSysId <", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidLessThanOrEqualTo(Integer value) {
            addCriterion("devSysId <=", value, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidIn(List<Integer> values) {
            addCriterion("devSysId in", values, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidNotIn(List<Integer> values) {
            addCriterion("devSysId not in", values, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidBetween(Integer value1, Integer value2) {
            addCriterion("devSysId between", value1, value2, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevsysidNotBetween(Integer value1, Integer value2) {
            addCriterion("devSysId not between", value1, value2, "devsysid");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkIsNull() {
            addCriterion("devParentIdpk is null");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkIsNotNull() {
            addCriterion("devParentIdpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkEqualTo(Integer value) {
            addCriterion("devParentIdpk =", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkNotEqualTo(Integer value) {
            addCriterion("devParentIdpk <>", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkGreaterThan(Integer value) {
            addCriterion("devParentIdpk >", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("devParentIdpk >=", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkLessThan(Integer value) {
            addCriterion("devParentIdpk <", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkLessThanOrEqualTo(Integer value) {
            addCriterion("devParentIdpk <=", value, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkIn(List<Integer> values) {
            addCriterion("devParentIdpk in", values, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkNotIn(List<Integer> values) {
            addCriterion("devParentIdpk not in", values, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkBetween(Integer value1, Integer value2) {
            addCriterion("devParentIdpk between", value1, value2, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andDevparentidpkNotBetween(Integer value1, Integer value2) {
            addCriterion("devParentIdpk not between", value1, value2, "devparentidpk");
            return (Criteria) this;
        }

        public Criteria andFirmidIsNull() {
            addCriterion("firmId is null");
            return (Criteria) this;
        }

        public Criteria andFirmidIsNotNull() {
            addCriterion("firmId is not null");
            return (Criteria) this;
        }

        public Criteria andFirmidEqualTo(Integer value) {
            addCriterion("firmId =", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidNotEqualTo(Integer value) {
            addCriterion("firmId <>", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidGreaterThan(Integer value) {
            addCriterion("firmId >", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidGreaterThanOrEqualTo(Integer value) {
            addCriterion("firmId >=", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidLessThan(Integer value) {
            addCriterion("firmId <", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidLessThanOrEqualTo(Integer value) {
            addCriterion("firmId <=", value, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidIn(List<Integer> values) {
            addCriterion("firmId in", values, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidNotIn(List<Integer> values) {
            addCriterion("firmId not in", values, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidBetween(Integer value1, Integer value2) {
            addCriterion("firmId between", value1, value2, "firmid");
            return (Criteria) this;
        }

        public Criteria andFirmidNotBetween(Integer value1, Integer value2) {
            addCriterion("firmId not between", value1, value2, "firmid");
            return (Criteria) this;
        }

        public Criteria andProjidIsNull() {
            addCriterion("projId is null");
            return (Criteria) this;
        }

        public Criteria andProjidIsNotNull() {
            addCriterion("projId is not null");
            return (Criteria) this;
        }

        public Criteria andProjidEqualTo(Integer value) {
            addCriterion("projId =", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotEqualTo(Integer value) {
            addCriterion("projId <>", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThan(Integer value) {
            addCriterion("projId >", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidGreaterThanOrEqualTo(Integer value) {
            addCriterion("projId >=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThan(Integer value) {
            addCriterion("projId <", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidLessThanOrEqualTo(Integer value) {
            addCriterion("projId <=", value, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidIn(List<Integer> values) {
            addCriterion("projId in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotIn(List<Integer> values) {
            addCriterion("projId not in", values, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidBetween(Integer value1, Integer value2) {
            addCriterion("projId between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andProjidNotBetween(Integer value1, Integer value2) {
            addCriterion("projId not between", value1, value2, "projid");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIsNull() {
            addCriterion("devSignature is null");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIsNotNull() {
            addCriterion("devSignature is not null");
            return (Criteria) this;
        }

        public Criteria andDevsignatureEqualTo(String value) {
            addCriterion("devSignature =", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotEqualTo(String value) {
            addCriterion("devSignature <>", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureGreaterThan(String value) {
            addCriterion("devSignature >", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureGreaterThanOrEqualTo(String value) {
            addCriterion("devSignature >=", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLessThan(String value) {
            addCriterion("devSignature <", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLessThanOrEqualTo(String value) {
            addCriterion("devSignature <=", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureLike(String value) {
            addCriterion("devSignature like", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotLike(String value) {
            addCriterion("devSignature not like", value, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureIn(List<String> values) {
            addCriterion("devSignature in", values, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotIn(List<String> values) {
            addCriterion("devSignature not in", values, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureBetween(String value1, String value2) {
            addCriterion("devSignature between", value1, value2, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevsignatureNotBetween(String value1, String value2) {
            addCriterion("devSignature not between", value1, value2, "devsignature");
            return (Criteria) this;
        }

        public Criteria andDevidIsNull() {
            addCriterion("devId is null");
            return (Criteria) this;
        }

        public Criteria andDevidIsNotNull() {
            addCriterion("devId is not null");
            return (Criteria) this;
        }

        public Criteria andDevidEqualTo(Integer value) {
            addCriterion("devId =", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidNotEqualTo(Integer value) {
            addCriterion("devId <>", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidGreaterThan(Integer value) {
            addCriterion("devId >", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidGreaterThanOrEqualTo(Integer value) {
            addCriterion("devId >=", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidLessThan(Integer value) {
            addCriterion("devId <", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidLessThanOrEqualTo(Integer value) {
            addCriterion("devId <=", value, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidIn(List<Integer> values) {
            addCriterion("devId in", values, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidNotIn(List<Integer> values) {
            addCriterion("devId not in", values, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidBetween(Integer value1, Integer value2) {
            addCriterion("devId between", value1, value2, "devid");
            return (Criteria) this;
        }

        public Criteria andDevidNotBetween(Integer value1, Integer value2) {
            addCriterion("devId not between", value1, value2, "devid");
            return (Criteria) this;
        }

        public Criteria andDevtyIsNull() {
            addCriterion("devTy is null");
            return (Criteria) this;
        }

        public Criteria andDevtyIsNotNull() {
            addCriterion("devTy is not null");
            return (Criteria) this;
        }

        public Criteria andDevtyEqualTo(String value) {
            addCriterion("devTy =", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyNotEqualTo(String value) {
            addCriterion("devTy <>", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyGreaterThan(String value) {
            addCriterion("devTy >", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyGreaterThanOrEqualTo(String value) {
            addCriterion("devTy >=", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyLessThan(String value) {
            addCriterion("devTy <", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyLessThanOrEqualTo(String value) {
            addCriterion("devTy <=", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyLike(String value) {
            addCriterion("devTy like", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyNotLike(String value) {
            addCriterion("devTy not like", value, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyIn(List<String> values) {
            addCriterion("devTy in", values, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyNotIn(List<String> values) {
            addCriterion("devTy not in", values, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyBetween(String value1, String value2) {
            addCriterion("devTy between", value1, value2, "devty");
            return (Criteria) this;
        }

        public Criteria andDevtyNotBetween(String value1, String value2) {
            addCriterion("devTy not between", value1, value2, "devty");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeIsNull() {
            addCriterion("devLoginTime is null");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeIsNotNull() {
            addCriterion("devLoginTime is not null");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeEqualTo(Date value) {
            addCriterion("devLoginTime =", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeNotEqualTo(Date value) {
            addCriterion("devLoginTime <>", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeGreaterThan(Date value) {
            addCriterion("devLoginTime >", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeGreaterThanOrEqualTo(Date value) {
            addCriterion("devLoginTime >=", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeLessThan(Date value) {
            addCriterion("devLoginTime <", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeLessThanOrEqualTo(Date value) {
            addCriterion("devLoginTime <=", value, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeIn(List<Date> values) {
            addCriterion("devLoginTime in", values, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeNotIn(List<Date> values) {
            addCriterion("devLoginTime not in", values, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeBetween(Date value1, Date value2) {
            addCriterion("devLoginTime between", value1, value2, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevlogintimeNotBetween(Date value1, Date value2) {
            addCriterion("devLoginTime not between", value1, value2, "devlogintime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeIsNull() {
            addCriterion("devProductTime is null");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeIsNotNull() {
            addCriterion("devProductTime is not null");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeEqualTo(Date value) {
            addCriterion("devProductTime =", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeNotEqualTo(Date value) {
            addCriterion("devProductTime <>", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeGreaterThan(Date value) {
            addCriterion("devProductTime >", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeGreaterThanOrEqualTo(Date value) {
            addCriterion("devProductTime >=", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeLessThan(Date value) {
            addCriterion("devProductTime <", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeLessThanOrEqualTo(Date value) {
            addCriterion("devProductTime <=", value, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeIn(List<Date> values) {
            addCriterion("devProductTime in", values, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeNotIn(List<Date> values) {
            addCriterion("devProductTime not in", values, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeBetween(Date value1, Date value2) {
            addCriterion("devProductTime between", value1, value2, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevproducttimeNotBetween(Date value1, Date value2) {
            addCriterion("devProductTime not between", value1, value2, "devproducttime");
            return (Criteria) this;
        }

        public Criteria andDevisscrapIsNull() {
            addCriterion("devIsScrap is null");
            return (Criteria) this;
        }

        public Criteria andDevisscrapIsNotNull() {
            addCriterion("devIsScrap is not null");
            return (Criteria) this;
        }

        public Criteria andDevisscrapEqualTo(Integer value) {
            addCriterion("devIsScrap =", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapNotEqualTo(Integer value) {
            addCriterion("devIsScrap <>", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapGreaterThan(Integer value) {
            addCriterion("devIsScrap >", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapGreaterThanOrEqualTo(Integer value) {
            addCriterion("devIsScrap >=", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapLessThan(Integer value) {
            addCriterion("devIsScrap <", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapLessThanOrEqualTo(Integer value) {
            addCriterion("devIsScrap <=", value, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapIn(List<Integer> values) {
            addCriterion("devIsScrap in", values, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapNotIn(List<Integer> values) {
            addCriterion("devIsScrap not in", values, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapBetween(Integer value1, Integer value2) {
            addCriterion("devIsScrap between", value1, value2, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevisscrapNotBetween(Integer value1, Integer value2) {
            addCriterion("devIsScrap not between", value1, value2, "devisscrap");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeIsNull() {
            addCriterion("devScrapTime is null");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeIsNotNull() {
            addCriterion("devScrapTime is not null");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeEqualTo(Date value) {
            addCriterion("devScrapTime =", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeNotEqualTo(Date value) {
            addCriterion("devScrapTime <>", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeGreaterThan(Date value) {
            addCriterion("devScrapTime >", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeGreaterThanOrEqualTo(Date value) {
            addCriterion("devScrapTime >=", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeLessThan(Date value) {
            addCriterion("devScrapTime <", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeLessThanOrEqualTo(Date value) {
            addCriterion("devScrapTime <=", value, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeIn(List<Date> values) {
            addCriterion("devScrapTime in", values, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeNotIn(List<Date> values) {
            addCriterion("devScrapTime not in", values, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeBetween(Date value1, Date value2) {
            addCriterion("devScrapTime between", value1, value2, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDevscraptimeNotBetween(Date value1, Date value2) {
            addCriterion("devScrapTime not between", value1, value2, "devscraptime");
            return (Criteria) this;
        }

        public Criteria andDrawingidIsNull() {
            addCriterion("drawingId is null");
            return (Criteria) this;
        }

        public Criteria andDrawingidIsNotNull() {
            addCriterion("drawingId is not null");
            return (Criteria) this;
        }

        public Criteria andDrawingidEqualTo(Integer value) {
            addCriterion("drawingId =", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidNotEqualTo(Integer value) {
            addCriterion("drawingId <>", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidGreaterThan(Integer value) {
            addCriterion("drawingId >", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidGreaterThanOrEqualTo(Integer value) {
            addCriterion("drawingId >=", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidLessThan(Integer value) {
            addCriterion("drawingId <", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidLessThanOrEqualTo(Integer value) {
            addCriterion("drawingId <=", value, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidIn(List<Integer> values) {
            addCriterion("drawingId in", values, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidNotIn(List<Integer> values) {
            addCriterion("drawingId not in", values, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidBetween(Integer value1, Integer value2) {
            addCriterion("drawingId between", value1, value2, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDrawingidNotBetween(Integer value1, Integer value2) {
            addCriterion("drawingId not between", value1, value2, "drawingid");
            return (Criteria) this;
        }

        public Criteria andDevplotxIsNull() {
            addCriterion("devPlotX is null");
            return (Criteria) this;
        }

        public Criteria andDevplotxIsNotNull() {
            addCriterion("devPlotX is not null");
            return (Criteria) this;
        }

        public Criteria andDevplotxEqualTo(Float value) {
            addCriterion("devPlotX =", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxNotEqualTo(Float value) {
            addCriterion("devPlotX <>", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxGreaterThan(Float value) {
            addCriterion("devPlotX >", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxGreaterThanOrEqualTo(Float value) {
            addCriterion("devPlotX >=", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxLessThan(Float value) {
            addCriterion("devPlotX <", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxLessThanOrEqualTo(Float value) {
            addCriterion("devPlotX <=", value, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxIn(List<Float> values) {
            addCriterion("devPlotX in", values, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxNotIn(List<Float> values) {
            addCriterion("devPlotX not in", values, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxBetween(Float value1, Float value2) {
            addCriterion("devPlotX between", value1, value2, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotxNotBetween(Float value1, Float value2) {
            addCriterion("devPlotX not between", value1, value2, "devplotx");
            return (Criteria) this;
        }

        public Criteria andDevplotyIsNull() {
            addCriterion("devPlotY is null");
            return (Criteria) this;
        }

        public Criteria andDevplotyIsNotNull() {
            addCriterion("devPlotY is not null");
            return (Criteria) this;
        }

        public Criteria andDevplotyEqualTo(Float value) {
            addCriterion("devPlotY =", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyNotEqualTo(Float value) {
            addCriterion("devPlotY <>", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyGreaterThan(Float value) {
            addCriterion("devPlotY >", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyGreaterThanOrEqualTo(Float value) {
            addCriterion("devPlotY >=", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyLessThan(Float value) {
            addCriterion("devPlotY <", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyLessThanOrEqualTo(Float value) {
            addCriterion("devPlotY <=", value, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyIn(List<Float> values) {
            addCriterion("devPlotY in", values, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyNotIn(List<Float> values) {
            addCriterion("devPlotY not in", values, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyBetween(Float value1, Float value2) {
            addCriterion("devPlotY between", value1, value2, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevplotyNotBetween(Float value1, Float value2) {
            addCriterion("devPlotY not between", value1, value2, "devploty");
            return (Criteria) this;
        }

        public Criteria andDevremarkIsNull() {
            addCriterion("devRemark is null");
            return (Criteria) this;
        }

        public Criteria andDevremarkIsNotNull() {
            addCriterion("devRemark is not null");
            return (Criteria) this;
        }

        public Criteria andDevremarkEqualTo(String value) {
            addCriterion("devRemark =", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkNotEqualTo(String value) {
            addCriterion("devRemark <>", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkGreaterThan(String value) {
            addCriterion("devRemark >", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkGreaterThanOrEqualTo(String value) {
            addCriterion("devRemark >=", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkLessThan(String value) {
            addCriterion("devRemark <", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkLessThanOrEqualTo(String value) {
            addCriterion("devRemark <=", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkLike(String value) {
            addCriterion("devRemark like", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkNotLike(String value) {
            addCriterion("devRemark not like", value, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkIn(List<String> values) {
            addCriterion("devRemark in", values, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkNotIn(List<String> values) {
            addCriterion("devRemark not in", values, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkBetween(String value1, String value2) {
            addCriterion("devRemark between", value1, value2, "devremark");
            return (Criteria) this;
        }

        public Criteria andDevremarkNotBetween(String value1, String value2) {
            addCriterion("devRemark not between", value1, value2, "devremark");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isDelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isDelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Integer value) {
            addCriterion("isDelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Integer value) {
            addCriterion("isDelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Integer value) {
            addCriterion("isDelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("isDelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Integer value) {
            addCriterion("isDelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Integer value) {
            addCriterion("isDelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Integer> values) {
            addCriterion("isDelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Integer> values) {
            addCriterion("isDelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Integer value1, Integer value2) {
            addCriterion("isDelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("isDelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andRoadIsNull() {
            addCriterion("road is null");
            return (Criteria) this;
        }

        public Criteria andRoadIsNotNull() {
            addCriterion("road is not null");
            return (Criteria) this;
        }

        public Criteria andRoadEqualTo(Integer value) {
            addCriterion("road =", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadNotEqualTo(Integer value) {
            addCriterion("road <>", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadGreaterThan(Integer value) {
            addCriterion("road >", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadGreaterThanOrEqualTo(Integer value) {
            addCriterion("road >=", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadLessThan(Integer value) {
            addCriterion("road <", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadLessThanOrEqualTo(Integer value) {
            addCriterion("road <=", value, "road");
            return (Criteria) this;
        }

        public Criteria andRoadIn(List<Integer> values) {
            addCriterion("road in", values, "road");
            return (Criteria) this;
        }

        public Criteria andRoadNotIn(List<Integer> values) {
            addCriterion("road not in", values, "road");
            return (Criteria) this;
        }

        public Criteria andRoadBetween(Integer value1, Integer value2) {
            addCriterion("road between", value1, value2, "road");
            return (Criteria) this;
        }

        public Criteria andRoadNotBetween(Integer value1, Integer value2) {
            addCriterion("road not between", value1, value2, "road");
            return (Criteria) this;
        }

        public Criteria andInstalllocationIsNull() {
            addCriterion("installLocation is null");
            return (Criteria) this;
        }

        public Criteria andInstalllocationIsNotNull() {
            addCriterion("installLocation is not null");
            return (Criteria) this;
        }

        public Criteria andInstalllocationEqualTo(String value) {
            addCriterion("installLocation =", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationNotEqualTo(String value) {
            addCriterion("installLocation <>", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationGreaterThan(String value) {
            addCriterion("installLocation >", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationGreaterThanOrEqualTo(String value) {
            addCriterion("installLocation >=", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationLessThan(String value) {
            addCriterion("installLocation <", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationLessThanOrEqualTo(String value) {
            addCriterion("installLocation <=", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationLike(String value) {
            addCriterion("installLocation like", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationNotLike(String value) {
            addCriterion("installLocation not like", value, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationIn(List<String> values) {
            addCriterion("installLocation in", values, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationNotIn(List<String> values) {
            addCriterion("installLocation not in", values, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationBetween(String value1, String value2) {
            addCriterion("installLocation between", value1, value2, "installlocation");
            return (Criteria) this;
        }

        public Criteria andInstalllocationNotBetween(String value1, String value2) {
            addCriterion("installLocation not between", value1, value2, "installlocation");
            return (Criteria) this;
        }

        public Criteria andIssendotherIsNull() {
            addCriterion("IsSendOther is null");
            return (Criteria) this;
        }

        public Criteria andIssendotherIsNotNull() {
            addCriterion("IsSendOther is not null");
            return (Criteria) this;
        }

        public Criteria andIssendotherEqualTo(String value) {
            addCriterion("IsSendOther =", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherNotEqualTo(String value) {
            addCriterion("IsSendOther <>", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherGreaterThan(String value) {
            addCriterion("IsSendOther >", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherGreaterThanOrEqualTo(String value) {
            addCriterion("IsSendOther >=", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherLessThan(String value) {
            addCriterion("IsSendOther <", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherLessThanOrEqualTo(String value) {
            addCriterion("IsSendOther <=", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherLike(String value) {
            addCriterion("IsSendOther like", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherNotLike(String value) {
            addCriterion("IsSendOther not like", value, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherIn(List<String> values) {
            addCriterion("IsSendOther in", values, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherNotIn(List<String> values) {
            addCriterion("IsSendOther not in", values, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherBetween(String value1, String value2) {
            addCriterion("IsSendOther between", value1, value2, "issendother");
            return (Criteria) this;
        }

        public Criteria andIssendotherNotBetween(String value1, String value2) {
            addCriterion("IsSendOther not between", value1, value2, "issendother");
            return (Criteria) this;
        }

        public Criteria andDevgroupidIsNull() {
            addCriterion("devgroupId is null");
            return (Criteria) this;
        }

        public Criteria andDevgroupidIsNotNull() {
            addCriterion("devgroupId is not null");
            return (Criteria) this;
        }

        public Criteria andDevgroupidEqualTo(Integer value) {
            addCriterion("devgroupId =", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidNotEqualTo(Integer value) {
            addCriterion("devgroupId <>", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidGreaterThan(Integer value) {
            addCriterion("devgroupId >", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidGreaterThanOrEqualTo(Integer value) {
            addCriterion("devgroupId >=", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidLessThan(Integer value) {
            addCriterion("devgroupId <", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidLessThanOrEqualTo(Integer value) {
            addCriterion("devgroupId <=", value, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidIn(List<Integer> values) {
            addCriterion("devgroupId in", values, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidNotIn(List<Integer> values) {
            addCriterion("devgroupId not in", values, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidBetween(Integer value1, Integer value2) {
            addCriterion("devgroupId between", value1, value2, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevgroupidNotBetween(Integer value1, Integer value2) {
            addCriterion("devgroupId not between", value1, value2, "devgroupid");
            return (Criteria) this;
        }

        public Criteria andDevtyidIsNull() {
            addCriterion("devTyId is null");
            return (Criteria) this;
        }

        public Criteria andDevtyidIsNotNull() {
            addCriterion("devTyId is not null");
            return (Criteria) this;
        }

        public Criteria andDevtyidEqualTo(Integer value) {
            addCriterion("devTyId =", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidNotEqualTo(Integer value) {
            addCriterion("devTyId <>", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidGreaterThan(Integer value) {
            addCriterion("devTyId >", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidGreaterThanOrEqualTo(Integer value) {
            addCriterion("devTyId >=", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidLessThan(Integer value) {
            addCriterion("devTyId <", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidLessThanOrEqualTo(Integer value) {
            addCriterion("devTyId <=", value, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidIn(List<Integer> values) {
            addCriterion("devTyId in", values, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidNotIn(List<Integer> values) {
            addCriterion("devTyId not in", values, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidBetween(Integer value1, Integer value2) {
            addCriterion("devTyId between", value1, value2, "devtyid");
            return (Criteria) this;
        }

        public Criteria andDevtyidNotBetween(Integer value1, Integer value2) {
            addCriterion("devTyId not between", value1, value2, "devtyid");
            return (Criteria) this;
        }

        public Criteria andIssendIsNull() {
            addCriterion("IsSend is null");
            return (Criteria) this;
        }

        public Criteria andIssendIsNotNull() {
            addCriterion("IsSend is not null");
            return (Criteria) this;
        }

        public Criteria andIssendEqualTo(String value) {
            addCriterion("IsSend =", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotEqualTo(String value) {
            addCriterion("IsSend <>", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendGreaterThan(String value) {
            addCriterion("IsSend >", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendGreaterThanOrEqualTo(String value) {
            addCriterion("IsSend >=", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendLessThan(String value) {
            addCriterion("IsSend <", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendLessThanOrEqualTo(String value) {
            addCriterion("IsSend <=", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendLike(String value) {
            addCriterion("IsSend like", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotLike(String value) {
            addCriterion("IsSend not like", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendIn(List<String> values) {
            addCriterion("IsSend in", values, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotIn(List<String> values) {
            addCriterion("IsSend not in", values, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendBetween(String value1, String value2) {
            addCriterion("IsSend between", value1, value2, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotBetween(String value1, String value2) {
            addCriterion("IsSend not between", value1, value2, "issend");
            return (Criteria) this;
        }

        public Criteria andSystemidIsNull() {
            addCriterion("SystemID is null");
            return (Criteria) this;
        }

        public Criteria andSystemidIsNotNull() {
            addCriterion("SystemID is not null");
            return (Criteria) this;
        }

        public Criteria andSystemidEqualTo(String value) {
            addCriterion("SystemID =", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidNotEqualTo(String value) {
            addCriterion("SystemID <>", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidGreaterThan(String value) {
            addCriterion("SystemID >", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidGreaterThanOrEqualTo(String value) {
            addCriterion("SystemID >=", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidLessThan(String value) {
            addCriterion("SystemID <", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidLessThanOrEqualTo(String value) {
            addCriterion("SystemID <=", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidLike(String value) {
            addCriterion("SystemID like", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidNotLike(String value) {
            addCriterion("SystemID not like", value, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidIn(List<String> values) {
            addCriterion("SystemID in", values, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidNotIn(List<String> values) {
            addCriterion("SystemID not in", values, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidBetween(String value1, String value2) {
            addCriterion("SystemID between", value1, value2, "systemid");
            return (Criteria) this;
        }

        public Criteria andSystemidNotBetween(String value1, String value2) {
            addCriterion("SystemID not between", value1, value2, "systemid");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureIsNull() {
            addCriterion("OlddevSignature is null");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureIsNotNull() {
            addCriterion("OlddevSignature is not null");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureEqualTo(String value) {
            addCriterion("OlddevSignature =", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureNotEqualTo(String value) {
            addCriterion("OlddevSignature <>", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureGreaterThan(String value) {
            addCriterion("OlddevSignature >", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureGreaterThanOrEqualTo(String value) {
            addCriterion("OlddevSignature >=", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureLessThan(String value) {
            addCriterion("OlddevSignature <", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureLessThanOrEqualTo(String value) {
            addCriterion("OlddevSignature <=", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureLike(String value) {
            addCriterion("OlddevSignature like", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureNotLike(String value) {
            addCriterion("OlddevSignature not like", value, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureIn(List<String> values) {
            addCriterion("OlddevSignature in", values, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureNotIn(List<String> values) {
            addCriterion("OlddevSignature not in", values, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureBetween(String value1, String value2) {
            addCriterion("OlddevSignature between", value1, value2, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andOlddevsignatureNotBetween(String value1, String value2) {
            addCriterion("OlddevSignature not between", value1, value2, "olddevsignature");
            return (Criteria) this;
        }

        public Criteria andChangetimeIsNull() {
            addCriterion("ChangeTime is null");
            return (Criteria) this;
        }

        public Criteria andChangetimeIsNotNull() {
            addCriterion("ChangeTime is not null");
            return (Criteria) this;
        }

        public Criteria andChangetimeEqualTo(Date value) {
            addCriterion("ChangeTime =", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeNotEqualTo(Date value) {
            addCriterion("ChangeTime <>", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeGreaterThan(Date value) {
            addCriterion("ChangeTime >", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ChangeTime >=", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeLessThan(Date value) {
            addCriterion("ChangeTime <", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeLessThanOrEqualTo(Date value) {
            addCriterion("ChangeTime <=", value, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeIn(List<Date> values) {
            addCriterion("ChangeTime in", values, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeNotIn(List<Date> values) {
            addCriterion("ChangeTime not in", values, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeBetween(Date value1, Date value2) {
            addCriterion("ChangeTime between", value1, value2, "changetime");
            return (Criteria) this;
        }

        public Criteria andChangetimeNotBetween(Date value1, Date value2) {
            addCriterion("ChangeTime not between", value1, value2, "changetime");
            return (Criteria) this;
        }

        public Criteria andPicurlIsNull() {
            addCriterion("picurl is null");
            return (Criteria) this;
        }

        public Criteria andPicurlIsNotNull() {
            addCriterion("picurl is not null");
            return (Criteria) this;
        }

        public Criteria andPicurlEqualTo(String value) {
            addCriterion("picurl =", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlNotEqualTo(String value) {
            addCriterion("picurl <>", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlGreaterThan(String value) {
            addCriterion("picurl >", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlGreaterThanOrEqualTo(String value) {
            addCriterion("picurl >=", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlLessThan(String value) {
            addCriterion("picurl <", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlLessThanOrEqualTo(String value) {
            addCriterion("picurl <=", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlLike(String value) {
            addCriterion("picurl like", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlNotLike(String value) {
            addCriterion("picurl not like", value, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlIn(List<String> values) {
            addCriterion("picurl in", values, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlNotIn(List<String> values) {
            addCriterion("picurl not in", values, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlBetween(String value1, String value2) {
            addCriterion("picurl between", value1, value2, "picurl");
            return (Criteria) this;
        }

        public Criteria andPicurlNotBetween(String value1, String value2) {
            addCriterion("picurl not between", value1, value2, "picurl");
            return (Criteria) this;
        }

        public Criteria andIsmasknetIsNull() {
            addCriterion("IsMaskNet is null");
            return (Criteria) this;
        }

        public Criteria andIsmasknetIsNotNull() {
            addCriterion("IsMaskNet is not null");
            return (Criteria) this;
        }

        public Criteria andIsmasknetEqualTo(Byte value) {
            addCriterion("IsMaskNet =", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetNotEqualTo(Byte value) {
            addCriterion("IsMaskNet <>", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetGreaterThan(Byte value) {
            addCriterion("IsMaskNet >", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetGreaterThanOrEqualTo(Byte value) {
            addCriterion("IsMaskNet >=", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetLessThan(Byte value) {
            addCriterion("IsMaskNet <", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetLessThanOrEqualTo(Byte value) {
            addCriterion("IsMaskNet <=", value, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetIn(List<Byte> values) {
            addCriterion("IsMaskNet in", values, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetNotIn(List<Byte> values) {
            addCriterion("IsMaskNet not in", values, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetBetween(Byte value1, Byte value2) {
            addCriterion("IsMaskNet between", value1, value2, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andIsmasknetNotBetween(Byte value1, Byte value2) {
            addCriterion("IsMaskNet not between", value1, value2, "ismasknet");
            return (Criteria) this;
        }

        public Criteria andMachinenoIsNull() {
            addCriterion("machineNo is null");
            return (Criteria) this;
        }

        public Criteria andMachinenoIsNotNull() {
            addCriterion("machineNo is not null");
            return (Criteria) this;
        }

        public Criteria andMachinenoEqualTo(String value) {
            addCriterion("machineNo =", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoNotEqualTo(String value) {
            addCriterion("machineNo <>", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoGreaterThan(String value) {
            addCriterion("machineNo >", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoGreaterThanOrEqualTo(String value) {
            addCriterion("machineNo >=", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoLessThan(String value) {
            addCriterion("machineNo <", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoLessThanOrEqualTo(String value) {
            addCriterion("machineNo <=", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoLike(String value) {
            addCriterion("machineNo like", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoNotLike(String value) {
            addCriterion("machineNo not like", value, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoIn(List<String> values) {
            addCriterion("machineNo in", values, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoNotIn(List<String> values) {
            addCriterion("machineNo not in", values, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoBetween(String value1, String value2) {
            addCriterion("machineNo between", value1, value2, "machineno");
            return (Criteria) this;
        }

        public Criteria andMachinenoNotBetween(String value1, String value2) {
            addCriterion("machineNo not between", value1, value2, "machineno");
            return (Criteria) this;
        }

        public Criteria andIscloseIsNull() {
            addCriterion("IsClose is null");
            return (Criteria) this;
        }

        public Criteria andIscloseIsNotNull() {
            addCriterion("IsClose is not null");
            return (Criteria) this;
        }

        public Criteria andIscloseEqualTo(Byte value) {
            addCriterion("IsClose =", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseNotEqualTo(Byte value) {
            addCriterion("IsClose <>", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseGreaterThan(Byte value) {
            addCriterion("IsClose >", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseGreaterThanOrEqualTo(Byte value) {
            addCriterion("IsClose >=", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseLessThan(Byte value) {
            addCriterion("IsClose <", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseLessThanOrEqualTo(Byte value) {
            addCriterion("IsClose <=", value, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseIn(List<Byte> values) {
            addCriterion("IsClose in", values, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseNotIn(List<Byte> values) {
            addCriterion("IsClose not in", values, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseBetween(Byte value1, Byte value2) {
            addCriterion("IsClose between", value1, value2, "isclose");
            return (Criteria) this;
        }

        public Criteria andIscloseNotBetween(Byte value1, Byte value2) {
            addCriterion("IsClose not between", value1, value2, "isclose");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}