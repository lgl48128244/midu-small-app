package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

/**
 * @author 乐鸟研发
 */
@ToString(callSuper = true)
@TableName("hby_industry")
public class HbyIndustry extends BaseEntity {

    private String industryName;

    private Integer bindNum;

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public Integer getBindNum() {
        return bindNum;
    }

    public void setBindNum(Integer bindNum) {
        this.bindNum = bindNum;
    }
}