package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.HbyMonthAndYearEleCount;
import com.leniao.entity.HbyMonthAndYearEleCountExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HbyMonthAndYearEleCountMapper extends BaseMapper<HbyMonthAndYearEleCount> {
    int countByExample(HbyMonthAndYearEleCountExample example);

    int deleteByExample(HbyMonthAndYearEleCountExample example);

    int deleteByPrimaryKey(Long id);

    //int insert(HbyMonthAndYearEleCount record);

    int insertSelective(HbyMonthAndYearEleCount record);

    List<HbyMonthAndYearEleCount> selectByExample(HbyMonthAndYearEleCountExample example);

    HbyMonthAndYearEleCount selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HbyMonthAndYearEleCount record, @Param("example") HbyMonthAndYearEleCountExample example);

    int updateByExample(@Param("record") HbyMonthAndYearEleCount record, @Param("example") HbyMonthAndYearEleCountExample example);

    int updateByPrimaryKeySelective(HbyMonthAndYearEleCount record);

    int updateByPrimaryKey(HbyMonthAndYearEleCount record);
}