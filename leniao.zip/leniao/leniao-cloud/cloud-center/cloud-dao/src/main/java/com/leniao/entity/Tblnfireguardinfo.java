package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.util.Date;

@TableName("tblnfireguardinfo")
@ToString
public class Tblnfireguardinfo {
    private Integer fireguardid;

    private String fireguardname;

    private String fireguardphone;

    private String fireguardtel;

    private String fireremark;

    private Integer isdelete;

    private Date createtime;

    private Integer userid;

    private Integer platformid;

    public Integer getFireguardid() {
        return fireguardid;
    }

    public void setFireguardid(Integer fireguardid) {
        this.fireguardid = fireguardid;
    }

    public String getFireguardname() {
        return fireguardname;
    }

    public void setFireguardname(String fireguardname) {
        this.fireguardname = fireguardname == null ? null : fireguardname.trim();
    }

    public String getFireguardphone() {
        return fireguardphone;
    }

    public void setFireguardphone(String fireguardphone) {
        this.fireguardphone = fireguardphone == null ? null : fireguardphone.trim();
    }

    public String getFireguardtel() {
        return fireguardtel;
    }

    public void setFireguardtel(String fireguardtel) {
        this.fireguardtel = fireguardtel == null ? null : fireguardtel.trim();
    }

    public String getFireremark() {
        return fireremark;
    }

    public void setFireremark(String fireremark) {
        this.fireremark = fireremark == null ? null : fireremark.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getPlatformid() {
        return platformid;
    }

    public void setPlatformid(Integer platformid) {
        this.platformid = platformid;
    }
}