package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;
@ToString
@TableName("tblngrid_gradehistory")
public class TblngridGradehistory {
    private Integer id;

    private String projid;

    private Integer unitid;

    private Date procdate;

    private BigDecimal warnwi;

    private BigDecimal faultwi;

    private BigDecimal servicewi;

    private BigDecimal feedbackwi;

    private BigDecimal operationwi;

    private Integer warncount;

    private Integer faultcount;

    private Integer servicecount;

    private Integer feedbackcount;

    private Integer operationcount;

    private BigDecimal warngrade;

    private BigDecimal faultgrade;

    private BigDecimal servicegrade;

    private BigDecimal feedbackgrade;

    private BigDecimal operationgrade;

    private BigDecimal totalgrade;

    private Date addtime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjid() {
        return projid;
    }

    public void setProjid(String projid) {
        this.projid = projid == null ? null : projid.trim();
    }

    public Integer getUnitid() {
        return unitid;
    }

    public void setUnitid(Integer unitid) {
        this.unitid = unitid;
    }

    public Date getProcdate() {
        return procdate;
    }

    public void setProcdate(Date procdate) {
        this.procdate = procdate;
    }

    public BigDecimal getWarnwi() {
        return warnwi;
    }

    public void setWarnwi(BigDecimal warnwi) {
        this.warnwi = warnwi;
    }

    public BigDecimal getFaultwi() {
        return faultwi;
    }

    public void setFaultwi(BigDecimal faultwi) {
        this.faultwi = faultwi;
    }

    public BigDecimal getServicewi() {
        return servicewi;
    }

    public void setServicewi(BigDecimal servicewi) {
        this.servicewi = servicewi;
    }

    public BigDecimal getFeedbackwi() {
        return feedbackwi;
    }

    public void setFeedbackwi(BigDecimal feedbackwi) {
        this.feedbackwi = feedbackwi;
    }

    public BigDecimal getOperationwi() {
        return operationwi;
    }

    public void setOperationwi(BigDecimal operationwi) {
        this.operationwi = operationwi;
    }

    public Integer getWarncount() {
        return warncount;
    }

    public void setWarncount(Integer warncount) {
        this.warncount = warncount;
    }

    public Integer getFaultcount() {
        return faultcount;
    }

    public void setFaultcount(Integer faultcount) {
        this.faultcount = faultcount;
    }

    public Integer getServicecount() {
        return servicecount;
    }

    public void setServicecount(Integer servicecount) {
        this.servicecount = servicecount;
    }

    public Integer getFeedbackcount() {
        return feedbackcount;
    }

    public void setFeedbackcount(Integer feedbackcount) {
        this.feedbackcount = feedbackcount;
    }

    public Integer getOperationcount() {
        return operationcount;
    }

    public void setOperationcount(Integer operationcount) {
        this.operationcount = operationcount;
    }

    public BigDecimal getWarngrade() {
        return warngrade;
    }

    public void setWarngrade(BigDecimal warngrade) {
        this.warngrade = warngrade;
    }

    public BigDecimal getFaultgrade() {
        return faultgrade;
    }

    public void setFaultgrade(BigDecimal faultgrade) {
        this.faultgrade = faultgrade;
    }

    public BigDecimal getServicegrade() {
        return servicegrade;
    }

    public void setServicegrade(BigDecimal servicegrade) {
        this.servicegrade = servicegrade;
    }

    public BigDecimal getFeedbackgrade() {
        return feedbackgrade;
    }

    public void setFeedbackgrade(BigDecimal feedbackgrade) {
        this.feedbackgrade = feedbackgrade;
    }

    public BigDecimal getOperationgrade() {
        return operationgrade;
    }

    public void setOperationgrade(BigDecimal operationgrade) {
        this.operationgrade = operationgrade;
    }

    public BigDecimal getTotalgrade() {
        return totalgrade;
    }

    public void setTotalgrade(BigDecimal totalgrade) {
        this.totalgrade = totalgrade;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }
}