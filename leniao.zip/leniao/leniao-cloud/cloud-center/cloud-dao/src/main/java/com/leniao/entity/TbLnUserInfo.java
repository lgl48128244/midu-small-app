package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@ToString
@TableName("tblnuserinfo")
public class TbLnUserInfo implements Serializable {
    @TableId
    private Integer userid;

    private String username;

    private String userpwd;

    private String usersex;

    private String userprovince;

    private String usercity;

    private String userarea;

    private String userphone;

    private String userqq;

    private String userwechat;

    private Integer userrightid;

    private Date usercreatetime;

    private Integer userisleave;

    private String userremark;

    private String code;

    private String deviceid;

    private Integer isdelete;

    private Integer issend;

    private String usereamil;

    private Integer platformid;

    private String qrcodename;

    private String reportnature;

    private String devicetype;

    private String userlogo;

    private String wxopenid;

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getUserpwd() {
        return userpwd;
    }

    public void setUserpwd(String userpwd) {
        this.userpwd = userpwd == null ? null : userpwd.trim();
    }

    public String getUsersex() {
        return usersex;
    }

    public void setUsersex(String usersex) {
        this.usersex = usersex == null ? null : usersex.trim();
    }

    public String getUserprovince() {
        return userprovince;
    }

    public void setUserprovince(String userprovince) {
        this.userprovince = userprovince == null ? null : userprovince.trim();
    }

    public String getUsercity() {
        return usercity;
    }

    public void setUsercity(String usercity) {
        this.usercity = usercity == null ? null : usercity.trim();
    }

    public String getUserarea() {
        return userarea;
    }

    public void setUserarea(String userarea) {
        this.userarea = userarea == null ? null : userarea.trim();
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone == null ? null : userphone.trim();
    }

    public String getUserqq() {
        return userqq;
    }

    public void setUserqq(String userqq) {
        this.userqq = userqq == null ? null : userqq.trim();
    }

    public String getUserwechat() {
        return userwechat;
    }

    public void setUserwechat(String userwechat) {
        this.userwechat = userwechat == null ? null : userwechat.trim();
    }

    public Integer getUserrightid() {
        return userrightid;
    }

    public void setUserrightid(Integer userrightid) {
        this.userrightid = userrightid;
    }

    public Date getUsercreatetime() {
        return usercreatetime;
    }

    public void setUsercreatetime(Date usercreatetime) {
        this.usercreatetime = usercreatetime;
    }

    public Integer getUserisleave() {
        return userisleave;
    }

    public void setUserisleave(Integer userisleave) {
        this.userisleave = userisleave;
    }

    public String getUserremark() {
        return userremark;
    }

    public void setUserremark(String userremark) {
        this.userremark = userremark == null ? null : userremark.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid == null ? null : deviceid.trim();
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getIssend() {
        return issend;
    }

    public void setIssend(Integer issend) {
        this.issend = issend;
    }

    public String getUsereamil() {
        return usereamil;
    }

    public void setUsereamil(String usereamil) {
        this.usereamil = usereamil == null ? null : usereamil.trim();
    }

    public Integer getPlatformid() {
        return platformid;
    }

    public void setPlatformid(Integer platformid) {
        this.platformid = platformid;
    }

    public String getQrcodename() {
        return qrcodename;
    }

    public void setQrcodename(String qrcodename) {
        this.qrcodename = qrcodename == null ? null : qrcodename.trim();
    }

    public String getReportnature() {
        return reportnature;
    }

    public void setReportnature(String reportnature) {
        this.reportnature = reportnature == null ? null : reportnature.trim();
    }

    public String getDevicetype() {
        return devicetype;
    }

    public void setDevicetype(String devicetype) {
        this.devicetype = devicetype == null ? null : devicetype.trim();
    }

    public String getUserlogo() {
        return userlogo;
    }

    public void setUserlogo(String userlogo) {
        this.userlogo = userlogo == null ? null : userlogo.trim();
    }

    public String getWxopenid() {
        return wxopenid;
    }

    public void setWxopenid(String wxopenid) {
        this.wxopenid = wxopenid == null ? null : wxopenid.trim();
    }
}