package com.leniao.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HbyProjectErrorInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public HbyProjectErrorInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNull() {
            addCriterion("unit_id is null");
            return (Criteria) this;
        }

        public Criteria andUnitIdIsNotNull() {
            addCriterion("unit_id is not null");
            return (Criteria) this;
        }

        public Criteria andUnitIdEqualTo(Integer value) {
            addCriterion("unit_id =", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotEqualTo(Integer value) {
            addCriterion("unit_id <>", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThan(Integer value) {
            addCriterion("unit_id >", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("unit_id >=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThan(Integer value) {
            addCriterion("unit_id <", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdLessThanOrEqualTo(Integer value) {
            addCriterion("unit_id <=", value, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdIn(List<Integer> values) {
            addCriterion("unit_id in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotIn(List<Integer> values) {
            addCriterion("unit_id not in", values, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdBetween(Integer value1, Integer value2) {
            addCriterion("unit_id between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andUnitIdNotBetween(Integer value1, Integer value2) {
            addCriterion("unit_id not between", value1, value2, "unitId");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeIsNull() {
            addCriterion("province_code is null");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeIsNotNull() {
            addCriterion("province_code is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeEqualTo(String value) {
            addCriterion("province_code =", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeNotEqualTo(String value) {
            addCriterion("province_code <>", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeGreaterThan(String value) {
            addCriterion("province_code >", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeGreaterThanOrEqualTo(String value) {
            addCriterion("province_code >=", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeLessThan(String value) {
            addCriterion("province_code <", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeLessThanOrEqualTo(String value) {
            addCriterion("province_code <=", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeLike(String value) {
            addCriterion("province_code like", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeNotLike(String value) {
            addCriterion("province_code not like", value, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeIn(List<String> values) {
            addCriterion("province_code in", values, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeNotIn(List<String> values) {
            addCriterion("province_code not in", values, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeBetween(String value1, String value2) {
            addCriterion("province_code between", value1, value2, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andProvinceCodeNotBetween(String value1, String value2) {
            addCriterion("province_code not between", value1, value2, "provinceCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeIsNull() {
            addCriterion("city_code is null");
            return (Criteria) this;
        }

        public Criteria andCityCodeIsNotNull() {
            addCriterion("city_code is not null");
            return (Criteria) this;
        }

        public Criteria andCityCodeEqualTo(String value) {
            addCriterion("city_code =", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeNotEqualTo(String value) {
            addCriterion("city_code <>", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeGreaterThan(String value) {
            addCriterion("city_code >", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeGreaterThanOrEqualTo(String value) {
            addCriterion("city_code >=", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeLessThan(String value) {
            addCriterion("city_code <", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeLessThanOrEqualTo(String value) {
            addCriterion("city_code <=", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeLike(String value) {
            addCriterion("city_code like", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeNotLike(String value) {
            addCriterion("city_code not like", value, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeIn(List<String> values) {
            addCriterion("city_code in", values, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeNotIn(List<String> values) {
            addCriterion("city_code not in", values, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeBetween(String value1, String value2) {
            addCriterion("city_code between", value1, value2, "cityCode");
            return (Criteria) this;
        }

        public Criteria andCityCodeNotBetween(String value1, String value2) {
            addCriterion("city_code not between", value1, value2, "cityCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeIsNull() {
            addCriterion("area_code is null");
            return (Criteria) this;
        }

        public Criteria andAreaCodeIsNotNull() {
            addCriterion("area_code is not null");
            return (Criteria) this;
        }

        public Criteria andAreaCodeEqualTo(String value) {
            addCriterion("area_code =", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeNotEqualTo(String value) {
            addCriterion("area_code <>", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeGreaterThan(String value) {
            addCriterion("area_code >", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeGreaterThanOrEqualTo(String value) {
            addCriterion("area_code >=", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeLessThan(String value) {
            addCriterion("area_code <", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeLessThanOrEqualTo(String value) {
            addCriterion("area_code <=", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeLike(String value) {
            addCriterion("area_code like", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeNotLike(String value) {
            addCriterion("area_code not like", value, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeIn(List<String> values) {
            addCriterion("area_code in", values, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeNotIn(List<String> values) {
            addCriterion("area_code not in", values, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeBetween(String value1, String value2) {
            addCriterion("area_code between", value1, value2, "areaCode");
            return (Criteria) this;
        }

        public Criteria andAreaCodeNotBetween(String value1, String value2) {
            addCriterion("area_code not between", value1, value2, "areaCode");
            return (Criteria) this;
        }

        public Criteria andIndustryIdIsNull() {
            addCriterion("industry_id is null");
            return (Criteria) this;
        }

        public Criteria andIndustryIdIsNotNull() {
            addCriterion("industry_id is not null");
            return (Criteria) this;
        }

        public Criteria andIndustryIdEqualTo(Long value) {
            addCriterion("industry_id =", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdNotEqualTo(Long value) {
            addCriterion("industry_id <>", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdGreaterThan(Long value) {
            addCriterion("industry_id >", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdGreaterThanOrEqualTo(Long value) {
            addCriterion("industry_id >=", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdLessThan(Long value) {
            addCriterion("industry_id <", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdLessThanOrEqualTo(Long value) {
            addCriterion("industry_id <=", value, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdIn(List<Long> values) {
            addCriterion("industry_id in", values, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdNotIn(List<Long> values) {
            addCriterion("industry_id not in", values, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdBetween(Long value1, Long value2) {
            addCriterion("industry_id between", value1, value2, "industryId");
            return (Criteria) this;
        }

        public Criteria andIndustryIdNotBetween(Long value1, Long value2) {
            addCriterion("industry_id not between", value1, value2, "industryId");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(Integer value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(Integer value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(Integer value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(Integer value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(Integer value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<Integer> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<Integer> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(Integer value1, Integer value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIsNull() {
            addCriterion("dev_idpk is null");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIsNotNull() {
            addCriterion("dev_idpk is not null");
            return (Criteria) this;
        }

        public Criteria andDevIdpkEqualTo(Integer value) {
            addCriterion("dev_idpk =", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotEqualTo(Integer value) {
            addCriterion("dev_idpk <>", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkGreaterThan(Integer value) {
            addCriterion("dev_idpk >", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkGreaterThanOrEqualTo(Integer value) {
            addCriterion("dev_idpk >=", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkLessThan(Integer value) {
            addCriterion("dev_idpk <", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkLessThanOrEqualTo(Integer value) {
            addCriterion("dev_idpk <=", value, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkIn(List<Integer> values) {
            addCriterion("dev_idpk in", values, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotIn(List<Integer> values) {
            addCriterion("dev_idpk not in", values, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkBetween(Integer value1, Integer value2) {
            addCriterion("dev_idpk between", value1, value2, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevIdpkNotBetween(Integer value1, Integer value2) {
            addCriterion("dev_idpk not between", value1, value2, "devIdpk");
            return (Criteria) this;
        }

        public Criteria andDevSignatureIsNull() {
            addCriterion("dev_signature is null");
            return (Criteria) this;
        }

        public Criteria andDevSignatureIsNotNull() {
            addCriterion("dev_signature is not null");
            return (Criteria) this;
        }

        public Criteria andDevSignatureEqualTo(String value) {
            addCriterion("dev_signature =", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureNotEqualTo(String value) {
            addCriterion("dev_signature <>", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureGreaterThan(String value) {
            addCriterion("dev_signature >", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("dev_signature >=", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureLessThan(String value) {
            addCriterion("dev_signature <", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureLessThanOrEqualTo(String value) {
            addCriterion("dev_signature <=", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureLike(String value) {
            addCriterion("dev_signature like", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureNotLike(String value) {
            addCriterion("dev_signature not like", value, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureIn(List<String> values) {
            addCriterion("dev_signature in", values, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureNotIn(List<String> values) {
            addCriterion("dev_signature not in", values, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureBetween(String value1, String value2) {
            addCriterion("dev_signature between", value1, value2, "devSignature");
            return (Criteria) this;
        }

        public Criteria andDevSignatureNotBetween(String value1, String value2) {
            addCriterion("dev_signature not between", value1, value2, "devSignature");
            return (Criteria) this;
        }

        public Criteria andOverlookIdIsNull() {
            addCriterion("overlook_id is null");
            return (Criteria) this;
        }

        public Criteria andOverlookIdIsNotNull() {
            addCriterion("overlook_id is not null");
            return (Criteria) this;
        }

        public Criteria andOverlookIdEqualTo(String value) {
            addCriterion("overlook_id =", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdNotEqualTo(String value) {
            addCriterion("overlook_id <>", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdGreaterThan(String value) {
            addCriterion("overlook_id >", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdGreaterThanOrEqualTo(String value) {
            addCriterion("overlook_id >=", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdLessThan(String value) {
            addCriterion("overlook_id <", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdLessThanOrEqualTo(String value) {
            addCriterion("overlook_id <=", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdLike(String value) {
            addCriterion("overlook_id like", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdNotLike(String value) {
            addCriterion("overlook_id not like", value, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdIn(List<String> values) {
            addCriterion("overlook_id in", values, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdNotIn(List<String> values) {
            addCriterion("overlook_id not in", values, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdBetween(String value1, String value2) {
            addCriterion("overlook_id between", value1, value2, "overlookId");
            return (Criteria) this;
        }

        public Criteria andOverlookIdNotBetween(String value1, String value2) {
            addCriterion("overlook_id not between", value1, value2, "overlookId");
            return (Criteria) this;
        }

        public Criteria andPlanIdIsNull() {
            addCriterion("plan_id is null");
            return (Criteria) this;
        }

        public Criteria andPlanIdIsNotNull() {
            addCriterion("plan_id is not null");
            return (Criteria) this;
        }

        public Criteria andPlanIdEqualTo(Long value) {
            addCriterion("plan_id =", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdNotEqualTo(Long value) {
            addCriterion("plan_id <>", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdGreaterThan(Long value) {
            addCriterion("plan_id >", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdGreaterThanOrEqualTo(Long value) {
            addCriterion("plan_id >=", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdLessThan(Long value) {
            addCriterion("plan_id <", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdLessThanOrEqualTo(Long value) {
            addCriterion("plan_id <=", value, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdIn(List<Long> values) {
            addCriterion("plan_id in", values, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdNotIn(List<Long> values) {
            addCriterion("plan_id not in", values, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdBetween(Long value1, Long value2) {
            addCriterion("plan_id between", value1, value2, "planId");
            return (Criteria) this;
        }

        public Criteria andPlanIdNotBetween(Long value1, Long value2) {
            addCriterion("plan_id not between", value1, value2, "planId");
            return (Criteria) this;
        }

        public Criteria andPollOrConIsNull() {
            addCriterion("poll_or_con is null");
            return (Criteria) this;
        }

        public Criteria andPollOrConIsNotNull() {
            addCriterion("poll_or_con is not null");
            return (Criteria) this;
        }

        public Criteria andPollOrConEqualTo(Integer value) {
            addCriterion("poll_or_con =", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConNotEqualTo(Integer value) {
            addCriterion("poll_or_con <>", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConGreaterThan(Integer value) {
            addCriterion("poll_or_con >", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConGreaterThanOrEqualTo(Integer value) {
            addCriterion("poll_or_con >=", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConLessThan(Integer value) {
            addCriterion("poll_or_con <", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConLessThanOrEqualTo(Integer value) {
            addCriterion("poll_or_con <=", value, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConIn(List<Integer> values) {
            addCriterion("poll_or_con in", values, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConNotIn(List<Integer> values) {
            addCriterion("poll_or_con not in", values, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConBetween(Integer value1, Integer value2) {
            addCriterion("poll_or_con between", value1, value2, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andPollOrConNotBetween(Integer value1, Integer value2) {
            addCriterion("poll_or_con not between", value1, value2, "pollOrCon");
            return (Criteria) this;
        }

        public Criteria andErrorTimeIsNull() {
            addCriterion("error_time is null");
            return (Criteria) this;
        }

        public Criteria andErrorTimeIsNotNull() {
            addCriterion("error_time is not null");
            return (Criteria) this;
        }

        public Criteria andErrorTimeEqualTo(Date value) {
            addCriterion("error_time =", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeNotEqualTo(Date value) {
            addCriterion("error_time <>", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeGreaterThan(Date value) {
            addCriterion("error_time >", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("error_time >=", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeLessThan(Date value) {
            addCriterion("error_time <", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeLessThanOrEqualTo(Date value) {
            addCriterion("error_time <=", value, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeIn(List<Date> values) {
            addCriterion("error_time in", values, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeNotIn(List<Date> values) {
            addCriterion("error_time not in", values, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeBetween(Date value1, Date value2) {
            addCriterion("error_time between", value1, value2, "errorTime");
            return (Criteria) this;
        }

        public Criteria andErrorTimeNotBetween(Date value1, Date value2) {
            addCriterion("error_time not between", value1, value2, "errorTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeIsNull() {
            addCriterion("normal_time is null");
            return (Criteria) this;
        }

        public Criteria andNormalTimeIsNotNull() {
            addCriterion("normal_time is not null");
            return (Criteria) this;
        }

        public Criteria andNormalTimeEqualTo(Date value) {
            addCriterion("normal_time =", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeNotEqualTo(Date value) {
            addCriterion("normal_time <>", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeGreaterThan(Date value) {
            addCriterion("normal_time >", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("normal_time >=", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeLessThan(Date value) {
            addCriterion("normal_time <", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeLessThanOrEqualTo(Date value) {
            addCriterion("normal_time <=", value, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeIn(List<Date> values) {
            addCriterion("normal_time in", values, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeNotIn(List<Date> values) {
            addCriterion("normal_time not in", values, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeBetween(Date value1, Date value2) {
            addCriterion("normal_time between", value1, value2, "normalTime");
            return (Criteria) this;
        }

        public Criteria andNormalTimeNotBetween(Date value1, Date value2) {
            addCriterion("normal_time not between", value1, value2, "normalTime");
            return (Criteria) this;
        }

        public Criteria andDealStatusIsNull() {
            addCriterion("deal_status is null");
            return (Criteria) this;
        }

        public Criteria andDealStatusIsNotNull() {
            addCriterion("deal_status is not null");
            return (Criteria) this;
        }

        public Criteria andDealStatusEqualTo(Integer value) {
            addCriterion("deal_status =", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusNotEqualTo(Integer value) {
            addCriterion("deal_status <>", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusGreaterThan(Integer value) {
            addCriterion("deal_status >", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("deal_status >=", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusLessThan(Integer value) {
            addCriterion("deal_status <", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusLessThanOrEqualTo(Integer value) {
            addCriterion("deal_status <=", value, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusIn(List<Integer> values) {
            addCriterion("deal_status in", values, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusNotIn(List<Integer> values) {
            addCriterion("deal_status not in", values, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusBetween(Integer value1, Integer value2) {
            addCriterion("deal_status between", value1, value2, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andDealStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("deal_status not between", value1, value2, "dealStatus");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeIsNull() {
            addCriterion("error_event_type is null");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeIsNotNull() {
            addCriterion("error_event_type is not null");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeEqualTo(Integer value) {
            addCriterion("error_event_type =", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeNotEqualTo(Integer value) {
            addCriterion("error_event_type <>", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeGreaterThan(Integer value) {
            addCriterion("error_event_type >", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("error_event_type >=", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeLessThan(Integer value) {
            addCriterion("error_event_type <", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeLessThanOrEqualTo(Integer value) {
            addCriterion("error_event_type <=", value, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeIn(List<Integer> values) {
            addCriterion("error_event_type in", values, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeNotIn(List<Integer> values) {
            addCriterion("error_event_type not in", values, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeBetween(Integer value1, Integer value2) {
            addCriterion("error_event_type between", value1, value2, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorEventTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("error_event_type not between", value1, value2, "errorEventType");
            return (Criteria) this;
        }

        public Criteria andErrorDescIsNull() {
            addCriterion("error_desc is null");
            return (Criteria) this;
        }

        public Criteria andErrorDescIsNotNull() {
            addCriterion("error_desc is not null");
            return (Criteria) this;
        }

        public Criteria andErrorDescEqualTo(String value) {
            addCriterion("error_desc =", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescNotEqualTo(String value) {
            addCriterion("error_desc <>", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescGreaterThan(String value) {
            addCriterion("error_desc >", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescGreaterThanOrEqualTo(String value) {
            addCriterion("error_desc >=", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescLessThan(String value) {
            addCriterion("error_desc <", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescLessThanOrEqualTo(String value) {
            addCriterion("error_desc <=", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescLike(String value) {
            addCriterion("error_desc like", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescNotLike(String value) {
            addCriterion("error_desc not like", value, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescIn(List<String> values) {
            addCriterion("error_desc in", values, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescNotIn(List<String> values) {
            addCriterion("error_desc not in", values, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescBetween(String value1, String value2) {
            addCriterion("error_desc between", value1, value2, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andErrorDescNotBetween(String value1, String value2) {
            addCriterion("error_desc not between", value1, value2, "errorDesc");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioIsNull() {
            addCriterion("vol_charge_ratio is null");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioIsNotNull() {
            addCriterion("vol_charge_ratio is not null");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioEqualTo(BigDecimal value) {
            addCriterion("vol_charge_ratio =", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioNotEqualTo(BigDecimal value) {
            addCriterion("vol_charge_ratio <>", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioGreaterThan(BigDecimal value) {
            addCriterion("vol_charge_ratio >", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("vol_charge_ratio >=", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioLessThan(BigDecimal value) {
            addCriterion("vol_charge_ratio <", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioLessThanOrEqualTo(BigDecimal value) {
            addCriterion("vol_charge_ratio <=", value, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioIn(List<BigDecimal> values) {
            addCriterion("vol_charge_ratio in", values, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioNotIn(List<BigDecimal> values) {
            addCriterion("vol_charge_ratio not in", values, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("vol_charge_ratio between", value1, value2, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andVolChargeRatioNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("vol_charge_ratio not between", value1, value2, "volChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioIsNull() {
            addCriterion("ele_charge_ratio is null");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioIsNotNull() {
            addCriterion("ele_charge_ratio is not null");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioEqualTo(BigDecimal value) {
            addCriterion("ele_charge_ratio =", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioNotEqualTo(BigDecimal value) {
            addCriterion("ele_charge_ratio <>", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioGreaterThan(BigDecimal value) {
            addCriterion("ele_charge_ratio >", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ele_charge_ratio >=", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioLessThan(BigDecimal value) {
            addCriterion("ele_charge_ratio <", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ele_charge_ratio <=", value, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioIn(List<BigDecimal> values) {
            addCriterion("ele_charge_ratio in", values, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioNotIn(List<BigDecimal> values) {
            addCriterion("ele_charge_ratio not in", values, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ele_charge_ratio between", value1, value2, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andEleChargeRatioNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ele_charge_ratio not between", value1, value2, "eleChargeRatio");
            return (Criteria) this;
        }

        public Criteria andPushTimeIsNull() {
            addCriterion("push_time is null");
            return (Criteria) this;
        }

        public Criteria andPushTimeIsNotNull() {
            addCriterion("push_time is not null");
            return (Criteria) this;
        }

        public Criteria andPushTimeEqualTo(Date value) {
            addCriterion("push_time =", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeNotEqualTo(Date value) {
            addCriterion("push_time <>", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeGreaterThan(Date value) {
            addCriterion("push_time >", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("push_time >=", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeLessThan(Date value) {
            addCriterion("push_time <", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeLessThanOrEqualTo(Date value) {
            addCriterion("push_time <=", value, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeIn(List<Date> values) {
            addCriterion("push_time in", values, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeNotIn(List<Date> values) {
            addCriterion("push_time not in", values, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeBetween(Date value1, Date value2) {
            addCriterion("push_time between", value1, value2, "pushTime");
            return (Criteria) this;
        }

        public Criteria andPushTimeNotBetween(Date value1, Date value2) {
            addCriterion("push_time not between", value1, value2, "pushTime");
            return (Criteria) this;
        }

        public Criteria andIsPushIsNull() {
            addCriterion("is_push is null");
            return (Criteria) this;
        }

        public Criteria andIsPushIsNotNull() {
            addCriterion("is_push is not null");
            return (Criteria) this;
        }

        public Criteria andIsPushEqualTo(Integer value) {
            addCriterion("is_push =", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushNotEqualTo(Integer value) {
            addCriterion("is_push <>", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushGreaterThan(Integer value) {
            addCriterion("is_push >", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_push >=", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushLessThan(Integer value) {
            addCriterion("is_push <", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushLessThanOrEqualTo(Integer value) {
            addCriterion("is_push <=", value, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushIn(List<Integer> values) {
            addCriterion("is_push in", values, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushNotIn(List<Integer> values) {
            addCriterion("is_push not in", values, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushBetween(Integer value1, Integer value2) {
            addCriterion("is_push between", value1, value2, "isPush");
            return (Criteria) this;
        }

        public Criteria andIsPushNotBetween(Integer value1, Integer value2) {
            addCriterion("is_push not between", value1, value2, "isPush");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCheckUserIsNull() {
            addCriterion("check_user is null");
            return (Criteria) this;
        }

        public Criteria andCheckUserIsNotNull() {
            addCriterion("check_user is not null");
            return (Criteria) this;
        }

        public Criteria andCheckUserEqualTo(Integer value) {
            addCriterion("check_user =", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotEqualTo(Integer value) {
            addCriterion("check_user <>", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserGreaterThan(Integer value) {
            addCriterion("check_user >", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserGreaterThanOrEqualTo(Integer value) {
            addCriterion("check_user >=", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserLessThan(Integer value) {
            addCriterion("check_user <", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserLessThanOrEqualTo(Integer value) {
            addCriterion("check_user <=", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserIn(List<Integer> values) {
            addCriterion("check_user in", values, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotIn(List<Integer> values) {
            addCriterion("check_user not in", values, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserBetween(Integer value1, Integer value2) {
            addCriterion("check_user between", value1, value2, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotBetween(Integer value1, Integer value2) {
            addCriterion("check_user not between", value1, value2, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameIsNull() {
            addCriterion("check_user_name is null");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameIsNotNull() {
            addCriterion("check_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameEqualTo(String value) {
            addCriterion("check_user_name =", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameNotEqualTo(String value) {
            addCriterion("check_user_name <>", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameGreaterThan(String value) {
            addCriterion("check_user_name >", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("check_user_name >=", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameLessThan(String value) {
            addCriterion("check_user_name <", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameLessThanOrEqualTo(String value) {
            addCriterion("check_user_name <=", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameLike(String value) {
            addCriterion("check_user_name like", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameNotLike(String value) {
            addCriterion("check_user_name not like", value, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameIn(List<String> values) {
            addCriterion("check_user_name in", values, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameNotIn(List<String> values) {
            addCriterion("check_user_name not in", values, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameBetween(String value1, String value2) {
            addCriterion("check_user_name between", value1, value2, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckUserNameNotBetween(String value1, String value2) {
            addCriterion("check_user_name not between", value1, value2, "checkUserName");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIsNull() {
            addCriterion("check_time is null");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIsNotNull() {
            addCriterion("check_time is not null");
            return (Criteria) this;
        }

        public Criteria andCheckTimeEqualTo(Date value) {
            addCriterion("check_time =", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotEqualTo(Date value) {
            addCriterion("check_time <>", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeGreaterThan(Date value) {
            addCriterion("check_time >", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("check_time >=", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeLessThan(Date value) {
            addCriterion("check_time <", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeLessThanOrEqualTo(Date value) {
            addCriterion("check_time <=", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIn(List<Date> values) {
            addCriterion("check_time in", values, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotIn(List<Date> values) {
            addCriterion("check_time not in", values, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeBetween(Date value1, Date value2) {
            addCriterion("check_time between", value1, value2, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotBetween(Date value1, Date value2) {
            addCriterion("check_time not between", value1, value2, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckResultIsNull() {
            addCriterion("check_result is null");
            return (Criteria) this;
        }

        public Criteria andCheckResultIsNotNull() {
            addCriterion("check_result is not null");
            return (Criteria) this;
        }

        public Criteria andCheckResultEqualTo(Integer value) {
            addCriterion("check_result =", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultNotEqualTo(Integer value) {
            addCriterion("check_result <>", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultGreaterThan(Integer value) {
            addCriterion("check_result >", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultGreaterThanOrEqualTo(Integer value) {
            addCriterion("check_result >=", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultLessThan(Integer value) {
            addCriterion("check_result <", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultLessThanOrEqualTo(Integer value) {
            addCriterion("check_result <=", value, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultIn(List<Integer> values) {
            addCriterion("check_result in", values, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultNotIn(List<Integer> values) {
            addCriterion("check_result not in", values, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultBetween(Integer value1, Integer value2) {
            addCriterion("check_result between", value1, value2, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckResultNotBetween(Integer value1, Integer value2) {
            addCriterion("check_result not between", value1, value2, "checkResult");
            return (Criteria) this;
        }

        public Criteria andCheckDescIsNull() {
            addCriterion("check_desc is null");
            return (Criteria) this;
        }

        public Criteria andCheckDescIsNotNull() {
            addCriterion("check_desc is not null");
            return (Criteria) this;
        }

        public Criteria andCheckDescEqualTo(String value) {
            addCriterion("check_desc =", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescNotEqualTo(String value) {
            addCriterion("check_desc <>", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescGreaterThan(String value) {
            addCriterion("check_desc >", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescGreaterThanOrEqualTo(String value) {
            addCriterion("check_desc >=", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescLessThan(String value) {
            addCriterion("check_desc <", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescLessThanOrEqualTo(String value) {
            addCriterion("check_desc <=", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescLike(String value) {
            addCriterion("check_desc like", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescNotLike(String value) {
            addCriterion("check_desc not like", value, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescIn(List<String> values) {
            addCriterion("check_desc in", values, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescNotIn(List<String> values) {
            addCriterion("check_desc not in", values, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescBetween(String value1, String value2) {
            addCriterion("check_desc between", value1, value2, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andCheckDescNotBetween(String value1, String value2) {
            addCriterion("check_desc not between", value1, value2, "checkDesc");
            return (Criteria) this;
        }

        public Criteria andFjUrlIsNull() {
            addCriterion("fj_url is null");
            return (Criteria) this;
        }

        public Criteria andFjUrlIsNotNull() {
            addCriterion("fj_url is not null");
            return (Criteria) this;
        }

        public Criteria andFjUrlEqualTo(String value) {
            addCriterion("fj_url =", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlNotEqualTo(String value) {
            addCriterion("fj_url <>", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlGreaterThan(String value) {
            addCriterion("fj_url >", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlGreaterThanOrEqualTo(String value) {
            addCriterion("fj_url >=", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlLessThan(String value) {
            addCriterion("fj_url <", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlLessThanOrEqualTo(String value) {
            addCriterion("fj_url <=", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlLike(String value) {
            addCriterion("fj_url like", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlNotLike(String value) {
            addCriterion("fj_url not like", value, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlIn(List<String> values) {
            addCriterion("fj_url in", values, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlNotIn(List<String> values) {
            addCriterion("fj_url not in", values, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlBetween(String value1, String value2) {
            addCriterion("fj_url between", value1, value2, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjUrlNotBetween(String value1, String value2) {
            addCriterion("fj_url not between", value1, value2, "fjUrl");
            return (Criteria) this;
        }

        public Criteria andFjDescIsNull() {
            addCriterion("fj_desc is null");
            return (Criteria) this;
        }

        public Criteria andFjDescIsNotNull() {
            addCriterion("fj_desc is not null");
            return (Criteria) this;
        }

        public Criteria andFjDescEqualTo(String value) {
            addCriterion("fj_desc =", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescNotEqualTo(String value) {
            addCriterion("fj_desc <>", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescGreaterThan(String value) {
            addCriterion("fj_desc >", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescGreaterThanOrEqualTo(String value) {
            addCriterion("fj_desc >=", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescLessThan(String value) {
            addCriterion("fj_desc <", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescLessThanOrEqualTo(String value) {
            addCriterion("fj_desc <=", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescLike(String value) {
            addCriterion("fj_desc like", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescNotLike(String value) {
            addCriterion("fj_desc not like", value, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescIn(List<String> values) {
            addCriterion("fj_desc in", values, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescNotIn(List<String> values) {
            addCriterion("fj_desc not in", values, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescBetween(String value1, String value2) {
            addCriterion("fj_desc between", value1, value2, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andFjDescNotBetween(String value1, String value2) {
            addCriterion("fj_desc not between", value1, value2, "fjDesc");
            return (Criteria) this;
        }

        public Criteria andVerifyUserIsNull() {
            addCriterion("verify_user is null");
            return (Criteria) this;
        }

        public Criteria andVerifyUserIsNotNull() {
            addCriterion("verify_user is not null");
            return (Criteria) this;
        }

        public Criteria andVerifyUserEqualTo(Integer value) {
            addCriterion("verify_user =", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNotEqualTo(Integer value) {
            addCriterion("verify_user <>", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserGreaterThan(Integer value) {
            addCriterion("verify_user >", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserGreaterThanOrEqualTo(Integer value) {
            addCriterion("verify_user >=", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserLessThan(Integer value) {
            addCriterion("verify_user <", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserLessThanOrEqualTo(Integer value) {
            addCriterion("verify_user <=", value, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserIn(List<Integer> values) {
            addCriterion("verify_user in", values, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNotIn(List<Integer> values) {
            addCriterion("verify_user not in", values, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserBetween(Integer value1, Integer value2) {
            addCriterion("verify_user between", value1, value2, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNotBetween(Integer value1, Integer value2) {
            addCriterion("verify_user not between", value1, value2, "verifyUser");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameIsNull() {
            addCriterion("verify_user_name is null");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameIsNotNull() {
            addCriterion("verify_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameEqualTo(String value) {
            addCriterion("verify_user_name =", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameNotEqualTo(String value) {
            addCriterion("verify_user_name <>", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameGreaterThan(String value) {
            addCriterion("verify_user_name >", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("verify_user_name >=", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameLessThan(String value) {
            addCriterion("verify_user_name <", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameLessThanOrEqualTo(String value) {
            addCriterion("verify_user_name <=", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameLike(String value) {
            addCriterion("verify_user_name like", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameNotLike(String value) {
            addCriterion("verify_user_name not like", value, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameIn(List<String> values) {
            addCriterion("verify_user_name in", values, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameNotIn(List<String> values) {
            addCriterion("verify_user_name not in", values, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameBetween(String value1, String value2) {
            addCriterion("verify_user_name between", value1, value2, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyUserNameNotBetween(String value1, String value2) {
            addCriterion("verify_user_name not between", value1, value2, "verifyUserName");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeIsNull() {
            addCriterion("verify_time is null");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeIsNotNull() {
            addCriterion("verify_time is not null");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeEqualTo(Date value) {
            addCriterion("verify_time =", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeNotEqualTo(Date value) {
            addCriterion("verify_time <>", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeGreaterThan(Date value) {
            addCriterion("verify_time >", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("verify_time >=", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeLessThan(Date value) {
            addCriterion("verify_time <", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("verify_time <=", value, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeIn(List<Date> values) {
            addCriterion("verify_time in", values, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeNotIn(List<Date> values) {
            addCriterion("verify_time not in", values, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeBetween(Date value1, Date value2) {
            addCriterion("verify_time between", value1, value2, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("verify_time not between", value1, value2, "verifyTime");
            return (Criteria) this;
        }

        public Criteria andVerifySuggIsNull() {
            addCriterion("verify_sugg is null");
            return (Criteria) this;
        }

        public Criteria andVerifySuggIsNotNull() {
            addCriterion("verify_sugg is not null");
            return (Criteria) this;
        }

        public Criteria andVerifySuggEqualTo(String value) {
            addCriterion("verify_sugg =", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggNotEqualTo(String value) {
            addCriterion("verify_sugg <>", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggGreaterThan(String value) {
            addCriterion("verify_sugg >", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggGreaterThanOrEqualTo(String value) {
            addCriterion("verify_sugg >=", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggLessThan(String value) {
            addCriterion("verify_sugg <", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggLessThanOrEqualTo(String value) {
            addCriterion("verify_sugg <=", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggLike(String value) {
            addCriterion("verify_sugg like", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggNotLike(String value) {
            addCriterion("verify_sugg not like", value, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggIn(List<String> values) {
            addCriterion("verify_sugg in", values, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggNotIn(List<String> values) {
            addCriterion("verify_sugg not in", values, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggBetween(String value1, String value2) {
            addCriterion("verify_sugg between", value1, value2, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifySuggNotBetween(String value1, String value2) {
            addCriterion("verify_sugg not between", value1, value2, "verifySugg");
            return (Criteria) this;
        }

        public Criteria andVerifyResultIsNull() {
            addCriterion("verify_result is null");
            return (Criteria) this;
        }

        public Criteria andVerifyResultIsNotNull() {
            addCriterion("verify_result is not null");
            return (Criteria) this;
        }

        public Criteria andVerifyResultEqualTo(Integer value) {
            addCriterion("verify_result =", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultNotEqualTo(Integer value) {
            addCriterion("verify_result <>", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultGreaterThan(Integer value) {
            addCriterion("verify_result >", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultGreaterThanOrEqualTo(Integer value) {
            addCriterion("verify_result >=", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultLessThan(Integer value) {
            addCriterion("verify_result <", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultLessThanOrEqualTo(Integer value) {
            addCriterion("verify_result <=", value, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultIn(List<Integer> values) {
            addCriterion("verify_result in", values, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultNotIn(List<Integer> values) {
            addCriterion("verify_result not in", values, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultBetween(Integer value1, Integer value2) {
            addCriterion("verify_result between", value1, value2, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andVerifyResultNotBetween(Integer value1, Integer value2) {
            addCriterion("verify_result not between", value1, value2, "verifyResult");
            return (Criteria) this;
        }

        public Criteria andRawErridIsNull() {
            addCriterion("raw_errID is null");
            return (Criteria) this;
        }

        public Criteria andRawErridIsNotNull() {
            addCriterion("raw_errID is not null");
            return (Criteria) this;
        }

        public Criteria andRawErridEqualTo(Integer value) {
            addCriterion("raw_errID =", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridNotEqualTo(Integer value) {
            addCriterion("raw_errID <>", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridGreaterThan(Integer value) {
            addCriterion("raw_errID >", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridGreaterThanOrEqualTo(Integer value) {
            addCriterion("raw_errID >=", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridLessThan(Integer value) {
            addCriterion("raw_errID <", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridLessThanOrEqualTo(Integer value) {
            addCriterion("raw_errID <=", value, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridIn(List<Integer> values) {
            addCriterion("raw_errID in", values, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridNotIn(List<Integer> values) {
            addCriterion("raw_errID not in", values, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridBetween(Integer value1, Integer value2) {
            addCriterion("raw_errID between", value1, value2, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawErridNotBetween(Integer value1, Integer value2) {
            addCriterion("raw_errID not between", value1, value2, "rawErrid");
            return (Criteria) this;
        }

        public Criteria andRawNodeIsNull() {
            addCriterion("raw_node is null");
            return (Criteria) this;
        }

        public Criteria andRawNodeIsNotNull() {
            addCriterion("raw_node is not null");
            return (Criteria) this;
        }

        public Criteria andRawNodeEqualTo(String value) {
            addCriterion("raw_node =", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeNotEqualTo(String value) {
            addCriterion("raw_node <>", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeGreaterThan(String value) {
            addCriterion("raw_node >", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeGreaterThanOrEqualTo(String value) {
            addCriterion("raw_node >=", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeLessThan(String value) {
            addCriterion("raw_node <", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeLessThanOrEqualTo(String value) {
            addCriterion("raw_node <=", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeLike(String value) {
            addCriterion("raw_node like", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeNotLike(String value) {
            addCriterion("raw_node not like", value, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeIn(List<String> values) {
            addCriterion("raw_node in", values, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeNotIn(List<String> values) {
            addCriterion("raw_node not in", values, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeBetween(String value1, String value2) {
            addCriterion("raw_node between", value1, value2, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawNodeNotBetween(String value1, String value2) {
            addCriterion("raw_node not between", value1, value2, "rawNode");
            return (Criteria) this;
        }

        public Criteria andRawTypeIsNull() {
            addCriterion("raw_type is null");
            return (Criteria) this;
        }

        public Criteria andRawTypeIsNotNull() {
            addCriterion("raw_type is not null");
            return (Criteria) this;
        }

        public Criteria andRawTypeEqualTo(Integer value) {
            addCriterion("raw_type =", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeNotEqualTo(Integer value) {
            addCriterion("raw_type <>", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeGreaterThan(Integer value) {
            addCriterion("raw_type >", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("raw_type >=", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeLessThan(Integer value) {
            addCriterion("raw_type <", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeLessThanOrEqualTo(Integer value) {
            addCriterion("raw_type <=", value, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeIn(List<Integer> values) {
            addCriterion("raw_type in", values, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeNotIn(List<Integer> values) {
            addCriterion("raw_type not in", values, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeBetween(Integer value1, Integer value2) {
            addCriterion("raw_type between", value1, value2, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("raw_type not between", value1, value2, "rawType");
            return (Criteria) this;
        }

        public Criteria andRawValueIsNull() {
            addCriterion("raw_value is null");
            return (Criteria) this;
        }

        public Criteria andRawValueIsNotNull() {
            addCriterion("raw_value is not null");
            return (Criteria) this;
        }

        public Criteria andRawValueEqualTo(BigDecimal value) {
            addCriterion("raw_value =", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueNotEqualTo(BigDecimal value) {
            addCriterion("raw_value <>", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueGreaterThan(BigDecimal value) {
            addCriterion("raw_value >", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raw_value >=", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueLessThan(BigDecimal value) {
            addCriterion("raw_value <", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raw_value <=", value, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueIn(List<BigDecimal> values) {
            addCriterion("raw_value in", values, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueNotIn(List<BigDecimal> values) {
            addCriterion("raw_value not in", values, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raw_value between", value1, value2, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawValueNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raw_value not between", value1, value2, "rawValue");
            return (Criteria) this;
        }

        public Criteria andRawUnitIsNull() {
            addCriterion("raw_unit is null");
            return (Criteria) this;
        }

        public Criteria andRawUnitIsNotNull() {
            addCriterion("raw_unit is not null");
            return (Criteria) this;
        }

        public Criteria andRawUnitEqualTo(String value) {
            addCriterion("raw_unit =", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitNotEqualTo(String value) {
            addCriterion("raw_unit <>", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitGreaterThan(String value) {
            addCriterion("raw_unit >", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitGreaterThanOrEqualTo(String value) {
            addCriterion("raw_unit >=", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitLessThan(String value) {
            addCriterion("raw_unit <", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitLessThanOrEqualTo(String value) {
            addCriterion("raw_unit <=", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitLike(String value) {
            addCriterion("raw_unit like", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitNotLike(String value) {
            addCriterion("raw_unit not like", value, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitIn(List<String> values) {
            addCriterion("raw_unit in", values, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitNotIn(List<String> values) {
            addCriterion("raw_unit not in", values, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitBetween(String value1, String value2) {
            addCriterion("raw_unit between", value1, value2, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUnitNotBetween(String value1, String value2) {
            addCriterion("raw_unit not between", value1, value2, "rawUnit");
            return (Criteria) this;
        }

        public Criteria andRawUuidIsNull() {
            addCriterion("raw_UUID is null");
            return (Criteria) this;
        }

        public Criteria andRawUuidIsNotNull() {
            addCriterion("raw_UUID is not null");
            return (Criteria) this;
        }

        public Criteria andRawUuidEqualTo(String value) {
            addCriterion("raw_UUID =", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidNotEqualTo(String value) {
            addCriterion("raw_UUID <>", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidGreaterThan(String value) {
            addCriterion("raw_UUID >", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidGreaterThanOrEqualTo(String value) {
            addCriterion("raw_UUID >=", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidLessThan(String value) {
            addCriterion("raw_UUID <", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidLessThanOrEqualTo(String value) {
            addCriterion("raw_UUID <=", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidLike(String value) {
            addCriterion("raw_UUID like", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidNotLike(String value) {
            addCriterion("raw_UUID not like", value, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidIn(List<String> values) {
            addCriterion("raw_UUID in", values, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidNotIn(List<String> values) {
            addCriterion("raw_UUID not in", values, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidBetween(String value1, String value2) {
            addCriterion("raw_UUID between", value1, value2, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andRawUuidNotBetween(String value1, String value2) {
            addCriterion("raw_UUID not between", value1, value2, "rawUuid");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("platform_id is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("platform_id is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Integer value) {
            addCriterion("platform_id =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Integer value) {
            addCriterion("platform_id <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Integer value) {
            addCriterion("platform_id >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("platform_id >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Integer value) {
            addCriterion("platform_id <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Integer value) {
            addCriterion("platform_id <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Integer> values) {
            addCriterion("platform_id in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Integer> values) {
            addCriterion("platform_id not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Integer value1, Integer value2) {
            addCriterion("platform_id between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Integer value1, Integer value2) {
            addCriterion("platform_id not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("create_user is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("create_user is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("create_user =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("create_user <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("create_user >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("create_user >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("create_user <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("create_user <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("create_user like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("create_user not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("create_user in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("create_user not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("create_user between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("create_user not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNull() {
            addCriterion("update_user is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNotNull() {
            addCriterion("update_user is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserEqualTo(String value) {
            addCriterion("update_user =", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotEqualTo(String value) {
            addCriterion("update_user <>", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThan(String value) {
            addCriterion("update_user >", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThanOrEqualTo(String value) {
            addCriterion("update_user >=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThan(String value) {
            addCriterion("update_user <", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThanOrEqualTo(String value) {
            addCriterion("update_user <=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLike(String value) {
            addCriterion("update_user like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotLike(String value) {
            addCriterion("update_user not like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIn(List<String> values) {
            addCriterion("update_user in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotIn(List<String> values) {
            addCriterion("update_user not in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserBetween(String value1, String value2) {
            addCriterion("update_user between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotBetween(String value1, String value2) {
            addCriterion("update_user not between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andDeletedIsNull() {
            addCriterion("deleted is null");
            return (Criteria) this;
        }

        public Criteria andDeletedIsNotNull() {
            addCriterion("deleted is not null");
            return (Criteria) this;
        }

        public Criteria andDeletedEqualTo(Integer value) {
            addCriterion("deleted =", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotEqualTo(Integer value) {
            addCriterion("deleted <>", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedGreaterThan(Integer value) {
            addCriterion("deleted >", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedGreaterThanOrEqualTo(Integer value) {
            addCriterion("deleted >=", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedLessThan(Integer value) {
            addCriterion("deleted <", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedLessThanOrEqualTo(Integer value) {
            addCriterion("deleted <=", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedIn(List<Integer> values) {
            addCriterion("deleted in", values, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotIn(List<Integer> values) {
            addCriterion("deleted not in", values, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedBetween(Integer value1, Integer value2) {
            addCriterion("deleted between", value1, value2, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotBetween(Integer value1, Integer value2) {
            addCriterion("deleted not between", value1, value2, "deleted");
            return (Criteria) this;
        }

        public Criteria andVersionIsNull() {
            addCriterion("version is null");
            return (Criteria) this;
        }

        public Criteria andVersionIsNotNull() {
            addCriterion("version is not null");
            return (Criteria) this;
        }

        public Criteria andVersionEqualTo(Integer value) {
            addCriterion("version =", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionNotEqualTo(Integer value) {
            addCriterion("version <>", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionGreaterThan(Integer value) {
            addCriterion("version >", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionGreaterThanOrEqualTo(Integer value) {
            addCriterion("version >=", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionLessThan(Integer value) {
            addCriterion("version <", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionLessThanOrEqualTo(Integer value) {
            addCriterion("version <=", value, "version");
            return (Criteria) this;
        }

        public Criteria andVersionIn(List<Integer> values) {
            addCriterion("version in", values, "version");
            return (Criteria) this;
        }

        public Criteria andVersionNotIn(List<Integer> values) {
            addCriterion("version not in", values, "version");
            return (Criteria) this;
        }

        public Criteria andVersionBetween(Integer value1, Integer value2) {
            addCriterion("version between", value1, value2, "version");
            return (Criteria) this;
        }

        public Criteria andVersionNotBetween(Integer value1, Integer value2) {
            addCriterion("version not between", value1, value2, "version");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}