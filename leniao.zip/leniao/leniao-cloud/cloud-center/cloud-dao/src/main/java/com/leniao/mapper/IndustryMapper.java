package com.leniao.mapper;

import com.leniao.model.dto.BaseIndustryDTO;

import java.util.List;

public interface IndustryMapper {

    List<BaseIndustryDTO.IndustryList> selectByBody(BaseIndustryDTO.IndustryReq req);
}