package com.leniao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TbLnUserInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TbLnUserInfoExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUseridIsNull() {
            addCriterion("userId is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userId is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userId =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userId <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userId >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userId >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userId <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userId <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userId in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userId not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userId between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userId not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUsernameIsNull() {
            addCriterion("userName is null");
            return (Criteria) this;
        }

        public Criteria andUsernameIsNotNull() {
            addCriterion("userName is not null");
            return (Criteria) this;
        }

        public Criteria andUsernameEqualTo(String value) {
            addCriterion("userName =", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotEqualTo(String value) {
            addCriterion("userName <>", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameGreaterThan(String value) {
            addCriterion("userName >", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("userName >=", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLessThan(String value) {
            addCriterion("userName <", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLessThanOrEqualTo(String value) {
            addCriterion("userName <=", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLike(String value) {
            addCriterion("userName like", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotLike(String value) {
            addCriterion("userName not like", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameIn(List<String> values) {
            addCriterion("userName in", values, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotIn(List<String> values) {
            addCriterion("userName not in", values, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameBetween(String value1, String value2) {
            addCriterion("userName between", value1, value2, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotBetween(String value1, String value2) {
            addCriterion("userName not between", value1, value2, "username");
            return (Criteria) this;
        }

        public Criteria andUserpwdIsNull() {
            addCriterion("userPwd is null");
            return (Criteria) this;
        }

        public Criteria andUserpwdIsNotNull() {
            addCriterion("userPwd is not null");
            return (Criteria) this;
        }

        public Criteria andUserpwdEqualTo(String value) {
            addCriterion("userPwd =", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdNotEqualTo(String value) {
            addCriterion("userPwd <>", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdGreaterThan(String value) {
            addCriterion("userPwd >", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdGreaterThanOrEqualTo(String value) {
            addCriterion("userPwd >=", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdLessThan(String value) {
            addCriterion("userPwd <", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdLessThanOrEqualTo(String value) {
            addCriterion("userPwd <=", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdLike(String value) {
            addCriterion("userPwd like", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdNotLike(String value) {
            addCriterion("userPwd not like", value, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdIn(List<String> values) {
            addCriterion("userPwd in", values, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdNotIn(List<String> values) {
            addCriterion("userPwd not in", values, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdBetween(String value1, String value2) {
            addCriterion("userPwd between", value1, value2, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUserpwdNotBetween(String value1, String value2) {
            addCriterion("userPwd not between", value1, value2, "userpwd");
            return (Criteria) this;
        }

        public Criteria andUsersexIsNull() {
            addCriterion("userSex is null");
            return (Criteria) this;
        }

        public Criteria andUsersexIsNotNull() {
            addCriterion("userSex is not null");
            return (Criteria) this;
        }

        public Criteria andUsersexEqualTo(String value) {
            addCriterion("userSex =", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexNotEqualTo(String value) {
            addCriterion("userSex <>", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexGreaterThan(String value) {
            addCriterion("userSex >", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexGreaterThanOrEqualTo(String value) {
            addCriterion("userSex >=", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexLessThan(String value) {
            addCriterion("userSex <", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexLessThanOrEqualTo(String value) {
            addCriterion("userSex <=", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexLike(String value) {
            addCriterion("userSex like", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexNotLike(String value) {
            addCriterion("userSex not like", value, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexIn(List<String> values) {
            addCriterion("userSex in", values, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexNotIn(List<String> values) {
            addCriterion("userSex not in", values, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexBetween(String value1, String value2) {
            addCriterion("userSex between", value1, value2, "usersex");
            return (Criteria) this;
        }

        public Criteria andUsersexNotBetween(String value1, String value2) {
            addCriterion("userSex not between", value1, value2, "usersex");
            return (Criteria) this;
        }

        public Criteria andUserprovinceIsNull() {
            addCriterion("userProvince is null");
            return (Criteria) this;
        }

        public Criteria andUserprovinceIsNotNull() {
            addCriterion("userProvince is not null");
            return (Criteria) this;
        }

        public Criteria andUserprovinceEqualTo(String value) {
            addCriterion("userProvince =", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceNotEqualTo(String value) {
            addCriterion("userProvince <>", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceGreaterThan(String value) {
            addCriterion("userProvince >", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceGreaterThanOrEqualTo(String value) {
            addCriterion("userProvince >=", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceLessThan(String value) {
            addCriterion("userProvince <", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceLessThanOrEqualTo(String value) {
            addCriterion("userProvince <=", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceLike(String value) {
            addCriterion("userProvince like", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceNotLike(String value) {
            addCriterion("userProvince not like", value, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceIn(List<String> values) {
            addCriterion("userProvince in", values, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceNotIn(List<String> values) {
            addCriterion("userProvince not in", values, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceBetween(String value1, String value2) {
            addCriterion("userProvince between", value1, value2, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUserprovinceNotBetween(String value1, String value2) {
            addCriterion("userProvince not between", value1, value2, "userprovince");
            return (Criteria) this;
        }

        public Criteria andUsercityIsNull() {
            addCriterion("userCity is null");
            return (Criteria) this;
        }

        public Criteria andUsercityIsNotNull() {
            addCriterion("userCity is not null");
            return (Criteria) this;
        }

        public Criteria andUsercityEqualTo(String value) {
            addCriterion("userCity =", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityNotEqualTo(String value) {
            addCriterion("userCity <>", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityGreaterThan(String value) {
            addCriterion("userCity >", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityGreaterThanOrEqualTo(String value) {
            addCriterion("userCity >=", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityLessThan(String value) {
            addCriterion("userCity <", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityLessThanOrEqualTo(String value) {
            addCriterion("userCity <=", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityLike(String value) {
            addCriterion("userCity like", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityNotLike(String value) {
            addCriterion("userCity not like", value, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityIn(List<String> values) {
            addCriterion("userCity in", values, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityNotIn(List<String> values) {
            addCriterion("userCity not in", values, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityBetween(String value1, String value2) {
            addCriterion("userCity between", value1, value2, "usercity");
            return (Criteria) this;
        }

        public Criteria andUsercityNotBetween(String value1, String value2) {
            addCriterion("userCity not between", value1, value2, "usercity");
            return (Criteria) this;
        }

        public Criteria andUserareaIsNull() {
            addCriterion("userArea is null");
            return (Criteria) this;
        }

        public Criteria andUserareaIsNotNull() {
            addCriterion("userArea is not null");
            return (Criteria) this;
        }

        public Criteria andUserareaEqualTo(String value) {
            addCriterion("userArea =", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaNotEqualTo(String value) {
            addCriterion("userArea <>", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaGreaterThan(String value) {
            addCriterion("userArea >", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaGreaterThanOrEqualTo(String value) {
            addCriterion("userArea >=", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaLessThan(String value) {
            addCriterion("userArea <", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaLessThanOrEqualTo(String value) {
            addCriterion("userArea <=", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaLike(String value) {
            addCriterion("userArea like", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaNotLike(String value) {
            addCriterion("userArea not like", value, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaIn(List<String> values) {
            addCriterion("userArea in", values, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaNotIn(List<String> values) {
            addCriterion("userArea not in", values, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaBetween(String value1, String value2) {
            addCriterion("userArea between", value1, value2, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserareaNotBetween(String value1, String value2) {
            addCriterion("userArea not between", value1, value2, "userarea");
            return (Criteria) this;
        }

        public Criteria andUserphoneIsNull() {
            addCriterion("userPhone is null");
            return (Criteria) this;
        }

        public Criteria andUserphoneIsNotNull() {
            addCriterion("userPhone is not null");
            return (Criteria) this;
        }

        public Criteria andUserphoneEqualTo(String value) {
            addCriterion("userPhone =", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneNotEqualTo(String value) {
            addCriterion("userPhone <>", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneGreaterThan(String value) {
            addCriterion("userPhone >", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneGreaterThanOrEqualTo(String value) {
            addCriterion("userPhone >=", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneLessThan(String value) {
            addCriterion("userPhone <", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneLessThanOrEqualTo(String value) {
            addCriterion("userPhone <=", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneLike(String value) {
            addCriterion("userPhone like", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneNotLike(String value) {
            addCriterion("userPhone not like", value, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneIn(List<String> values) {
            addCriterion("userPhone in", values, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneNotIn(List<String> values) {
            addCriterion("userPhone not in", values, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneBetween(String value1, String value2) {
            addCriterion("userPhone between", value1, value2, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserphoneNotBetween(String value1, String value2) {
            addCriterion("userPhone not between", value1, value2, "userphone");
            return (Criteria) this;
        }

        public Criteria andUserqqIsNull() {
            addCriterion("userQQ is null");
            return (Criteria) this;
        }

        public Criteria andUserqqIsNotNull() {
            addCriterion("userQQ is not null");
            return (Criteria) this;
        }

        public Criteria andUserqqEqualTo(String value) {
            addCriterion("userQQ =", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqNotEqualTo(String value) {
            addCriterion("userQQ <>", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqGreaterThan(String value) {
            addCriterion("userQQ >", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqGreaterThanOrEqualTo(String value) {
            addCriterion("userQQ >=", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqLessThan(String value) {
            addCriterion("userQQ <", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqLessThanOrEqualTo(String value) {
            addCriterion("userQQ <=", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqLike(String value) {
            addCriterion("userQQ like", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqNotLike(String value) {
            addCriterion("userQQ not like", value, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqIn(List<String> values) {
            addCriterion("userQQ in", values, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqNotIn(List<String> values) {
            addCriterion("userQQ not in", values, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqBetween(String value1, String value2) {
            addCriterion("userQQ between", value1, value2, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserqqNotBetween(String value1, String value2) {
            addCriterion("userQQ not between", value1, value2, "userqq");
            return (Criteria) this;
        }

        public Criteria andUserwechatIsNull() {
            addCriterion("userWeChat is null");
            return (Criteria) this;
        }

        public Criteria andUserwechatIsNotNull() {
            addCriterion("userWeChat is not null");
            return (Criteria) this;
        }

        public Criteria andUserwechatEqualTo(String value) {
            addCriterion("userWeChat =", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatNotEqualTo(String value) {
            addCriterion("userWeChat <>", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatGreaterThan(String value) {
            addCriterion("userWeChat >", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatGreaterThanOrEqualTo(String value) {
            addCriterion("userWeChat >=", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatLessThan(String value) {
            addCriterion("userWeChat <", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatLessThanOrEqualTo(String value) {
            addCriterion("userWeChat <=", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatLike(String value) {
            addCriterion("userWeChat like", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatNotLike(String value) {
            addCriterion("userWeChat not like", value, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatIn(List<String> values) {
            addCriterion("userWeChat in", values, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatNotIn(List<String> values) {
            addCriterion("userWeChat not in", values, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatBetween(String value1, String value2) {
            addCriterion("userWeChat between", value1, value2, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserwechatNotBetween(String value1, String value2) {
            addCriterion("userWeChat not between", value1, value2, "userwechat");
            return (Criteria) this;
        }

        public Criteria andUserrightidIsNull() {
            addCriterion("userRightId is null");
            return (Criteria) this;
        }

        public Criteria andUserrightidIsNotNull() {
            addCriterion("userRightId is not null");
            return (Criteria) this;
        }

        public Criteria andUserrightidEqualTo(Integer value) {
            addCriterion("userRightId =", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidNotEqualTo(Integer value) {
            addCriterion("userRightId <>", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidGreaterThan(Integer value) {
            addCriterion("userRightId >", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidGreaterThanOrEqualTo(Integer value) {
            addCriterion("userRightId >=", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidLessThan(Integer value) {
            addCriterion("userRightId <", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidLessThanOrEqualTo(Integer value) {
            addCriterion("userRightId <=", value, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidIn(List<Integer> values) {
            addCriterion("userRightId in", values, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidNotIn(List<Integer> values) {
            addCriterion("userRightId not in", values, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidBetween(Integer value1, Integer value2) {
            addCriterion("userRightId between", value1, value2, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUserrightidNotBetween(Integer value1, Integer value2) {
            addCriterion("userRightId not between", value1, value2, "userrightid");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeIsNull() {
            addCriterion("userCreateTime is null");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeIsNotNull() {
            addCriterion("userCreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeEqualTo(Date value) {
            addCriterion("userCreateTime =", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeNotEqualTo(Date value) {
            addCriterion("userCreateTime <>", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeGreaterThan(Date value) {
            addCriterion("userCreateTime >", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("userCreateTime >=", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeLessThan(Date value) {
            addCriterion("userCreateTime <", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("userCreateTime <=", value, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeIn(List<Date> values) {
            addCriterion("userCreateTime in", values, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeNotIn(List<Date> values) {
            addCriterion("userCreateTime not in", values, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeBetween(Date value1, Date value2) {
            addCriterion("userCreateTime between", value1, value2, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUsercreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("userCreateTime not between", value1, value2, "usercreatetime");
            return (Criteria) this;
        }

        public Criteria andUserisleaveIsNull() {
            addCriterion("userIsLeave is null");
            return (Criteria) this;
        }

        public Criteria andUserisleaveIsNotNull() {
            addCriterion("userIsLeave is not null");
            return (Criteria) this;
        }

        public Criteria andUserisleaveEqualTo(Integer value) {
            addCriterion("userIsLeave =", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveNotEqualTo(Integer value) {
            addCriterion("userIsLeave <>", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveGreaterThan(Integer value) {
            addCriterion("userIsLeave >", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveGreaterThanOrEqualTo(Integer value) {
            addCriterion("userIsLeave >=", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveLessThan(Integer value) {
            addCriterion("userIsLeave <", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveLessThanOrEqualTo(Integer value) {
            addCriterion("userIsLeave <=", value, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveIn(List<Integer> values) {
            addCriterion("userIsLeave in", values, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveNotIn(List<Integer> values) {
            addCriterion("userIsLeave not in", values, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveBetween(Integer value1, Integer value2) {
            addCriterion("userIsLeave between", value1, value2, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserisleaveNotBetween(Integer value1, Integer value2) {
            addCriterion("userIsLeave not between", value1, value2, "userisleave");
            return (Criteria) this;
        }

        public Criteria andUserremarkIsNull() {
            addCriterion("userRemark is null");
            return (Criteria) this;
        }

        public Criteria andUserremarkIsNotNull() {
            addCriterion("userRemark is not null");
            return (Criteria) this;
        }

        public Criteria andUserremarkEqualTo(String value) {
            addCriterion("userRemark =", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkNotEqualTo(String value) {
            addCriterion("userRemark <>", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkGreaterThan(String value) {
            addCriterion("userRemark >", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkGreaterThanOrEqualTo(String value) {
            addCriterion("userRemark >=", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkLessThan(String value) {
            addCriterion("userRemark <", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkLessThanOrEqualTo(String value) {
            addCriterion("userRemark <=", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkLike(String value) {
            addCriterion("userRemark like", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkNotLike(String value) {
            addCriterion("userRemark not like", value, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkIn(List<String> values) {
            addCriterion("userRemark in", values, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkNotIn(List<String> values) {
            addCriterion("userRemark not in", values, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkBetween(String value1, String value2) {
            addCriterion("userRemark between", value1, value2, "userremark");
            return (Criteria) this;
        }

        public Criteria andUserremarkNotBetween(String value1, String value2) {
            addCriterion("userRemark not between", value1, value2, "userremark");
            return (Criteria) this;
        }

        public Criteria andCodeIsNull() {
            addCriterion("code is null");
            return (Criteria) this;
        }

        public Criteria andCodeIsNotNull() {
            addCriterion("code is not null");
            return (Criteria) this;
        }

        public Criteria andCodeEqualTo(String value) {
            addCriterion("code =", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotEqualTo(String value) {
            addCriterion("code <>", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThan(String value) {
            addCriterion("code >", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThanOrEqualTo(String value) {
            addCriterion("code >=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThan(String value) {
            addCriterion("code <", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThanOrEqualTo(String value) {
            addCriterion("code <=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLike(String value) {
            addCriterion("code like", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotLike(String value) {
            addCriterion("code not like", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeIn(List<String> values) {
            addCriterion("code in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotIn(List<String> values) {
            addCriterion("code not in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeBetween(String value1, String value2) {
            addCriterion("code between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotBetween(String value1, String value2) {
            addCriterion("code not between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andDeviceidIsNull() {
            addCriterion("deviceId is null");
            return (Criteria) this;
        }

        public Criteria andDeviceidIsNotNull() {
            addCriterion("deviceId is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceidEqualTo(String value) {
            addCriterion("deviceId =", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidNotEqualTo(String value) {
            addCriterion("deviceId <>", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidGreaterThan(String value) {
            addCriterion("deviceId >", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidGreaterThanOrEqualTo(String value) {
            addCriterion("deviceId >=", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidLessThan(String value) {
            addCriterion("deviceId <", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidLessThanOrEqualTo(String value) {
            addCriterion("deviceId <=", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidLike(String value) {
            addCriterion("deviceId like", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidNotLike(String value) {
            addCriterion("deviceId not like", value, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidIn(List<String> values) {
            addCriterion("deviceId in", values, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidNotIn(List<String> values) {
            addCriterion("deviceId not in", values, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidBetween(String value1, String value2) {
            addCriterion("deviceId between", value1, value2, "deviceid");
            return (Criteria) this;
        }

        public Criteria andDeviceidNotBetween(String value1, String value2) {
            addCriterion("deviceId not between", value1, value2, "deviceid");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isDelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isDelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Integer value) {
            addCriterion("isDelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Integer value) {
            addCriterion("isDelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Integer value) {
            addCriterion("isDelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("isDelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Integer value) {
            addCriterion("isDelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Integer value) {
            addCriterion("isDelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Integer> values) {
            addCriterion("isDelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Integer> values) {
            addCriterion("isDelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Integer value1, Integer value2) {
            addCriterion("isDelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("isDelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIssendIsNull() {
            addCriterion("isSend is null");
            return (Criteria) this;
        }

        public Criteria andIssendIsNotNull() {
            addCriterion("isSend is not null");
            return (Criteria) this;
        }

        public Criteria andIssendEqualTo(Integer value) {
            addCriterion("isSend =", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotEqualTo(Integer value) {
            addCriterion("isSend <>", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendGreaterThan(Integer value) {
            addCriterion("isSend >", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendGreaterThanOrEqualTo(Integer value) {
            addCriterion("isSend >=", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendLessThan(Integer value) {
            addCriterion("isSend <", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendLessThanOrEqualTo(Integer value) {
            addCriterion("isSend <=", value, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendIn(List<Integer> values) {
            addCriterion("isSend in", values, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotIn(List<Integer> values) {
            addCriterion("isSend not in", values, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendBetween(Integer value1, Integer value2) {
            addCriterion("isSend between", value1, value2, "issend");
            return (Criteria) this;
        }

        public Criteria andIssendNotBetween(Integer value1, Integer value2) {
            addCriterion("isSend not between", value1, value2, "issend");
            return (Criteria) this;
        }

        public Criteria andUsereamilIsNull() {
            addCriterion("userEamil is null");
            return (Criteria) this;
        }

        public Criteria andUsereamilIsNotNull() {
            addCriterion("userEamil is not null");
            return (Criteria) this;
        }

        public Criteria andUsereamilEqualTo(String value) {
            addCriterion("userEamil =", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilNotEqualTo(String value) {
            addCriterion("userEamil <>", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilGreaterThan(String value) {
            addCriterion("userEamil >", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilGreaterThanOrEqualTo(String value) {
            addCriterion("userEamil >=", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilLessThan(String value) {
            addCriterion("userEamil <", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilLessThanOrEqualTo(String value) {
            addCriterion("userEamil <=", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilLike(String value) {
            addCriterion("userEamil like", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilNotLike(String value) {
            addCriterion("userEamil not like", value, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilIn(List<String> values) {
            addCriterion("userEamil in", values, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilNotIn(List<String> values) {
            addCriterion("userEamil not in", values, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilBetween(String value1, String value2) {
            addCriterion("userEamil between", value1, value2, "usereamil");
            return (Criteria) this;
        }

        public Criteria andUsereamilNotBetween(String value1, String value2) {
            addCriterion("userEamil not between", value1, value2, "usereamil");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNull() {
            addCriterion("platformId is null");
            return (Criteria) this;
        }

        public Criteria andPlatformidIsNotNull() {
            addCriterion("platformId is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformidEqualTo(Integer value) {
            addCriterion("platformId =", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotEqualTo(Integer value) {
            addCriterion("platformId <>", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThan(Integer value) {
            addCriterion("platformId >", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidGreaterThanOrEqualTo(Integer value) {
            addCriterion("platformId >=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThan(Integer value) {
            addCriterion("platformId <", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidLessThanOrEqualTo(Integer value) {
            addCriterion("platformId <=", value, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidIn(List<Integer> values) {
            addCriterion("platformId in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotIn(List<Integer> values) {
            addCriterion("platformId not in", values, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidBetween(Integer value1, Integer value2) {
            addCriterion("platformId between", value1, value2, "platformid");
            return (Criteria) this;
        }

        public Criteria andPlatformidNotBetween(Integer value1, Integer value2) {
            addCriterion("platformId not between", value1, value2, "platformid");
            return (Criteria) this;
        }

        public Criteria andQrcodenameIsNull() {
            addCriterion("qrCodename is null");
            return (Criteria) this;
        }

        public Criteria andQrcodenameIsNotNull() {
            addCriterion("qrCodename is not null");
            return (Criteria) this;
        }

        public Criteria andQrcodenameEqualTo(String value) {
            addCriterion("qrCodename =", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameNotEqualTo(String value) {
            addCriterion("qrCodename <>", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameGreaterThan(String value) {
            addCriterion("qrCodename >", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameGreaterThanOrEqualTo(String value) {
            addCriterion("qrCodename >=", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameLessThan(String value) {
            addCriterion("qrCodename <", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameLessThanOrEqualTo(String value) {
            addCriterion("qrCodename <=", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameLike(String value) {
            addCriterion("qrCodename like", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameNotLike(String value) {
            addCriterion("qrCodename not like", value, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameIn(List<String> values) {
            addCriterion("qrCodename in", values, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameNotIn(List<String> values) {
            addCriterion("qrCodename not in", values, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameBetween(String value1, String value2) {
            addCriterion("qrCodename between", value1, value2, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andQrcodenameNotBetween(String value1, String value2) {
            addCriterion("qrCodename not between", value1, value2, "qrcodename");
            return (Criteria) this;
        }

        public Criteria andReportnatureIsNull() {
            addCriterion("reportNature is null");
            return (Criteria) this;
        }

        public Criteria andReportnatureIsNotNull() {
            addCriterion("reportNature is not null");
            return (Criteria) this;
        }

        public Criteria andReportnatureEqualTo(String value) {
            addCriterion("reportNature =", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureNotEqualTo(String value) {
            addCriterion("reportNature <>", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureGreaterThan(String value) {
            addCriterion("reportNature >", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureGreaterThanOrEqualTo(String value) {
            addCriterion("reportNature >=", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureLessThan(String value) {
            addCriterion("reportNature <", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureLessThanOrEqualTo(String value) {
            addCriterion("reportNature <=", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureLike(String value) {
            addCriterion("reportNature like", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureNotLike(String value) {
            addCriterion("reportNature not like", value, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureIn(List<String> values) {
            addCriterion("reportNature in", values, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureNotIn(List<String> values) {
            addCriterion("reportNature not in", values, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureBetween(String value1, String value2) {
            addCriterion("reportNature between", value1, value2, "reportnature");
            return (Criteria) this;
        }

        public Criteria andReportnatureNotBetween(String value1, String value2) {
            addCriterion("reportNature not between", value1, value2, "reportnature");
            return (Criteria) this;
        }

        public Criteria andDevicetypeIsNull() {
            addCriterion("deviceType is null");
            return (Criteria) this;
        }

        public Criteria andDevicetypeIsNotNull() {
            addCriterion("deviceType is not null");
            return (Criteria) this;
        }

        public Criteria andDevicetypeEqualTo(String value) {
            addCriterion("deviceType =", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeNotEqualTo(String value) {
            addCriterion("deviceType <>", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeGreaterThan(String value) {
            addCriterion("deviceType >", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeGreaterThanOrEqualTo(String value) {
            addCriterion("deviceType >=", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeLessThan(String value) {
            addCriterion("deviceType <", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeLessThanOrEqualTo(String value) {
            addCriterion("deviceType <=", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeLike(String value) {
            addCriterion("deviceType like", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeNotLike(String value) {
            addCriterion("deviceType not like", value, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeIn(List<String> values) {
            addCriterion("deviceType in", values, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeNotIn(List<String> values) {
            addCriterion("deviceType not in", values, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeBetween(String value1, String value2) {
            addCriterion("deviceType between", value1, value2, "devicetype");
            return (Criteria) this;
        }

        public Criteria andDevicetypeNotBetween(String value1, String value2) {
            addCriterion("deviceType not between", value1, value2, "devicetype");
            return (Criteria) this;
        }

        public Criteria andUserlogoIsNull() {
            addCriterion("userLogo is null");
            return (Criteria) this;
        }

        public Criteria andUserlogoIsNotNull() {
            addCriterion("userLogo is not null");
            return (Criteria) this;
        }

        public Criteria andUserlogoEqualTo(String value) {
            addCriterion("userLogo =", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoNotEqualTo(String value) {
            addCriterion("userLogo <>", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoGreaterThan(String value) {
            addCriterion("userLogo >", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoGreaterThanOrEqualTo(String value) {
            addCriterion("userLogo >=", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoLessThan(String value) {
            addCriterion("userLogo <", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoLessThanOrEqualTo(String value) {
            addCriterion("userLogo <=", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoLike(String value) {
            addCriterion("userLogo like", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoNotLike(String value) {
            addCriterion("userLogo not like", value, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoIn(List<String> values) {
            addCriterion("userLogo in", values, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoNotIn(List<String> values) {
            addCriterion("userLogo not in", values, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoBetween(String value1, String value2) {
            addCriterion("userLogo between", value1, value2, "userlogo");
            return (Criteria) this;
        }

        public Criteria andUserlogoNotBetween(String value1, String value2) {
            addCriterion("userLogo not between", value1, value2, "userlogo");
            return (Criteria) this;
        }

        public Criteria andWxopenidIsNull() {
            addCriterion("wxOpenId is null");
            return (Criteria) this;
        }

        public Criteria andWxopenidIsNotNull() {
            addCriterion("wxOpenId is not null");
            return (Criteria) this;
        }

        public Criteria andWxopenidEqualTo(String value) {
            addCriterion("wxOpenId =", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidNotEqualTo(String value) {
            addCriterion("wxOpenId <>", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidGreaterThan(String value) {
            addCriterion("wxOpenId >", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidGreaterThanOrEqualTo(String value) {
            addCriterion("wxOpenId >=", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidLessThan(String value) {
            addCriterion("wxOpenId <", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidLessThanOrEqualTo(String value) {
            addCriterion("wxOpenId <=", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidLike(String value) {
            addCriterion("wxOpenId like", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidNotLike(String value) {
            addCriterion("wxOpenId not like", value, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidIn(List<String> values) {
            addCriterion("wxOpenId in", values, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidNotIn(List<String> values) {
            addCriterion("wxOpenId not in", values, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidBetween(String value1, String value2) {
            addCriterion("wxOpenId between", value1, value2, "wxopenid");
            return (Criteria) this;
        }

        public Criteria andWxopenidNotBetween(String value1, String value2) {
            addCriterion("wxOpenId not between", value1, value2, "wxopenid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}