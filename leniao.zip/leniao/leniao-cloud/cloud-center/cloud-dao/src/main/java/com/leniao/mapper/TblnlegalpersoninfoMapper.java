package com.leniao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leniao.entity.Tblnlegalpersoninfo;
import com.leniao.entity.TblnlegalpersoninfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TblnlegalpersoninfoMapper extends BaseMapper<Tblnlegalpersoninfo> {
    int countByExample(TblnlegalpersoninfoExample example);

    int deleteByExample(TblnlegalpersoninfoExample example);

    int deleteByPrimaryKey(Integer legalpersonid);

    int insert(Tblnlegalpersoninfo record);

    int insertSelective(Tblnlegalpersoninfo record);

    List<Tblnlegalpersoninfo> selectByExample(TblnlegalpersoninfoExample example);

    Tblnlegalpersoninfo selectByPrimaryKey(Integer legalpersonid);

    int updateByExampleSelective(@Param("record") Tblnlegalpersoninfo record, @Param("example") TblnlegalpersoninfoExample example);

    int updateByExample(@Param("record") Tblnlegalpersoninfo record, @Param("example") TblnlegalpersoninfoExample example);

    int updateByPrimaryKeySelective(Tblnlegalpersoninfo record);

    int updateByPrimaryKey(Tblnlegalpersoninfo record);
}