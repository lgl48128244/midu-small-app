package com.leniao.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.ToString;

@ToString
@TableName("hby_overlook_dev_join")
public class HbyOverLookDevJoin {
    @TableId
    private Long id;

    private Long lookId;

    private Integer devIdpk;

    private Integer devProTy;

    private Integer devWorkState;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLookId() {
        return lookId;
    }

    public void setLookId(Long lookId) {
        this.lookId = lookId;
    }

    public Integer getDevIdpk() {
        return devIdpk;
    }

    public void setDevIdpk(Integer devIdpk) {
        this.devIdpk = devIdpk;
    }

    public Integer getDevProTy() {
        return devProTy;
    }

    public void setDevProTy(Integer devProTy) {
        this.devProTy = devProTy;
    }

    public Integer getDevWorkState() {
        return devWorkState;
    }

    public void setDevWorkState(Integer devWorkState) {
        this.devWorkState = devWorkState;
    }
}